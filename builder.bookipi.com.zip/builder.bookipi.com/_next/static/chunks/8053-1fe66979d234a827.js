"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8053], {
        8053: function(e, t, n) {
            n.d(t, {
                S1: function() {
                    return tg
                },
                j: function() {
                    return ty
                }
            });
            var i, r, o, s, u, a, c, l, d, f, p, v = function(e, t) {
                return (v = Object.setPrototypeOf || ({
                    __proto__: []
                }) instanceof Array && function(e, t) {
                    e.__proto__ = t
                } || function(e, t) {
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                })(e, t)
            };

            function h(e, t) {
                if ("function" != typeof t && null !== t) throw TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function n() {
                    this.constructor = e
                }
                v(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            }
            var g = function() {
                return (g = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                    return e
                }).apply(this, arguments)
            };

            function y(e, t) {
                var n = {};
                for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && 0 > t.indexOf(i) && (n[i] = e[i]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var r = 0, i = Object.getOwnPropertySymbols(e); r < i.length; r++) 0 > t.indexOf(i[r]) && Object.prototype.propertyIsEnumerable.call(e, i[r]) && (n[i[r]] = e[i[r]]);
                return n
            }

            function m(e, t, n, i) {
                return new(n || (n = Promise))(function(r, o) {
                    function s(e) {
                        try {
                            a(i.next(e))
                        } catch (e) {
                            o(e)
                        }
                    }

                    function u(e) {
                        try {
                            a(i.throw(e))
                        } catch (e) {
                            o(e)
                        }
                    }

                    function a(e) {
                        var t;
                        e.done ? r(e.value) : ((t = e.value) instanceof n ? t : new n(function(e) {
                            e(t)
                        })).then(s, u)
                    }
                    a((i = i.apply(e, t || [])).next())
                })
            }

            function b(e, t) {
                var n, i, r, o, s = {
                    label: 0,
                    sent: function() {
                        if (1 & r[0]) throw r[1];
                        return r[1]
                    },
                    trys: [],
                    ops: []
                };
                return o = {
                    next: u(0),
                    throw: u(1),
                    return: u(2)
                }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                    return this
                }), o;

                function u(u) {
                    return function(a) {
                        return function(u) {
                            if (n) throw TypeError("Generator is already executing.");
                            for (; o && (o = 0, u[0] && (s = 0)), s;) try {
                                if (n = 1, i && (r = 2 & u[0] ? i.return : u[0] ? i.throw || ((r = i.return) && r.call(i), 0) : i.next) && !(r = r.call(i, u[1])).done) return r;
                                switch (i = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                                    case 0:
                                    case 1:
                                        r = u;
                                        break;
                                    case 4:
                                        return s.label++, {
                                            value: u[1],
                                            done: !1
                                        };
                                    case 5:
                                        s.label++, i = u[1], u = [0];
                                        continue;
                                    case 7:
                                        u = s.ops.pop(), s.trys.pop();
                                        continue;
                                    default:
                                        if (!(r = (r = s.trys).length > 0 && r[r.length - 1]) && (6 === u[0] || 2 === u[0])) {
                                            s = 0;
                                            continue
                                        }
                                        if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                            s.label = u[1];
                                            break
                                        }
                                        if (6 === u[0] && s.label < r[1]) {
                                            s.label = r[1], r = u;
                                            break
                                        }
                                        if (r && s.label < r[2]) {
                                            s.label = r[2], s.ops.push(u);
                                            break
                                        }
                                        r[2] && s.ops.pop(), s.trys.pop();
                                        continue
                                }
                                u = t.call(e, s)
                            } catch (e) {
                                u = [6, e], i = 0
                            } finally {
                                n = r = 0
                            }
                            if (5 & u[0]) throw u[1];
                            return {
                                value: u[0] ? u[1] : void 0,
                                done: !0
                            }
                        }([u, a])
                    }
                }
            }

            function _(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    n = t && e[t],
                    i = 0;
                if (n) return n.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && i >= e.length && (e = void 0), {
                            value: e && e[i++],
                            done: !e
                        }
                    }
                };
                throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function I(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var i, r, o = n.call(e),
                    s = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(i = o.next()).done;) s.push(i.value)
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        i && !i.done && (n = o.return) && n.call(o)
                    } finally {
                        if (r) throw r.error
                    }
                }
                return s
            }

            function w(e, t, n) {
                if (n || 2 == arguments.length)
                    for (var i, r = 0, o = t.length; r < o; r++) !i && r in t || (i || (i = Array.prototype.slice.call(t, 0, r)), i[r] = t[r]);
                return e.concat(i || Array.prototype.slice.call(t))
            }
            "function" == typeof SuppressedError && SuppressedError, (i = c || (c = {}))[i.None = 0] = "None", i[i.Error = 1] = "Error", i[i.Warn = 2] = "Warn", i[i.Verbose = 3] = "Verbose", i[i.Debug = 4] = "Debug";
            var S = function(e) {
                    return function() {
                        var t = g({}, e.config);
                        return {
                            logger: t.loggerProvider,
                            logLevel: t.logLevel
                        }
                    }
                },
                E = function(e, t) {
                    var n, i;
                    t = (t = t.replace(/\[(\w+)\]/g, ".$1")).replace(/^\./, "");
                    try {
                        for (var r = _(t.split(".")), o = r.next(); !o.done; o = r.next()) {
                            var s = o.value;
                            if (!(s in e)) return;
                            e = e[s]
                        }
                    } catch (e) {
                        n = {
                            error: e
                        }
                    } finally {
                        try {
                            o && !o.done && (i = r.return) && i.call(r)
                        } finally {
                            if (n) throw n.error
                        }
                    }
                    return e
                },
                T = function(e, t) {
                    return function() {
                        var n, i, r = {};
                        try {
                            for (var o = _(t), s = o.next(); !s.done; s = o.next()) {
                                var u = s.value;
                                r[u] = E(e, u)
                            }
                        } catch (e) {
                            n = {
                                error: e
                            }
                        } finally {
                            try {
                                s && !s.done && (i = o.return) && i.call(o)
                            } finally {
                                if (n) throw n.error
                            }
                        }
                        return r
                    }
                },
                k = function(e, t, n, i, r) {
                    return void 0 === r && (r = null),
                        function() {
                            for (var o = [], s = 0; s < arguments.length; s++) o[s] = arguments[s];
                            var u = n(),
                                a = u.logger,
                                l = u.logLevel;
                            if (l && l < c.Debug || !l || !a) return e.apply(r, o);
                            var d = {
                                type: "invoke public method",
                                name: t,
                                args: o,
                                stacktrace: (Error().stack || "").split("\n").slice(3).map(function(e) {
                                    return e.trim()
                                }),
                                time: {
                                    start: new Date().toISOString()
                                },
                                states: {}
                            };
                            i && d.states && (d.states.before = i());
                            var f = e.apply(r, o);
                            return f && f.promise ? f.promise.then(function() {
                                i && d.states && (d.states.after = i()), d.time && (d.time.end = new Date().toISOString()), a.debug(JSON.stringify(d, null, 2))
                            }) : (i && d.states && (d.states.after = i()), d.time && (d.time.end = new Date().toISOString()), a.debug(JSON.stringify(d, null, 2))), f
                        }
                },
                O = function(e) {
                    return {
                        promise: e || Promise.resolve()
                    }
                };
            (r = l || (l = {})).Unknown = "unknown", r.Skipped = "skipped", r.Success = "success", r.RateLimit = "rate_limit", r.PayloadTooLarge = "payload_too_large", r.Invalid = "invalid", r.Failed = "failed", r.Timeout = "Timeout", r.SystemError = "SystemError";
            var P = "".concat("AMP", "_unsent"),
                R = "https://api2.amplitude.com/2/httpapi",
                x = function(e, t) {
                    var n = Math.max(t, 1);
                    return e.reduce(function(e, t, i) {
                        var r = Math.floor(i / n);
                        return e[r] || (e[r] = []), e[r].push(t), e
                    }, [])
                },
                U = function(e, t, n) {
                    return void 0 === t && (t = 0), void 0 === n && (n = l.Unknown), {
                        event: e,
                        code: t,
                        message: n
                    }
                },
                N = "Amplitude Logger ",
                D = function() {
                    function e() {
                        this.logLevel = c.None
                    }
                    return e.prototype.disable = function() {
                        this.logLevel = c.None
                    }, e.prototype.enable = function(e) {
                        void 0 === e && (e = c.Warn), this.logLevel = e
                    }, e.prototype.log = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        this.logLevel < c.Verbose || console.log("".concat(N, "[Log]: ").concat(e.join(" ")))
                    }, e.prototype.warn = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        this.logLevel < c.Warn || console.warn("".concat(N, "[Warn]: ").concat(e.join(" ")))
                    }, e.prototype.error = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        this.logLevel < c.Error || console.error("".concat(N, "[Error]: ").concat(e.join(" ")))
                    }, e.prototype.debug = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        this.logLevel < c.Debug || console.log("".concat(N, "[Debug]: ").concat(e.join(" ")))
                    }, e
                }(),
                q = function() {
                    return {
                        flushMaxRetries: 12,
                        flushQueueSize: 200,
                        flushIntervalMillis: 1e4,
                        instanceName: "$default_instance",
                        logLevel: c.Warn,
                        loggerProvider: new D,
                        offline: !1,
                        optOut: !1,
                        serverUrl: R,
                        serverZone: "US",
                        useBatch: !1
                    }
                },
                A = function() {
                    function e(e) {
                        this._optOut = !1;
                        var t, n, i, r, o = q();
                        this.apiKey = e.apiKey, this.flushIntervalMillis = null !== (t = e.flushIntervalMillis) && void 0 !== t ? t : o.flushIntervalMillis, this.flushMaxRetries = e.flushMaxRetries || o.flushMaxRetries, this.flushQueueSize = e.flushQueueSize || o.flushQueueSize, this.instanceName = e.instanceName || o.instanceName, this.loggerProvider = e.loggerProvider || o.loggerProvider, this.logLevel = null !== (n = e.logLevel) && void 0 !== n ? n : o.logLevel, this.minIdLength = e.minIdLength, this.plan = e.plan, this.ingestionMetadata = e.ingestionMetadata, this.offline = void 0 !== e.offline ? e.offline : o.offline, this.optOut = null !== (i = e.optOut) && void 0 !== i ? i : o.optOut, this.serverUrl = e.serverUrl, this.serverZone = e.serverZone || o.serverZone, this.storageProvider = e.storageProvider, this.transportProvider = e.transportProvider, this.useBatch = null !== (r = e.useBatch) && void 0 !== r ? r : o.useBatch, this.loggerProvider.enable(this.logLevel);
                        var s = L(e.serverUrl, e.serverZone, e.useBatch);
                        this.serverZone = s.serverZone, this.serverUrl = s.serverUrl
                    }
                    return Object.defineProperty(e.prototype, "optOut", {
                        get: function() {
                            return this._optOut
                        },
                        set: function(e) {
                            this._optOut = e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e
                }(),
                L = function(e, t, n) {
                    if (void 0 === e && (e = ""), void 0 === t && (t = q().serverZone), void 0 === n && (n = q().useBatch), e) return {
                        serverUrl: e,
                        serverZone: void 0
                    };
                    var i, r = ["US", "EU"].includes(t) ? t : q().serverZone;
                    return {
                        serverZone: r,
                        serverUrl: (i = n, "EU" === r ? i ? "https://api.eu.amplitude.com/batch" : "https://api.eu.amplitude.com/2/httpapi" : i ? "https://api2.amplitude.com/batch" : R)
                    }
                };

            function C(e) {
                var t = "";
                try {
                    "body" in e && (t = JSON.stringify(e.body, null, 2))
                } catch (e) {}
                return t
            }
            var j = function() {
                    function e() {
                        this.name = "amplitude", this.type = "destination", this.retryTimeout = 1e3, this.throttleTimeout = 3e4, this.storageKey = "", this.scheduled = null, this.queue = []
                    }
                    return e.prototype.setup = function(e) {
                        var t;
                        return m(this, void 0, void 0, function() {
                            var n, i = this;
                            return b(this, function(r) {
                                switch (r.label) {
                                    case 0:
                                        return this.config = e, this.storageKey = "".concat(P, "_").concat(this.config.apiKey.substring(0, 10)), [4, null === (t = this.config.storageProvider) || void 0 === t ? void 0 : t.get(this.storageKey)];
                                    case 1:
                                        return n = r.sent(), this.saveEvents(), n && n.length > 0 && Promise.all(n.map(function(e) {
                                            return i.execute(e)
                                        })).catch(), [2, Promise.resolve(void 0)]
                                }
                            })
                        })
                    }, e.prototype.execute = function(e) {
                        var t = this;
                        return new Promise(function(n) {
                            t.addToQueue({
                                event: e,
                                attempts: 0,
                                callback: function(e) {
                                    return n(e)
                                },
                                timeout: 0
                            })
                        })
                    }, e.prototype.addToQueue = function() {
                        for (var e = this, t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                        t.filter(function(t) {
                            return t.attempts < e.config.flushMaxRetries ? (t.attempts += 1, !0) : (e.fulfillRequest([t], 500, "Event rejected due to exceeded retry count"), !1)
                        }).forEach(function(t) {
                            if (e.queue = e.queue.concat(t), 0 === t.timeout) {
                                e.schedule(e.config.flushIntervalMillis);
                                return
                            }
                            setTimeout(function() {
                                t.timeout = 0, e.schedule(0)
                            }, t.timeout)
                        }), this.saveEvents()
                    }, e.prototype.schedule = function(e) {
                        var t = this;
                        this.scheduled || this.config.offline || (this.scheduled = setTimeout(function() {
                            t.flush(!0).then(function() {
                                t.queue.length > 0 && t.schedule(e)
                            })
                        }, e))
                    }, e.prototype.flush = function(e) {
                        return void 0 === e && (e = !1), m(this, void 0, void 0, function() {
                            var t, n, i = this;
                            return b(this, function(r) {
                                switch (r.label) {
                                    case 0:
                                        if (this.config.offline) return this.config.loggerProvider.debug("Skipping flush while offline."), [2];
                                        return t = [], n = [], this.queue.forEach(function(e) {
                                            return 0 === e.timeout ? t.push(e) : n.push(e)
                                        }), this.queue = n, this.scheduled && (clearTimeout(this.scheduled), this.scheduled = null), [4, Promise.all(x(t, this.config.flushQueueSize).map(function(t) {
                                            return i.send(t, e)
                                        }))];
                                    case 1:
                                        return r.sent(), [2]
                                }
                            })
                        })
                    }, e.prototype.send = function(e, t) {
                        return void 0 === t && (t = !0), m(this, void 0, void 0, function() {
                            var n, i, r, o;
                            return b(this, function(s) {
                                switch (s.label) {
                                    case 0:
                                        if (!this.config.apiKey) return [2, this.fulfillRequest(e, 400, "Event rejected due to missing API key")];
                                        n = {
                                            api_key: this.config.apiKey,
                                            events: e.map(function(e) {
                                                var t = e.event;
                                                return t.extra, y(t, ["extra"])
                                            }),
                                            options: {
                                                min_id_length: this.config.minIdLength
                                            },
                                            client_upload_time: new Date().toISOString()
                                        }, s.label = 1;
                                    case 1:
                                        return s.trys.push([1, 3, , 4]), i = L(this.config.serverUrl, this.config.serverZone, this.config.useBatch).serverUrl, [4, this.config.transportProvider.send(i, n)];
                                    case 2:
                                        if (null === (r = s.sent())) return this.fulfillRequest(e, 0, "Unexpected error occurred"), [2];
                                        if (!t) return "body" in r ? this.fulfillRequest(e, r.statusCode, "".concat(r.status, ": ").concat(C(r))) : this.fulfillRequest(e, r.statusCode, r.status), [2];
                                        return this.handleResponse(r, e), [3, 4];
                                    case 3:
                                        var u;
                                        return o = (u = s.sent()) instanceof Error ? u.message : String(u), this.config.loggerProvider.error(o), this.fulfillRequest(e, 0, o), [3, 4];
                                    case 4:
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.handleResponse = function(e, t) {
                        var n = e.status;
                        switch (n) {
                            case l.Success:
                                this.handleSuccessResponse(e, t);
                                break;
                            case l.Invalid:
                                this.handleInvalidResponse(e, t);
                                break;
                            case l.PayloadTooLarge:
                                this.handlePayloadTooLargeResponse(e, t);
                                break;
                            case l.RateLimit:
                                this.handleRateLimitResponse(e, t);
                                break;
                            default:
                                this.config.loggerProvider.warn("{code: 0, error: \"Status '".concat(n, "' provided for ").concat(t.length, ' events"}')), this.handleOtherResponse(t)
                        }
                    }, e.prototype.handleSuccessResponse = function(e, t) {
                        this.fulfillRequest(t, e.statusCode, "Event tracked successfully")
                    }, e.prototype.handleInvalidResponse = function(e, t) {
                        var n = this;
                        if (e.body.missingField || e.body.error.startsWith("Invalid API key")) {
                            this.fulfillRequest(t, e.statusCode, e.body.error);
                            return
                        }
                        var i = w(w(w(w([], I(Object.values(e.body.eventsWithInvalidFields)), !1), I(Object.values(e.body.eventsWithMissingFields)), !1), I(Object.values(e.body.eventsWithInvalidIdLengths)), !1), I(e.body.silencedEvents), !1).flat(),
                            r = new Set(i),
                            o = t.filter(function(t, i) {
                                if (r.has(i)) {
                                    n.fulfillRequest([t], e.statusCode, e.body.error);
                                    return
                                }
                                return !0
                            });
                        o.length > 0 && this.config.loggerProvider.warn(C(e)), this.addToQueue.apply(this, w([], I(o), !1))
                    }, e.prototype.handlePayloadTooLargeResponse = function(e, t) {
                        if (1 === t.length) {
                            this.fulfillRequest(t, e.statusCode, e.body.error);
                            return
                        }
                        this.config.loggerProvider.warn(C(e)), this.config.flushQueueSize /= 2, this.addToQueue.apply(this, w([], I(t), !1))
                    }, e.prototype.handleRateLimitResponse = function(e, t) {
                        var n = this,
                            i = Object.keys(e.body.exceededDailyQuotaUsers),
                            r = Object.keys(e.body.exceededDailyQuotaDevices),
                            o = e.body.throttledEvents,
                            s = new Set(i),
                            u = new Set(r),
                            a = new Set(o),
                            c = t.filter(function(t, i) {
                                if (t.event.user_id && s.has(t.event.user_id) || t.event.device_id && u.has(t.event.device_id)) {
                                    n.fulfillRequest([t], e.statusCode, e.body.error);
                                    return
                                }
                                return a.has(i) && (t.timeout = n.throttleTimeout), !0
                            });
                        c.length > 0 && this.config.loggerProvider.warn(C(e)), this.addToQueue.apply(this, w([], I(c), !1))
                    }, e.prototype.handleOtherResponse = function(e) {
                        var t = this;
                        this.addToQueue.apply(this, w([], I(e.map(function(e) {
                            return e.timeout = e.attempts * t.retryTimeout, e
                        })), !1))
                    }, e.prototype.fulfillRequest = function(e, t, n) {
                        this.saveEvents(), e.forEach(function(e) {
                            return e.callback(U(e.event, t, n))
                        })
                    }, e.prototype.saveEvents = function() {
                        if (this.config.storageProvider) {
                            var e = Array.from(this.queue.map(function(e) {
                                return e.event
                            }));
                            this.config.storageProvider.set(this.storageKey, e)
                        }
                    }, e
                }(),
                M = function(e) {
                    return e ? (e ^ 16 * Math.random() >> e / 4).toString(16) : (String(1e7) + String(-1e3) + String(-4e3) + String(-8e3) + String(-1e11)).replace(/[018]/g, M)
                };
            (o = d || (d = {})).SET = "$set", o.SET_ONCE = "$setOnce", o.ADD = "$add", o.APPEND = "$append", o.PREPEND = "$prepend", o.REMOVE = "$remove", o.PREINSERT = "$preInsert", o.POSTINSERT = "$postInsert", o.UNSET = "$unset", o.CLEAR_ALL = "$clearAll", (s = f || (f = {})).REVENUE_PRODUCT_ID = "$productId", s.REVENUE_QUANTITY = "$quantity", s.REVENUE_PRICE = "$price", s.REVENUE_TYPE = "$revenueType", s.REVENUE = "$revenue", (u = p || (p = {})).IDENTIFY = "$identify", u.GROUP_IDENTIFY = "$groupidentify", u.REVENUE = "revenue_amount";
            var V = function(e) {
                    if (Object.keys(e).length > 1e3) return !1;
                    for (var t in e) {
                        var n = e[t];
                        if (!F(t, n)) return !1
                    }
                    return !0
                },
                F = function(e, t) {
                    var n, i;
                    if ("string" != typeof e) return !1;
                    if (Array.isArray(t)) {
                        var r = !0;
                        try {
                            for (var o = _(t), s = o.next(); !s.done; s = o.next()) {
                                var u = s.value;
                                if (Array.isArray(u)) return !1;
                                if ("object" == typeof u) r = r && V(u);
                                else if (!["number", "string"].includes(typeof u)) return !1;
                                if (!r) return !1
                            }
                        } catch (e) {
                            n = {
                                error: e
                            }
                        } finally {
                            try {
                                s && !s.done && (i = o.return) && i.call(o)
                            } finally {
                                if (n) throw n.error
                            }
                        }
                    } else if (null == t) return !1;
                    else if ("object" == typeof t) return V(t);
                    else if (!["number", "string", "boolean"].includes(typeof t)) return !1;
                    return !0
                },
                Q = function() {
                    function e() {
                        this._propertySet = new Set, this._properties = {}
                    }
                    return e.prototype.getUserProperties = function() {
                        return g({}, this._properties)
                    }, e.prototype.set = function(e, t) {
                        return this._safeSet(d.SET, e, t), this
                    }, e.prototype.setOnce = function(e, t) {
                        return this._safeSet(d.SET_ONCE, e, t), this
                    }, e.prototype.append = function(e, t) {
                        return this._safeSet(d.APPEND, e, t), this
                    }, e.prototype.prepend = function(e, t) {
                        return this._safeSet(d.PREPEND, e, t), this
                    }, e.prototype.postInsert = function(e, t) {
                        return this._safeSet(d.POSTINSERT, e, t), this
                    }, e.prototype.preInsert = function(e, t) {
                        return this._safeSet(d.PREINSERT, e, t), this
                    }, e.prototype.remove = function(e, t) {
                        return this._safeSet(d.REMOVE, e, t), this
                    }, e.prototype.add = function(e, t) {
                        return this._safeSet(d.ADD, e, t), this
                    }, e.prototype.unset = function(e) {
                        return this._safeSet(d.UNSET, e, "-"), this
                    }, e.prototype.clearAll = function() {
                        return this._properties = {}, this._properties[d.CLEAR_ALL] = "-", this
                    }, e.prototype._safeSet = function(e, t, n) {
                        if (this._validate(e, t, n)) {
                            var i = this._properties[e];
                            return void 0 === i && (i = {}, this._properties[e] = i), i[t] = n, this._propertySet.add(t), !0
                        }
                        return !1
                    }, e.prototype._validate = function(e, t, n) {
                        return !(void 0 !== this._properties[d.CLEAR_ALL] || this._propertySet.has(t)) && (e === d.ADD ? "number" == typeof n : e === d.UNSET || e === d.REMOVE || F(t, n))
                    }, e
                }(),
                $ = function() {
                    function e() {
                        this.productId = "", this.quantity = 1, this.price = 0
                    }
                    return e.prototype.setProductId = function(e) {
                        return this.productId = e, this
                    }, e.prototype.setQuantity = function(e) {
                        return e > 0 && (this.quantity = e), this
                    }, e.prototype.setPrice = function(e) {
                        return this.price = e, this
                    }, e.prototype.setRevenueType = function(e) {
                        return this.revenueType = e, this
                    }, e.prototype.setRevenue = function(e) {
                        return this.revenue = e, this
                    }, e.prototype.setEventProperties = function(e) {
                        return V(e) && (this.properties = e), this
                    }, e.prototype.getEventProperties = function() {
                        var e = this.properties ? g({}, this.properties) : {};
                        return e[f.REVENUE_PRODUCT_ID] = this.productId, e[f.REVENUE_QUANTITY] = this.quantity, e[f.REVENUE_PRICE] = this.price, e[f.REVENUE_TYPE] = this.revenueType, e[f.REVENUE] = this.revenue, e
                    }, e
                }(),
                K = function() {
                    function e(e) {
                        this.client = e, this.queue = [], this.applying = !1, this.plugins = []
                    }
                    return e.prototype.register = function(e, t) {
                        var n, i, r;
                        return m(this, void 0, void 0, function() {
                            return b(this, function(o) {
                                switch (o.label) {
                                    case 0:
                                        return e.name = null !== (n = e.name) && void 0 !== n ? n : M(), e.type = null !== (i = e.type) && void 0 !== i ? i : "enrichment", [4, null === (r = e.setup) || void 0 === r ? void 0 : r.call(e, t, this.client)];
                                    case 1:
                                        return o.sent(), this.plugins.push(e), [2]
                                }
                            })
                        })
                    }, e.prototype.deregister = function(e) {
                        var t;
                        return m(this, void 0, void 0, function() {
                            var n, i;
                            return b(this, function(r) {
                                switch (r.label) {
                                    case 0:
                                        return n = this.plugins.findIndex(function(t) {
                                            return t.name === e
                                        }), i = this.plugins[n], this.plugins.splice(n, 1), [4, null === (t = i.teardown) || void 0 === t ? void 0 : t.call(i)];
                                    case 1:
                                        return r.sent(), [2]
                                }
                            })
                        })
                    }, e.prototype.reset = function(e) {
                        this.applying = !1, this.plugins.map(function(e) {
                            var t;
                            return null === (t = e.teardown) || void 0 === t ? void 0 : t.call(e)
                        }), this.plugins = [], this.client = e
                    }, e.prototype.push = function(e) {
                        var t = this;
                        return new Promise(function(n) {
                            t.queue.push([e, n]), t.scheduleApply(0)
                        })
                    }, e.prototype.scheduleApply = function(e) {
                        var t = this;
                        this.applying || (this.applying = !0, setTimeout(function() {
                            t.apply(t.queue.shift()).then(function() {
                                t.applying = !1, t.queue.length > 0 && t.scheduleApply(0)
                            })
                        }, e))
                    }, e.prototype.apply = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t, n, i, r, o, s, u, a, c, l, d, f, p, v;
                            return b(this, function(h) {
                                switch (h.label) {
                                    case 0:
                                        if (!e) return [2];
                                        t = I(e, 1)[0], n = I(e, 2)[1], i = this.plugins.filter(function(e) {
                                            return "before" === e.type
                                        }), h.label = 1;
                                    case 1:
                                        h.trys.push([1, 6, 7, 8]), o = (r = _(i)).next(), h.label = 2;
                                    case 2:
                                        if (o.done) return [3, 5];
                                        if (!(s = o.value).execute) return [3, 4];
                                        return [4, s.execute(g({}, t))];
                                    case 3:
                                        if (null === (u = h.sent())) return n({
                                            event: t,
                                            code: 0,
                                            message: ""
                                        }), [2];
                                        t = u, h.label = 4;
                                    case 4:
                                        return o = r.next(), [3, 2];
                                    case 5:
                                        return [3, 8];
                                    case 6:
                                        return d = {
                                            error: h.sent()
                                        }, [3, 8];
                                    case 7:
                                        try {
                                            o && !o.done && (f = r.return) && f.call(r)
                                        } finally {
                                            if (d) throw d.error
                                        }
                                        return [7];
                                    case 8:
                                        a = this.plugins.filter(function(e) {
                                            return "enrichment" === e.type || void 0 === e.type
                                        }), h.label = 9;
                                    case 9:
                                        h.trys.push([9, 14, 15, 16]), l = (c = _(a)).next(), h.label = 10;
                                    case 10:
                                        if (l.done) return [3, 13];
                                        if (!(s = l.value).execute) return [3, 12];
                                        return [4, s.execute(g({}, t))];
                                    case 11:
                                        if (null === (u = h.sent())) return n({
                                            event: t,
                                            code: 0,
                                            message: ""
                                        }), [2];
                                        t = u, h.label = 12;
                                    case 12:
                                        return l = c.next(), [3, 10];
                                    case 13:
                                        return [3, 16];
                                    case 14:
                                        return p = {
                                            error: h.sent()
                                        }, [3, 16];
                                    case 15:
                                        try {
                                            l && !l.done && (v = c.return) && v.call(c)
                                        } finally {
                                            if (p) throw p.error
                                        }
                                        return [7];
                                    case 16:
                                        return Promise.all(this.plugins.filter(function(e) {
                                            return "destination" === e.type
                                        }).map(function(e) {
                                            var n = g({}, t);
                                            return e.execute(n).catch(function(e) {
                                                return U(n, 0, String(e))
                                            })
                                        })).then(function(e) {
                                            n(I(e, 1)[0] || U(t, 100, "Event not tracked, no destination plugins on the instance"))
                                        }), [2]
                                }
                            })
                        })
                    }, e.prototype.flush = function() {
                        return m(this, void 0, void 0, function() {
                            var e, t = this;
                            return b(this, function(n) {
                                switch (n.label) {
                                    case 0:
                                        return e = this.queue, this.queue = [], [4, Promise.all(e.map(function(e) {
                                            return t.apply(e)
                                        }))];
                                    case 1:
                                        return n.sent(), [4, Promise.all(this.plugins.filter(function(e) {
                                            return "destination" === e.type
                                        }).map(function(e) {
                                            return e.flush && e.flush()
                                        }))];
                                    case 2:
                                        return n.sent(), [2]
                                }
                            })
                        })
                    }, e
                }(),
                B = function(e, t) {
                    return g(g({}, t), {
                        event_type: p.IDENTIFY,
                        user_properties: e.getUserProperties()
                    })
                },
                z = function(e, t, n, i) {
                    var r;
                    return g(g({}, i), {
                        event_type: p.GROUP_IDENTIFY,
                        group_properties: n.getUserProperties(),
                        groups: ((r = {})[e] = t, r)
                    })
                },
                W = function(e, t, n) {
                    var i, r = new Q;
                    return r.set(e, t), g(g({}, n), {
                        event_type: p.IDENTIFY,
                        user_properties: r.getUserProperties(),
                        groups: ((i = {})[e] = t, i)
                    })
                },
                J = function() {
                    function e(e) {
                        void 0 === e && (e = "$default"), this.initializing = !1, this.q = [], this.dispatchQ = [], this.logEvent = this.track.bind(this), this.timeline = new K(this), this.name = e
                    }
                    return e.prototype._init = function(e) {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(t) {
                                switch (t.label) {
                                    case 0:
                                        return this.config = e, this.timeline.reset(this), [4, this.runQueuedFunctions("q")];
                                    case 1:
                                        return t.sent(), [2]
                                }
                            })
                        })
                    }, e.prototype.runQueuedFunctions = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t, n, i, r, o;
                            return b(this, function(s) {
                                switch (s.label) {
                                    case 0:
                                        t = this[e], this[e] = [], s.label = 1;
                                    case 1:
                                        s.trys.push([1, 6, 7, 8]), i = (n = _(t)).next(), s.label = 2;
                                    case 2:
                                        if (i.done) return [3, 5];
                                        return [4, (0, i.value)()];
                                    case 3:
                                        s.sent(), s.label = 4;
                                    case 4:
                                        return i = n.next(), [3, 2];
                                    case 5:
                                        return [3, 8];
                                    case 6:
                                        return r = {
                                            error: s.sent()
                                        }, [3, 8];
                                    case 7:
                                        try {
                                            i && !i.done && (o = n.return) && o.call(n)
                                        } finally {
                                            if (r) throw r.error
                                        }
                                        return [7];
                                    case 8:
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.track = function(e, t, n) {
                        var i = g(g(g({}, "string" == typeof e ? {
                            event_type: e
                        } : e), n), t && {
                            event_properties: t
                        });
                        return O(this.dispatch(i))
                    }, e.prototype.identify = function(e, t) {
                        var n = B(e, t);
                        return O(this.dispatch(n))
                    }, e.prototype.groupIdentify = function(e, t, n, i) {
                        var r = z(e, t, n, i);
                        return O(this.dispatch(r))
                    }, e.prototype.setGroup = function(e, t, n) {
                        var i = W(e, t, n);
                        return O(this.dispatch(i))
                    }, e.prototype.revenue = function(e, t) {
                        var n = g(g({}, t), {
                            event_type: p.REVENUE,
                            event_properties: e.getEventProperties()
                        });
                        return O(this.dispatch(n))
                    }, e.prototype.add = function(e) {
                        return this.config ? O(this.timeline.register(e, this.config)) : (this.q.push(this.add.bind(this, e)), O())
                    }, e.prototype.remove = function(e) {
                        return this.config ? O(this.timeline.deregister(e)) : (this.q.push(this.remove.bind(this, e)), O())
                    }, e.prototype.dispatchWithCallback = function(e, t) {
                        if (!this.config) return t(U(e, 0, "Client not initialized"));
                        this.process(e).then(t)
                    }, e.prototype.dispatch = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t = this;
                            return b(this, function(n) {
                                return this.config ? [2, this.process(e)] : [2, new Promise(function(n) {
                                    t.dispatchQ.push(t.dispatchWithCallback.bind(t, e, n))
                                })]
                            })
                        })
                    }, e.prototype.process = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t, n;
                            return b(this, function(i) {
                                switch (i.label) {
                                    case 0:
                                        if (i.trys.push([0, 2, , 3]), this.config.optOut) return [2, U(e, 0, "Event skipped due to optOut config")];
                                        return [4, this.timeline.push(e)];
                                    case 1:
                                        return 200 === (t = i.sent()).code ? this.config.loggerProvider.log(t.message) : 100 === t.code ? this.config.loggerProvider.warn(t.message) : this.config.loggerProvider.error(t.message), [2, t];
                                    case 2:
                                        return n = String(i.sent()), this.config.loggerProvider.error(n), [2, t = U(e, 0, n)];
                                    case 3:
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.setOptOut = function(e) {
                        if (!this.config) {
                            this.q.push(this.setOptOut.bind(this, !!e));
                            return
                        }
                        this.config.optOut = !!e
                    }, e.prototype.flush = function() {
                        return O(this.timeline.flush())
                    }, e
                }(),
                Y = function() {
                    function e() {}
                    return e.prototype.getApplicationContext = function() {
                        return {
                            versionName: this.versionName,
                            language: Z(),
                            platform: "Web",
                            os: void 0,
                            deviceModel: void 0
                        }
                    }, e
                }(),
                Z = function() {
                    return "undefined" != typeof navigator && (navigator.languages && navigator.languages[0] || navigator.language) || ""
                },
                G = function() {
                    function e() {
                        this.queue = []
                    }
                    return e.prototype.logEvent = function(e) {
                        this.receiver ? this.receiver(e) : this.queue.length < 512 && this.queue.push(e)
                    }, e.prototype.setEventReceiver = function(e) {
                        this.receiver = e, this.queue.length > 0 && (this.queue.forEach(function(t) {
                            e(t)
                        }), this.queue = [])
                    }, e
                }(),
                H = function() {
                    return (H = Object.assign || function(e) {
                        for (var t, n = 1, i = arguments.length; n < i; n++)
                            for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                        return e
                    }).apply(this, arguments)
                },
                X = function(e, t) {
                    var n = typeof e;
                    if (n !== typeof t) return !1;
                    for (var i = 0, r = ["string", "number", "boolean", "undefined"]; i < r.length; i++)
                        if (r[i] === n) return e === t;
                    if (null == e && null == t) return !0;
                    if (null == e || null == t || e.length !== t.length) return !1;
                    var o = Array.isArray(e),
                        s = Array.isArray(t);
                    if (o !== s) return !1;
                    if (o && s) {
                        for (var u = 0; u < e.length; u++)
                            if (!X(e[u], t[u])) return !1
                    } else {
                        if (!X(Object.keys(e).sort(), Object.keys(t).sort())) return !1;
                        var a = !0;
                        return Object.keys(e).forEach(function(n) {
                            X(e[n], t[n]) || (a = !1)
                        }), a
                    }
                    return !0
                };
            Object.entries || (Object.entries = function(e) {
                for (var t = Object.keys(e), n = t.length, i = Array(n); n--;) i[n] = [t[n], e[t[n]]];
                return i
            });
            var ee = function() {
                    function e() {
                        this.identity = {
                            userProperties: {}
                        }, this.listeners = new Set
                    }
                    return e.prototype.editIdentity = function() {
                        var e = this,
                            t = H({}, this.identity.userProperties),
                            n = H(H({}, this.identity), {
                                userProperties: t
                            });
                        return {
                            setUserId: function(e) {
                                return n.userId = e, this
                            },
                            setDeviceId: function(e) {
                                return n.deviceId = e, this
                            },
                            setUserProperties: function(e) {
                                return n.userProperties = e, this
                            },
                            setOptOut: function(e) {
                                return n.optOut = e, this
                            },
                            updateUserProperties: function(e) {
                                for (var t = n.userProperties || {}, i = 0, r = Object.entries(e); i < r.length; i++) {
                                    var o = r[i],
                                        s = o[0],
                                        u = o[1];
                                    switch (s) {
                                        case "$set":
                                            for (var a = 0, c = Object.entries(u); a < c.length; a++) {
                                                var l = c[a],
                                                    d = l[0],
                                                    f = l[1];
                                                t[d] = f
                                            }
                                            break;
                                        case "$unset":
                                            for (var p = 0, v = Object.keys(u); p < v.length; p++) {
                                                var d = v[p];
                                                delete t[d]
                                            }
                                            break;
                                        case "$clearAll":
                                            t = {}
                                    }
                                }
                                return n.userProperties = t, this
                            },
                            commit: function() {
                                return e.setIdentity(n), this
                            }
                        }
                    }, e.prototype.getIdentity = function() {
                        return H({}, this.identity)
                    }, e.prototype.setIdentity = function(e) {
                        var t = H({}, this.identity);
                        this.identity = H({}, e), X(t, this.identity) || this.listeners.forEach(function(t) {
                            t(e)
                        })
                    }, e.prototype.addIdentityListener = function(e) {
                        this.listeners.add(e)
                    }, e.prototype.removeIdentityListener = function(e) {
                        this.listeners.delete(e)
                    }, e
                }(),
                et = "undefined" != typeof globalThis ? globalThis : void 0 !== n.g ? n.g : self,
                en = function() {
                    function e() {
                        this.identityStore = new ee, this.eventBridge = new G, this.applicationContextProvider = new Y
                    }
                    return e.getInstance = function(t) {
                        return et.analyticsConnectorInstances || (et.analyticsConnectorInstances = {}), et.analyticsConnectorInstances[t] || (et.analyticsConnectorInstances[t] = new e), et.analyticsConnectorInstances[t]
                    }, e
                }(),
                ei = function(e) {
                    return void 0 === e && (e = "$default_instance"), en.getInstance(e)
                },
                er = function(e, t) {
                    ei(t).identityStore.editIdentity().setUserId(e).commit()
                },
                eo = function(e, t) {
                    ei(t).identityStore.editIdentity().setDeviceId(e).commit()
                },
                es = function() {
                    function e() {
                        this.name = "identity", this.type = "before", this.identityStore = ei().identityStore
                    }
                    return e.prototype.execute = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t;
                            return b(this, function(n) {
                                return (t = e.user_properties) && this.identityStore.editIdentity().updateUserProperties(t).commit(), [2, e]
                            })
                        })
                    }, e.prototype.setup = function(e) {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(t) {
                                return e.instanceName && (this.identityStore = ei(e.instanceName).identityStore), [2]
                            })
                        })
                    }, e
                }(),
                eu = function(e, t) {
                    return "boolean" == typeof e ? e : (null == e ? void 0 : e[t]) !== !1
                },
                ea = function(e) {
                    return eu(e, "attribution")
                },
                ec = function(e) {
                    return eu(e, "pageViews")
                },
                el = function(e) {
                    var t, n = function() {
                            return !1
                        },
                        i = void 0,
                        r = e.pageCounter;
                    return ec(e.defaultTracking) && (n = void 0, t = void 0, e.defaultTracking && "object" == typeof e.defaultTracking && e.defaultTracking.pageViews && "object" == typeof e.defaultTracking.pageViews && ("trackOn" in e.defaultTracking.pageViews && (n = e.defaultTracking.pageViews.trackOn), "trackHistoryChanges" in e.defaultTracking.pageViews && (i = e.defaultTracking.pageViews.trackHistoryChanges), "eventType" in e.defaultTracking.pageViews && e.defaultTracking.pageViews.eventType && (t = e.defaultTracking.pageViews.eventType))), {
                        trackOn: n,
                        trackHistoryChanges: i,
                        eventType: t,
                        pageCounter: r
                    }
                },
                ed = function(e, t) {
                    return void 0 === t && (t = Date.now()), Date.now() - t > e
                },
                ef = function(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var i = t[n],
                            r = i.name,
                            o = i.args,
                            s = i.resolve,
                            u = e && e[r];
                        if ("function" == typeof u) {
                            var a = u.apply(e, o);
                            "function" == typeof s && s(null == a ? void 0 : a.promise)
                        }
                    }
                    return e
                },
                ep = function(e) {
                    return e && void 0 !== e._q
                },
                ev = function() {
                    if ("undefined" == typeof navigator) return "";
                    var e, t, n, i, r = navigator.userLanguage;
                    return null !== (i = null !== (n = null !== (t = null === (e = navigator.languages) || void 0 === e ? void 0 : e[0]) && void 0 !== t ? t : navigator.language) && void 0 !== n ? n : r) && void 0 !== i ? i : ""
                },
                eh = function() {
                    function e() {
                        this.name = "@amplitude/plugin-context-browser", this.type = "before", this.library = "amplitude-ts/".concat("2.5.1"), "undefined" != typeof navigator && (this.userAgent = navigator.userAgent)
                    }
                    return e.prototype.setup = function(e) {
                        return this.config = e, Promise.resolve(void 0)
                    }, e.prototype.execute = function(e) {
                        var t, n;
                        return m(this, void 0, void 0, function() {
                            var i, r, o;
                            return b(this, function(s) {
                                return i = new Date().getTime(), r = null !== (t = this.config.lastEventId) && void 0 !== t ? t : -1, o = null !== (n = e.event_id) && void 0 !== n ? n : r + 1, this.config.lastEventId = o, e.time || (this.config.lastEventTime = i), [2, g(g(g(g(g(g(g(g({
                                    user_id: this.config.userId,
                                    device_id: this.config.deviceId,
                                    session_id: this.config.sessionId,
                                    time: i
                                }, this.config.appVersion && {
                                    app_version: this.config.appVersion
                                }), this.config.trackingOptions.platform && {
                                    platform: "Web"
                                }), this.config.trackingOptions.language && {
                                    language: ev()
                                }), this.config.trackingOptions.ipAddress && {
                                    ip: "$remote"
                                }), {
                                    insert_id: M(),
                                    partner_id: this.config.partnerId,
                                    plan: this.config.plan
                                }), this.config.ingestionMetadata && {
                                    ingestion_metadata: {
                                        source_name: this.config.ingestionMetadata.sourceName,
                                        source_version: this.config.ingestionMetadata.sourceVersion
                                    }
                                }), e), {
                                    event_id: o,
                                    library: this.library,
                                    user_agent: this.userAgent
                                })]
                            })
                        })
                    }, e
                }(),
                eg = function() {
                    function e() {
                        this.memoryStorage = new Map
                    }
                    return e.prototype.isEnabled = function() {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(e) {
                                return [2, !0]
                            })
                        })
                    }, e.prototype.get = function(e) {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(t) {
                                return [2, this.memoryStorage.get(e)]
                            })
                        })
                    }, e.prototype.getRaw = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t;
                            return b(this, function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.get(e)];
                                    case 1:
                                        return [2, (t = n.sent()) ? JSON.stringify(t) : void 0]
                                }
                            })
                        })
                    }, e.prototype.set = function(e, t) {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(n) {
                                return this.memoryStorage.set(e, t), [2]
                            })
                        })
                    }, e.prototype.remove = function(e) {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(t) {
                                return this.memoryStorage.delete(e), [2]
                            })
                        })
                    }, e.prototype.reset = function() {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(e) {
                                return this.memoryStorage.clear(), [2]
                            })
                        })
                    }, e
                }(),
                ey = function(e, t, n) {
                    return void 0 === t && (t = ""), void 0 === n && (n = 10), ["AMP", t, e.substring(0, n)].filter(Boolean).join("_")
                },
                em = function() {
                    return "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof self ? self : void 0 !== n.g ? n.g : void 0
                },
                eb = function() {
                    var e, t = em();
                    return (null === (e = null == t ? void 0 : t.location) || void 0 === e ? void 0 : e.search) ? t.location.search.substring(1).split("&").filter(Boolean).reduce(function(e, t) {
                        var n = t.split("=", 2),
                            i = e_(n[0]),
                            r = e_(n[1]);
                        return r && (e[i] = r), e
                    }, {}) : {}
                },
                e_ = function(e) {
                    void 0 === e && (e = "");
                    try {
                        return decodeURIComponent(e)
                    } catch (e) {
                        return ""
                    }
                },
                eI = function() {
                    function e(e) {
                        this.options = g({}, e)
                    }
                    return e.prototype.isEnabled = function() {
                        return m(this, void 0, void 0, function() {
                            var t, n;
                            return b(this, function(i) {
                                switch (i.label) {
                                    case 0:
                                        if (!em()) return [2, !1];
                                        e.testValue = String(Date.now()), t = new e(this.options), n = "AMP_TEST", i.label = 1;
                                    case 1:
                                        return i.trys.push([1, 4, 5, 7]), [4, t.set(n, e.testValue)];
                                    case 2:
                                        return i.sent(), [4, t.get(n)];
                                    case 3:
                                        return [2, i.sent() === e.testValue];
                                    case 4:
                                        return i.sent(), [2, !1];
                                    case 5:
                                        return [4, t.remove(n)];
                                    case 6:
                                        return i.sent(), [7];
                                    case 7:
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.get = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t;
                            return b(this, function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.getRaw(e)];
                                    case 1:
                                        if (!(t = n.sent())) return [2, void 0];
                                        try {
                                            try {
                                                t = decodeURIComponent(atob(t))
                                            } catch (e) {}
                                            return [2, JSON.parse(t)]
                                        } catch (e) {
                                            return [2, void 0]
                                        }
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.getRaw = function(e) {
                        var t, n;
                        return m(this, void 0, void 0, function() {
                            var i, r;
                            return b(this, function(o) {
                                return (r = (null !== (n = null === (t = null == (i = em()) ? void 0 : i.document) || void 0 === t ? void 0 : t.cookie.split("; ")) && void 0 !== n ? n : []).find(function(t) {
                                    return 0 === t.indexOf(e + "=")
                                })) ? [2, r.substring(e.length + 1)] : [2, void 0]
                            })
                        })
                    }, e.prototype.set = function(e, t) {
                        var n;
                        return m(this, void 0, void 0, function() {
                            var i, r, o, s, u, a;
                            return b(this, function(c) {
                                try {
                                    i = null !== (n = this.options.expirationDays) && void 0 !== n ? n : 0, r = null !== t ? i : -1, o = void 0, r && ((s = new Date).setTime(s.getTime() + 864e5 * r), o = s), u = "".concat(e, "=").concat(btoa(encodeURIComponent(JSON.stringify(t)))), o && (u += "; expires=".concat(o.toUTCString())), u += "; path=/", this.options.domain && (u += "; domain=".concat(this.options.domain)), this.options.secure && (u += "; Secure"), this.options.sameSite && (u += "; SameSite=".concat(this.options.sameSite)), (a = em()) && (a.document.cookie = u)
                                } catch (e) {}
                                return [2]
                            })
                        })
                    }, e.prototype.remove = function(e) {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.set(e, null)];
                                    case 1:
                                        return t.sent(), [2]
                                }
                            })
                        })
                    }, e.prototype.reset = function() {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(e) {
                                return [2]
                            })
                        })
                    }, e
                }(),
                ew = function() {
                    function e() {}
                    return e.prototype.send = function(e, t) {
                        return Promise.resolve(null)
                    }, e.prototype.buildResponse = function(e) {
                        if ("object" != typeof e) return null;
                        var t, n, i, r, o, s, u, a, c, d, f, p, v, h, g, y, m, b, _, I, w, S, E = e.code || 0,
                            T = this.buildStatus(E);
                        switch (T) {
                            case l.Success:
                                return {
                                    status: T,
                                    statusCode: E,
                                    body: {
                                        eventsIngested: null !== (t = e.events_ingested) && void 0 !== t ? t : 0,
                                        payloadSizeBytes: null !== (n = e.payload_size_bytes) && void 0 !== n ? n : 0,
                                        serverUploadTime: null !== (i = e.server_upload_time) && void 0 !== i ? i : 0
                                    }
                                };
                            case l.Invalid:
                                return {
                                    status: T,
                                    statusCode: E,
                                    body: {
                                        error: null !== (r = e.error) && void 0 !== r ? r : "",
                                        missingField: null !== (o = e.missing_field) && void 0 !== o ? o : "",
                                        eventsWithInvalidFields: null !== (s = e.events_with_invalid_fields) && void 0 !== s ? s : {},
                                        eventsWithMissingFields: null !== (u = e.events_with_missing_fields) && void 0 !== u ? u : {},
                                        eventsWithInvalidIdLengths: null !== (a = e.events_with_invalid_id_lengths) && void 0 !== a ? a : {},
                                        epsThreshold: null !== (c = e.eps_threshold) && void 0 !== c ? c : 0,
                                        exceededDailyQuotaDevices: null !== (d = e.exceeded_daily_quota_devices) && void 0 !== d ? d : {},
                                        silencedDevices: null !== (f = e.silenced_devices) && void 0 !== f ? f : [],
                                        silencedEvents: null !== (p = e.silenced_events) && void 0 !== p ? p : [],
                                        throttledDevices: null !== (v = e.throttled_devices) && void 0 !== v ? v : {},
                                        throttledEvents: null !== (h = e.throttled_events) && void 0 !== h ? h : []
                                    }
                                };
                            case l.PayloadTooLarge:
                                return {
                                    status: T,
                                    statusCode: E,
                                    body: {
                                        error: null !== (g = e.error) && void 0 !== g ? g : ""
                                    }
                                };
                            case l.RateLimit:
                                return {
                                    status: T,
                                    statusCode: E,
                                    body: {
                                        error: null !== (y = e.error) && void 0 !== y ? y : "",
                                        epsThreshold: null !== (m = e.eps_threshold) && void 0 !== m ? m : 0,
                                        throttledDevices: null !== (b = e.throttled_devices) && void 0 !== b ? b : {},
                                        throttledUsers: null !== (_ = e.throttled_users) && void 0 !== _ ? _ : {},
                                        exceededDailyQuotaDevices: null !== (I = e.exceeded_daily_quota_devices) && void 0 !== I ? I : {},
                                        exceededDailyQuotaUsers: null !== (w = e.exceeded_daily_quota_users) && void 0 !== w ? w : {},
                                        throttledEvents: null !== (S = e.throttled_events) && void 0 !== S ? S : []
                                    }
                                };
                            case l.Timeout:
                            default:
                                return {
                                    status: T,
                                    statusCode: E
                                }
                        }
                    }, e.prototype.buildStatus = function(e) {
                        return e >= 200 && e < 300 ? l.Success : 429 === e ? l.RateLimit : 413 === e ? l.PayloadTooLarge : 408 === e ? l.Timeout : e >= 400 && e < 500 ? l.Invalid : e >= 500 ? l.Failed : l.Unknown
                    }, e
                }(),
                eS = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return h(t, e), t.prototype.send = function(e, t) {
                        return m(this, void 0, void 0, function() {
                            var n, i;
                            return b(this, function(r) {
                                switch (r.label) {
                                    case 0:
                                        if ("undefined" == typeof fetch) throw Error("FetchTransport is not supported");
                                        return n = {
                                            headers: {
                                                "Content-Type": "application/json",
                                                Accept: "*/*"
                                            },
                                            body: JSON.stringify(t),
                                            method: "POST"
                                        }, [4, fetch(e, n)];
                                    case 1:
                                        return [4, r.sent().json()];
                                    case 2:
                                        return i = r.sent(), [2, this.buildResponse(i)]
                                }
                            })
                        })
                    }, t
                }(ew),
                eE = function() {
                    function e(e) {
                        this.storage = e
                    }
                    return e.prototype.isEnabled = function() {
                        return m(this, void 0, void 0, function() {
                            var t, n, i;
                            return b(this, function(r) {
                                switch (r.label) {
                                    case 0:
                                        if (!this.storage) return [2, !1];
                                        t = String(Date.now()), n = new e(this.storage), i = "AMP_TEST", r.label = 1;
                                    case 1:
                                        return r.trys.push([1, 4, 5, 7]), [4, n.set(i, t)];
                                    case 2:
                                        return r.sent(), [4, n.get(i)];
                                    case 3:
                                        return [2, r.sent() === t];
                                    case 4:
                                        return r.sent(), [2, !1];
                                    case 5:
                                        return [4, n.remove(i)];
                                    case 6:
                                        return r.sent(), [7];
                                    case 7:
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.get = function(e) {
                        return m(this, void 0, void 0, function() {
                            var t;
                            return b(this, function(n) {
                                switch (n.label) {
                                    case 0:
                                        return n.trys.push([0, 2, , 3]), [4, this.getRaw(e)];
                                    case 1:
                                        if (!(t = n.sent())) return [2, void 0];
                                        return [2, JSON.parse(t)];
                                    case 2:
                                        return n.sent(), console.error("[Amplitude] Error: Could not get value from storage"), [2, void 0];
                                    case 3:
                                        return [2]
                                }
                            })
                        })
                    }, e.prototype.getRaw = function(e) {
                        var t;
                        return m(this, void 0, void 0, function() {
                            return b(this, function(n) {
                                return [2, (null === (t = this.storage) || void 0 === t ? void 0 : t.getItem(e)) || void 0]
                            })
                        })
                    }, e.prototype.set = function(e, t) {
                        var n;
                        return m(this, void 0, void 0, function() {
                            return b(this, function(i) {
                                try {
                                    null === (n = this.storage) || void 0 === n || n.setItem(e, JSON.stringify(t))
                                } catch (e) {}
                                return [2]
                            })
                        })
                    }, e.prototype.remove = function(e) {
                        var t;
                        return m(this, void 0, void 0, function() {
                            return b(this, function(n) {
                                try {
                                    null === (t = this.storage) || void 0 === t || t.removeItem(e)
                                } catch (e) {}
                                return [2]
                            })
                        })
                    }, e.prototype.reset = function() {
                        var e;
                        return m(this, void 0, void 0, function() {
                            return b(this, function(t) {
                                try {
                                    null === (e = this.storage) || void 0 === e || e.clear()
                                } catch (e) {}
                                return [2]
                            })
                        })
                    }, e
                }(),
                eT = function(e) {
                    function t(t) {
                        var n, i = this;
                        return (i = e.call(this, null === (n = em()) || void 0 === n ? void 0 : n.localStorage) || this).loggerProvider = null == t ? void 0 : t.loggerProvider, i
                    }
                    return h(t, e), t.prototype.set = function(t, n) {
                        var i;
                        return m(this, void 0, void 0, function() {
                            var r;
                            return b(this, function(o) {
                                switch (o.label) {
                                    case 0:
                                        if (!(Array.isArray(n) && n.length > 1e3)) return [3, 2];
                                        return r = n.length - 1e3, [4, e.prototype.set.call(this, t, n.slice(0, 1e3))];
                                    case 1:
                                        return o.sent(), null === (i = this.loggerProvider) || void 0 === i || i.error("Failed to save ".concat(r, " events because the queue length exceeded ").concat(1e3, ".")), [3, 4];
                                    case 2:
                                        return [4, e.prototype.set.call(this, t, n)];
                                    case 3:
                                        o.sent(), o.label = 4;
                                    case 4:
                                        return [2]
                                }
                            })
                        })
                    }, t
                }(eE),
                ek = function(e) {
                    function t() {
                        var t;
                        return e.call(this, null === (t = em()) || void 0 === t ? void 0 : t.sessionStorage) || this
                    }
                    return h(t, e), t
                }(eE),
                eO = function(e) {
                    function t() {
                        var t = null !== e && e.apply(this, arguments) || this;
                        return t.state = {
                            done: 4
                        }, t
                    }
                    return h(t, e), t.prototype.send = function(e, t) {
                        return m(this, void 0, void 0, function() {
                            var n = this;
                            return b(this, function(i) {
                                return [2, new Promise(function(i, r) {
                                    "undefined" == typeof XMLHttpRequest && r(Error("XHRTransport is not supported."));
                                    var o = new XMLHttpRequest;
                                    o.open("POST", e, !0), o.onreadystatechange = function() {
                                        if (o.readyState === n.state.done) try {
                                            var e = o.responseText,
                                                t = JSON.parse(e),
                                                s = n.buildResponse(t);
                                            i(s)
                                        } catch (e) {
                                            r(e)
                                        }
                                    }, o.setRequestHeader("Content-Type", "application/json"), o.setRequestHeader("Accept", "*/*"), o.send(JSON.stringify(t))
                                })]
                            })
                        })
                    }, t
                }(ew),
                eP = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return h(t, e), t.prototype.send = function(e, t) {
                        return m(this, void 0, void 0, function() {
                            var n = this;
                            return b(this, function(i) {
                                return [2, new Promise(function(i, r) {
                                    var o = em();
                                    if (!(null == o ? void 0 : o.navigator.sendBeacon)) throw Error("SendBeaconTransport is not supported");
                                    try {
                                        var s = JSON.stringify(t);
                                        if (o.navigator.sendBeacon(e, JSON.stringify(t))) return i(n.buildResponse({
                                            code: 200,
                                            events_ingested: t.events.length,
                                            payload_size_bytes: s.length,
                                            server_upload_time: Date.now()
                                        }));
                                        return i(n.buildResponse({
                                            code: 500
                                        }))
                                    } catch (e) {
                                        r(e)
                                    }
                                })]
                            })
                        })
                    }, t
                }(ew),
                eR = function(e) {
                    var t = parseInt(e, 32);
                    if (!isNaN(t)) return t
                },
                ex = function(e) {
                    if (atob && escape && e) try {
                        return decodeURIComponent(escape(atob(e)))
                    } catch (e) {
                        return
                    }
                },
                eU = "[Amplitude]",
                eN = "".concat(eU, " Form Started"),
                eD = "".concat(eU, " Form Submitted"),
                eq = "".concat(eU, " File Downloaded"),
                eA = "session_start",
                eL = "session_end",
                eC = "".concat(eU, " File Extension"),
                ej = "".concat(eU, " File Name"),
                eM = "".concat(eU, " Link ID"),
                eV = "".concat(eU, " Link Text"),
                eF = "".concat(eU, " Link URL"),
                eQ = "".concat(eU, " Form ID"),
                e$ = "".concat(eU, " Form Name"),
                eK = "".concat(eU, " Form Destination"),
                eB = "cookie",
                ez = function(e) {
                    function t(t, n, i, r, o, s, u, a, l, d, f, p, v, h, g, y, m, b, _, I, w, S, E, T, k, O, P, R, x, U, N) {
                        void 0 === i && (i = new eg), void 0 === r && (r = {
                            domain: "",
                            expiration: 365,
                            sameSite: "Lax",
                            secure: !1,
                            upgrade: !0
                        }), void 0 === u && (u = 1e3), void 0 === a && (a = 5), void 0 === l && (l = 30), void 0 === d && (d = eB), void 0 === g && (g = new D), void 0 === y && (y = c.Warn), void 0 === b && (b = !1), void 0 === _ && (_ = !1), void 0 === S && (S = ""), void 0 === E && (E = "US"), void 0 === k && (k = 18e5), void 0 === O && (O = new eT({
                            loggerProvider: g
                        })), void 0 === P && (P = {
                            ipAddress: !0,
                            language: !0,
                            platform: !0
                        }), void 0 === R && (R = "fetch"), void 0 === x && (x = !1);
                        var q = e.call(this, {
                            apiKey: t,
                            storageProvider: O,
                            transportProvider: eJ(R)
                        }) || this;
                        return q.apiKey = t, q.appVersion = n, q.cookieOptions = r, q.defaultTracking = o, q.flushIntervalMillis = u, q.flushMaxRetries = a, q.flushQueueSize = l, q.identityStorage = d, q.ingestionMetadata = f, q.instanceName = p, q.loggerProvider = g, q.logLevel = y, q.minIdLength = m, q.offline = b, q.partnerId = I, q.plan = w, q.serverUrl = S, q.serverZone = E, q.sessionTimeout = k, q.storageProvider = O, q.trackingOptions = P, q.transport = R, q.useBatch = x, q._optOut = !1, q._cookieStorage = i, q.deviceId = s, q.lastEventId = v, q.lastEventTime = h, q.optOut = _, q.sessionId = T, q.pageCounter = N, q.userId = U, q.loggerProvider.enable(q.logLevel), q
                    }
                    return h(t, e), Object.defineProperty(t.prototype, "cookieStorage", {
                        get: function() {
                            return this._cookieStorage
                        },
                        set: function(e) {
                            this._cookieStorage !== e && (this._cookieStorage = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "deviceId", {
                        get: function() {
                            return this._deviceId
                        },
                        set: function(e) {
                            this._deviceId !== e && (this._deviceId = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "userId", {
                        get: function() {
                            return this._userId
                        },
                        set: function(e) {
                            this._userId !== e && (this._userId = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "sessionId", {
                        get: function() {
                            return this._sessionId
                        },
                        set: function(e) {
                            this._sessionId !== e && (this._sessionId = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "optOut", {
                        get: function() {
                            return this._optOut
                        },
                        set: function(e) {
                            this._optOut !== e && (this._optOut = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "lastEventTime", {
                        get: function() {
                            return this._lastEventTime
                        },
                        set: function(e) {
                            this._lastEventTime !== e && (this._lastEventTime = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "lastEventId", {
                        get: function() {
                            return this._lastEventId
                        },
                        set: function(e) {
                            this._lastEventId !== e && (this._lastEventId = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "pageCounter", {
                        get: function() {
                            return this._pageCounter
                        },
                        set: function(e) {
                            this._pageCounter !== e && (this._pageCounter = e, this.updateStorage())
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.updateStorage = function() {
                        var e = {
                            deviceId: this._deviceId,
                            userId: this._userId,
                            sessionId: this._sessionId,
                            optOut: this._optOut,
                            lastEventTime: this._lastEventTime,
                            lastEventId: this._lastEventId,
                            pageCounter: this._pageCounter
                        };
                        this.cookieStorage.set(ey(this.apiKey), e)
                    }, t
                }(A),
                eW = function(e, t) {
                    switch (void 0 === e && (e = eB), void 0 === t && (t = {}), e) {
                        case "localStorage":
                            return new eT;
                        case "sessionStorage":
                            return new ek;
                        case "none":
                            return new eg;
                        default:
                            return new eI(g(g({}, t), {
                                expirationDays: t.expiration
                            }))
                    }
                },
                eJ = function(e) {
                    return "xhr" === e ? new eO : "beacon" === e ? new eP : new eS
                },
                eY = "dclid",
                eZ = "fbclid",
                eG = "gbraid",
                eH = "gclid",
                eX = "ko_click_id",
                e0 = "li_fat_id",
                e1 = "msclkid",
                e2 = "rtd_cid",
                e4 = "ttclid",
                e3 = "twclid",
                e5 = "wbraid",
                e6 = {
                    utm_campaign: void 0,
                    utm_content: void 0,
                    utm_id: void 0,
                    utm_medium: void 0,
                    utm_source: void 0,
                    utm_term: void 0,
                    referrer: void 0,
                    referring_domain: void 0,
                    dclid: void 0,
                    gbraid: void 0,
                    gclid: void 0,
                    fbclid: void 0,
                    ko_click_id: void 0,
                    li_fat_id: void 0,
                    msclkid: void 0,
                    rtd_cid: void 0,
                    ttclid: void 0,
                    twclid: void 0,
                    wbraid: void 0
                },
                e7 = function() {
                    function e() {}
                    return e.prototype.parse = function() {
                        return m(this, void 0, void 0, function() {
                            return b(this, function(e) {
                                return [2, g(g(g(g({}, e6), this.getUtmParam()), this.getReferrer()), this.getClickIds())]
                            })
                        })
                    }, e.prototype.getUtmParam = function() {
                        var e = eb();
                        return {
                            utm_campaign: e.utm_campaign,
                            utm_content: e.utm_content,
                            utm_id: e.utm_id,
                            utm_medium: e.utm_medium,
                            utm_source: e.utm_source,
                            utm_term: e.utm_term
                        }
                    }, e.prototype.getReferrer = function() {
                        var e, t, n = {
                            referrer: void 0,
                            referring_domain: void 0
                        };
                        try {
                            n.referrer = document.referrer || void 0, n.referring_domain = null !== (t = null === (e = n.referrer) || void 0 === e ? void 0 : e.split("/")[2]) && void 0 !== t ? t : void 0
                        } catch (e) {}
                        return n
                    }, e.prototype.getClickIds = function() {
                        var e, t = eb();
                        return (e = {})[eY] = t[eY], e[eZ] = t[eZ], e[eG] = t[eG], e[eH] = t[eH], e[eX] = t[eX], e[e0] = t[e0], e[e1] = t[e1], e[e2] = t[e2], e[e4] = t[e4], e[e3] = t[e3], e[e5] = t[e5], e
                    }, e
                }(),
                e8 = function(e) {
                    var t = e.split(".");
                    return t.length <= 2 ? e : t.slice(t.length - 2, t.length).join(".")
                },
                e9 = function(e, t, n, i) {
                    void 0 === i && (i = !0), e.referrer;
                    var r = e.referring_domain,
                        o = y(e, ["referrer", "referring_domain"]),
                        s = t || {},
                        u = (s.referrer, s.referring_domain),
                        a = y(s, ["referrer", "referring_domain"]);
                    if (te(n.excludeReferrers, e.referring_domain) || !i && Object.values(e).every(function(e) {
                            return !e
                        }) && t) return !1;
                    var c = JSON.stringify(o) !== JSON.stringify(a),
                        l = e8(r || "") !== e8(u || "");
                    return !t || c || l
                },
                te = function(e, t) {
                    return void 0 === e && (e = []), void 0 === t && (t = ""), e.some(function(e) {
                        return e instanceof RegExp ? e.test(t) : e === t
                    })
                },
                tt = function(e) {
                    var t = e;
                    return t ? (t.startsWith(".") && (t = t.substring(1)), [new RegExp("".concat(t.replace(".", "\\."), "$"))]) : []
                },
                tn = function(e) {
                    var t = this;
                    return void 0 === e && (e = {}), {
                        name: "@amplitude/plugin-web-attribution-browser",
                        type: "before",
                        setup: function(t, n) {
                            var i;
                            return m(this, void 0, void 0, function() {
                                var r, o, s, u, a, c;
                                return b(this, function(l) {
                                    var d, f, p;
                                    switch (l.label) {
                                        case 0:
                                            return r = g({
                                                initialEmptyValue: "EMPTY",
                                                resetSessionOnNewCampaign: !1,
                                                excludeReferrers: tt(null === (i = t.cookieOptions) || void 0 === i ? void 0 : i.domain)
                                            }, e), t.loggerProvider.log("Installing @amplitude/plugin-web-attribution-browser."), o = t.cookieStorage, d = t.apiKey, void 0 === f && (f = 10), s = ["AMP", "MKTG", d.substring(0, f)].filter(Boolean).join("_"), [4, Promise.all([new e7().parse(), o.get(s)])];
                                        case 1:
                                            return e9(a = (u = I.apply(void 0, [l.sent(), 2]))[0], u[1], r, ed(t.sessionTimeout, t.lastEventTime)) && (r.resetSessionOnNewCampaign && (n.setSessionId(Date.now()), t.loggerProvider.log("Created a new session for new campaign.")), t.loggerProvider.log("Tracking attribution."), p = r, c = B(Object.entries(g(g({}, e6), a)).reduce(function(e, t) {
                                                var n, i = I(t, 2),
                                                    r = i[0],
                                                    o = i[1];
                                                return (e.setOnce("initial_".concat(r), null !== (n = null != o ? o : p.initialEmptyValue) && void 0 !== n ? n : "EMPTY"), o) ? e.set(r, o) : e.unset(r)
                                            }, new Q)), n.track(c), o.set(s, a)), [2]
                                    }
                                })
                            })
                        },
                        execute: function(e) {
                            return m(t, void 0, void 0, function() {
                                return b(this, function(t) {
                                    return [2, e]
                                })
                            })
                        }
                    }
                },
                ti = function(e) {
                    var t = {};
                    for (var n in e) {
                        var i = e[n];
                        i && (t[n] = i)
                    }
                    return t
                },
                tr = function(e) {
                    void 0 === e && (e = {});
                    var t, n, i, r = em(),
                        o = void 0,
                        s = function() {
                            return m(void 0, void 0, void 0, function() {
                                var t, n, r;
                                return b(this, function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return n = {
                                                event_type: null !== (r = e.eventType) && void 0 !== r ? r : "[Amplitude] Page Viewed"
                                            }, t = [{}], [4, to()];
                                        case 1:
                                            return [2, (n.event_properties = g.apply(void 0, [g.apply(void 0, t.concat([o.sent()])), {
                                                "[Amplitude] Page Domain": "undefined" != typeof location && location.hostname || "",
                                                "[Amplitude] Page Location": "undefined" != typeof location && location.href || "",
                                                "[Amplitude] Page Path": "undefined" != typeof location && location.pathname || "",
                                                "[Amplitude] Page Title": "undefined" != typeof document && document.title || "",
                                                "[Amplitude] Page URL": "undefined" != typeof location && location.href.split("?")[0] || "",
                                                "[Amplitude] Page Counter": i
                                            }]), n)]
                                    }
                                })
                            })
                        },
                        u = function() {
                            return void 0 === e.trackOn || "function" == typeof e.trackOn && e.trackOn()
                        },
                        a = "undefined" != typeof location ? location.href : null,
                        c = function() {
                            return m(void 0, void 0, void 0, function() {
                                var n, i, r, c;
                                return b(this, function(l) {
                                    switch (l.label) {
                                        case 0:
                                            if (n = location.href, i = tu(e.trackHistoryChanges, n, a || "") && u(), a = n, !i) return [3, 4];
                                            if (null == o || o.log("Tracking page view event"), null != t) return [3, 1];
                                            return [3, 3];
                                        case 1:
                                            return c = (r = t).track, [4, s()];
                                        case 2:
                                            c.apply(r, [l.sent()]), l.label = 3;
                                        case 3:
                                            l.label = 4;
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        },
                        l = function() {
                            c()
                        };
                    return {
                        name: "@amplitude/plugin-page-view-tracking-browser",
                        type: "enrichment",
                        setup: function(e, a) {
                            return m(void 0, void 0, void 0, function() {
                                var d, f;
                                return b(this, function(p) {
                                    switch (p.label) {
                                        case 0:
                                            if (t = a, (o = e.loggerProvider).log("Installing @amplitude/plugin-page-view-tracking-browser"), e.pageCounter = e.pageCounter ? e.pageCounter + 1 : 1, i = e.pageCounter, r && (r.addEventListener("popstate", l), n = r.history.pushState, r.history.pushState = new Proxy(r.history.pushState, {
                                                    apply: function(e, t, n) {
                                                        var i = I(n, 3),
                                                            r = i[0],
                                                            o = i[1],
                                                            s = i[2];
                                                        e.apply(t, [r, o, s]), c()
                                                    }
                                                })), !u()) return [3, 2];
                                            return o.log("Tracking page view event"), f = (d = t).track, [4, s()];
                                        case 1:
                                            f.apply(d, [p.sent()]), p.label = 2;
                                        case 2:
                                            return [2]
                                    }
                                })
                            })
                        },
                        execute: function(t) {
                            return m(void 0, void 0, void 0, function() {
                                var n;
                                return b(this, function(i) {
                                    switch (i.label) {
                                        case 0:
                                            if (!("attribution" === e.trackOn && ts(t))) return [3, 2];
                                            return null == o || o.log("Enriching campaign event to page view event with campaign parameters"), [4, s()];
                                        case 1:
                                            n = i.sent(), t.event_type = n.event_type, t.event_properties = g(g({}, t.event_properties), n.event_properties), i.label = 2;
                                        case 2:
                                            return [2, t]
                                    }
                                })
                            })
                        },
                        teardown: function() {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(e) {
                                    return r && (r.removeEventListener("popstate", l), n && (r.history.pushState = n)), [2]
                                })
                            })
                        }
                    }
                },
                to = function() {
                    return m(void 0, void 0, void 0, function() {
                        var e;
                        return b(this, function(t) {
                            switch (t.label) {
                                case 0:
                                    return e = ti, [4, new e7().parse()];
                                case 1:
                                    return [2, e.apply(void 0, [t.sent()])]
                            }
                        })
                    })
                },
                ts = function(e) {
                    if ("$identify" === e.event_type && e.user_properties) {
                        var t = e.user_properties,
                            n = t[d.SET] || {},
                            i = t[d.UNSET] || {},
                            r = w(w([], I(Object.keys(n)), !1), I(Object.keys(i)), !1);
                        return Object.keys(e6).every(function(e) {
                            return r.includes(e)
                        })
                    }
                    return !1
                },
                tu = function(e, t, n) {
                    return "pathOnly" === e ? t.split("?")[0] !== n.split("?")[0] : t !== n
                },
                ta = function() {
                    var e, t = [],
                        n = function(e, n, i) {
                            e.addEventListener(n, i), t.push({
                                element: e,
                                type: n,
                                handler: i
                            })
                        },
                        i = function() {
                            t.forEach(function(e) {
                                var t = e.element,
                                    n = e.type,
                                    i = e.handler;
                                null == t || t.removeEventListener(n, i)
                            }), t = []
                        };
                    return {
                        name: "@amplitude/plugin-form-interaction-tracking-browser",
                        type: "enrichment",
                        setup: function(t, i) {
                            return m(void 0, void 0, void 0, function() {
                                var r;
                                return b(this, function(o) {
                                    return i ? ("undefined" == typeof document || (r = function(e) {
                                        var t = !1;
                                        n(e, "change", function() {
                                            var n;
                                            t || i.track(eN, ((n = {})[eQ] = tc(e.id), n[e$] = tc(e.name), n[eK] = e.action, n)), t = !0
                                        }), n(e, "submit", function() {
                                            var n, r;
                                            t || i.track(eN, ((n = {})[eQ] = tc(e.id), n[e$] = tc(e.name), n[eK] = e.action, n)), i.track(eD, ((r = {})[eQ] = tc(e.id), r[e$] = tc(e.name), r[eK] = e.action, r)), t = !1
                                        })
                                    }, Array.from(document.getElementsByTagName("form")).forEach(r), "undefined" != typeof MutationObserver && (e = new MutationObserver(function(e) {
                                        e.forEach(function(e) {
                                            e.addedNodes.forEach(function(e) {
                                                "FORM" === e.nodeName && r(e), "querySelectorAll" in e && "function" == typeof e.querySelectorAll && Array.from(e.querySelectorAll("form")).map(r)
                                            })
                                        })
                                    })).observe(document.body, {
                                        subtree: !0,
                                        childList: !0
                                    })), [2]) : (t.loggerProvider.warn("Form interaction tracking requires a later version of @amplitude/analytics-browser. Form interaction events are not tracked."), [2])
                                })
                            })
                        },
                        execute: function(e) {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(t) {
                                    return [2, e]
                                })
                            })
                        },
                        teardown: function() {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(t) {
                                    return null == e || e.disconnect(), i(), [2]
                                })
                            })
                        }
                    }
                },
                tc = function(e) {
                    if ("string" == typeof e) return e
                },
                tl = function() {
                    var e, t = [],
                        n = function(e, n, i) {
                            e.addEventListener(n, i), t.push({
                                element: e,
                                type: n,
                                handler: i
                            })
                        },
                        i = function() {
                            t.forEach(function(e) {
                                var t = e.element,
                                    n = e.type,
                                    i = e.handler;
                                null == t || t.removeEventListener(n, i)
                            }), t = []
                        };
                    return {
                        name: "@amplitude/plugin-file-download-tracking-browser",
                        type: "enrichment",
                        setup: function(t, i) {
                            return m(void 0, void 0, void 0, function() {
                                var r, o;
                                return b(this, function(s) {
                                    return i ? ("undefined" == typeof document || (r = function(e) {
                                        try {
                                            t = new URL(e.href, window.location.href)
                                        } catch (e) {
                                            return
                                        }
                                        var t, r = o.exec(t.href),
                                            s = null == r ? void 0 : r[1];
                                        s && n(e, "click", function() {
                                            var n;
                                            s && i.track(eq, ((n = {})[eC] = s, n[ej] = t.pathname, n[eM] = e.id, n[eV] = e.text, n[eF] = e.href, n))
                                        })
                                    }, o = /\.(pdf|xlsx?|docx?|txt|rtf|csv|exe|key|pp(s|t|tx)|7z|pkg|rar|gz|zip|avi|mov|mp4|mpe?g|wmv|midi?|mp3|wav|wma)$/, Array.from(document.getElementsByTagName("a")).forEach(r), "undefined" != typeof MutationObserver && (e = new MutationObserver(function(e) {
                                        e.forEach(function(e) {
                                            e.addedNodes.forEach(function(e) {
                                                "A" === e.nodeName && r(e), "querySelectorAll" in e && "function" == typeof e.querySelectorAll && Array.from(e.querySelectorAll("a")).map(r)
                                            })
                                        })
                                    })).observe(document.body, {
                                        subtree: !0,
                                        childList: !0
                                    })), [2]) : (t.loggerProvider.warn("File download tracking requires a later version of @amplitude/analytics-browser. File download events are not tracked."), [2])
                                })
                            })
                        },
                        execute: function(e) {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(t) {
                                    return [2, e]
                                })
                            })
                        },
                        teardown: function() {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(t) {
                                    return null == e || e.disconnect(), i(), [2]
                                })
                            })
                        }
                    }
                },
                td = !1,
                tf = function(e) {
                    td || void 0 !== e.defaultTracking || (e.loggerProvider.warn("`options.defaultTracking` is set to undefined. This implicitly configures your Amplitude instance to track Page Views, Sessions, File Downloads, and Form Interactions. You can suppress this warning by explicitly setting a value to `options.defaultTracking`. The value must either be a boolean, to enable and disable all default events, or an object, for advanced configuration. For example:\n\namplitude.init(<YOUR_API_KEY>, {\n  defaultTracking: true,\n});\n\nVisit https://www.docs.developers.amplitude.com/data/sdks/browser-2/#tracking-default-events for more details."), td = !0)
                },
                tp = function() {
                    var e = em(),
                        t = [],
                        n = function(n, i) {
                            e && (e.addEventListener(n, i), t.push({
                                type: n,
                                handler: i
                            }))
                        },
                        i = function() {
                            t.forEach(function(t) {
                                var n = t.type,
                                    i = t.handler;
                                e && e.removeEventListener(n, i)
                            }), t = []
                        };
                    return {
                        name: "@amplitude/plugin-network-checker-browser",
                        type: "before",
                        setup: function(e, t) {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(i) {
                                    return e.offline = !navigator.onLine, n("online", function() {
                                        e.loggerProvider.debug("Network connectivity changed to online."), e.offline = !1, setTimeout(function() {
                                            t.flush()
                                        }, e.flushIntervalMillis)
                                    }), n("offline", function() {
                                        e.loggerProvider.debug("Network connectivity changed to offline."), e.offline = !0
                                    }), [2]
                                })
                            })
                        },
                        teardown: function() {
                            return m(void 0, void 0, void 0, function() {
                                return b(this, function(e) {
                                    return i(), [2]
                                })
                            })
                        }
                    }
                },
                tv = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return h(t, e), t.prototype.init = function(e, t, n) {
                        var i, r;
                        return void 0 === e && (e = ""), arguments.length > 2 ? (i = t, r = n) : "string" == typeof t ? (i = t, r = void 0) : (i = null == t ? void 0 : t.userId, r = t), O(this._init(g(g({}, r), {
                            userId: i,
                            apiKey: e
                        })))
                    }, t.prototype._init = function(t) {
                        var n, i;
                        return m(this, void 0, void 0, function() {
                            var r, o, s, u = this;
                            return b(this, function(a) {
                                var c, l, d, f;
                                switch (a.label) {
                                    case 0:
                                        if (this.initializing) return [2];
                                        return this.initializing = !0, [4, (c = t.apiKey, l = t, d = this, void 0 === l && (l = {}), m(void 0, void 0, void 0, function() {
                                            var e, t, n, i, r, o, s, u, a, f, p, v, h, y, _, w, S, E, T, k, O, P, R, x, U, N, D, q, A, L, C, j, V, F, Q, $, K, B, z, W;
                                            return b(this, function(J) {
                                                var Y, Z, G;
                                                switch (J.label) {
                                                    case 0:
                                                        if (e = l.identityStorage || eB, S = {}, !(e !== eB)) return [3, 1];
                                                        return n = "", [3, 5];
                                                    case 1:
                                                        if (!(null !== (T = null === (E = l.cookieOptions) || void 0 === E ? void 0 : E.domain) && void 0 !== T)) return [3, 2];
                                                        return i = T, [3, 4];
                                                    case 2:
                                                        return [4, m(void 0, void 0, void 0, function() {
                                                            var e, t, n, i, r, o, s;
                                                            return b(this, function(u) {
                                                                switch (u.label) {
                                                                    case 0:
                                                                        return [4, new eI().isEnabled()];
                                                                    case 1:
                                                                        if (!u.sent() || !Y && "undefined" == typeof location) return [2, ""];
                                                                        for (e = (null != Y ? Y : location.hostname).split("."), t = [], n = "AMP_TLDTEST", i = e.length - 2; i >= 0; --i) t.push(e.slice(i).join("."));
                                                                        i = 0, u.label = 2;
                                                                    case 2:
                                                                        if (!(i < t.length)) return [3, 7];
                                                                        return o = {
                                                                            domain: "." + (r = t[i])
                                                                        }, [4, (s = new eI(o)).set(n, 1)];
                                                                    case 3:
                                                                        return u.sent(), [4, s.get(n)];
                                                                    case 4:
                                                                        if (!u.sent()) return [3, 6];
                                                                        return [4, s.remove(n)];
                                                                    case 5:
                                                                        return u.sent(), [2, "." + r];
                                                                    case 6:
                                                                        return i++, [3, 2];
                                                                    case 7:
                                                                        return [2, ""]
                                                                }
                                                            })
                                                        })];
                                                    case 3:
                                                        i = J.sent(), J.label = 4;
                                                    case 4:
                                                        n = i, J.label = 5;
                                                    case 5:
                                                        return t = g.apply(void 0, [(S.domain = n, S.expiration = 365, S.sameSite = "Lax", S.secure = !1, S.upgrade = !0, S), l.cookieOptions]), [4, (Z = r = eW(l.identityStorage, t), void 0 === (G = null === (O = null === (k = l.cookieOptions) || void 0 === k ? void 0 : k.upgrade) || void 0 === O || O) && (G = !0), m(void 0, void 0, void 0, function() {
                                                            var e, t, n, i, r, o, s, u, a;
                                                            return b(this, function(l) {
                                                                switch (l.label) {
                                                                    case 0:
                                                                        return e = "".concat("amp", "_").concat(c.substring(0, 6)), [4, Z.getRaw(e)];
                                                                    case 1:
                                                                        if (!(t = l.sent())) return [2, {
                                                                            optOut: !1
                                                                        }];
                                                                        if (!G) return [3, 3];
                                                                        return [4, Z.remove(e)];
                                                                    case 2:
                                                                        l.sent(), l.label = 3;
                                                                    case 3:
                                                                        return i = (n = I(t.split("."), 6))[0], r = n[1], o = n[2], s = n[3], u = n[4], a = n[5], [2, {
                                                                            deviceId: i,
                                                                            userId: ex(r),
                                                                            sessionId: eR(s),
                                                                            lastEventId: eR(a),
                                                                            lastEventTime: eR(u),
                                                                            optOut: !!o
                                                                        }]
                                                                }
                                                            })
                                                        }))];
                                                    case 6:
                                                        return o = J.sent(), [4, r.get(ey(c))];
                                                    case 7:
                                                        return s = J.sent(), u = eb(), a = null !== (U = null !== (x = null !== (R = null !== (P = l.deviceId) && void 0 !== P ? P : u.deviceId) && void 0 !== R ? R : null == s ? void 0 : s.deviceId) && void 0 !== x ? x : o.deviceId) && void 0 !== U ? U : M(), f = null !== (N = null == s ? void 0 : s.lastEventId) && void 0 !== N ? N : o.lastEventId, p = null !== (D = null == s ? void 0 : s.lastEventTime) && void 0 !== D ? D : o.lastEventTime, v = null !== (A = null !== (q = l.optOut) && void 0 !== q ? q : null == s ? void 0 : s.optOut) && void 0 !== A ? A : o.optOut, h = null !== (L = null == s ? void 0 : s.sessionId) && void 0 !== L ? L : o.sessionId, y = null !== (j = null !== (C = l.userId) && void 0 !== C ? C : null == s ? void 0 : s.userId) && void 0 !== j ? j : o.userId, d.previousSessionDeviceId = null !== (V = null == s ? void 0 : s.deviceId) && void 0 !== V ? V : o.deviceId, d.previousSessionUserId = null !== (F = null == s ? void 0 : s.userId) && void 0 !== F ? F : o.userId, _ = {
                                                            ipAddress: null === ($ = null === (Q = l.trackingOptions) || void 0 === Q ? void 0 : Q.ipAddress) || void 0 === $ || $,
                                                            language: null === (B = null === (K = l.trackingOptions) || void 0 === K ? void 0 : K.language) || void 0 === B || B,
                                                            platform: null === (W = null === (z = l.trackingOptions) || void 0 === z ? void 0 : z.platform) || void 0 === W || W
                                                        }, w = null == s ? void 0 : s.pageCounter, [2, new ez(c, l.appVersion, r, t, l.defaultTracking, a, l.flushIntervalMillis, l.flushMaxRetries, l.flushQueueSize, e, l.ingestionMetadata, l.instanceName, f, p, l.loggerProvider, l.logLevel, l.minIdLength, l.offline, v, l.partnerId, l.plan, l.serverUrl, l.serverZone, h, l.sessionTimeout, l.storageProvider, _, l.transport, l.useBatch, y, w)]
                                                }
                                            })
                                        }))];
                                    case 1:
                                        return r = a.sent(), [4, e.prototype._init.call(this, r)];
                                    case 2:
                                        if (a.sent(), this.setSessionId(null !== (i = null !== (n = t.sessionId) && void 0 !== n ? n : this.config.sessionId) && void 0 !== i ? i : Date.now()), (o = ei(t.instanceName)).identityStore.setIdentity({
                                                userId: this.config.userId,
                                                deviceId: this.config.deviceId
                                            }), !(null !== this.config.offline)) return [3, 4];
                                        return [4, this.add(tp()).promise];
                                    case 3:
                                        a.sent(), a.label = 4;
                                    case 4:
                                        return [4, this.add(new j).promise];
                                    case 5:
                                        return a.sent(), [4, this.add(new eh).promise];
                                    case 6:
                                        return a.sent(), [4, this.add(new es).promise];
                                    case 7:
                                        if (a.sent(), tf(this.config), !eu(this.config.defaultTracking, "fileDownloads")) return [3, 9];
                                        return [4, this.add(tl()).promise];
                                    case 8:
                                        a.sent(), a.label = 9;
                                    case 9:
                                        if (!eu(this.config.defaultTracking, "formInteractions")) return [3, 11];
                                        return [4, this.add(ta()).promise];
                                    case 10:
                                        a.sent(), a.label = 11;
                                    case 11:
                                        if (!ea(this.config.defaultTracking)) return [3, 13];
                                        return s = tn(ea((f = this.config).defaultTracking) && f.defaultTracking && "object" == typeof f.defaultTracking && f.defaultTracking.attribution && "object" == typeof f.defaultTracking.attribution ? g({}, f.defaultTracking.attribution) : {}), [4, this.add(s).promise];
                                    case 12:
                                        a.sent(), a.label = 13;
                                    case 13:
                                        if (!ec(this.config.defaultTracking)) return [3, 15];
                                        return [4, this.add(tr(el(this.config))).promise];
                                    case 14:
                                        a.sent(), a.label = 15;
                                    case 15:
                                        return this.initializing = !1, [4, this.runQueuedFunctions("dispatchQ")];
                                    case 16:
                                        return a.sent(), o.eventBridge.setEventReceiver(function(e) {
                                            u.track(e.eventType, e.eventProperties)
                                        }), [2]
                                }
                            })
                        })
                    }, t.prototype.getUserId = function() {
                        var e;
                        return null === (e = this.config) || void 0 === e ? void 0 : e.userId
                    }, t.prototype.setUserId = function(e) {
                        if (!this.config) {
                            this.q.push(this.setUserId.bind(this, e));
                            return
                        }(e !== this.config.userId || void 0 === e) && (this.config.userId = e, er(e, this.config.instanceName))
                    }, t.prototype.getDeviceId = function() {
                        var e;
                        return null === (e = this.config) || void 0 === e ? void 0 : e.deviceId
                    }, t.prototype.setDeviceId = function(e) {
                        if (!this.config) {
                            this.q.push(this.setDeviceId.bind(this, e));
                            return
                        }
                        this.config.deviceId = e, eo(e, this.config.instanceName)
                    }, t.prototype.reset = function() {
                        this.setDeviceId(M()), this.setUserId(void 0)
                    }, t.prototype.getSessionId = function() {
                        var e;
                        return null === (e = this.config) || void 0 === e ? void 0 : e.sessionId
                    }, t.prototype.setSessionId = function(e) {
                        if (!this.config) {
                            this.q.push(this.setSessionId.bind(this, e));
                            return
                        }
                        if (e !== this.config.sessionId) {
                            var t, n = this.getSessionId(),
                                i = this.config.lastEventTime,
                                r = null !== (t = this.config.lastEventId) && void 0 !== t ? t : -1;
                            this.config.sessionId = e, this.config.lastEventTime = void 0, this.config.pageCounter = 0, eu(this.config.defaultTracking, "sessions") && (n && i && this.track(eL, void 0, {
                                device_id: this.previousSessionDeviceId,
                                event_id: ++r,
                                session_id: n,
                                time: i + 1,
                                user_id: this.previousSessionUserId
                            }), this.config.lastEventTime = this.config.sessionId, this.track(eA, void 0, {
                                event_id: ++r,
                                session_id: this.config.sessionId,
                                time: this.config.lastEventTime
                            })), this.previousSessionDeviceId = this.config.deviceId, this.previousSessionUserId = this.config.userId
                        }
                    }, t.prototype.extendSession = function() {
                        if (!this.config) {
                            this.q.push(this.extendSession.bind(this));
                            return
                        }
                        this.config.lastEventTime = Date.now()
                    }, t.prototype.setTransport = function(e) {
                        if (!this.config) {
                            this.q.push(this.setTransport.bind(this, e));
                            return
                        }
                        this.config.transportProvider = eJ(e)
                    }, t.prototype.identify = function(t, n) {
                        if (ep(t)) {
                            var i = t._q;
                            t._q = [], t = ef(new Q, i)
                        }
                        return (null == n ? void 0 : n.user_id) && this.setUserId(n.user_id), (null == n ? void 0 : n.device_id) && this.setDeviceId(n.device_id), e.prototype.identify.call(this, t, n)
                    }, t.prototype.groupIdentify = function(t, n, i, r) {
                        if (ep(i)) {
                            var o = i._q;
                            i._q = [], i = ef(new Q, o)
                        }
                        return e.prototype.groupIdentify.call(this, t, n, i, r)
                    }, t.prototype.revenue = function(t, n) {
                        if (ep(t)) {
                            var i = t._q;
                            t._q = [], t = ef(new $, i)
                        }
                        return e.prototype.revenue.call(this, t, n)
                    }, t.prototype.process = function(t) {
                        return m(this, void 0, void 0, function() {
                            var n, i;
                            return b(this, function(r) {
                                return n = Date.now(), i = ed(this.config.sessionTimeout, this.config.lastEventTime), t.event_type !== eA && t.event_type !== eL && (!t.session_id || t.session_id === this.getSessionId()) && i && this.setSessionId(n), [2, e.prototype.process.call(this, t)]
                            })
                        })
                    }, t
                }(J),
                th = {
                    init: k((a = new tv).init.bind(a), "init", S(a), T(a, ["config"])),
                    add: k(a.add.bind(a), "add", S(a), T(a, ["config.apiKey", "timeline.plugins"])),
                    remove: k(a.remove.bind(a), "remove", S(a), T(a, ["config.apiKey", "timeline.plugins"])),
                    track: k(a.track.bind(a), "track", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    logEvent: k(a.logEvent.bind(a), "logEvent", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    identify: k(a.identify.bind(a), "identify", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    groupIdentify: k(a.groupIdentify.bind(a), "groupIdentify", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    setGroup: k(a.setGroup.bind(a), "setGroup", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    revenue: k(a.revenue.bind(a), "revenue", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    flush: k(a.flush.bind(a), "flush", S(a), T(a, ["config.apiKey", "timeline.queue.length"])),
                    getUserId: k(a.getUserId.bind(a), "getUserId", S(a), T(a, ["config", "config.userId"])),
                    setUserId: k(a.setUserId.bind(a), "setUserId", S(a), T(a, ["config", "config.userId"])),
                    getDeviceId: k(a.getDeviceId.bind(a), "getDeviceId", S(a), T(a, ["config", "config.deviceId"])),
                    setDeviceId: k(a.setDeviceId.bind(a), "setDeviceId", S(a), T(a, ["config", "config.deviceId"])),
                    reset: k(a.reset.bind(a), "reset", S(a), T(a, ["config", "config.userId", "config.deviceId"])),
                    getSessionId: k(a.getSessionId.bind(a), "getSessionId", S(a), T(a, ["config"])),
                    setSessionId: k(a.setSessionId.bind(a), "setSessionId", S(a), T(a, ["config"])),
                    extendSession: k(a.extendSession.bind(a), "extendSession", S(a), T(a, ["config"])),
                    setOptOut: k(a.setOptOut.bind(a), "setOptOut", S(a), T(a, ["config"])),
                    setTransport: k(a.setTransport.bind(a), "setTransport", S(a), T(a, ["config"]))
                };
            th.add, th.extendSession, th.flush, th.getDeviceId, th.getSessionId, th.getUserId, th.groupIdentify, th.identify;
            var tg = th.init,
                ty = (th.logEvent, th.remove, th.reset, th.revenue, th.setDeviceId, th.setGroup, th.setOptOut, th.setSessionId, th.setTransport, th.setUserId, th.track)
        }
    }
]);