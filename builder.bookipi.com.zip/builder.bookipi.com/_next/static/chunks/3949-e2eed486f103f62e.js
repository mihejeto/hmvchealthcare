"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3949], {
        3949: function(e, t, r) {
            r.d(t, {
                Gr: function() {
                    return ex
                },
                Ny: function() {
                    return eF
                },
                cC: function() {
                    return eS
                },
                NQ: function() {
                    return ew
                }
            });
            var i, n, s = /^[a-zA-Z:_][a-zA-Z0-9:_.-]*$/,
                a = {
                    revert: function() {}
                },
                u = new Map,
                o = new Set;

            function c(e) {
                var t = u.get(e);
                return t || (t = {
                    element: e,
                    attributes: {}
                }, u.set(e, t)), t
            }

            function l(e, t, r, i, n) {
                var s = r(e),
                    a = {
                        isDirty: !1,
                        originalValue: s,
                        virtualValue: s,
                        mutations: [],
                        el: e,
                        _positionTimeout: null,
                        observer: new MutationObserver(function() {
                            if ("position" !== t || !a._positionTimeout) {
                                "position" === t && (a._positionTimeout = setTimeout(function() {
                                    a._positionTimeout = null
                                }, 1e3));
                                var i = r(e);
                                ("position" !== t || i.parentNode !== a.virtualValue.parentNode || i.insertBeforeNode !== a.virtualValue.insertBeforeNode) && i !== a.virtualValue && (a.originalValue = i, n(a))
                            }
                        }),
                        mutationRunner: n,
                        setValue: i,
                        getCurrentValue: r
                    };
                return "position" === t && e.parentNode ? a.observer.observe(e.parentNode, {
                    childList: !0,
                    subtree: !0,
                    attributes: !1,
                    characterData: !1
                }) : a.observer.observe(e, "html" === t ? {
                    childList: !0,
                    subtree: !0,
                    attributes: !0,
                    characterData: !0
                } : {
                    childList: !1,
                    subtree: !1,
                    attributes: !0,
                    attributeFilter: [t]
                }), a
            }

            function h(e, t) {
                var r = t.getCurrentValue(t.el);
                t.virtualValue = e, e && "string" != typeof e ? r && e.parentNode === r.parentNode && e.insertBeforeNode === r.insertBeforeNode || (t.isDirty = !0, B()) : e !== r && (t.isDirty = !0, B())
            }

            function f(e) {
                var t, r = e.originalValue;
                e.mutations.forEach(function(e) {
                    return r = e.mutate(r)
                }), h((t = r, i || (i = document.createElement("div")), i.innerHTML = t, i.innerHTML), e)
            }

            function d(e) {
                var t = new Set(e.originalValue.split(/\s+/).filter(Boolean));
                e.mutations.forEach(function(e) {
                    return e.mutate(t)
                }), h(Array.from(t).filter(Boolean).join(" "), e)
            }

            function p(e) {
                var t = e.originalValue;
                e.mutations.forEach(function(e) {
                    return t = e.mutate(t)
                }), h(t, e)
            }

            function _(e) {
                var t = e.originalValue;
                e.mutations.forEach(function(e) {
                    t = function(e) {
                        var t = e.parentSelector,
                            r = e.insertBeforeSelector,
                            i = document.querySelector(t);
                        if (!i) return null;
                        var n = r ? document.querySelector(r) : null;
                        return r && !n ? null : {
                            parentNode: i,
                            insertBeforeNode: n
                        }
                    }(e.mutate()) || t
                }), h(t, e)
            }
            var g = function(e) {
                    return e.innerHTML
                },
                m = function(e, t) {
                    return e.innerHTML = t
                };

            function y(e) {
                var t = c(e);
                return t.html || (t.html = l(e, "html", g, m, f)), t.html
            }
            var v = function(e) {
                    return {
                        parentNode: e.parentElement,
                        insertBeforeNode: e.nextElementSibling
                    }
                },
                b = function(e, t) {
                    (!t.insertBeforeNode || t.parentNode.contains(t.insertBeforeNode)) && t.parentNode.insertBefore(e, t.insertBeforeNode)
                };

            function k(e) {
                var t = c(e);
                return t.position || (t.position = l(e, "position", v, b, _)), t.position
            }
            var x = function(e, t) {
                    return t ? e.className = t : e.removeAttribute("class")
                },
                A = function(e) {
                    return e.className
                };

            function E(e) {
                var t = c(e);
                return t.classes || (t.classes = l(e, "class", A, x, d)), t.classes
            }

            function S(e, t) {
                var r = c(e);
                return r.attributes[t] || (r.attributes[t] = l(e, t, function(e) {
                    var r;
                    return null != (r = e.getAttribute(t)) ? r : null
                }, function(e, r) {
                    return null !== r ? e.setAttribute(t, r) : e.removeAttribute(t)
                }, p)), r.attributes[t]
            }

            function w(e, t, r) {
                if (r.isDirty) {
                    r.isDirty = !1;
                    var i, n, s, a, o, c, l, h, f, d, p = r.virtualValue;
                    !r.mutations.length && (d = u.get(e)) && ("html" === t ? (null == (i = d.html) || null == (n = i.observer) || n.disconnect(), delete d.html) : "class" === t ? (null == (s = d.classes) || null == (a = s.observer) || a.disconnect(), delete d.classes) : "position" === t ? (null == (o = d.position) || null == (c = o.observer) || c.disconnect(), delete d.position) : (null == (l = d.attributes) || null == (h = l[t]) || null == (f = h.observer) || f.disconnect(), delete d.attributes[t])), r.setValue(e, p)
                }
            }

            function F(e, t) {
                e.html && w(t, "html", e.html), e.classes && w(t, "class", e.classes), e.position && w(t, "position", e.position), Object.keys(e.attributes).forEach(function(r) {
                    w(t, r, e.attributes[r])
                })
            }

            function B() {
                u.forEach(F)
            }

            function R(e) {
                if ("position" !== e.kind || 1 !== e.elements.size) {
                    var t = new Set(e.elements);
                    document.querySelectorAll(e.selector).forEach(function(r) {
                        if (!t.has(r)) {
                            var i;
                            e.elements.add(r), i = null, "html" === e.kind ? i = y(r) : "class" === e.kind ? i = E(r) : "attribute" === e.kind ? i = S(r, e.attribute) : "position" === e.kind && (i = k(r)), i && (i.mutations.push(e), i.mutationRunner(i))
                        }
                    })
                }
            }

            function V() {
                o.forEach(R)
            }

            function C(e) {
                return "undefined" == typeof document ? a : (o.add(e), R(e), {
                    revert: function() {
                        e.elements.forEach(function(t) {
                            return function(e, t) {
                                var r = null;
                                if ("html" === e.kind ? r = y(t) : "class" === e.kind ? r = E(t) : "attribute" === e.kind ? r = S(t, e.attribute) : "position" === e.kind && (r = k(t)), r) {
                                    var i = r.mutations.indexOf(e); - 1 !== i && r.mutations.splice(i, 1), r.mutationRunner(r)
                                }
                            }(e, t)
                        }), e.elements.clear(), o.delete(e)
                    }
                })
            }

            function O(e, t) {
                return C({
                    kind: "html",
                    elements: new Set,
                    mutate: t,
                    selector: e
                })
            }

            function T(e, t) {
                return C({
                    kind: "position",
                    elements: new Set,
                    mutate: t,
                    selector: e
                })
            }

            function N(e, t) {
                return C({
                    kind: "class",
                    elements: new Set,
                    mutate: t,
                    selector: e
                })
            }

            function $(e, t, r) {
                return s.test(t) ? "class" === t || "className" === t ? N(e, function(e) {
                    var t = r(Array.from(e).join(" "));
                    e.clear(), t && t.split(/\s+/g).filter(Boolean).forEach(function(t) {
                        return e.add(t)
                    })
                }) : C({
                    kind: "attribute",
                    attribute: t,
                    elements: new Set,
                    mutate: r,
                    selector: e
                }) : a
            }
            "undefined" != typeof document && (n || (n = new MutationObserver(function() {
                V()
            })), V(), n.observe(document.documentElement, {
                childList: !0,
                subtree: !0,
                attributes: !1,
                characterData: !1
            }));
            var K = {
                html: O,
                classes: N,
                attribute: $,
                position: T,
                declarative: function(e) {
                    var t = e.selector,
                        r = e.action,
                        i = e.value,
                        n = e.attribute,
                        s = e.parentSelector,
                        u = e.insertBeforeSelector;
                    if ("html" === n) {
                        if ("append" === r) return O(t, function(e) {
                            return e + (null != i ? i : "")
                        });
                        if ("set" === r) return O(t, function() {
                            return null != i ? i : ""
                        })
                    } else if ("class" === n) {
                        if ("append" === r) return N(t, function(e) {
                            i && e.add(i)
                        });
                        if ("remove" === r) return N(t, function(e) {
                            i && e.delete(i)
                        });
                        if ("set" === r) return N(t, function(e) {
                            e.clear(), i && e.add(i)
                        })
                    } else if ("position" === n) {
                        if ("set" === r && s) return T(t, function() {
                            return {
                                insertBeforeSelector: u,
                                parentSelector: s
                            }
                        })
                    } else {
                        if ("append" === r) return $(t, n, function(e) {
                            return null !== e ? e + (null != i ? i : "") : null != i ? i : ""
                        });
                        if ("set" === r) return $(t, n, function() {
                            return null != i ? i : ""
                        });
                        if ("remove" === r) return $(t, n, function() {
                            return null
                        })
                    }
                    return a
                }
            };

            function I(e) {
                let t = 2166136261,
                    r = e.length;
                for (let i = 0; i < r; i++) t ^= e.charCodeAt(i), t += (t << 1) + (t << 4) + (t << 7) + (t << 8) + (t << 24);
                return t >>> 0
            }

            function M(e, t, r) {
                return 2 === r ? I(I(e + t) + "") % 1e4 / 1e4 : 1 === r ? I(t + e) % 1e3 / 1e3 : null
            }

            function H(e, t) {
                return e >= t[0] && e < t[1]
            }

            function D(e) {
                try {
                    let t = e.replace(/([^\\])\//g, "$1\\/");
                    return new RegExp(t)
                } catch (e) {
                    console.error(e);
                    return
                }
            }
            let L = e => Uint8Array.from(atob(e), e => e.charCodeAt(0));
            async function U(e, t, r) {
                if (t = t || "", !(r = r || globalThis.crypto && globalThis.crypto.subtle)) throw Error("No SubtleCrypto implementation found");
                try {
                    let i = await r.importKey("raw", L(t), {
                            name: "AES-CBC",
                            length: 128
                        }, !0, ["encrypt", "decrypt"]),
                        [n, s] = e.split("."),
                        a = await r.decrypt({
                            name: "AES-CBC",
                            iv: L(n)
                        }, i, L(s));
                    return new TextDecoder().decode(a)
                } catch (e) {
                    throw Error("Failed to decrypt")
                }
            }

            function P(e) {
                return "string" == typeof e ? e : JSON.stringify(e)
            }

            function j(e) {
                "number" == typeof e && (e += ""), e && "string" == typeof e || (e = "0");
                let t = e.replace(/(^v|\+.*$)/g, "").split(/[-.]/);
                return 3 === t.length && t.push("~"), t.map(e => e.match(/^[0-9]+$/) ? e.padStart(5, " ") : e).join("-")
            }
            let J = {};

            function q(e, t) {
                if ("$or" in t) return G(e, t.$or);
                if ("$nor" in t) return !G(e, t.$nor);
                if ("$and" in t) return function(e, t) {
                    for (let r = 0; r < t.length; r++)
                        if (!q(e, t[r])) return !1;
                    return !0
                }(e, t.$and);
                if ("$not" in t) return !q(e, t.$not);
                for (let [r, i] of Object.entries(t))
                    if (! function e(t, r) {
                            if ("string" == typeof t) return r + "" === t;
                            if ("number" == typeof t) return 1 * r === t;
                            if ("boolean" == typeof t) return !!r === t;
                            if (null === t) return null === r;
                            if (Array.isArray(t) || !z(t)) return JSON.stringify(r) === JSON.stringify(t);
                            for (let i in t)
                                if (! function(t, r, i) {
                                        switch (t) {
                                            case "$veq":
                                                return j(r) === j(i);
                                            case "$vne":
                                                return j(r) !== j(i);
                                            case "$vgt":
                                                return j(r) > j(i);
                                            case "$vgte":
                                                return j(r) >= j(i);
                                            case "$vlt":
                                                return j(r) < j(i);
                                            case "$vlte":
                                                return j(r) <= j(i);
                                            case "$eq":
                                                return r === i;
                                            case "$ne":
                                                return r !== i;
                                            case "$lt":
                                                return r < i;
                                            case "$lte":
                                                return r <= i;
                                            case "$gt":
                                                return r > i;
                                            case "$gte":
                                                return r >= i;
                                            case "$exists":
                                                return i ? null != r : null == r;
                                            case "$in":
                                                if (!Array.isArray(i)) return !1;
                                                return Q(r, i);
                                            case "$nin":
                                                if (!Array.isArray(i)) return !1;
                                                return !Q(r, i);
                                            case "$not":
                                                return !e(i, r);
                                            case "$size":
                                                if (!Array.isArray(r)) return !1;
                                                return e(i, r.length);
                                            case "$elemMatch":
                                                return function(t, r) {
                                                    if (!Array.isArray(t)) return !1;
                                                    let i = z(r) ? t => e(r, t) : e => q(e, r);
                                                    for (let e = 0; e < t.length; e++)
                                                        if (t[e] && i(t[e])) return !0;
                                                    return !1
                                                }(r, i);
                                            case "$all":
                                                if (!Array.isArray(r)) return !1;
                                                for (let t = 0; t < i.length; t++) {
                                                    let n = !1;
                                                    for (let s = 0; s < r.length; s++)
                                                        if (e(i[t], r[s])) {
                                                            n = !0;
                                                            break
                                                        }
                                                    if (!n) return !1
                                                }
                                                return !0;
                                            case "$regex":
                                                try {
                                                    return (J[i] || (J[i] = new RegExp(i.replace(/([^\\])\//g, "$1\\/"))), J[i]).test(r)
                                                } catch (e) {
                                                    return !1
                                                }
                                            case "$type":
                                                return function(e) {
                                                    if (null === e) return "null";
                                                    if (Array.isArray(e)) return "array";
                                                    let t = typeof e;
                                                    return ["string", "number", "boolean", "object", "undefined"].includes(t) ? t : "unknown"
                                                }(r) === i;
                                            default:
                                                return console.error("Unknown operator: " + t), !1
                                        }
                                    }(i, r, t[i])) return !1;
                            return !0
                        }(i, function(e, t) {
                            let r = t.split("."),
                                i = e;
                            for (let e = 0; e < r.length; e++) {
                                if (!i || "object" != typeof i || !(r[e] in i)) return null;
                                i = i[r[e]]
                            }
                            return i
                        }(e, r))) return !1;
                return !0
            }

            function z(e) {
                let t = Object.keys(e);
                return t.length > 0 && t.filter(e => "$" === e[0]).length === t.length
            }

            function Q(e, t) {
                return Array.isArray(e) ? e.some(e => t.includes(e)) : t.includes(e)
            }

            function G(e, t) {
                if (!t.length) return !0;
                for (let r = 0; r < t.length; r++)
                    if (q(e, t[r])) return !0;
                return !1
            }
            let Z = {
                    staleTTL: 6e4,
                    maxAge: 864e5,
                    cacheKey: "gbFeaturesCache",
                    backgroundSync: !0,
                    maxEntries: 10,
                    disableIdleStreams: !1,
                    idleStreamInterval: 2e4
                },
                W = {
                    fetch: globalThis.fetch ? globalThis.fetch.bind(globalThis) : void 0,
                    SubtleCrypto: globalThis.crypto ? globalThis.crypto.subtle : void 0,
                    EventSource: globalThis.EventSource
                },
                X = {
                    fetchFeaturesCall: e => {
                        let {
                            host: t,
                            clientKey: r,
                            headers: i
                        } = e;
                        return W.fetch("".concat(t, "/api/features/").concat(r), {
                            headers: i
                        })
                    },
                    fetchRemoteEvalCall: e => {
                        let {
                            host: t,
                            clientKey: r,
                            payload: i,
                            headers: n
                        } = e, s = {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                ...n
                            },
                            body: JSON.stringify(i)
                        };
                        return W.fetch("".concat(t, "/api/eval/").concat(r), s)
                    },
                    eventSourceCall: e => {
                        let {
                            host: t,
                            clientKey: r,
                            headers: i
                        } = e;
                        return i ? new W.EventSource("".concat(t, "/sub/").concat(r), {
                            headers: i
                        }) : new W.EventSource("".concat(t, "/sub/").concat(r))
                    },
                    startIdleListener: () => {
                        let e;
                        let t = "undefined" != typeof window && "undefined" != typeof document;
                        if (!t) return;
                        let r = () => {
                            "visible" === document.visibilityState ? (window.clearTimeout(e), ei.forEach(e => {
                                e && "idle" === e.state && ev(e)
                            })) : "hidden" === document.visibilityState && (e = window.setTimeout(ea, Z.idleStreamInterval))
                        };
                        return document.addEventListener("visibilitychange", r), () => document.removeEventListener("visibilitychange", r)
                    },
                    stopIdleListener: () => {}
                };
            try {
                globalThis.localStorage && (W.localStorage = globalThis.localStorage)
            } catch (e) {}
            let Y = new Map,
                ee = !1,
                et = new Map,
                er = new Map,
                ei = new Map,
                en = new Set;
            async function es(e, t, r, i, n, s) {
                s || (Z.backgroundSync = !1);
                let a = await eo(e, i, t, r);
                n && a && await ep(e, a)
            }

            function ea() {
                ei.forEach(e => {
                    e && (e.state = "idle", ey(e))
                })
            }
            async function eu() {
                try {
                    if (!W.localStorage) return;
                    await W.localStorage.setItem(Z.cacheKey, JSON.stringify(Array.from(et.entries())))
                } catch (e) {}
            }
            async function eo(e, t, r, i) {
                var n;
                let s = ec(e),
                    a = el(e),
                    u = new Date,
                    o = new Date(u.getTime() - Z.maxAge + Z.staleTTL);
                await eh();
                let c = et.get(a);
                return c && !i && (t || c.staleAt > u) && c.staleAt > o ? (c.sse && en.add(s), c.staleAt < u ? e_(e) : eg(e), c.data) : await (n = e_(e), new Promise(e => {
                    let t, i = !1,
                        s = r => {
                            i || (i = !0, t && clearTimeout(t), e(r || null))
                        };
                    r && (t = setTimeout(() => s(), r)), n.then(e => s(e)).catch(() => s())
                }))
            }

            function ec(e) {
                let [t, r] = e.getApiInfo();
                return "".concat(t, "||").concat(r)
            }

            function el(e) {
                let t = ec(e);
                if (!e.isRemoteEval()) return t;
                let r = e.getAttributes(),
                    i = e.getCacheKeyAttributes() || Object.keys(e.getAttributes()),
                    n = {};
                i.forEach(e => {
                    n[e] = r[e]
                });
                let s = e.getForcedVariations(),
                    a = e.getUrl();
                return "".concat(t, "||").concat(JSON.stringify({
                    ca: n,
                    fv: s,
                    url: a
                }))
            }
            async function eh() {
                if (!ee) {
                    ee = !0;
                    try {
                        if (W.localStorage) {
                            let e = await W.localStorage.getItem(Z.cacheKey);
                            if (e) {
                                let t = JSON.parse(e);
                                t && Array.isArray(t) && t.forEach(e => {
                                    let [t, r] = e;
                                    et.set(t, { ...r,
                                        staleAt: new Date(r.staleAt)
                                    })
                                }), ef()
                            }
                        }
                    } catch (e) {}
                    if (!Z.disableIdleStreams) {
                        let e = X.startIdleListener();
                        e && (X.stopIdleListener = e)
                    }
                }
            }

            function ef() {
                let e = Array.from(et.entries()).map(e => {
                        let [t, r] = e;
                        return {
                            key: t,
                            staleAt: r.staleAt.getTime()
                        }
                    }).sort((e, t) => e.staleAt - t.staleAt),
                    t = Math.min(Math.max(0, et.size - Z.maxEntries), et.size);
                for (let r = 0; r < t; r++) et.delete(e[r].key)
            }

            function ed(e, t, r) {
                let i = r.dateUpdated || "",
                    n = new Date(Date.now() + Z.staleTTL),
                    s = et.get(t);
                if (s && i && s.version === i) {
                    s.staleAt = n, eu();
                    return
                }
                et.set(t, {
                    data: r,
                    version: i,
                    staleAt: n,
                    sse: en.has(e)
                }), ef(), eu();
                let a = Y.get(e);
                a && a.forEach(e => ep(e, r))
            }
            async function ep(e, t) {
                t = await e.decryptPayload(t, void 0, W.SubtleCrypto), await e.refreshStickyBuckets(t), e.setExperiments(t.experiments || e.getExperiments()), e.setFeatures(t.features || e.getFeatures())
            }
            async function e_(e) {
                let {
                    apiHost: t,
                    apiRequestHeaders: r
                } = e.getApiHosts(), i = e.getClientKey(), n = e.isRemoteEval(), s = ec(e), a = el(e), u = er.get(a);
                if (!u) {
                    let o = n ? X.fetchRemoteEvalCall({
                        host: t,
                        clientKey: i,
                        payload: {
                            attributes: e.getAttributes(),
                            forcedVariations: e.getForcedVariations(),
                            forcedFeatures: Array.from(e.getForcedFeatures().entries()),
                            url: e.getUrl()
                        },
                        headers: r
                    }) : X.fetchFeaturesCall({
                        host: t,
                        clientKey: i,
                        headers: r
                    });
                    u = o.then(e => {
                        if (!e.ok) throw Error("HTTP error: ".concat(e.status));
                        return "enabled" === e.headers.get("x-sse-support") && en.add(s), e.json()
                    }).then(t => (ed(s, a, t), eg(e), er.delete(a), t)).catch(e => (er.delete(a), Promise.resolve({}))), er.set(a, u)
                }
                return await u
            }

            function eg(e) {
                let t = ec(e),
                    r = el(e),
                    {
                        streamingHost: i,
                        streamingHostRequestHeaders: n
                    } = e.getApiHosts(),
                    s = e.getClientKey();
                if (Z.backgroundSync && en.has(t) && W.EventSource) {
                    if (ei.has(t)) return;
                    let e = {
                        src: null,
                        host: i,
                        clientKey: s,
                        headers: n,
                        cb: i => {
                            try {
                                if ("features-updated" === i.type) {
                                    let e = Y.get(t);
                                    e && e.forEach(e => {
                                        e_(e)
                                    })
                                } else if ("features" === i.type) {
                                    let e = JSON.parse(i.data);
                                    ed(t, r, e)
                                }
                                e.errors = 0
                            } catch (t) {
                                em(e)
                            }
                        },
                        errors: 0,
                        state: "active"
                    };
                    ei.set(t, e), ev(e)
                }
            }

            function em(e) {
                if ("idle" !== e.state && (e.errors++, e.errors > 3 || e.src && 2 === e.src.readyState)) {
                    let t = Math.pow(3, e.errors - 3) * (1e3 + 1e3 * Math.random());
                    ey(e), setTimeout(() => {
                        ["idle", "active"].includes(e.state) || ev(e)
                    }, Math.min(t, 3e5))
                }
            }

            function ey(e) {
                e.src && (e.src.onopen = null, e.src.onerror = null, e.src.close(), e.src = null, "active" === e.state && (e.state = "disabled"))
            }

            function ev(e) {
                e.src = X.eventSourceCall({
                    host: e.host,
                    clientKey: e.clientKey,
                    headers: e.headers
                }), e.state = "active", e.src.addEventListener("features", e.cb), e.src.addEventListener("features-updated", e.cb), e.src.onerror = () => em(e), e.src.onopen = () => {
                    e.errors = 0
                }
            }
            let eb = "undefined" != typeof window && "undefined" != typeof document,
                ek = function() {
                    let e;
                    try {
                        e = "0.34.0"
                    } catch (t) {
                        e = ""
                    }
                    return e
                }();
            class ex {
                constructor(e) {
                    if (e = e || {}, this.version = ek, this._ctx = this.context = e, this._renderer = null, this._trackedExperiments = new Set, this._trackedFeatures = {}, this.debug = !1, this._subscriptions = new Set, this._rtQueue = [], this._rtTimer = 0, this.ready = !1, this._assigned = new Map, this._forcedFeatureValues = new Map, this._attributeOverrides = {}, this._activeAutoExperiments = new Map, this._triggeredExpKeys = new Set, this._loadFeaturesCalled = !1, e.remoteEval) {
                        if (e.decryptionKey) throw Error("Encryption is not available for remoteEval");
                        if (!e.clientKey) throw Error("Missing clientKey");
                        let t = !1;
                        try {
                            t = !!new URL(e.apiHost || "").hostname.match(/growthbook\.io$/i)
                        } catch (e) {}
                        if (t) throw Error("Cannot use remoteEval on GrowthBook Cloud")
                    } else if (e.cacheKeyAttributes) throw Error("cacheKeyAttributes are only used for remoteEval");
                    e.features && (this.ready = !0), eb && e.enableDevMode && (window._growthbook = this, document.dispatchEvent(new Event("gbloaded"))), e.experiments && (this.ready = !0, this._updateAllAutoExperiments()), e.clientKey && !e.remoteEval && this._refresh({}, !0, !1)
                }
                async loadFeatures(e) {
                    e && e.autoRefresh && (this._ctx.subscribeToChanges = !0), this._loadFeaturesCalled = !0, await this._refresh(e, !0, !0), this._canSubscribe() && function(e) {
                        let t = ec(e),
                            r = Y.get(t) || new Set;
                        r.add(e), Y.set(t, r)
                    }(this)
                }
                async refreshFeatures(e) {
                    await this._refresh(e, !1, !0)
                }
                getApiInfo() {
                    return [this.getApiHosts().apiHost, this.getClientKey()]
                }
                getApiHosts() {
                    let e = this._ctx.apiHost || "https://cdn.growthbook.io";
                    return {
                        apiHost: e.replace(/\/*$/, ""),
                        streamingHost: (this._ctx.streamingHost || e).replace(/\/*$/, ""),
                        apiRequestHeaders: this._ctx.apiHostRequestHeaders,
                        streamingHostRequestHeaders: this._ctx.streamingHostRequestHeaders
                    }
                }
                getClientKey() {
                    return this._ctx.clientKey || ""
                }
                isRemoteEval() {
                    return this._ctx.remoteEval || !1
                }
                getCacheKeyAttributes() {
                    return this._ctx.cacheKeyAttributes
                }
                async _refresh(e, t, r) {
                    if (e = e || {}, !this._ctx.clientKey) throw Error("Missing clientKey");
                    await es(this, e.timeout, e.skipCache || this._ctx.enableDevMode, t, r, !1 !== this._ctx.backgroundSync)
                }
                _render() {
                    this._renderer && this._renderer()
                }
                setFeatures(e) {
                    this._ctx.features = e, this.ready = !0, this._render()
                }
                async setEncryptedFeatures(e, t, r) {
                    let i = await U(e, t || this._ctx.decryptionKey, r);
                    this.setFeatures(JSON.parse(i))
                }
                setExperiments(e) {
                    this._ctx.experiments = e, this.ready = !0, this._updateAllAutoExperiments()
                }
                async setEncryptedExperiments(e, t, r) {
                    let i = await U(e, t || this._ctx.decryptionKey, r);
                    this.setExperiments(JSON.parse(i))
                }
                async decryptPayload(e, t, r) {
                    return e.encryptedFeatures && (e.features = JSON.parse(await U(e.encryptedFeatures, t || this._ctx.decryptionKey, r)), delete e.encryptedFeatures), e.encryptedExperiments && (e.experiments = JSON.parse(await U(e.encryptedExperiments, t || this._ctx.decryptionKey, r)), delete e.encryptedExperiments), e
                }
                async setAttributes(e) {
                    if (this._ctx.attributes = e, this._ctx.stickyBucketService && await this.refreshStickyBuckets(), this._ctx.remoteEval) {
                        await this._refreshForRemoteEval();
                        return
                    }
                    this._render(), this._updateAllAutoExperiments()
                }
                async setAttributeOverrides(e) {
                    if (this._attributeOverrides = e, this._ctx.stickyBucketService && await this.refreshStickyBuckets(), this._ctx.remoteEval) {
                        await this._refreshForRemoteEval();
                        return
                    }
                    this._render(), this._updateAllAutoExperiments()
                }
                async setForcedVariations(e) {
                    if (this._ctx.forcedVariations = e || {}, this._ctx.remoteEval) {
                        await this._refreshForRemoteEval();
                        return
                    }
                    this._render(), this._updateAllAutoExperiments()
                }
                setForcedFeatures(e) {
                    this._forcedFeatureValues = e, this._render()
                }
                async setURL(e) {
                    if (this._ctx.url = e, this._ctx.remoteEval) {
                        await this._refreshForRemoteEval(), this._updateAllAutoExperiments(!0);
                        return
                    }
                    this._updateAllAutoExperiments(!0)
                }
                getAttributes() {
                    return { ...this._ctx.attributes,
                        ...this._attributeOverrides
                    }
                }
                getForcedVariations() {
                    return this._ctx.forcedVariations || {}
                }
                getForcedFeatures() {
                    return this._forcedFeatureValues || new Map
                }
                getStickyBucketAssignmentDocs() {
                    return this._ctx.stickyBucketAssignmentDocs || {}
                }
                getUrl() {
                    return this._ctx.url || ""
                }
                getFeatures() {
                    return this._ctx.features || {}
                }
                getExperiments() {
                    return this._ctx.experiments || []
                }
                subscribe(e) {
                    return this._subscriptions.add(e), () => {
                        this._subscriptions.delete(e)
                    }
                }
                _canSubscribe() {
                    return !1 !== this._ctx.backgroundSync && this._ctx.subscribeToChanges
                }
                async _refreshForRemoteEval() {
                    this._ctx.remoteEval && this._loadFeaturesCalled && await this._refresh({}, !1, !0).catch(() => {})
                }
                getAllResults() {
                    return new Map(this._assigned)
                }
                destroy() {
                    var e;
                    this._subscriptions.clear(), this._assigned.clear(), this._trackedExperiments.clear(), this._trackedFeatures = {}, this._rtQueue = [], this._rtTimer && clearTimeout(this._rtTimer), e = this, Y.forEach(t => t.delete(e)), eb && window._growthbook === this && delete window._growthbook, this._activeAutoExperiments.forEach(e => {
                        e.undo()
                    }), this._activeAutoExperiments.clear(), this._triggeredExpKeys.clear()
                }
                setRenderer(e) {
                    this._renderer = e
                }
                forceVariation(e, t) {
                    if (this._ctx.forcedVariations = this._ctx.forcedVariations || {}, this._ctx.forcedVariations[e] = t, this._ctx.remoteEval) {
                        this._refreshForRemoteEval();
                        return
                    }
                    this._updateAllAutoExperiments(), this._render()
                }
                run(e) {
                    let t = this._run(e, null);
                    return this._fireSubscriptions(e, t), t
                }
                triggerExperiment(e) {
                    if (this._triggeredExpKeys.add(e), !this._ctx.experiments) return null;
                    let t = this._ctx.experiments.filter(t => t.key === e);
                    return t.map(e => e.manual ? this._runAutoExperiment(e) : null).filter(e => null !== e)
                }
                _runAutoExperiment(e, t) {
                    let r = this._activeAutoExperiments.get(e);
                    if (e.manual && !this._triggeredExpKeys.has(e.key) && !r) return null;
                    let i = this.run(e),
                        n = JSON.stringify(i.value);
                    if (!t && i.inExperiment && r && r.valueHash === n) return i;
                    if (r && this._undoActiveAutoExperiment(e), i.inExperiment) {
                        let t = this._applyDOMChanges(i.value);
                        t && this._activeAutoExperiments.set(e, {
                            undo: t,
                            valueHash: n
                        })
                    }
                    return i
                }
                _undoActiveAutoExperiment(e) {
                    let t = this._activeAutoExperiments.get(e);
                    t && (t.undo(), this._activeAutoExperiments.delete(e))
                }
                _updateAllAutoExperiments(e) {
                    let t = this._ctx.experiments || [],
                        r = new Set(t);
                    this._activeAutoExperiments.forEach((e, t) => {
                        r.has(t) || (e.undo(), this._activeAutoExperiments.delete(t))
                    }), t.forEach(t => {
                        this._runAutoExperiment(t, e)
                    })
                }
                _fireSubscriptions(e, t) {
                    let r = e.key,
                        i = this._assigned.get(r);
                    i && i.result.inExperiment === t.inExperiment && i.result.variationId === t.variationId || (this._assigned.set(r, {
                        experiment: e,
                        result: t
                    }), this._subscriptions.forEach(r => {
                        try {
                            r(e, t)
                        } catch (e) {
                            console.error(e)
                        }
                    }))
                }
                _trackFeatureUsage(e, t) {
                    if ("override" === t.source) return;
                    let r = JSON.stringify(t.value);
                    if (this._trackedFeatures[e] !== r) {
                        if (this._trackedFeatures[e] = r, this._ctx.onFeatureUsage) try {
                            this._ctx.onFeatureUsage(e, t)
                        } catch (e) {}
                        eb && window.fetch && (this._rtQueue.push({
                            key: e,
                            on: t.on
                        }), this._rtTimer || (this._rtTimer = window.setTimeout(() => {
                            this._rtTimer = 0;
                            let e = [...this._rtQueue];
                            this._rtQueue = [], this._ctx.realtimeKey && window.fetch("https://rt.growthbook.io/?key=".concat(this._ctx.realtimeKey, "&events=").concat(encodeURIComponent(JSON.stringify(e))), {
                                cache: "no-cache",
                                mode: "no-cors"
                            }).catch(() => {})
                        }, this._ctx.realtimeInterval || 2e3)))
                    }
                }
                _getFeatureResult(e, t, r, i, n, s) {
                    let a = {
                        value: t,
                        on: !!t,
                        off: !t,
                        source: r,
                        ruleId: i || ""
                    };
                    return n && (a.experiment = n), s && (a.experimentResult = s), this._trackFeatureUsage(e, a), a
                }
                isOn(e) {
                    return this.evalFeature(e).on
                }
                isOff(e) {
                    return this.evalFeature(e).off
                }
                getFeatureValue(e, t) {
                    let r = this.evalFeature(e).value;
                    return null === r ? t : r
                }
                feature(e) {
                    return this.evalFeature(e)
                }
                evalFeature(e) {
                    return this._evalFeature(e)
                }
                _evalFeature(e, t) {
                    if ((t = t || {
                            evaluatedFeatures: new Set
                        }).evaluatedFeatures.has(e)) return this._getFeatureResult(e, null, "cyclicPrerequisite");
                    if (t.evaluatedFeatures.add(e), t.id = e, this._forcedFeatureValues.has(e)) return this._getFeatureResult(e, this._forcedFeatureValues.get(e), "override");
                    if (!this._ctx.features || !this._ctx.features[e]) return this._getFeatureResult(e, null, "unknownFeature");
                    let r = this._ctx.features[e];
                    if (r.rules) e: for (let i of r.rules) {
                        if (i.parentConditions)
                            for (let r of i.parentConditions) {
                                let i = this._evalFeature(r.id, t);
                                if ("cyclicPrerequisite" === i.source) return this._getFeatureResult(e, null, "cyclicPrerequisite");
                                let n = {
                                        value: i.value
                                    },
                                    s = q(n, r.condition || {});
                                if (!s) {
                                    if (r.gate) return this._getFeatureResult(e, null, "prerequisite");
                                    continue e
                                }
                            }
                        if (i.filters && this._isFilteredOut(i.filters)) continue;
                        if ("force" in i) {
                            if (i.condition && !this._conditionPasses(i.condition) || !this._isIncludedInRollout(i.seed || e, i.hashAttribute, this._ctx.stickyBucketService && !i.disableStickyBucketing ? i.fallbackAttribute : void 0, i.range, i.coverage, i.hashVersion)) continue;
                            return i.tracks && i.tracks.forEach(e => {
                                this._track(e.experiment, e.result)
                            }), this._getFeatureResult(e, i.force, "force", i.id)
                        }
                        if (!i.variations) continue;
                        let r = {
                            variations: i.variations,
                            key: i.key || e
                        };
                        "coverage" in i && (r.coverage = i.coverage), i.weights && (r.weights = i.weights), i.hashAttribute && (r.hashAttribute = i.hashAttribute), i.fallbackAttribute && (r.fallbackAttribute = i.fallbackAttribute), i.disableStickyBucketing && (r.disableStickyBucketing = i.disableStickyBucketing), void 0 !== i.bucketVersion && (r.bucketVersion = i.bucketVersion), void 0 !== i.minBucketVersion && (r.minBucketVersion = i.minBucketVersion), i.namespace && (r.namespace = i.namespace), i.meta && (r.meta = i.meta), i.ranges && (r.ranges = i.ranges), i.name && (r.name = i.name), i.phase && (r.phase = i.phase), i.seed && (r.seed = i.seed), i.hashVersion && (r.hashVersion = i.hashVersion), i.filters && (r.filters = i.filters), i.condition && (r.condition = i.condition);
                        let n = this._run(r, e);
                        if (this._fireSubscriptions(r, n), n.inExperiment && !n.passthrough) return this._getFeatureResult(e, n.value, "experiment", i.id, r, n)
                    }
                    return this._getFeatureResult(e, void 0 === r.defaultValue ? null : r.defaultValue, "defaultValue")
                }
                _isIncludedInRollout(e, t, r, i, n, s) {
                    if (!i && void 0 === n) return !0;
                    let {
                        hashValue: a
                    } = this._getHashAttribute(t, r);
                    if (!a) return !1;
                    let u = M(e, a, s || 1);
                    return null !== u && (i ? H(u, i) : void 0 === n || u <= n)
                }
                _conditionPasses(e) {
                    return q(this.getAttributes(), e)
                }
                _isFilteredOut(e) {
                    return e.some(e => {
                        let {
                            hashValue: t
                        } = this._getHashAttribute(e.attribute);
                        if (!t) return !0;
                        let r = M(e.seed, t, e.hashVersion || 2);
                        return null === r || !e.ranges.some(e => H(r, e))
                    })
                }
                _run(e, t) {
                    let r = e.key,
                        i = e.variations.length;
                    if (i < 2 || !1 === this._ctx.enabled || (e = this._mergeOverrides(e)).urlPatterns && ! function(e, t) {
                            if (!t.length) return !1;
                            let r = !1,
                                i = !1;
                            for (let n = 0; n < t.length; n++) {
                                let s = function(e, t, r) {
                                    try {
                                        let i = new URL(e, "https://_");
                                        if ("regex" === t) {
                                            let e = D(r);
                                            if (!e) return !1;
                                            return e.test(i.href) || e.test(i.href.substring(i.origin.length))
                                        }
                                        if ("simple" === t) return function(e, t) {
                                            try {
                                                let r = new URL(t.replace(/^([^:/?]*)\./i, "https://$1.").replace(/\*/g, "_____"), "https://_____"),
                                                    i = [
                                                        [e.host, r.host, !1],
                                                        [e.pathname, r.pathname, !0]
                                                    ];
                                                return r.hash && i.push([e.hash, r.hash, !1]), r.searchParams.forEach((t, r) => {
                                                    i.push([e.searchParams.get(r) || "", t, !1])
                                                }), !i.some(e => ! function(e, t, r) {
                                                    try {
                                                        let i = t.replace(/[*.+?^${}()|[\]\\]/g, "\\$&").replace(/_____/g, ".*");
                                                        r && (i = "\\/?" + i.replace(/(^\/|\/$)/g, "") + "\\/?");
                                                        let n = RegExp("^" + i + "$", "i");
                                                        return n.test(e)
                                                    } catch (e) {
                                                        return !1
                                                    }
                                                }(e[0], e[1], e[2]))
                                            } catch (e) {
                                                return !1
                                            }
                                        }(i, r);
                                        return !1
                                    } catch (e) {
                                        return !1
                                    }
                                }(e, t[n].type, t[n].pattern);
                                if (!1 === t[n].include) {
                                    if (s) return !1
                                } else r = !0, s && (i = !0)
                            }
                            return i || !r
                        }(this._getContextUrl(), e.urlPatterns)) return this._getResult(e, -1, !1, t);
                    let n = function(e, t, r) {
                        if (!t) return null;
                        let i = t.split("?")[1];
                        if (!i) return null;
                        let n = i.replace(/#.*/, "").split("&").map(e => e.split("=", 2)).filter(t => {
                            let [r] = t;
                            return r === e
                        }).map(e => {
                            let [, t] = e;
                            return parseInt(t)
                        });
                        return n.length > 0 && n[0] >= 0 && n[0] < r ? n[0] : null
                    }(r, this._getContextUrl(), i);
                    if (null !== n) return this._getResult(e, n, !1, t);
                    if (this._ctx.forcedVariations && r in this._ctx.forcedVariations) {
                        let i = this._ctx.forcedVariations[r];
                        return this._getResult(e, i, !1, t)
                    }
                    if ("draft" === e.status || !1 === e.active) return this._getResult(e, -1, !1, t);
                    let {
                        hashAttribute: s,
                        hashValue: a
                    } = this._getHashAttribute(e.hashAttribute, this._ctx.stickyBucketService && !e.disableStickyBucketing ? e.fallbackAttribute : void 0);
                    if (!a) return this._getResult(e, -1, !1, t);
                    let u = -1,
                        o = !1,
                        c = !1;
                    if (this._ctx.stickyBucketService && !e.disableStickyBucketing) {
                        let {
                            variation: t,
                            versionIsBlocked: r
                        } = this._getStickyBucketVariation(e.key, e.bucketVersion, e.minBucketVersion, e.meta);
                        o = t >= 0, u = t, c = !!r
                    }
                    if (!o) {
                        if (e.filters) {
                            if (this._isFilteredOut(e.filters)) return this._getResult(e, -1, !1, t)
                        } else if (e.namespace && ! function(e, t) {
                                let r = M("__" + t[0], e, 1);
                                return null !== r && r >= t[1] && r < t[2]
                            }(a, e.namespace)) return this._getResult(e, -1, !1, t);
                        if (e.include && ! function(e) {
                                try {
                                    return e()
                                } catch (e) {
                                    return console.error(e), !1
                                }
                            }(e.include) || e.condition && !this._conditionPasses(e.condition)) return this._getResult(e, -1, !1, t);
                        if (e.parentConditions)
                            for (let r of e.parentConditions) {
                                let i = this._evalFeature(r.id);
                                if ("cyclicPrerequisite" === i.source) return this._getResult(e, -1, !1, t);
                                let n = {
                                    value: i.value
                                };
                                if (!q(n, r.condition || {})) return this._getResult(e, -1, !1, t)
                            }
                        if (e.groups && !this._hasGroupOverlap(e.groups)) return this._getResult(e, -1, !1, t)
                    }
                    if (e.url && !this._urlIsValid(e.url)) return this._getResult(e, -1, !1, t);
                    let l = M(e.seed || r, a, e.hashVersion || 1);
                    if (null === l) return this._getResult(e, -1, !1, t);
                    if (!o) {
                        let t = e.ranges || function(e, t, r) {
                            (t = void 0 === t ? 1 : t) < 0 ? t = 0 : t > 1 && (t = 1);
                            let i = e <= 0 ? [] : Array(e).fill(1 / e);
                            (r = r || i).length !== e && (r = i);
                            let n = r.reduce((e, t) => t + e, 0);
                            (n < .99 || n > 1.01) && (r = i);
                            let s = 0;
                            return r.map(e => {
                                let r = s;
                                return s += e, [r, r + t * e]
                            })
                        }(i, void 0 === e.coverage ? 1 : e.coverage, e.weights);
                        u = function(e, t) {
                            for (let r = 0; r < t.length; r++)
                                if (H(e, t[r])) return r;
                            return -1
                        }(l, t)
                    }
                    if (c) return this._getResult(e, -1, !1, t, void 0, !0);
                    if (u < 0) return this._getResult(e, -1, !1, t);
                    if ("force" in e) return this._getResult(e, void 0 === e.force ? -1 : e.force, !1, t);
                    if (this._ctx.qaMode || "stopped" === e.status) return this._getResult(e, -1, !1, t);
                    let h = this._getResult(e, u, !0, t, l, o);
                    if (this._ctx.stickyBucketService && !e.disableStickyBucketing) {
                        let {
                            changed: t,
                            key: r,
                            doc: i
                        } = this._generateStickyBucketAssignmentDoc(s, P(a), {
                            [this._getStickyBucketExperimentKey(e.key, e.bucketVersion)]: h.key
                        });
                        t && (this._ctx.stickyBucketAssignmentDocs = this._ctx.stickyBucketAssignmentDocs || {}, this._ctx.stickyBucketAssignmentDocs[r] = i, this._ctx.stickyBucketService.saveAssignments(i))
                    }
                    return this._track(e, h), h
                }
                log(e, t) {
                    this.debug && (this._ctx.log ? this._ctx.log(e, t) : console.log(e, t))
                }
                _track(e, t) {
                    if (!this._ctx.trackingCallback) return;
                    let r = e.key,
                        i = t.hashAttribute + t.hashValue + r + t.variationId;
                    if (!this._trackedExperiments.has(i)) {
                        this._trackedExperiments.add(i);
                        try {
                            this._ctx.trackingCallback(e, t)
                        } catch (e) {
                            console.error(e)
                        }
                    }
                }
                _mergeOverrides(e) {
                    let t = e.key,
                        r = this._ctx.overrides;
                    return r && r[t] && "string" == typeof(e = Object.assign({}, e, r[t])).url && (e.url = D(e.url)), e
                }
                _getHashAttribute(e, t) {
                    let r = e || "id",
                        i = "";
                    return this._attributeOverrides[r] ? i = this._attributeOverrides[r] : this._ctx.attributes ? i = this._ctx.attributes[r] || "" : this._ctx.user && (i = this._ctx.user[r] || ""), !i && t && (this._attributeOverrides[t] ? i = this._attributeOverrides[t] : this._ctx.attributes ? i = this._ctx.attributes[t] || "" : this._ctx.user && (i = this._ctx.user[t] || ""), i && (r = t)), {
                        hashAttribute: r,
                        hashValue: i
                    }
                }
                _getResult(e, t, r, i, n, s) {
                    let a = !0;
                    (t < 0 || t >= e.variations.length) && (t = 0, a = !1);
                    let {
                        hashAttribute: u,
                        hashValue: o
                    } = this._getHashAttribute(e.hashAttribute, this._ctx.stickyBucketService && !e.disableStickyBucketing ? e.fallbackAttribute : void 0), c = e.meta ? e.meta[t] : {}, l = {
                        key: c.key || "" + t,
                        featureId: i,
                        inExperiment: a,
                        hashUsed: r,
                        variationId: t,
                        value: e.variations[t],
                        hashAttribute: u,
                        hashValue: o,
                        stickyBucketUsed: !!s
                    };
                    return c.name && (l.name = c.name), void 0 !== n && (l.bucket = n), c.passthrough && (l.passthrough = c.passthrough), l
                }
                _getContextUrl() {
                    return this._ctx.url || (eb ? window.location.href : "")
                }
                _urlIsValid(e) {
                    let t = this._getContextUrl();
                    if (!t) return !1;
                    let r = t.replace(/^https?:\/\//, "").replace(/^[^/]*\//, "/");
                    return !!(e.test(t) || e.test(r))
                }
                _hasGroupOverlap(e) {
                    let t = this._ctx.groups || {};
                    for (let r = 0; r < e.length; r++)
                        if (t[e[r]]) return !0;
                    return !1
                }
                _applyDOMChanges(e) {
                    if (!eb) return;
                    let t = [];
                    if (e.css) {
                        let r = document.createElement("style");
                        r.innerHTML = e.css, document.head.appendChild(r), t.push(() => r.remove())
                    }
                    if (e.js) {
                        let r = document.createElement("script");
                        r.innerHTML = e.js, document.head.appendChild(r), t.push(() => r.remove())
                    }
                    return e.domMutations && e.domMutations.forEach(e => {
                        t.push(K.declarative(e).revert)
                    }), () => {
                        t.forEach(e => e())
                    }
                }
                _deriveStickyBucketIdentifierAttributes(e) {
                    let t = new Set,
                        r = e && e.features ? e.features : this.getFeatures(),
                        i = e && e.experiments ? e.experiments : this.getExperiments();
                    return Object.keys(r).forEach(e => {
                        let i = r[e];
                        if (i.rules)
                            for (let e of i.rules) e.variations && (t.add(e.hashAttribute || "id"), e.fallbackAttribute && t.add(e.fallbackAttribute))
                    }), i.map(e => {
                        t.add(e.hashAttribute || "id"), e.fallbackAttribute && t.add(e.fallbackAttribute)
                    }), Array.from(t)
                }
                async refreshStickyBuckets(e) {
                    if (this._ctx.stickyBucketService) {
                        let t = this._getStickyBucketAttributes(e);
                        this._ctx.stickyBucketAssignmentDocs = await this._ctx.stickyBucketService.getAllAssignments(t)
                    }
                }
                _getStickyBucketAssignments() {
                    let e = {};
                    return Object.values(this._ctx.stickyBucketAssignmentDocs || {}).forEach(t => {
                        t.assignments && Object.assign(e, t.assignments)
                    }), e
                }
                _getStickyBucketVariation(e, t, r, i) {
                    t = t || 0, r = r || 0, i = i || [];
                    let n = this._getStickyBucketExperimentKey(e, t),
                        s = this._getStickyBucketAssignments();
                    if (r > 0)
                        for (let t = 0; t <= r; t++) {
                            let r = this._getStickyBucketExperimentKey(e, t);
                            if (void 0 !== s[r]) return {
                                variation: -1,
                                versionIsBlocked: !0
                            }
                        }
                    let a = s[n];
                    if (void 0 === a) return {
                        variation: -1
                    };
                    let u = i.findIndex(e => e.key === a);
                    return u < 0 ? {
                        variation: -1
                    } : {
                        variation: u
                    }
                }
                _getStickyBucketExperimentKey(e, t) {
                    return t = t || 0, "".concat(e, "__").concat(t)
                }
                _getStickyBucketAttributes(e) {
                    let t = {};
                    return this._ctx.stickyBucketIdentifierAttributes = this._ctx.stickyBucketIdentifierAttributes ? this._ctx.stickyBucketIdentifierAttributes : this._deriveStickyBucketIdentifierAttributes(e), this._ctx.stickyBucketIdentifierAttributes.forEach(e => {
                        let {
                            hashValue: r
                        } = this._getHashAttribute(e);
                        t[e] = P(r)
                    }), t
                }
                _generateStickyBucketAssignmentDoc(e, t, r) {
                    let i = "".concat(e, "||").concat(t),
                        n = this._ctx.stickyBucketAssignmentDocs && this._ctx.stickyBucketAssignmentDocs[i] && this._ctx.stickyBucketAssignmentDocs[i].assignments || {},
                        s = { ...n,
                            ...r
                        },
                        a = JSON.stringify(n) !== JSON.stringify(s);
                    return {
                        key: i,
                        doc: {
                            attributeName: e,
                            attributeValue: t,
                            assignments: s
                        },
                        changed: a
                    }
                }
            }
            var eA = r(2386);
            let eE = eA.createContext({});

            function eS(e) {
                let t = ew();
                return !!t && t.isOn(e)
            }

            function ew() {
                let {
                    growthbook: e
                } = eA.useContext(eE);
                return e
            }
            let eF = ({
                children: e,
                growthbook: t
            }) => {
                let [r, i] = eA.useState(0);
                return eA.useEffect(() => {
                    if (t && t.setRenderer) return t.setRenderer(() => {
                        i(e => e + 1)
                    }), () => {
                        t.setRenderer(() => {})
                    }
                }, [t]), eA.createElement(eE.Provider, {
                    value: {
                        growthbook: t
                    }
                }, e)
            }
        }
    }
]);