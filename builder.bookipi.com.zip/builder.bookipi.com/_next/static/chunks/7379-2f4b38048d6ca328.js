"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7379], {
        3175: function(e, t, n) {
            n.d(t, {
                y: function() {
                    return o
                }
            });
            var s = n(5689),
                i = n(8986),
                r = n(983),
                a = n(1355);
            let o = () => (0, s.jsx)(a.e, {
                feature: i.y8.subscription,
                children: (0, s.jsx)(r.Badge, {
                    type: "onlyText",
                    size: "s",
                    color: "blue",
                    badgeText: "PRO",
                    showText: !0
                })
            })
        },
        3474: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return r
                }
            });
            var s = n(5689),
                i = n(4279);
            let r = e => {
                let {
                    onGetDomain: t,
                    onConnectDomain: n,
                    disabled: r,
                    className: a
                } = e;
                return (0, s.jsxs)("div", {
                    className: (0, i.Z)("flex w-full flex-col gap-3", a),
                    children: [(0, s.jsx)("button", {
                        className: "rounded-lg border border-primary-700 bg-primary-700 px-4 py-2 text-center text-sm text-white disabled:cursor-not-allowed disabled:opacity-50",
                        onClick: t,
                        disabled: r,
                        children: "Get a domain"
                    }), (0, s.jsx)("button", {
                        className: "rounded-lg border border-primary-700 px-4 py-2 text-center text-sm text-primary-700 disabled:cursor-not-allowed disabled:opacity-50",
                        onClick: n,
                        disabled: r,
                        children: "Connect my domain"
                    })]
                })
            }
        },
        1355: function(e, t, n) {
            n.d(t, {
                e: function() {
                    return a
                }
            });
            var s = n(7105),
                i = n(3949),
                r = n(2386);

            function a(e) {
                let {
                    children: t,
                    feature: n
                } = e, [a, o] = (0, r.useState)(!1), l = (0, i.cC)(n);
                return ((0, s.q)(() => {
                    o(!0)
                }), a && l) ? t : null
            }
        },
        8986: function(e, t, n) {
            n.d(t, {
                TN: function() {
                    return o
                },
                _n: function() {
                    return r
                },
                kh: function() {
                    return i
                },
                y8: function() {
                    return a
                }
            });
            var s = n(982);
            let i = {
                    LIMITS: {
                        SERVICES: 5,
                        FAQS: 15
                    }
                },
                r = "https://builder.bookipi.com/pages/",
                a = {
                    intercom: "aiwb-intercom",
                    nolt: "aiwb-nolt",
                    customDomain: "aiwb-custom-domain",
                    subscription: "aiwb-subscription"
                },
                o = {
                    dev: {
                        NEXT_PUBLIC_ENV: "dev",
                        NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY: "sdk-Q3sGw8cYPZiVt4XQ",
                        NEXT_PUBLIC_HOME_PAGE_URL: "builder.bkpi.co"
                    },
                    production: {
                        NEXT_PUBLIC_ENV: "production",
                        NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY: "sdk-lVVnx6wT0H931nJT",
                        NEXT_PUBLIC_HOME_PAGE_URL: "builder.bookipi.com"
                    }
                };
            s.env.NEXT_PUBLIC_ENV
        },
        4053: function(e, t, n) {
            n.d(t, {
                AMPLITUDE_EVENT_SOURCES: function() {
                    return s
                }
            });
            let s = {
                SIDEBAR: "sidebar",
                SIDEBAR_FOOTER: "sidebar_toggle_footer_branding",
                SIDEBAR_CONNECT_MY_DOMAIN_BUTTON: "sidebar_connect_my_domain_button",
                SIDEBAR_GET_A_DOMAIN_BUTTON: "sidebar_get_a_domain_button",
                PUBLISH_MODAL: "publish_modal",
                PUBLISH_MODAL_CONNECT_NOW_BUTTON: "publish_modal_connect_now_button"
            }
        },
        2355: function(e, t, n) {
            n.r(t), n.d(t, {
                EntriContext: function() {
                    return y
                },
                EntriProvider: function() {
                    return N
                },
                useEntri: function() {
                    return j
                }
            });
            var s = n(5689),
                i = n(2066),
                r = n(2846),
                a = n(4426);

            function o() {
                let e = (0, i._)(["\n  query getEntriToken {\n    getEntriToken {\n      auth_token\n    }\n  }\n"]);
                return o = function() {
                    return e
                }, e
            }
            let l = (0, a.Ps)(o()),
                c = async () => {
                    var e;
                    let t = await (0, r.S)().request(l);
                    return null == t ? void 0 : null === (e = t.getEntriToken) || void 0 === e ? void 0 : e.auth_token
                };

            function u() {
                let e = (0, i._)(["\n  mutation SetDomain($input: DomainValue!) {\n    setDomain(input: $input) {\n      domain\n      domainStatus\n    }\n  }\n"]);
                return u = function() {
                    return e
                }, e
            }
            let d = (0, a.Ps)(u()),
                m = e => (0, r.S)().request(d, {
                    input: {
                        domain: e
                    }
                });
            var p = n(8159),
                x = n(9239),
                h = n(6612),
                b = n(7305),
                f = n(2386),
                g = n(7637),
                w = n(1703);
            let y = (0, f.createContext)({
                    showEntri: () => {},
                    showPurchaseEntri: () => {},
                    loading: !1
                }),
                v = "https://builder.bookipi.com";

            function N(e) {
                let {
                    children: t
                } = e, [n, i] = (0, f.useState)(!1), [r, a] = (0, f.useState)({}), o = (0, w.useToastContext)(), {
                    trackEvent: l
                } = (0, h.i)(), {
                    businessInfo: {
                        id: u
                    },
                    setBusinessInfo: d
                } = (0, g.useBusinessInfo)(), N = {
                    applicationId: "bookipi",
                    userId: u,
                    power: !0,
                    dnsRecords: [{
                        type: "CNAME",
                        host: "{SUBDOMAIN}",
                        value: "{CNAME_TARGET}",
                        ttl: 300,
                        applicationUrl: "".concat(v, "/domain/").concat(u),
                        powerRootPathAccess: ["/_next/static/css/"]
                    }, {
                        type: "A",
                        host: "@",
                        value: "{ENTRI_SERVERS}",
                        ttl: 300,
                        applicationUrl: "".concat(v, "/domain/").concat(u)
                    }]
                }, j = async () => {
                    i(!0);
                    let e = await c();
                    if (!e) {
                        o.showToast(x.RZ.FAILED_TO_FETCH_ENTRI_TOKEN, b.Ix.DANGER), i(!1);
                        return
                    }
                    window.entri.showEntri({ ...N,
                        token: e
                    })
                }, _ = async () => {
                    i(!0);
                    let e = await c();
                    if (!e) {
                        o.showToast(x.RZ.FAILED_TO_FETCH_ENTRI_TOKEN, b.Ix.DANGER), i(!1);
                        return
                    }
                    window.entri.purchaseDomain({ ...N,
                        token: e,
                        freeDomain: !1
                    })
                };
                return (0, f.useEffect)(() => {
                    let e = e => {
                        let t = {
                            step: "step" in e ? e.step : e.lastStatus,
                            user: u
                        };
                        return e.provider && Object.assign(t, {
                            provider: e.provider
                        }), e.domain && Object.assign(t, {
                            domain: e.domain
                        }), "user" in e && e.user && Object.assign(t, {
                            user: e.user
                        }), t
                    };
                    async function t(t) {
                        let n = t.detail;
                        if (i(!1), n.success) {
                            try {
                                await m(n.domain), d(e => ({ ...e,
                                    domain: n.domain,
                                    domainStatus: p.Fu.PENDING
                                }));
                                let e = "purchase" === n.setupType;
                                e ? l("Web Builder Domain Purchase Success", {
                                    provider: n.provider,
                                    domain: n.domain
                                }) : l("Web Builder Custom Domain Added", {
                                    provider: n.provider,
                                    domain: n.domain
                                })
                            } catch (e) {
                                o.showToast("Failed to save domain", b.Ix.DANGER)
                            }
                            return
                        }
                        l("Web Builder Custom Domain Modal Closed", e(n))
                    }

                    function n(t) {
                        let n = t.detail,
                            s = n.step,
                            i = "".concat(s, "-").concat(n.user);
                        !r[i] && "user" in n && n.user && (l("Web Builder Custom Domain Step Change", e(n)), a(e => ({ ...e,
                            [i]: !0
                        })))
                    }
                    return window.addEventListener("onEntriClose", t, !1), window.addEventListener("onEntriStepChange", n, !1), () => {
                        window.removeEventListener("onEntriClose", t, !1), window.removeEventListener("onEntriStepChange", n, !1)
                    }
                }, []), (0, s.jsx)(y.Provider, {
                    value: {
                        showEntri: j,
                        showPurchaseEntri: _,
                        loading: n
                    },
                    children: t
                })
            }
            let j = () => (0, f.useContext)(y)
        },
        2917: function(e, t, n) {
            n.r(t), n.d(t, {
                SubscriptionContext: function() {
                    return ed
                },
                SubscriptionProvider: function() {
                    return ep
                },
                useSubscription: function() {
                    return ex
                }
            });
            var s, i, r = n(5689),
                a = n(2066),
                o = n(2846),
                l = n(4426);

            function c() {
                let e = (0, a._)(["\n  query GetSubscriptionParams {\n    getSubscriptionParams {\n      companyId\n      customerId\n      userId\n      lang\n      features\n      token\n      url\n    }\n  }\n"]);
                return c = function() {
                    return e
                }, e
            }
            let u = (0, l.Ps)(c()),
                d = async () => {
                    let e = await (0, o.S)().request(u);
                    return e.getSubscriptionParams
                };
            var m = n(7105),
                p = n(2386),
                x = n(1293);

            function h(e) {
                let {
                    children: t,
                    target: n
                } = e, [s, i] = (0, p.useState)("");
                return ((0, m.q)(() => {
                    if ("string" == typeof n) {
                        let e = document.querySelector(n);
                        if (!e) throw Error("No element found with selector: ".concat(n));
                        i(n)
                    }
                    n instanceof HTMLElement && i(n), i(document.body)
                }), s) ? (0, x.createPortal)(t, s) : null
            }
            let b = e => {
                let {
                    isOpen: t,
                    url: n
                } = e;
                if (t) return (0, r.jsx)(h, {
                    children: (0, r.jsx)("iframe", {
                        style: {
                            border: "none",
                            bottom: 0,
                            height: "100vh",
                            left: 0,
                            position: "absolute",
                            right: 0,
                            top: 0,
                            width: "100%",
                            zIndex: 19999
                        },
                        src: n
                    })
                })
            };
            var f = n(4053),
                g = n(7637),
                w = n(2355),
                y = n(3906),
                v = n(983),
                N = n(8244),
                j = n.n(N),
                _ = n(3474),
                E = n(4868),
                C = {
                    src: "https://builder.bookipi.com/_next/static/media/product-launch.513ed181.svg",
                    height: 148,
                    width: 148,
                    blurWidth: 0,
                    blurHeight: 0
                };
            let P = () => (0, r.jsxs)("div", {
                    className: "flex flex-col items-center gap-4 py-2 text-center",
                    children: [(0, r.jsx)(j(), {
                        src: C,
                        alt: "",
                        className: "align-middle",
                        width: 148,
                        height: 148
                    }), (0, r.jsx)("p", {
                        className: "w-2/3 break-words text-base font-normal",
                        children: "You can now publish your website to a custom domain"
                    })]
                }),
                S = () => {
                    let {
                        loading: e
                    } = (0, w.useEntri)(), {
                        customDomainModalProps: t
                    } = (0, g.useBusinessInfo)(), {
                        onGetDomain: n,
                        onConnectDomain: s
                    } = (0, y.f)(f.AMPLITUDE_EVENT_SOURCES.PUBLISH_MODAL);
                    return (0, r.jsx)(E.A, {
                        isOpen: t.isOpen,
                        isToggling: t.isToggling,
                        closeModal: t.close,
                        children: (0, r.jsx)(v.Modal, {
                            showHeader: !0,
                            showFooter: !1,
                            className: "h-auto w-full max-w-[480px] bg-white md:h-auto",
                            size: "l",
                            modalHeaderProps: {
                                titlePosition: "center",
                                title: "Custom domain",
                                showLeftIcon: !1,
                                showCloseIcon: !0,
                                onClose: t.close
                            },
                            children: (0, r.jsxs)("div", {
                                className: "flex flex-col gap-3 p-6",
                                children: [(0, r.jsx)(P, {}), (0, r.jsx)(_.I, {
                                    className: "px-6 py-3",
                                    onGetDomain: n,
                                    onConnectDomain: s,
                                    disabled: e
                                })]
                            })
                        })
                    })
                };
            var T = n(6612),
                I = n(4279),
                O = n(3175);

            function B(e) {
                let {
                    onUpgrade: t,
                    close: n
                } = e, [s, i] = (0, p.useState)(!1);
                return (0, r.jsxs)("div", {
                    className: "flex flex-col gap-3",
                    children: [(0, r.jsx)(v.Button, {
                        color: "blue",
                        className: (0, I.Z)({
                            "pointer-events-none": s
                        }),
                        onClick: () => {
                            t("none"), i(!0)
                        },
                        children: "Manage subscription"
                    }), (0, r.jsx)("button", {
                        onClick: n,
                        className: "h-10 rounded-lg border border-gray-200 bg-white py-2 text-sm font-medium text-gray-800 hover:border-gray-200/80 hover:bg-gray-200/20",
                        children: "Cancel"
                    })]
                })
            }

            function k() {
                let e = (0, a._)(["\n  query GetSubscriptionPlans {\n    getSubscriptionPlans {\n      name\n      description\n      group\n      defaultPrice\n      currency\n      _id\n      prices {\n        name\n        description\n        companyId\n        flatFee\n        isTieredPricing\n        setupFee\n        pricingModel\n        years\n        months\n        prorate\n        _id\n      }\n    }\n  }\n"]);
                return k = function() {
                    return e
                }, e
            }
            let D = (0, l.Ps)(k()),
                L = async () => {
                    let e = await (0, o.S)().request(D);
                    return null == e ? void 0 : e.getSubscriptionPlans
                };
            var A = n(245),
                M = {
                    src: "https://builder.bookipi.com/_next/static/media/check-outline.fe18a0e3.svg",
                    height: 20,
                    width: 20,
                    blurWidth: 0,
                    blurHeight: 0
                };
            let U = [{
                    name: "Custom domain"
                }, {
                    name: "Remove Bookipi branding"
                }],
                R = () => (0, r.jsx)("ul", {
                    className: "rounded-b-lg border-2 border-t-0 border-gray-100 py-2",
                    children: U.map((e, t) => {
                        let {
                            name: n
                        } = e;
                        return (0, r.jsxs)("li", {
                            className: "flex h-10 w-full flex-row items-center justify-between px-4",
                            children: [(0, r.jsx)("h4", {
                                className: "text-base font-medium text-gray-900",
                                children: n
                            }), (0, r.jsxs)("span", {
                                className: "inline-flex gap-1.5 text-base font-normal text-gray-900",
                                children: [(0, r.jsx)(j(), {
                                    src: M,
                                    alt: "check",
                                    className: "align-middle",
                                    width: 20,
                                    height: 20
                                }), "included"]
                            })]
                        }, "".concat(n, "-").concat(t))
                    })
                });

            function F() {
                return (0, r.jsxs)("div", {
                    className: "mb-3 flex flex-col items-center gap-2",
                    children: [(0, r.jsx)(v.Skeleton, {
                        width: 100,
                        className: "h-4 min-w-full rounded-sm"
                    }), (0, r.jsx)(v.Skeleton, {
                        width: 100,
                        className: "h-40 min-w-full rounded-sm"
                    }), (0, r.jsx)(v.Skeleton, {
                        width: 100,
                        className: "h-4 min-w-full rounded-sm"
                    })]
                })
            }(s = i || (i = {})).MONTHLY = "monthly", s.ANNUALLY = "annually";
            let q = e => {
                    if (!e) return 0;
                    let t = e.flatFee / 100;
                    return 1 === e.years ? t / 12 : t
                },
                H = e => {
                    let t = e.toFixed(2),
                        [n, s] = t.split(".");
                    return "00" === s ? n : t
                },
                G = (e, t) => e ? "".concat(q(e).toFixed(2), " ").concat(t) : "",
                W = (e, t, n) => {
                    if (!e || !t) return {};
                    let s = e > t ? e : t,
                        i = (s - (e > t ? t : e)) / s * 100,
                        r = H(s);
                    return 0 === i ? {} : {
                        prevPrice: "".concat(r, " ").concat(n),
                        rateDetail: "Save ".concat(i.toFixed(0), "%")
                    }
                };

            function Y(e) {
                let t = e.find(e => "active" === e.status);
                return t || e.at(-1) || null
            }

            function V(e) {
                var t, n;
                let {
                    isYearlyPlan: s,
                    onUpgrade: i,
                    plan: a
                } = e, {
                    yearly: o,
                    monthly: l
                } = function(e) {
                    let t = e.prices.find(e => e.months),
                        n = e.prices.find(e => e.years);
                    return {
                        monthly: t,
                        yearly: n
                    }
                }(a);
                if (!a || !o || !l) return null;
                let c = s ? o : l,
                    u = s ? W(q({
                        years: o.years,
                        flatFee: o.flatFee
                    }), q({
                        years: l.years,
                        flatFee: l.flatFee
                    }), a.currency) : {
                        prevPrice: "",
                        rateDetail: ""
                    },
                    d = ["Per month"];
                return s && d.push("billed yearly"), (0, r.jsxs)("section", {
                    className: "flex flex-col gap-5 rounded-t-lg border-2 border-gray-100 p-5",
                    children: [(0, r.jsxs)("div", {
                        className: "mb-2 flex w-full flex-row justify-between",
                        children: [(0, r.jsxs)("div", {
                            className: "flex w-[246px] min-w-[246px] flex-col items-start",
                            children: [(0, r.jsx)("h2", {
                                className: "text-2xl font-bold text-gray-900",
                                children: a.name
                            }), (0, r.jsx)("p", {
                                className: "text-base font-normal text-gray-500",
                                children: a.description
                            })]
                        }), (0, r.jsxs)("div", {
                            className: "flex w-[160px] min-w-[160px] flex-col items-end",
                            children: [(0, r.jsx)("span", {
                                className: "text-xl font-bold text-gray-900",
                                children: G({
                                    years: c.years,
                                    flatFee: c.flatFee
                                }, a.currency)
                            }), s && (0, r.jsxs)("p", {
                                className: "inline-flex gap-1",
                                children: [(0, r.jsx)("span", {
                                    className: "text-base font-normal text-gray-500 line-through",
                                    children: null !== (t = u.prevPrice) && void 0 !== t ? t : ""
                                }), (0, r.jsx)("span", {
                                    className: " text-base font-normal text-blue-600",
                                    children: null !== (n = u.rateDetail) && void 0 !== n ? n : ""
                                })]
                            }), (0, r.jsx)("span", {
                                className: "text-sm font-normal text-gray-500",
                                children: d.join(", ")
                            })]
                        })]
                    }), (0, r.jsx)(v.Button, {
                        size: "l",
                        outline: !1,
                        onClick: () => i(s ? o._id : l._id, s),
                        children: "Upgrade"
                    })]
                })
            }

            function z(e) {
                let {
                    isYearlyPlan: t,
                    onToggle: n,
                    disabled: s
                } = e;
                return (0, r.jsxs)("div", {
                    className: "mb-5 flex w-full flex-row justify-between",
                    children: [(0, r.jsx)("h3", {
                        className: "text-xl font-semibold text-gray-900",
                        children: "Upgrade"
                    }), (0, r.jsxs)("div", {
                        className: "flex flex-row items-center justify-between px-1",
                        children: [s ? (0, r.jsx)(v.Tooltip, {
                            color: "dark",
                            position: "top",
                            size: "s",
                            showIcon: !1,
                            showTitle: !1,
                            showBody: !0,
                            body: "You can only subscribe to the same cycle as your current plan",
                            children: (0, r.jsx)("h3", {
                                className: "mr-2.5 text-base font-medium text-gray-500",
                                children: "Yearly discount"
                            })
                        }) : (0, r.jsx)("h3", {
                            className: "mr-2.5 text-base font-medium text-gray-500",
                            children: "Yearly discount"
                        }), (0, r.jsx)(v.Toggle, {
                            size: "s",
                            checked: t,
                            disabled: s,
                            onChange: n
                        })]
                    })]
                })
            }

            function K(e) {
                var t;
                let {
                    onUpgrade: n
                } = e, {
                    data: s,
                    isLoading: i,
                    error: a
                } = function() {
                    let {
                        data: e,
                        error: t,
                        isLoading: n
                    } = (0, A.a)({
                        queryKey: ["subscriptionPlans"],
                        queryFn: async () => {
                            let e = await L();
                            return e.find(e => e.prices.length) || e.at(0)
                        }
                    });
                    return {
                        data: e,
                        error: t,
                        isLoading: n
                    }
                }(), {
                    subscription: o
                } = ex(), l = (null === (t = o.v2) || void 0 === t ? void 0 : t.status.toLowerCase()) === "active", [c, u] = (0, p.useState)(!l || o.isYearly);
                return i ? (0, r.jsx)(F, {}) : a ? (0, r.jsx)("h1", {
                    className: "text-center",
                    children: "Error loading subscription plans"
                }) : s ? (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("hr", {
                        className: "w-full border-gray-200 pb-[30px] dark:border-gray-700"
                    }), (0, r.jsx)(z, {
                        isYearlyPlan: c,
                        disabled: l,
                        onToggle: () => {
                            l || u(e => !e)
                        }
                    }), (0, r.jsx)(V, {
                        plan: s,
                        isYearlyPlan: c,
                        onUpgrade: n
                    }), (0, r.jsx)(R, {})]
                }) : (0, r.jsx)("h1", {
                    className: "text-center",
                    children: "No Subscription plans available"
                })
            }

            function X(e) {
                let {
                    showManage: t,
                    onUpgrade: n,
                    isOpen: s,
                    close: i
                } = e;
                return s ? t ? (0, r.jsx)(B, {
                    onUpgrade: n,
                    close: i
                }) : (0, r.jsx)(K, {
                    onUpgrade: n
                }) : null
            }
            var Z = {
                    src: "https://builder.bookipi.com/_next/static/media/exclamation-circle.c441db24.svg",
                    height: 48,
                    width: 48,
                    blurWidth: 0,
                    blurHeight: 0
                },
                Q = {
                    src: "https://builder.bookipi.com/_next/static/media/x-solid.c713f635.svg",
                    height: 24,
                    width: 24,
                    blurWidth: 0,
                    blurHeight: 0
                };
            let $ = () => (0, r.jsx)("header", {
                    className: "",
                    children: (0, r.jsx)(j(), {
                        src: Z,
                        alt: "",
                        className: "align-middle",
                        width: 48,
                        height: 48
                    })
                }),
                J = e => {
                    let {
                        showManage: t = !1
                    } = e;
                    return t ? (0, r.jsx)("div", {
                        className: "text-center",
                        children: (0, r.jsxs)("div", {
                            className: "flex flex-col items-center gap-2",
                            children: [(0, r.jsx)("h2", {
                                className: "text-2xl font-semibold text-gray-900",
                                children: "Subscription required"
                            }), (0, r.jsxs)("p", {
                                className: "px-10 text-base font-normal text-gray-500",
                                children: ["You have canceled AI Web Builder Pro plan. Please", " ", (0, r.jsx)("strong", {
                                    children: "Reactivate"
                                }), " to access this feature."]
                            })]
                        })
                    }) : (0, r.jsx)("div", {
                        className: "text-center",
                        children: (0, r.jsxs)("div", {
                            className: "flex flex-col items-center gap-2",
                            children: [(0, r.jsx)("h2", {
                                className: "text-xl font-semibold text-gray-900",
                                children: "Upgrade to AI Web Builder Pro"
                            }), (0, r.jsxs)("div", {
                                className: "flex flex-row gap-2 text-base font-normal text-gray-500",
                                children: ["to unlock ", (0, r.jsx)(O.y, {}), " features"]
                            })]
                        })
                    })
                },
                ee = e => {
                    let {
                        isOpen: t,
                        isToggling: n,
                        close: s
                    } = e, {
                        subscription: i,
                        showIFrame: a,
                        isExpired: o,
                        paywallEventProperties: l
                    } = ex(), {
                        trackEvent: c
                    } = (0, T.i)();
                    return (0, r.jsx)(E.A, {
                        isOpen: t,
                        isToggling: n,
                        closeModal: s,
                        children: (0, r.jsxs)("div", {
                            className: "relative z-30",
                            children: [(0, r.jsx)("button", {
                                className: "absolute right-5 top-5 z-30",
                                onClick: s,
                                type: "button",
                                children: (0, r.jsx)(j(), {
                                    src: Q,
                                    alt: "close",
                                    className: "align-middle",
                                    width: 24,
                                    height: 24
                                })
                            }), (0, r.jsx)(v.Modal, {
                                showHeader: !1,
                                showFooter: !1,
                                className: (0, I.Z)("h-auto w-full bg-white md:h-auto", {
                                    "max-w-[552px] px-6 py-8": !o,
                                    "max-w-[480px] px-6 py-6": o
                                }),
                                size: o ? "m" : "l",
                                children: (0, r.jsxs)("div", {
                                    className: "relative flex w-full flex-col items-center gap-[30px]",
                                    children: [(0, r.jsx)($, {}), (0, r.jsx)(J, {
                                        showManage: o
                                    }), (0, r.jsx)("div", {
                                        className: "w-full",
                                        children: (0, r.jsx)(X, {
                                            isOpen: t,
                                            showManage: o,
                                            onUpgrade: (e, t) => (void 0 !== t && c("Web Builder Paywall Modal Upgrade Button Clicked", { ...l,
                                                plan_interval: t ? "yearly" : "monthly"
                                            }), o) ? a("/edit") : i.withPaymentMenthod ? a("/order/".concat(e)) : a("/payment-method/new/".concat(e)),
                                            close: s
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                },
                et = () => (0, r.jsx)("div", {
                    className: "text-center",
                    children: (0, r.jsxs)("div", {
                        className: "flex flex-col items-center gap-2",
                        children: [(0, r.jsx)("h2", {
                            className: "text-2xl font-semibold text-gray-900",
                            children: "Subscription required"
                        }), (0, r.jsxs)("p", {
                            className: "text-sm font-normal text-gray-500",
                            children: ["This feature is only available with an active subscription. Please login to ", (0, r.jsx)("br", {}), (0, r.jsx)("span", {
                                className: "font-bold",
                                children: "Bookipi web version"
                            })]
                        })]
                    })
                }),
                en = e => {
                    let {
                        isOpen: t,
                        isToggling: n,
                        close: s
                    } = e;
                    return (0, r.jsx)(E.A, {
                        isOpen: t,
                        isToggling: n,
                        closeModal: s,
                        children: (0, r.jsx)(v.Modal, {
                            modalFooterProps: {
                                showSecondaryButton: !1,
                                showPrimaryButton: !0,
                                primaryButtonProps: {
                                    children: "Okay",
                                    disabled: !1,
                                    onClick: s
                                },
                                style: "vertical"
                            },
                            className: "relative h-auto w-full max-w-md bg-white md:h-auto",
                            showHeader: !1,
                            showFooter: !0,
                            size: "s",
                            children: (0, r.jsx)("section", {
                                className: "px-6 py-8",
                                children: (0, r.jsxs)("div", {
                                    className: "relative flex w-full flex-col items-center gap-[30px]",
                                    children: [(0, r.jsx)($, {}), (0, r.jsx)(et, {})]
                                })
                            })
                        })
                    })
                };
            var es = n(8986),
                ei = n(2808);

            function er() {
                let e = (0, a._)(["\n  query GetSubscriptionInfo {\n    getSubscriptionInfo {\n      product {\n        group\n      }\n      status\n      startDate\n      endDate\n      frequency\n      isCancelling\n      customer {\n        _id\n        email\n        paymentMethods {\n          _id\n          provider\n        }\n      }\n    }\n  }\n"]);
                return er = function() {
                    return e
                }, e
            }
            let ea = (0, l.Ps)(er()),
                eo = async () => {
                    let e = await (0, o.S)().request(ea),
                        t = null == e ? void 0 : e.getSubscriptionInfo.filter(e => "aiwb" === e.product.group),
                        n = null == e ? void 0 : e.getSubscriptionInfo.filter(e => "v2" === e.product.group),
                        s = Y(t),
                        i = Y(n);
                    return {
                        aiwb: s,
                        v2: i
                    }
                };
            var el = n(3949);
            let ec = {
                    url: "",
                    isOpen: !1,
                    subscription: {
                        v2: null,
                        aiwb: null,
                        isYearly: !1,
                        withPaymentMenthod: !1
                    }
                },
                eu = {
                    plan_name: "ai_website_builder_pro",
                    plan_interval: "",
                    source_action: ""
                },
                ed = (0, p.createContext)({
                    isOpen: !1,
                    subscription: ec.subscription,
                    isSubscribed: !1,
                    isCancelled: !1,
                    isExpired: !1,
                    isDomainBlocked: !1,
                    showIFrame: () => {},
                    accessFeature: () => {},
                    paywallModalProps: {
                        isOpen: !1,
                        toggle: () => {},
                        close: () => {},
                        isToggling: !1
                    },
                    paywallEventProperties: eu,
                    setPaywallEventProperties: e => {}
                }),
                em = (e, t) => t(e),
                ep = e => {
                    var t, n, s;
                    let {
                        children: a
                    } = e, [o, l] = (0, p.useReducer)(em, ec), [c, u] = (0, p.useState)(eu), {
                        data: {
                            companyId: m
                        },
                        refetch: x
                    } = (0, A.a)({
                        queryKey: ["subscriptionInfo"],
                        queryFn: async () => {
                            let [e, t] = await Promise.all([eo(), d()]), n = function(e) {
                                let {
                                    aiwb: t,
                                    v2: n
                                } = e;
                                return [n, t].some(e => null == e ? void 0 : e.customer.paymentMethods.length)
                            }(e);
                            return l(t => ({ ...t,
                                subscription: { ...e,
                                    isYearly: function(e) {
                                        let {
                                            aiwb: t,
                                            v2: n
                                        } = e;
                                        return !!n && (null == n ? void 0 : n.frequency.toLowerCase()) === i.ANNUALLY
                                    }(e),
                                    withPaymentMenthod: n
                                }
                            })), {
                                companyId: t.companyId
                            }
                        },
                        refetchOnMount: "always",
                        refetchOnWindowFocus: !1,
                        refetchOnReconnect: !1,
                        initialData: {
                            companyId: ""
                        }
                    }), h = (0, el.NQ)(), f = (0, el.cC)(es.y8.subscription), {
                        isDomainConnected: w,
                        businessInfo: y
                    } = (0, g.useBusinessInfo)(), N = (0, ei.U)(), {
                        trackEvent: j
                    } = (0, T.i)(), _ = !!(null === (t = o.subscription.aiwb) || void 0 === t ? void 0 : t.isCancelling), E = (null === (n = o.subscription.aiwb) || void 0 === n ? void 0 : n.status.toLowerCase()) === "active", C = E && !_;
                    (0, p.useEffect)(() => {
                        if (!h || !y) return;
                        let e = h.getAttributes(),
                            t = { ...e,
                                aiwbId: y.id,
                                aiwbName: y.businessName,
                                aiwbDescription: y.businessDescription,
                                aiwbExistingCustomDomainUser: !E && w,
                                companyId: m
                            };
                        h.setAttributes(t)
                    }, [h, y, E, w, m]);
                    let P = (null === (s = o.subscription.aiwb) || void 0 === s ? void 0 : s.status.toLowerCase()) === "terminated",
                        I = w && P,
                        O = (0, v.usePopup)({
                            defaultOpen: !1,
                            duration: 100
                        }),
                        B = N ? en : ee,
                        k = () => {
                            O.close(), u(eu)
                        };
                    (0, p.useEffect)(() => {
                        if (o.isOpen) {
                            let e = {
                                    close: () => {
                                        l(e => ({ ...e,
                                            isOpen: !1
                                        }))
                                    },
                                    mounted: () => {
                                        k()
                                    },
                                    subscribed: x
                                },
                                t = t => {
                                    var n;
                                    let {
                                        data: s
                                    } = t;
                                    null === (n = e[null == s ? void 0 : s.action]) || void 0 === n || n.call(e)
                                };
                            return window.addEventListener("message", t), () => {
                                window.removeEventListener("message", t)
                            }
                        }
                    }, [o.isOpen, O.close]);
                    let D = async e => {
                        let {
                            customerId: t,
                            userId: n,
                            token: s,
                            lang: i,
                            url: r
                        } = await d(), a = new URLSearchParams({
                            customerId: t,
                            userId: n,
                            token: s,
                            lang: i
                        }), o = "".concat(r).concat(e, "?").concat(a.toString());
                        l(e => ({ ...e,
                            isOpen: !0,
                            url: o
                        }))
                    };
                    return (0, r.jsxs)(ed.Provider, {
                        value: {
                            isOpen: o.isOpen,
                            subscription: o.subscription,
                            isSubscribed: C,
                            isCancelled: _,
                            isExpired: P,
                            isDomainBlocked: I,
                            showIFrame: D,
                            accessFeature: (e, t) => {
                                let n = { ...c,
                                    source_action: t
                                };
                                if (u(n), E || !f) return e();
                                j("Web Builder Paywall Modal Viewed", n), O.toggle()
                            },
                            paywallModalProps: O,
                            paywallEventProperties: c,
                            setPaywallEventProperties: u
                        },
                        children: [a, (0, r.jsx)(B, { ...O,
                            close: k
                        }), (0, r.jsx)(b, {
                            isOpen: o.isOpen,
                            url: o.url
                        }), (0, r.jsx)(S, {})]
                    })
                },
                ex = () => (0, p.useContext)(ed)
        },
        3906: function(e, t, n) {
            n.d(t, {
                f: function() {
                    return l
                }
            });
            var s = n(4053),
                i = n(7637),
                r = n(2355),
                a = n(2917),
                o = n(6612);
            let l = e => {
                let {
                    trackEvent: t
                } = (0, o.i)(), {
                    accessFeature: n
                } = (0, a.useSubscription)(), {
                    showPurchaseEntri: l,
                    showEntri: c
                } = (0, r.useEntri)(), {
                    customDomainModalProps: u
                } = (0, i.useBusinessInfo)(), {
                    SIDEBAR_GET_A_DOMAIN_BUTTON: d,
                    SIDEBAR: m,
                    SIDEBAR_CONNECT_MY_DOMAIN_BUTTON: p
                } = s.AMPLITUDE_EVENT_SOURCES;
                return {
                    onGetDomain: () => {
                        t("Web Builder Get A Domain Button Clicked", {
                            button_location: e
                        }), u.close();
                        let s = e === m ? d : e;
                        n(() => l(), s)
                    },
                    onConnectDomain: () => {
                        t("Web Builder Connect My Domain Button Clicked", {
                            button_location: e
                        });
                        let s = e === m ? p : e;
                        n(() => c(), s)
                    }
                }
            }
        }
    }
]);