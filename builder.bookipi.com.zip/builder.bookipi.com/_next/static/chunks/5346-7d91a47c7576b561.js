"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5346], {
        1123: function(e, t, r) {
            let n;
            r.d(t, {
                Lt: function() {
                    return n4
                },
                u_: function() {
                    return op
                },
                FN: function() {
                    return ap
                },
                u: function() {
                    return oB
                }
            });
            var o, a, l, i, s = r(5689),
                d = r(2386),
                c = r.t(d, 2),
                u = r(991);
            let g = /^\[(.+)\]$/;

            function f(e, t) {
                let r = e;
                return t.split("-").forEach(e => {
                    r.nextPart.has(e) || r.nextPart.set(e, {
                        nextPart: new Map,
                        validators: []
                    }), r = r.nextPart.get(e)
                }), r
            }
            let b = /\s+/;

            function p() {
                let e, t, r = 0,
                    n = "";
                for (; r < arguments.length;)(e = arguments[r++]) && (t = function e(t) {
                    let r;
                    if ("string" == typeof t) return t;
                    let n = "";
                    for (let o = 0; o < t.length; o++) t[o] && (r = e(t[o])) && (n && (n += " "), n += r);
                    return n
                }(e)) && (n && (n += " "), n += t);
                return n
            }

            function h(e) {
                let t = t => t[e] || [];
                return t.isThemeGetter = !0, t
            }
            let m = /^\[(?:([a-z-]+):)?(.+)\]$/i,
                y = /^\d+\/\d+$/,
                x = new Set(["px", "full", "screen"]),
                v = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                w = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                k = /^-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                N = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;

            function j(e) {
                return C(e) || x.has(e) || y.test(e)
            }

            function E(e) {
                return B(e, "length", W)
            }

            function C(e) {
                return !!e && !Number.isNaN(Number(e))
            }

            function T(e) {
                return B(e, "number", C)
            }

            function R(e) {
                return !!e && Number.isInteger(Number(e))
            }

            function S(e) {
                return e.endsWith("%") && C(e.slice(0, -1))
            }

            function M(e) {
                return m.test(e)
            }

            function L(e) {
                return v.test(e)
            }
            let I = new Set(["length", "size", "percentage"]);

            function D(e) {
                return B(e, I, _)
            }

            function P(e) {
                return B(e, "position", _)
            }
            let z = new Set(["image", "url"]);

            function O(e) {
                return B(e, z, G)
            }

            function A(e) {
                return B(e, "", Y)
            }

            function F() {
                return !0
            }

            function B(e, t, r) {
                let n = m.exec(e);
                return !!n && (n[1] ? "string" == typeof t ? n[1] === t : t.has(n[1]) : r(n[2]))
            }

            function W(e) {
                return w.test(e)
            }

            function _() {
                return !1
            }

            function Y(e) {
                return k.test(e)
            }

            function G(e) {
                return N.test(e)
            }
            let H = function(e) {
                let t, r, n;
                let o = function(l) {
                    let i = [].reduce((e, t) => t(e), e());
                    return r = (t = {
                        cache: function(e) {
                            if (e < 1) return {
                                get: () => void 0,
                                set: () => {}
                            };
                            let t = 0,
                                r = new Map,
                                n = new Map;

                            function o(o, a) {
                                r.set(o, a), ++t > e && (t = 0, n = r, r = new Map)
                            }
                            return {
                                get(e) {
                                    let t = r.get(e);
                                    return void 0 !== t ? t : void 0 !== (t = n.get(e)) ? (o(e, t), t) : void 0
                                },
                                set(e, t) {
                                    r.has(e) ? r.set(e, t) : o(e, t)
                                }
                            }
                        }(i.cacheSize),
                        splitModifiers: function(e) {
                            let t = e.separator,
                                r = 1 === t.length,
                                n = t[0],
                                o = t.length;
                            return function(e) {
                                let a;
                                let l = [],
                                    i = 0,
                                    s = 0;
                                for (let d = 0; d < e.length; d++) {
                                    let c = e[d];
                                    if (0 === i) {
                                        if (c === n && (r || e.slice(d, d + o) === t)) {
                                            l.push(e.slice(s, d)), s = d + o;
                                            continue
                                        }
                                        if ("/" === c) {
                                            a = d;
                                            continue
                                        }
                                    }
                                    "[" === c ? i++ : "]" === c && i--
                                }
                                let d = 0 === l.length ? e : e.substring(s),
                                    c = d.startsWith("!"),
                                    u = c ? d.substring(1) : d,
                                    g = a && a > s ? a - s : void 0;
                                return {
                                    modifiers: l,
                                    hasImportantModifier: c,
                                    baseClassName: u,
                                    maybePostfixModifierPosition: g
                                }
                            }
                        }(i),
                        ... function(e) {
                            let t = function(e) {
                                    var t;
                                    let {
                                        theme: r,
                                        prefix: n
                                    } = e, o = {
                                        nextPart: new Map,
                                        validators: []
                                    }, a = (t = Object.entries(e.classGroups), n ? t.map(([e, t]) => {
                                        let r = t.map(e => "string" == typeof e ? n + e : "object" == typeof e ? Object.fromEntries(Object.entries(e).map(([e, t]) => [n + e, t])) : e);
                                        return [e, r]
                                    }) : t);
                                    return a.forEach(([e, t]) => {
                                        (function e(t, r, n, o) {
                                            t.forEach(t => {
                                                if ("string" == typeof t) {
                                                    let e = "" === t ? r : f(r, t);
                                                    e.classGroupId = n;
                                                    return
                                                }
                                                if ("function" == typeof t) {
                                                    if (t.isThemeGetter) {
                                                        e(t(o), r, n, o);
                                                        return
                                                    }
                                                    r.validators.push({
                                                        validator: t,
                                                        classGroupId: n
                                                    });
                                                    return
                                                }
                                                Object.entries(t).forEach(([t, a]) => {
                                                    e(a, f(r, t), n, o)
                                                })
                                            })
                                        })(t, o, e, r)
                                    }), o
                                }(e),
                                {
                                    conflictingClassGroups: r,
                                    conflictingClassGroupModifiers: n
                                } = e;
                            return {
                                getClassGroupId: function(e) {
                                    let r = e.split("-");
                                    return "" === r[0] && 1 !== r.length && r.shift(),
                                        function e(t, r) {
                                            if (0 === t.length) return r.classGroupId;
                                            let n = t[0],
                                                o = r.nextPart.get(n),
                                                a = o ? e(t.slice(1), o) : void 0;
                                            if (a) return a;
                                            if (0 === r.validators.length) return;
                                            let l = t.join("-");
                                            return r.validators.find(({
                                                validator: e
                                            }) => e(l)) ? .classGroupId
                                        }(r, t) || function(e) {
                                            if (g.test(e)) {
                                                let t = g.exec(e)[1],
                                                    r = t ? .substring(0, t.indexOf(":"));
                                                if (r) return "arbitrary.." + r
                                            }
                                        }(e)
                                },
                                getConflictingClassGroupIds: function(e, t) {
                                    let o = r[e] || [];
                                    return t && n[e] ? [...o, ...n[e]] : o
                                }
                            }
                        }(i)
                    }).cache.get, n = t.cache.set, o = a, a(l)
                };

                function a(e) {
                    let o = r(e);
                    if (o) return o;
                    let a = function(e, t) {
                        let {
                            splitModifiers: r,
                            getClassGroupId: n,
                            getConflictingClassGroupIds: o
                        } = t, a = new Set;
                        return e.trim().split(b).map(e => {
                            let {
                                modifiers: t,
                                hasImportantModifier: o,
                                baseClassName: a,
                                maybePostfixModifierPosition: l
                            } = r(e), i = n(l ? a.substring(0, l) : a), s = !!l;
                            if (!i) {
                                if (!l || !(i = n(a))) return {
                                    isTailwindClass: !1,
                                    originalClassName: e
                                };
                                s = !1
                            }
                            let d = (function(e) {
                                if (e.length <= 1) return e;
                                let t = [],
                                    r = [];
                                return e.forEach(e => {
                                    let n = "[" === e[0];
                                    n ? (t.push(...r.sort(), e), r = []) : r.push(e)
                                }), t.push(...r.sort()), t
                            })(t).join(":");
                            return {
                                isTailwindClass: !0,
                                modifierId: o ? d + "!" : d,
                                classGroupId: i,
                                originalClassName: e,
                                hasPostfixModifier: s
                            }
                        }).reverse().filter(e => {
                            if (!e.isTailwindClass) return !0;
                            let {
                                modifierId: t,
                                classGroupId: r,
                                hasPostfixModifier: n
                            } = e, l = t + r;
                            return !a.has(l) && (a.add(l), o(r, n).forEach(e => a.add(t + e)), !0)
                        }).reverse().map(e => e.originalClassName).join(" ")
                    }(e, t);
                    return n(e, a), a
                }
                return function() {
                    return o(p.apply(null, arguments))
                }
            }(function() {
                let e = h("colors"),
                    t = h("spacing"),
                    r = h("blur"),
                    n = h("brightness"),
                    o = h("borderColor"),
                    a = h("borderRadius"),
                    l = h("borderSpacing"),
                    i = h("borderWidth"),
                    s = h("contrast"),
                    d = h("grayscale"),
                    c = h("hueRotate"),
                    u = h("invert"),
                    g = h("gap"),
                    f = h("gradientColorStops"),
                    b = h("gradientColorStopPositions"),
                    p = h("inset"),
                    m = h("margin"),
                    y = h("opacity"),
                    x = h("padding"),
                    v = h("saturate"),
                    w = h("scale"),
                    k = h("sepia"),
                    N = h("skew"),
                    I = h("space"),
                    z = h("translate"),
                    B = () => ["auto", "contain", "none"],
                    W = () => ["auto", "hidden", "clip", "visible", "scroll"],
                    _ = () => ["auto", M, t],
                    Y = () => [M, t],
                    G = () => ["", j, E],
                    H = () => ["auto", C, M],
                    $ = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"],
                    U = () => ["solid", "dashed", "dotted", "double", "none"],
                    q = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity", "plus-lighter"],
                    K = () => ["start", "end", "center", "between", "around", "evenly", "stretch"],
                    V = () => ["", "0", M],
                    X = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                    Z = () => [C, T],
                    Q = () => [C, M];
                return {
                    cacheSize: 500,
                    separator: ":",
                    theme: {
                        colors: [F],
                        spacing: [j, E],
                        blur: ["none", "", L, M],
                        brightness: Z(),
                        borderColor: [e],
                        borderRadius: ["none", "", "full", L, M],
                        borderSpacing: Y(),
                        borderWidth: G(),
                        contrast: Z(),
                        grayscale: V(),
                        hueRotate: Q(),
                        invert: V(),
                        gap: Y(),
                        gradientColorStops: [e],
                        gradientColorStopPositions: [S, E],
                        inset: _(),
                        margin: _(),
                        opacity: Z(),
                        padding: Y(),
                        saturate: Z(),
                        scale: Z(),
                        sepia: V(),
                        skew: Q(),
                        space: Y(),
                        translate: Y()
                    },
                    classGroups: {
                        aspect: [{
                            aspect: ["auto", "square", "video", M]
                        }],
                        container: ["container"],
                        columns: [{
                            columns: [L]
                        }],
                        "break-after": [{
                            "break-after": X()
                        }],
                        "break-before": [{
                            "break-before": X()
                        }],
                        "break-inside": [{
                            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                        }],
                        "box-decoration": [{
                            "box-decoration": ["slice", "clone"]
                        }],
                        box: [{
                            box: ["border", "content"]
                        }],
                        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                        float: [{
                            float: ["right", "left", "none"]
                        }],
                        clear: [{
                            clear: ["left", "right", "both", "none"]
                        }],
                        isolation: ["isolate", "isolation-auto"],
                        "object-fit": [{
                            object: ["contain", "cover", "fill", "none", "scale-down"]
                        }],
                        "object-position": [{
                            object: [...$(), M]
                        }],
                        overflow: [{
                            overflow: W()
                        }],
                        "overflow-x": [{
                            "overflow-x": W()
                        }],
                        "overflow-y": [{
                            "overflow-y": W()
                        }],
                        overscroll: [{
                            overscroll: B()
                        }],
                        "overscroll-x": [{
                            "overscroll-x": B()
                        }],
                        "overscroll-y": [{
                            "overscroll-y": B()
                        }],
                        position: ["static", "fixed", "absolute", "relative", "sticky"],
                        inset: [{
                            inset: [p]
                        }],
                        "inset-x": [{
                            "inset-x": [p]
                        }],
                        "inset-y": [{
                            "inset-y": [p]
                        }],
                        start: [{
                            start: [p]
                        }],
                        end: [{
                            end: [p]
                        }],
                        top: [{
                            top: [p]
                        }],
                        right: [{
                            right: [p]
                        }],
                        bottom: [{
                            bottom: [p]
                        }],
                        left: [{
                            left: [p]
                        }],
                        visibility: ["visible", "invisible", "collapse"],
                        z: [{
                            z: ["auto", R, M]
                        }],
                        basis: [{
                            basis: _()
                        }],
                        "flex-direction": [{
                            flex: ["row", "row-reverse", "col", "col-reverse"]
                        }],
                        "flex-wrap": [{
                            flex: ["wrap", "wrap-reverse", "nowrap"]
                        }],
                        flex: [{
                            flex: ["1", "auto", "initial", "none", M]
                        }],
                        grow: [{
                            grow: V()
                        }],
                        shrink: [{
                            shrink: V()
                        }],
                        order: [{
                            order: ["first", "last", "none", R, M]
                        }],
                        "grid-cols": [{
                            "grid-cols": [F]
                        }],
                        "col-start-end": [{
                            col: ["auto", {
                                span: ["full", R, M]
                            }, M]
                        }],
                        "col-start": [{
                            "col-start": H()
                        }],
                        "col-end": [{
                            "col-end": H()
                        }],
                        "grid-rows": [{
                            "grid-rows": [F]
                        }],
                        "row-start-end": [{
                            row: ["auto", {
                                span: [R, M]
                            }, M]
                        }],
                        "row-start": [{
                            "row-start": H()
                        }],
                        "row-end": [{
                            "row-end": H()
                        }],
                        "grid-flow": [{
                            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                        }],
                        "auto-cols": [{
                            "auto-cols": ["auto", "min", "max", "fr", M]
                        }],
                        "auto-rows": [{
                            "auto-rows": ["auto", "min", "max", "fr", M]
                        }],
                        gap: [{
                            gap: [g]
                        }],
                        "gap-x": [{
                            "gap-x": [g]
                        }],
                        "gap-y": [{
                            "gap-y": [g]
                        }],
                        "justify-content": [{
                            justify: ["normal", ...K()]
                        }],
                        "justify-items": [{
                            "justify-items": ["start", "end", "center", "stretch"]
                        }],
                        "justify-self": [{
                            "justify-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        "align-content": [{
                            content: ["normal", ...K(), "baseline"]
                        }],
                        "align-items": [{
                            items: ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "align-self": [{
                            self: ["auto", "start", "end", "center", "stretch", "baseline"]
                        }],
                        "place-content": [{
                            "place-content": [...K(), "baseline"]
                        }],
                        "place-items": [{
                            "place-items": ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "place-self": [{
                            "place-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        p: [{
                            p: [x]
                        }],
                        px: [{
                            px: [x]
                        }],
                        py: [{
                            py: [x]
                        }],
                        ps: [{
                            ps: [x]
                        }],
                        pe: [{
                            pe: [x]
                        }],
                        pt: [{
                            pt: [x]
                        }],
                        pr: [{
                            pr: [x]
                        }],
                        pb: [{
                            pb: [x]
                        }],
                        pl: [{
                            pl: [x]
                        }],
                        m: [{
                            m: [m]
                        }],
                        mx: [{
                            mx: [m]
                        }],
                        my: [{
                            my: [m]
                        }],
                        ms: [{
                            ms: [m]
                        }],
                        me: [{
                            me: [m]
                        }],
                        mt: [{
                            mt: [m]
                        }],
                        mr: [{
                            mr: [m]
                        }],
                        mb: [{
                            mb: [m]
                        }],
                        ml: [{
                            ml: [m]
                        }],
                        "space-x": [{
                            "space-x": [I]
                        }],
                        "space-x-reverse": ["space-x-reverse"],
                        "space-y": [{
                            "space-y": [I]
                        }],
                        "space-y-reverse": ["space-y-reverse"],
                        w: [{
                            w: ["auto", "min", "max", "fit", M, t]
                        }],
                        "min-w": [{
                            "min-w": ["min", "max", "fit", M, j]
                        }],
                        "max-w": [{
                            "max-w": ["0", "none", "full", "min", "max", "fit", "prose", {
                                screen: [L]
                            }, L, M]
                        }],
                        h: [{
                            h: [M, t, "auto", "min", "max", "fit"]
                        }],
                        "min-h": [{
                            "min-h": ["min", "max", "fit", j, M]
                        }],
                        "max-h": [{
                            "max-h": [M, t, "min", "max", "fit"]
                        }],
                        "font-size": [{
                            text: ["base", L, E]
                        }],
                        "font-smoothing": ["antialiased", "subpixel-antialiased"],
                        "font-style": ["italic", "not-italic"],
                        "font-weight": [{
                            font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", T]
                        }],
                        "font-family": [{
                            font: [F]
                        }],
                        "fvn-normal": ["normal-nums"],
                        "fvn-ordinal": ["ordinal"],
                        "fvn-slashed-zero": ["slashed-zero"],
                        "fvn-figure": ["lining-nums", "oldstyle-nums"],
                        "fvn-spacing": ["proportional-nums", "tabular-nums"],
                        "fvn-fraction": ["diagonal-fractions", "stacked-fractons"],
                        tracking: [{
                            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", M]
                        }],
                        "line-clamp": [{
                            "line-clamp": ["none", C, T]
                        }],
                        leading: [{
                            leading: ["none", "tight", "snug", "normal", "relaxed", "loose", j, M]
                        }],
                        "list-image": [{
                            "list-image": ["none", M]
                        }],
                        "list-style-type": [{
                            list: ["none", "disc", "decimal", M]
                        }],
                        "list-style-position": [{
                            list: ["inside", "outside"]
                        }],
                        "placeholder-color": [{
                            placeholder: [e]
                        }],
                        "placeholder-opacity": [{
                            "placeholder-opacity": [y]
                        }],
                        "text-alignment": [{
                            text: ["left", "center", "right", "justify", "start", "end"]
                        }],
                        "text-color": [{
                            text: [e]
                        }],
                        "text-opacity": [{
                            "text-opacity": [y]
                        }],
                        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                        "text-decoration-style": [{
                            decoration: [...U(), "wavy"]
                        }],
                        "text-decoration-thickness": [{
                            decoration: ["auto", "from-font", j, E]
                        }],
                        "underline-offset": [{
                            "underline-offset": ["auto", j, M]
                        }],
                        "text-decoration-color": [{
                            decoration: [e]
                        }],
                        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                        indent: [{
                            indent: Y()
                        }],
                        "vertical-align": [{
                            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", M]
                        }],
                        whitespace: [{
                            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                        }],
                        break: [{
                            break: ["normal", "words", "all", "keep"]
                        }],
                        hyphens: [{
                            hyphens: ["none", "manual", "auto"]
                        }],
                        content: [{
                            content: ["none", M]
                        }],
                        "bg-attachment": [{
                            bg: ["fixed", "local", "scroll"]
                        }],
                        "bg-clip": [{
                            "bg-clip": ["border", "padding", "content", "text"]
                        }],
                        "bg-opacity": [{
                            "bg-opacity": [y]
                        }],
                        "bg-origin": [{
                            "bg-origin": ["border", "padding", "content"]
                        }],
                        "bg-position": [{
                            bg: [...$(), P]
                        }],
                        "bg-repeat": [{
                            bg: ["no-repeat", {
                                repeat: ["", "x", "y", "round", "space"]
                            }]
                        }],
                        "bg-size": [{
                            bg: ["auto", "cover", "contain", D]
                        }],
                        "bg-image": [{
                            bg: ["none", {
                                "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                            }, O]
                        }],
                        "bg-color": [{
                            bg: [e]
                        }],
                        "gradient-from-pos": [{
                            from: [b]
                        }],
                        "gradient-via-pos": [{
                            via: [b]
                        }],
                        "gradient-to-pos": [{
                            to: [b]
                        }],
                        "gradient-from": [{
                            from: [f]
                        }],
                        "gradient-via": [{
                            via: [f]
                        }],
                        "gradient-to": [{
                            to: [f]
                        }],
                        rounded: [{
                            rounded: [a]
                        }],
                        "rounded-s": [{
                            "rounded-s": [a]
                        }],
                        "rounded-e": [{
                            "rounded-e": [a]
                        }],
                        "rounded-t": [{
                            "rounded-t": [a]
                        }],
                        "rounded-r": [{
                            "rounded-r": [a]
                        }],
                        "rounded-b": [{
                            "rounded-b": [a]
                        }],
                        "rounded-l": [{
                            "rounded-l": [a]
                        }],
                        "rounded-ss": [{
                            "rounded-ss": [a]
                        }],
                        "rounded-se": [{
                            "rounded-se": [a]
                        }],
                        "rounded-ee": [{
                            "rounded-ee": [a]
                        }],
                        "rounded-es": [{
                            "rounded-es": [a]
                        }],
                        "rounded-tl": [{
                            "rounded-tl": [a]
                        }],
                        "rounded-tr": [{
                            "rounded-tr": [a]
                        }],
                        "rounded-br": [{
                            "rounded-br": [a]
                        }],
                        "rounded-bl": [{
                            "rounded-bl": [a]
                        }],
                        "border-w": [{
                            border: [i]
                        }],
                        "border-w-x": [{
                            "border-x": [i]
                        }],
                        "border-w-y": [{
                            "border-y": [i]
                        }],
                        "border-w-s": [{
                            "border-s": [i]
                        }],
                        "border-w-e": [{
                            "border-e": [i]
                        }],
                        "border-w-t": [{
                            "border-t": [i]
                        }],
                        "border-w-r": [{
                            "border-r": [i]
                        }],
                        "border-w-b": [{
                            "border-b": [i]
                        }],
                        "border-w-l": [{
                            "border-l": [i]
                        }],
                        "border-opacity": [{
                            "border-opacity": [y]
                        }],
                        "border-style": [{
                            border: [...U(), "hidden"]
                        }],
                        "divide-x": [{
                            "divide-x": [i]
                        }],
                        "divide-x-reverse": ["divide-x-reverse"],
                        "divide-y": [{
                            "divide-y": [i]
                        }],
                        "divide-y-reverse": ["divide-y-reverse"],
                        "divide-opacity": [{
                            "divide-opacity": [y]
                        }],
                        "divide-style": [{
                            divide: U()
                        }],
                        "border-color": [{
                            border: [o]
                        }],
                        "border-color-x": [{
                            "border-x": [o]
                        }],
                        "border-color-y": [{
                            "border-y": [o]
                        }],
                        "border-color-t": [{
                            "border-t": [o]
                        }],
                        "border-color-r": [{
                            "border-r": [o]
                        }],
                        "border-color-b": [{
                            "border-b": [o]
                        }],
                        "border-color-l": [{
                            "border-l": [o]
                        }],
                        "divide-color": [{
                            divide: [o]
                        }],
                        "outline-style": [{
                            outline: ["", ...U()]
                        }],
                        "outline-offset": [{
                            "outline-offset": [j, M]
                        }],
                        "outline-w": [{
                            outline: [j, E]
                        }],
                        "outline-color": [{
                            outline: [e]
                        }],
                        "ring-w": [{
                            ring: G()
                        }],
                        "ring-w-inset": ["ring-inset"],
                        "ring-color": [{
                            ring: [e]
                        }],
                        "ring-opacity": [{
                            "ring-opacity": [y]
                        }],
                        "ring-offset-w": [{
                            "ring-offset": [j, E]
                        }],
                        "ring-offset-color": [{
                            "ring-offset": [e]
                        }],
                        shadow: [{
                            shadow: ["", "inner", "none", L, A]
                        }],
                        "shadow-color": [{
                            shadow: [F]
                        }],
                        opacity: [{
                            opacity: [y]
                        }],
                        "mix-blend": [{
                            "mix-blend": q()
                        }],
                        "bg-blend": [{
                            "bg-blend": q()
                        }],
                        filter: [{
                            filter: ["", "none"]
                        }],
                        blur: [{
                            blur: [r]
                        }],
                        brightness: [{
                            brightness: [n]
                        }],
                        contrast: [{
                            contrast: [s]
                        }],
                        "drop-shadow": [{
                            "drop-shadow": ["", "none", L, M]
                        }],
                        grayscale: [{
                            grayscale: [d]
                        }],
                        "hue-rotate": [{
                            "hue-rotate": [c]
                        }],
                        invert: [{
                            invert: [u]
                        }],
                        saturate: [{
                            saturate: [v]
                        }],
                        sepia: [{
                            sepia: [k]
                        }],
                        "backdrop-filter": [{
                            "backdrop-filter": ["", "none"]
                        }],
                        "backdrop-blur": [{
                            "backdrop-blur": [r]
                        }],
                        "backdrop-brightness": [{
                            "backdrop-brightness": [n]
                        }],
                        "backdrop-contrast": [{
                            "backdrop-contrast": [s]
                        }],
                        "backdrop-grayscale": [{
                            "backdrop-grayscale": [d]
                        }],
                        "backdrop-hue-rotate": [{
                            "backdrop-hue-rotate": [c]
                        }],
                        "backdrop-invert": [{
                            "backdrop-invert": [u]
                        }],
                        "backdrop-opacity": [{
                            "backdrop-opacity": [y]
                        }],
                        "backdrop-saturate": [{
                            "backdrop-saturate": [v]
                        }],
                        "backdrop-sepia": [{
                            "backdrop-sepia": [k]
                        }],
                        "border-collapse": [{
                            border: ["collapse", "separate"]
                        }],
                        "border-spacing": [{
                            "border-spacing": [l]
                        }],
                        "border-spacing-x": [{
                            "border-spacing-x": [l]
                        }],
                        "border-spacing-y": [{
                            "border-spacing-y": [l]
                        }],
                        "table-layout": [{
                            table: ["auto", "fixed"]
                        }],
                        caption: [{
                            caption: ["top", "bottom"]
                        }],
                        transition: [{
                            transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", M]
                        }],
                        duration: [{
                            duration: Q()
                        }],
                        ease: [{
                            ease: ["linear", "in", "out", "in-out", M]
                        }],
                        delay: [{
                            delay: Q()
                        }],
                        animate: [{
                            animate: ["none", "spin", "ping", "pulse", "bounce", M]
                        }],
                        transform: [{
                            transform: ["", "gpu", "none"]
                        }],
                        scale: [{
                            scale: [w]
                        }],
                        "scale-x": [{
                            "scale-x": [w]
                        }],
                        "scale-y": [{
                            "scale-y": [w]
                        }],
                        rotate: [{
                            rotate: [R, M]
                        }],
                        "translate-x": [{
                            "translate-x": [z]
                        }],
                        "translate-y": [{
                            "translate-y": [z]
                        }],
                        "skew-x": [{
                            "skew-x": [N]
                        }],
                        "skew-y": [{
                            "skew-y": [N]
                        }],
                        "transform-origin": [{
                            origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", M]
                        }],
                        accent: [{
                            accent: ["auto", e]
                        }],
                        appearance: ["appearance-none"],
                        cursor: [{
                            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", M]
                        }],
                        "caret-color": [{
                            caret: [e]
                        }],
                        "pointer-events": [{
                            "pointer-events": ["none", "auto"]
                        }],
                        resize: [{
                            resize: ["none", "y", "x", ""]
                        }],
                        "scroll-behavior": [{
                            scroll: ["auto", "smooth"]
                        }],
                        "scroll-m": [{
                            "scroll-m": Y()
                        }],
                        "scroll-mx": [{
                            "scroll-mx": Y()
                        }],
                        "scroll-my": [{
                            "scroll-my": Y()
                        }],
                        "scroll-ms": [{
                            "scroll-ms": Y()
                        }],
                        "scroll-me": [{
                            "scroll-me": Y()
                        }],
                        "scroll-mt": [{
                            "scroll-mt": Y()
                        }],
                        "scroll-mr": [{
                            "scroll-mr": Y()
                        }],
                        "scroll-mb": [{
                            "scroll-mb": Y()
                        }],
                        "scroll-ml": [{
                            "scroll-ml": Y()
                        }],
                        "scroll-p": [{
                            "scroll-p": Y()
                        }],
                        "scroll-px": [{
                            "scroll-px": Y()
                        }],
                        "scroll-py": [{
                            "scroll-py": Y()
                        }],
                        "scroll-ps": [{
                            "scroll-ps": Y()
                        }],
                        "scroll-pe": [{
                            "scroll-pe": Y()
                        }],
                        "scroll-pt": [{
                            "scroll-pt": Y()
                        }],
                        "scroll-pr": [{
                            "scroll-pr": Y()
                        }],
                        "scroll-pb": [{
                            "scroll-pb": Y()
                        }],
                        "scroll-pl": [{
                            "scroll-pl": Y()
                        }],
                        "snap-align": [{
                            snap: ["start", "end", "center", "align-none"]
                        }],
                        "snap-stop": [{
                            snap: ["normal", "always"]
                        }],
                        "snap-type": [{
                            snap: ["none", "x", "y", "both"]
                        }],
                        "snap-strictness": [{
                            snap: ["mandatory", "proximity"]
                        }],
                        touch: [{
                            touch: ["auto", "none", "manipulation"]
                        }],
                        "touch-x": [{
                            "touch-pan": ["x", "left", "right"]
                        }],
                        "touch-y": [{
                            "touch-pan": ["y", "up", "down"]
                        }],
                        "touch-pz": ["touch-pinch-zoom"],
                        select: [{
                            select: ["none", "text", "all", "auto"]
                        }],
                        "will-change": [{
                            "will-change": ["auto", "scroll", "contents", "transform", M]
                        }],
                        fill: [{
                            fill: [e, "none"]
                        }],
                        "stroke-w": [{
                            stroke: [j, E, T]
                        }],
                        stroke: [{
                            stroke: [e, "none"]
                        }],
                        sr: ["sr-only", "not-sr-only"]
                    },
                    conflictingClassGroups: {
                        overflow: ["overflow-x", "overflow-y"],
                        overscroll: ["overscroll-x", "overscroll-y"],
                        inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                        "inset-x": ["right", "left"],
                        "inset-y": ["top", "bottom"],
                        flex: ["basis", "grow", "shrink"],
                        gap: ["gap-x", "gap-y"],
                        p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                        px: ["pr", "pl"],
                        py: ["pt", "pb"],
                        m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                        mx: ["mr", "ml"],
                        my: ["mt", "mb"],
                        "font-size": ["leading"],
                        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                        "fvn-ordinal": ["fvn-normal"],
                        "fvn-slashed-zero": ["fvn-normal"],
                        "fvn-figure": ["fvn-normal"],
                        "fvn-spacing": ["fvn-normal"],
                        "fvn-fraction": ["fvn-normal"],
                        "line-clamp": ["display", "overflow"],
                        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                        "rounded-s": ["rounded-ss", "rounded-es"],
                        "rounded-e": ["rounded-se", "rounded-ee"],
                        "rounded-t": ["rounded-tl", "rounded-tr"],
                        "rounded-r": ["rounded-tr", "rounded-br"],
                        "rounded-b": ["rounded-br", "rounded-bl"],
                        "rounded-l": ["rounded-tl", "rounded-bl"],
                        "border-spacing": ["border-spacing-x", "border-spacing-y"],
                        "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                        "border-w-x": ["border-w-r", "border-w-l"],
                        "border-w-y": ["border-w-t", "border-w-b"],
                        "border-color": ["border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                        "border-color-x": ["border-color-r", "border-color-l"],
                        "border-color-y": ["border-color-t", "border-color-b"],
                        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                        "scroll-mx": ["scroll-mr", "scroll-ml"],
                        "scroll-my": ["scroll-mt", "scroll-mb"],
                        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                        "scroll-px": ["scroll-pr", "scroll-pl"],
                        "scroll-py": ["scroll-pt", "scroll-pb"],
                        touch: ["touch-x", "touch-y", "touch-pz"],
                        "touch-x": ["touch"],
                        "touch-y": ["touch"],
                        "touch-pz": ["touch"]
                    },
                    conflictingClassGroupModifiers: {
                        "font-size": ["leading"]
                    }
                }
            });

            function $(e) {
                return null !== e && "object" == typeof e && e.constructor === Object
            }

            function U(e) {
                if (!$(e)) return e;
                let t = {};
                for (let r in e) t[r] = U(e[r]);
                return t
            }

            function q(e, t) {
                if ($(t) && 0 === Object.keys(t).length) return U({ ...e,
                    ...t
                });
                let r = { ...e,
                    ...t
                };
                if ($(t) && $(e))
                    for (let n in t) $(t[n]) && n in e && $(e[n]) ? r[n] = q(e[n], t[n]) : r[n] = $(t[n]) ? U(t[n]) : t[n];
                return r
            }
            let K = {
                    accordion: {
                        root: {
                            base: "divide-y divide-gray-200 border-gray-200 dark:divide-gray-700 dark:border-gray-700",
                            flush: {
                                off: "rounded-lg border",
                                on: "border-b"
                            }
                        },
                        content: {
                            base: "py-5 px-5 last:rounded-b-lg dark:bg-gray-900 first:rounded-t-lg"
                        },
                        title: {
                            arrow: {
                                base: "h-6 w-6 shrink-0",
                                open: {
                                    off: "",
                                    on: "rotate-180"
                                }
                            },
                            base: "flex w-full items-center justify-between first:rounded-t-lg last:rounded-b-lg py-5 px-5 text-left font-medium text-gray-500 dark:text-gray-400",
                            flush: {
                                off: "hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 dark:hover:bg-gray-800 dark:focus:ring-gray-800",
                                on: "bg-transparent dark:bg-transparent"
                            },
                            heading: "",
                            open: {
                                off: "",
                                on: "text-gray-900 bg-gray-100 dark:bg-gray-800 dark:text-white"
                            }
                        }
                    },
                    alert: {
                        base: "flex flex-col gap-2 p-4 text-sm",
                        borderAccent: "border-t-4",
                        closeButton: {
                            base: "-mx-1.5 -my-1.5 ml-auto inline-flex h-8 w-8 rounded-lg p-1.5 focus:ring-2",
                            icon: "w-5 h-5",
                            color: {
                                info: "bg-cyan-100 text-cyan-500 hover:bg-cyan-200 focus:ring-cyan-400 dark:bg-cyan-200 dark:text-cyan-600 dark:hover:bg-cyan-300",
                                gray: "bg-gray-100 text-gray-500 hover:bg-gray-200 focus:ring-gray-400 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white",
                                failure: "bg-red-100 text-red-500 hover:bg-red-200 focus:ring-red-400 dark:bg-red-200 dark:text-red-600 dark:hover:bg-red-300",
                                success: "bg-green-100 text-green-500 hover:bg-green-200 focus:ring-green-400 dark:bg-green-200 dark:text-green-600 dark:hover:bg-green-300",
                                warning: "bg-yellow-100 text-yellow-500 hover:bg-yellow-200 focus:ring-yellow-400 dark:bg-yellow-200 dark:text-yellow-600 dark:hover:bg-yellow-300",
                                red: "bg-red-100 text-red-500 hover:bg-red-200 focus:ring-red-400 dark:bg-red-200 dark:text-red-600 dark:hover:bg-red-300",
                                green: "bg-green-100 text-green-500 hover:bg-green-200 focus:ring-green-400 dark:bg-green-200 dark:text-green-600 dark:hover:bg-green-300",
                                yellow: "bg-yellow-100 text-yellow-500 hover:bg-yellow-200 focus:ring-yellow-400 dark:bg-yellow-200 dark:text-yellow-600 dark:hover:bg-yellow-300",
                                blue: "bg-cyan-100 text-cyan-500 hover:bg-cyan-200 focus:ring-cyan-400 dark:bg-cyan-200 dark:text-cyan-600 dark:hover:bg-cyan-300",
                                cyan: "bg-cyan-100 text-cyan-500 hover:bg-cyan-200 focus:ring-cyan-400 dark:bg-cyan-200 dark:text-cyan-600 dark:hover:bg-cyan-300",
                                pink: "bg-pink-100 text-pink-500 hover:bg-pink-200 focus:ring-pink-400 dark:bg-pink-200 dark:text-pink-600 dark:hover:bg-pink-300",
                                lime: "bg-lime-100 text-lime-500 hover:bg-lime-200 focus:ring-lime-400 dark:bg-lime-200 dark:text-lime-600 dark:hover:bg-lime-300",
                                dark: "bg-gray-100 text-gray-500 hover:bg-gray-200 focus:ring-gray-400 dark:bg-gray-200 dark:text-gray-600 dark:hover:bg-gray-300",
                                indigo: "bg-indigo-100 text-indigo-500 hover:bg-indigo-200 focus:ring-indigo-400 dark:bg-indigo-200 dark:text-indigo-600 dark:hover:bg-indigo-300",
                                purple: "bg-purple-100 text-purple-500 hover:bg-purple-200 focus:ring-purple-400 dark:bg-purple-200 dark:text-purple-600 dark:hover:bg-purple-300",
                                teal: "bg-teal-100 text-teal-500 hover:bg-teal-200 focus:ring-teal-400 dark:bg-teal-200 dark:text-teal-600 dark:hover:bg-teal-300",
                                light: "bg-gray-50 text-gray-500 hover:bg-gray-100 focus:ring-gray-200 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-700 dark:hover:text-white"
                            }
                        },
                        color: {
                            info: "text-cyan-700 bg-cyan-100 border-cyan-500 dark:bg-cyan-200 dark:text-cyan-800",
                            gray: "text-gray-700 bg-gray-100 border-gray-500 dark:bg-gray-700 dark:text-gray-300",
                            failure: "text-red-700 bg-red-100 border-red-500 dark:bg-red-200 dark:text-red-800",
                            success: "text-green-700 bg-green-100 border-green-500 dark:bg-green-200 dark:text-green-800",
                            warning: "text-yellow-700 bg-yellow-100 border-yellow-500 dark:bg-yellow-200 dark:text-yellow-800",
                            red: "text-red-700 bg-red-100 border-red-500 dark:bg-red-200 dark:text-red-800",
                            green: "text-green-700 bg-green-100 border-green-500 dark:bg-green-200 dark:text-green-800",
                            yellow: "text-yellow-700 bg-yellow-100 border-yellow-500 dark:bg-yellow-200 dark:text-yellow-800",
                            blue: "text-cyan-700 bg-cyan-100 border-cyan-500 dark:bg-cyan-200 dark:text-cyan-800",
                            cyan: "text-cyan-700 bg-cyan-100 border-cyan-500 dark:bg-cyan-200 dark:text-cyan-800",
                            pink: "text-pink-700 bg-pink-100 border-pink-500 dark:bg-pink-200 dark:text-pink-800",
                            lime: "text-lime-700 bg-lime-100 border-lime-500 dark:bg-lime-200 dark:text-lime-800",
                            dark: "text-gray-200 bg-gray-800 border-gray-600 dark:bg-gray-900 dark:text-gray-300",
                            indigo: "text-indigo-700 bg-indigo-100 border-indigo-500 dark:bg-indigo-200 dark:text-indigo-800",
                            purple: "text-purple-700 bg-purple-100 border-purple-500 dark:bg-purple-200 dark:text-purple-800",
                            teal: "text-teal-700 bg-teal-100 border-teal-500 dark:bg-teal-200 dark:text-teal-800",
                            light: "text-gray-600 bg-gray-50 border-gray-400 dark:bg-gray-500 dark:text-gray-200"
                        },
                        icon: "mr-3 inline h-5 w-5 flex-shrink-0",
                        rounded: "rounded-lg",
                        wrapper: "flex items-center"
                    },
                    avatar: {
                        root: {
                            base: "flex justify-center items-center space-x-4 rounded",
                            bordered: "p-1 ring-2",
                            rounded: "rounded-full",
                            color: {
                                dark: "ring-gray-800 dark:ring-gray-800",
                                failure: "ring-red-500 dark:ring-red-700",
                                gray: "ring-gray-500 dark:ring-gray-400",
                                info: "ring-cyan-400 dark:ring-cyan-800",
                                light: "ring-gray-300 dark:ring-gray-500",
                                purple: "ring-purple-500 dark:ring-purple-600",
                                success: "ring-green-500 dark:ring-green-500",
                                warning: "ring-yellow-300 dark:ring-yellow-500",
                                pink: "ring-pink-500 dark:ring-pink-500"
                            },
                            img: {
                                base: "rounded",
                                off: "relative overflow-hidden bg-gray-100 dark:bg-gray-600",
                                on: "",
                                placeholder: "absolute w-auto h-auto text-gray-400 -bottom-1"
                            },
                            size: {
                                xs: "w-6 h-6",
                                sm: "w-8 h-8",
                                md: "w-10 h-10",
                                lg: "w-20 h-20",
                                xl: "w-36 h-36"
                            },
                            stacked: "ring-2 ring-gray-300 dark:ring-gray-500",
                            statusPosition: {
                                "bottom-left": "-bottom-1 -left-1",
                                "bottom-center": "-bottom-1 center",
                                "bottom-right": "-bottom-1 -right-1",
                                "top-left": "-top-1 -left-1",
                                "top-center": "-top-1 center",
                                "top-right": "-top-1 -right-1",
                                "center-right": "center -right-1",
                                center: "center center",
                                "center-left": "center -left-1"
                            },
                            status: {
                                away: "bg-yellow-400",
                                base: "absolute h-3.5 w-3.5 rounded-full border-2 border-white dark:border-gray-800",
                                busy: "bg-red-400",
                                offline: "bg-gray-400",
                                online: "bg-green-400"
                            },
                            initials: {
                                text: "font-medium text-gray-600 dark:text-gray-300",
                                base: "inline-flex overflow-hidden relative justify-center items-center bg-gray-100 dark:bg-gray-600"
                            }
                        },
                        group: {
                            base: "flex -space-x-4"
                        },
                        groupCounter: {
                            base: "relative flex items-center justify-center w-10 h-10 text-xs font-medium text-white bg-gray-700 rounded-full ring-2 ring-gray-300 hover:bg-gray-600 dark:ring-gray-500"
                        }
                    },
                    badge: {
                        root: {
                            base: "flex h-fit items-center gap-1 font-semibold",
                            color: {
                                info: "bg-cyan-100 text-cyan-800 dark:bg-cyan-200 dark:text-cyan-800 group-hover:bg-cyan-200 dark:group-hover:bg-cyan-300",
                                gray: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 group-hover:bg-gray-200 dark:group-hover:bg-gray-600",
                                failure: "bg-red-100 text-red-800 dark:bg-red-200 dark:text-red-900 group-hover:bg-red-200 dark:group-hover:bg-red-300",
                                success: "bg-green-100 text-green-800 dark:bg-green-200 dark:text-green-900 group-hover:bg-green-200 dark:group-hover:bg-green-300",
                                warning: "bg-yellow-100 text-yellow-800 dark:bg-yellow-200 dark:text-yellow-900 group-hover:bg-yellow-200 dark:group-hover:bg-yellow-300",
                                indigo: "bg-indigo-100 text-indigo-800 dark:bg-indigo-200 dark:text-indigo-900 group-hover:bg-indigo-200 dark:group-hover:bg-indigo-300",
                                purple: "bg-purple-100 text-purple-800 dark:bg-purple-200 dark:text-purple-900 group-hover:bg-purple-200 dark:group-hover:bg-purple-300",
                                pink: "bg-pink-100 text-pink-800 dark:bg-pink-200 dark:text-pink-900 group-hover:bg-pink-200 dark:group-hover:bg-pink-300",
                                blue: "bg-cyan-100 text-cyan-800 dark:bg-cyan-200 dark:text-cyan-900 group-hover:bg-cyan-200 dark:group-hover:bg-cyan-300",
                                cyan: "bg-cyan-100 text-cyan-800 dark:bg-cyan-200 dark:text-cyan-900 group-hover:bg-cyan-200 dark:group-hover:bg-cyan-300",
                                dark: "bg-gray-600 text-gray-100 dark:bg-gray-900 dark:text-gray-200 group-hover:bg-gray-500 dark:group-hover:bg-gray-700",
                                light: "bg-gray-200 text-gray-800 dark:bg-gray-400 dark:text-gray-900 group-hover:bg-gray-300 dark:group-hover:bg-gray-500",
                                green: "bg-green-100 text-green-800 dark:bg-green-200 dark:text-green-900 group-hover:bg-green-200 dark:group-hover:bg-green-300",
                                lime: "bg-lime-100 text-lime-800 dark:bg-lime-200 dark:text-lime-900 group-hover:bg-lime-200 dark:group-hover:bg-lime-300",
                                red: "bg-red-100 text-red-800 dark:bg-red-200 dark:text-red-900 group-hover:bg-red-200 dark:group-hover:bg-red-300",
                                teal: "bg-teal-100 text-teal-800 dark:bg-teal-200 dark:text-teal-900 group-hover:bg-teal-200 dark:group-hover:bg-teal-300",
                                yellow: "bg-yellow-100 text-yellow-800 dark:bg-yellow-200 dark:text-yellow-900 group-hover:bg-yellow-200 dark:group-hover:bg-yellow-300"
                            },
                            href: "group",
                            size: {
                                xs: "p-1 text-xs",
                                sm: "p-1.5 text-sm"
                            }
                        },
                        icon: {
                            off: "rounded px-2 py-0.5",
                            on: "rounded-full p-1.5",
                            size: {
                                xs: "w-3 h-3",
                                sm: "w-3.5 h-3.5"
                            }
                        }
                    },
                    blockquote: {
                        root: {
                            base: "text-xl italic font-semibold text-gray-900 dark:text-white"
                        }
                    },
                    breadcrumb: {
                        root: {
                            base: "",
                            list: "flex items-center"
                        },
                        item: {
                            base: "group flex items-center",
                            chevron: "mx-1 h-4 w-4 text-gray-400 group-first:hidden md:mx-2",
                            href: {
                                off: "flex items-center text-sm font-medium text-gray-500 dark:text-gray-400",
                                on: "flex items-center text-sm font-medium text-gray-700 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
                            },
                            icon: "mr-2 h-4 w-4"
                        }
                    },
                    button: {
                        base: "group flex items-stretch items-center justify-center p-0.5 text-center font-medium relative focus:z-10 focus:outline-none",
                        fullSized: "w-full",
                        color: {
                            dark: "text-white bg-gray-800 border border-transparent enabled:hover:bg-gray-900 focus:ring-4 focus:ring-gray-300 dark:bg-gray-800 dark:enabled:hover:bg-gray-700 dark:focus:ring-gray-800 dark:border-gray-700",
                            failure: "text-white bg-red-700 border border-transparent enabled:hover:bg-red-800 focus:ring-4 focus:ring-red-300 dark:bg-red-600 dark:enabled:hover:bg-red-700 dark:focus:ring-red-900",
                            gray: "text-gray-900 bg-white border border-gray-200 enabled:hover:bg-gray-100 enabled:hover:text-cyan-700 :ring-cyan-700 focus:text-cyan-700 dark:bg-transparent dark:text-gray-400 dark:border-gray-600 dark:enabled:hover:text-white dark:enabled:hover:bg-gray-700 focus:ring-2",
                            info: "text-white bg-cyan-700 border border-transparent enabled:hover:bg-cyan-800 focus:ring-4 focus:ring-cyan-300 dark:bg-cyan-600 dark:enabled:hover:bg-cyan-700 dark:focus:ring-cyan-800",
                            light: "text-gray-900 bg-white border border-gray-300 enabled:hover:bg-gray-100 focus:ring-4 focus:ring-cyan-300 dark:bg-gray-600 dark:text-white dark:border-gray-600 dark:enabled:hover:bg-gray-700 dark:enabled:hover:border-gray-700 dark:focus:ring-gray-700",
                            purple: "text-white bg-purple-700 border border-transparent enabled:hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 dark:bg-purple-600 dark:enabled:hover:bg-purple-700 dark:focus:ring-purple-900",
                            success: "text-white bg-green-700 border border-transparent enabled:hover:bg-green-800 focus:ring-4 focus:ring-green-300 dark:bg-green-600 dark:enabled:hover:bg-green-700 dark:focus:ring-green-800",
                            warning: "text-white bg-yellow-400 border border-transparent enabled:hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 dark:focus:ring-yellow-900",
                            blue: "text-white bg-blue-700 border border-transparent enabled:hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                            cyan: "text-cyan-900 bg-white border border-cyan-300 enabled:hover:bg-cyan-100 focus:ring-4 focus:ring-cyan-300 dark:bg-cyan-600 dark:text-white dark:border-cyan-600 dark:enabled:hover:bg-cyan-700 dark:enabled:hover:border-cyan-700 dark:focus:ring-cyan-700",
                            green: "text-green-900 bg-white border border-green-300 enabled:hover:bg-green-100 focus:ring-4 focus:ring-green-300 dark:bg-green-600 dark:text-white dark:border-green-600 dark:enabled:hover:bg-green-700 dark:enabled:hover:border-green-700 dark:focus:ring-green-700",
                            indigo: "text-indigo-900 bg-white border border-indigo-300 enabled:hover:bg-indigo-100 focus:ring-4 focus:ring-indigo-300 dark:bg-indigo-600 dark:text-white dark:border-indigo-600 dark:enabled:hover:bg-indigo-700 dark:enabled:hover:border-indigo-700 dark:focus:ring-indigo-700",
                            lime: "text-lime-900 bg-white border border-lime-300 enabled:hover:bg-lime-100 focus:ring-4 focus:ring-lime-300 dark:bg-lime-600 dark:text-white dark:border-lime-600 dark:enabled:hover:bg-lime-700 dark:enabled:hover:border-lime-700 dark:focus:ring-lime-700",
                            pink: "text-pink-900 bg-white border border-pink-300 enabled:hover:bg-pink-100 focus:ring-4 focus:ring-pink-300 dark:bg-pink-600 dark:text-white dark:border-pink-600 dark:enabled:hover:bg-pink-700 dark:enabled:hover:border-pink-700 dark:focus:ring-pink-700",
                            red: "text-red-900 bg-white border border-red-300 enabled:hover:bg-red-100 focus:ring-4 focus:ring-red-300 dark:bg-red-600 dark:text-white dark:border-red-600 dark:enabled:hover:bg-red-700 dark:enabled:hover:border-red-700 dark:focus:ring-red-700",
                            teal: "text-teal-900 bg-white border border-teal-300 enabled:hover:bg-teal-100 focus:ring-4 focus:ring-teal-300 dark:bg-teal-600 dark:text-white dark:border-teal-600 dark:enabled:hover:bg-teal-700 dark:enabled:hover:border-teal-700 dark:focus:ring-teal-700",
                            yellow: "text-yellow-900 bg-white border border-yellow-300 enabled:hover:bg-yellow-100 focus:ring-4 focus:ring-yellow-300 dark:bg-yellow-600 dark:text-white dark:border-yellow-600 dark:enabled:hover:bg-yellow-700 dark:enabled:hover:border-yellow-700 dark:focus:ring-yellow-700"
                        },
                        disabled: "cursor-not-allowed opacity-50",
                        isProcessing: "cursor-wait",
                        spinnerSlot: "absolute h-full top-0 flex items-center animate-fade-in",
                        spinnerLeftPosition: {
                            xs: "left-2",
                            sm: "left-3",
                            md: "left-4",
                            lg: "left-5",
                            xl: "left-6"
                        },
                        gradient: {
                            cyan: "text-white bg-gradient-to-r from-cyan-400 via-cyan-500 to-cyan-600 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-cyan-300 dark:focus:ring-cyan-800",
                            failure: "text-white bg-gradient-to-r from-red-400 via-red-500 to-red-600 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-red-300 dark:focus:ring-red-800",
                            info: "text-white bg-gradient-to-r from-cyan-500 via-cyan-600 to-cyan-700 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-cyan-300 dark:focus:ring-cyan-800 ",
                            lime: "text-gray-900 bg-gradient-to-r from-lime-200 via-lime-400 to-lime-500 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-lime-300 dark:focus:ring-lime-800",
                            pink: "text-white bg-gradient-to-r from-pink-400 via-pink-500 to-pink-600 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-pink-300 dark:focus:ring-pink-800",
                            purple: "text-white bg-gradient-to-r from-purple-500 via-purple-600 to-purple-700 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-purple-300 dark:focus:ring-purple-800",
                            success: "text-white bg-gradient-to-r from-green-400 via-green-500 to-green-600 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-green-300 dark:focus:ring-green-800",
                            teal: "text-white bg-gradient-to-r from-teal-400 via-teal-500 to-teal-600 enabled:hover:bg-gradient-to-br focus:ring-4 focus:ring-teal-300 dark:focus:ring-teal-800"
                        },
                        gradientDuoTone: {
                            cyanToBlue: "text-white bg-gradient-to-r from-cyan-500 to-cyan-500 enabled:hover:bg-gradient-to-bl focus:ring-4 focus:ring-cyan-300 dark:focus:ring-cyan-800",
                            greenToBlue: "text-white bg-gradient-to-br from-green-400 to-cyan-600 enabled:hover:bg-gradient-to-bl focus:ring-4 focus:ring-green-200 dark:focus:ring-green-800",
                            pinkToOrange: "text-white bg-gradient-to-br from-pink-500 to-orange-400 enabled:hover:bg-gradient-to-bl focus:ring-4 focus:ring-pink-200 dark:focus:ring-pink-800",
                            purpleToBlue: "text-white bg-gradient-to-br from-purple-600 to-cyan-500 enabled:hover:bg-gradient-to-bl focus:ring-4 focus:ring-cyan-300 dark:focus:ring-cyan-800",
                            purpleToPink: "text-white bg-gradient-to-r from-purple-500 to-pink-500 enabled:hover:bg-gradient-to-l focus:ring-4 focus:ring-purple-200 dark:focus:ring-purple-800",
                            redToYellow: "text-gray-900 bg-gradient-to-r from-red-200 via-red-300 to-yellow-200 enabled:hover:bg-gradient-to-bl focus:ring-4 focus:ring-red-100 dark:focus:ring-red-400",
                            tealToLime: "text-gray-900 bg-gradient-to-r from-teal-200 to-lime-200 enabled:hover:bg-gradient-to-l enabled:hover:from-teal-200 enabled:hover:to-lime-200 enabled:hover:text-gray-900 focus:ring-4 focus:ring-lime-200 dark:focus:ring-teal-700"
                        },
                        inner: {
                            base: "flex items-stretch items-center transition-all duration-200",
                            position: {
                                none: "",
                                start: "rounded-r-none",
                                middle: "rounded-none",
                                end: "rounded-l-none"
                            },
                            outline: "border border-transparent",
                            isProcessingPadding: {
                                xs: "pl-8",
                                sm: "pl-10",
                                md: "pl-12",
                                lg: "pl-16",
                                xl: "pl-20"
                            }
                        },
                        label: "ml-2 inline-flex h-4 w-4 items-center justify-center rounded-full bg-cyan-200 text-xs font-semibold text-cyan-800",
                        outline: {
                            color: {
                                gray: "border border-gray-900 dark:border-white",
                                default: "border-0",
                                light: ""
                            },
                            off: "",
                            on: "flex justify-center bg-white text-gray-900 transition-all duration-75 ease-in group-enabled:group-hover:bg-opacity-0 group-enabled:group-hover:text-inherit dark:bg-gray-900 dark:text-white w-full",
                            pill: {
                                off: "rounded-md",
                                on: "rounded-full"
                            }
                        },
                        pill: {
                            off: "rounded-lg",
                            on: "rounded-full"
                        },
                        size: {
                            xs: "text-xs px-2 py-1",
                            sm: "text-sm px-3 py-1.5",
                            md: "text-sm px-4 py-2",
                            lg: "text-base px-5 py-2.5",
                            xl: "text-base px-6 py-3"
                        }
                    },
                    buttonGroup: {
                        base: "inline-flex",
                        position: {
                            none: "focus:ring-2",
                            start: "rounded-r-none",
                            middle: "rounded-none border-l-0 pl-0",
                            end: "rounded-l-none border-l-0 pl-0"
                        }
                    },
                    card: {
                        root: {
                            base: "flex rounded-lg border border-gray-200 bg-white shadow-md dark:border-gray-700 dark:bg-gray-800",
                            children: "flex h-full flex-col justify-center gap-4 p-6",
                            horizontal: {
                                off: "flex-col",
                                on: "flex-col md:max-w-xl md:flex-row"
                            },
                            href: "hover:bg-gray-100 dark:hover:bg-gray-700"
                        },
                        img: {
                            base: "",
                            horizontal: {
                                off: "rounded-t-lg",
                                on: "h-96 w-full rounded-t-lg object-cover md:h-auto md:w-48 md:rounded-none md:rounded-l-lg"
                            }
                        }
                    },
                    carousel: {
                        root: {
                            base: "relative h-full w-full",
                            leftControl: "absolute top-0 left-0 flex h-full items-center justify-center px-4 focus:outline-none",
                            rightControl: "absolute top-0 right-0 flex h-full items-center justify-center px-4 focus:outline-none"
                        },
                        indicators: {
                            active: {
                                off: "bg-white/50 hover:bg-white dark:bg-gray-800/50 dark:hover:bg-gray-800",
                                on: "bg-white dark:bg-gray-800"
                            },
                            base: "h-3 w-3 rounded-full",
                            wrapper: "absolute bottom-5 left-1/2 flex -translate-x-1/2 space-x-3"
                        },
                        item: {
                            base: "absolute top-1/2 left-1/2 block w-full -translate-x-1/2 -translate-y-1/2",
                            wrapper: {
                                off: "w-full flex-shrink-0 transform cursor-default snap-center",
                                on: "w-full flex-shrink-0 transform cursor-grab snap-center"
                            }
                        },
                        control: {
                            base: "inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/30 group-hover:bg-white/50 group-focus:outline-none group-focus:ring-4 group-focus:ring-white dark:bg-gray-800/30 dark:group-hover:bg-gray-800/60 dark:group-focus:ring-gray-800/70 sm:h-10 sm:w-10",
                            icon: "h-5 w-5 text-white dark:text-gray-800 sm:h-6 sm:w-6"
                        },
                        scrollContainer: {
                            base: "flex h-full snap-mandatory overflow-y-hidden overflow-x-scroll scroll-smooth rounded-lg",
                            snap: "snap-x"
                        }
                    },
                    checkbox: {
                        root: {
                            base: "h-4 w-4 rounded focus:ring-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 bg-gray-100",
                            color: {
                                default: "focus:ring-cyan-600 dark:ring-offset-gray-800 dark:focus:ring-cyan-600 text-cyan-600",
                                dark: "focus:ring-gray-800 dark:ring-offset-gray-800 dark:focus:ring-gray-800 text-gray-800",
                                failure: "focus:ring-red-900 dark:ring-offset-red-900 dark:focus:ring-red-900 text-red-900",
                                gray: "focus:ring-gray-900 dark:ring-offset-gray-900 dark:focus:ring-gray-900 text-gray-900",
                                info: "focus:ring-cyan-800 dark:ring-offset-gray-800 dark:focus:ring-cyan-800 text-cyan-800",
                                light: "focus:ring-gray-900 dark:ring-offset-gray-900 dark:focus:ring-gray-900 text-gray-900",
                                purple: "focus:ring-purple-600 dark:ring-offset-purple-600 dark:focus:ring-purple-600 text-purple-600",
                                success: "focus:ring-green-800 dark:ring-offset-green-800 dark:focus:ring-green-800 text-green-800",
                                warning: "focus:ring-yellow-400 dark:ring-offset-yellow-400 dark:focus:ring-yellow-400 text-yellow-400",
                                blue: "focus:ring-blue-600 dark:ring-offset-blue-700 dark:focus:ring-blue-700 text-blue-700",
                                cyan: "focus:ring-cyan-600 dark:ring-offset-cyan-600 dark:focus:ring-cyan-600 text-cyan-600",
                                green: "focus:ring-green-600 dark:ring-offset-green-600 dark:focus:ring-green-600 text-green-600",
                                indigo: "focus:ring-indigo-700 dark:ring-offset-indigo-700 dark:focus:ring-indigo-700 text-indigo-700",
                                lime: "focus:ring-lime-700 dark:ring-offset-lime-700 dark:focus:ring-lime-700 text-lime-700",
                                pink: "focus:ring-pink-600 dark:ring-offset-pink-600 dark:focus:ring-pink-600 text-pink-600",
                                red: "focus:ring-red-600 dark:ring-offset-red-600 dark:focus:ring-red-600 text-red-600",
                                teal: "focus:ring-teal-600 dark:ring-offset-teal-600 dark:focus:ring-teal-600 text-teal-600",
                                yellow: "focus:ring-yellow-400 dark:ring-offset-yellow-400 dark:focus:ring-yellow-400 text-yellow-400"
                            }
                        }
                    },
                    datepicker: {
                        root: {
                            base: "relative"
                        },
                        popup: {
                            root: {
                                base: "absolute top-10 z-50 block pt-2",
                                inline: "relative top-0 z-auto",
                                inner: "inline-block rounded-lg bg-white p-4 shadow-lg dark:bg-gray-700"
                            },
                            header: {
                                base: "",
                                title: "px-2 py-3 text-center font-semibold text-gray-900 dark:text-white",
                                selectors: {
                                    base: "flex justify-between mb-2",
                                    button: {
                                        base: "text-sm rounded-lg text-gray-900 dark:text-white bg-white dark:bg-gray-700 font-semibold py-2.5 px-5 hover:bg-gray-100 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-200 view-switch",
                                        prev: "",
                                        next: "",
                                        view: ""
                                    }
                                }
                            },
                            view: {
                                base: "p-1"
                            },
                            footer: {
                                base: "flex mt-2 space-x-2",
                                button: {
                                    base: "w-full rounded-lg px-5 py-2 text-center text-sm font-medium focus:ring-4 focus:ring-cyan-300",
                                    today: "bg-cyan-700 text-white hover:bg-cyan-800 dark:bg-cyan-600 dark:hover:bg-cyan-700",
                                    clear: "border border-gray-300 bg-white text-gray-900 hover:bg-gray-100 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
                                }
                            }
                        },
                        views: {
                            days: {
                                header: {
                                    base: "grid grid-cols-7 mb-1",
                                    title: "dow h-6 text-center text-sm font-medium leading-6 text-gray-500 dark:text-gray-400"
                                },
                                items: {
                                    base: "grid w-64 grid-cols-7",
                                    item: {
                                        base: "block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-600 ",
                                        selected: "bg-cyan-700 text-white hover:bg-cyan-600",
                                        disabled: "text-gray-500"
                                    }
                                }
                            },
                            months: {
                                items: {
                                    base: "grid w-64 grid-cols-4",
                                    item: {
                                        base: "block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-600",
                                        selected: "bg-cyan-700 text-white hover:bg-cyan-600",
                                        disabled: "text-gray-500"
                                    }
                                }
                            },
                            years: {
                                items: {
                                    base: "grid w-64 grid-cols-4",
                                    item: {
                                        base: "block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-600 text-gray-900",
                                        selected: "bg-cyan-700 text-white hover:bg-cyan-600",
                                        disabled: "text-gray-500"
                                    }
                                }
                            },
                            decades: {
                                items: {
                                    base: "grid w-64 grid-cols-4",
                                    item: {
                                        base: "block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9  hover:bg-gray-100 dark:text-white dark:hover:bg-gray-600 text-gray-900",
                                        selected: "bg-cyan-700 text-white hover:bg-cyan-600",
                                        disabled: "text-gray-500"
                                    }
                                }
                            }
                        }
                    },
                    darkThemeToggle: {
                        root: {
                            base: "rounded-lg p-2.5 text-sm text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-700",
                            icon: "h-5 w-5"
                        }
                    },
                    dropdown: {
                        arrowIcon: "ml-2 h-4 w-4",
                        content: "py-1 focus:outline-none",
                        floating: {
                            animation: "transition-opacity",
                            arrow: {
                                base: "absolute z-10 h-2 w-2 rotate-45",
                                style: {
                                    dark: "bg-gray-900 dark:bg-gray-700",
                                    light: "bg-white",
                                    auto: "bg-white dark:bg-gray-700"
                                },
                                placement: "-4px"
                            },
                            base: "z-10 w-fit rounded divide-y divide-gray-100 shadow focus:outline-none",
                            content: "py-1 text-sm text-gray-700 dark:text-gray-200",
                            divider: "my-1 h-px bg-gray-100 dark:bg-gray-600",
                            header: "block py-2 px-4 text-sm text-gray-700 dark:text-gray-200",
                            hidden: "invisible opacity-0",
                            item: {
                                container: "",
                                base: "flex items-center justify-start py-2 px-4 text-sm text-gray-700 cursor-pointer w-full hover:bg-gray-100 focus:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-600 focus:outline-none dark:hover:text-white dark:focus:bg-gray-600 dark:focus:text-white",
                                icon: "mr-2 h-4 w-4"
                            },
                            style: {
                                dark: "bg-gray-900 text-white dark:bg-gray-700",
                                light: "border border-gray-200 bg-white text-gray-900",
                                auto: "border border-gray-200 bg-white text-gray-900 dark:border-none dark:bg-gray-700 dark:text-white"
                            },
                            target: "w-fit"
                        },
                        inlineWrapper: "flex items-center"
                    },
                    fileInput: {
                        root: {
                            base: "flex"
                        },
                        field: {
                            base: "relative w-full",
                            input: {
                                base: "rounded-lg overflow-hidden block w-full border disabled:cursor-not-allowed disabled:opacity-50",
                                sizes: {
                                    sm: "sm:text-xs",
                                    md: "text-sm",
                                    lg: "sm:text-md"
                                },
                                colors: {
                                    gray: "bg-gray-50 border-gray-300 text-gray-900 focus:border-cyan-500 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                                    info: "border-cyan-500 bg-cyan-50 text-cyan-900 placeholder-cyan-700 focus:border-cyan-500 focus:ring-cyan-500 dark:border-cyan-400 dark:bg-cyan-100 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                                    failure: "border-red-500 bg-red-50 text-red-900 placeholder-red-700 focus:border-red-500 focus:ring-red-500 dark:border-red-400 dark:bg-red-100 dark:focus:border-red-500 dark:focus:ring-red-500",
                                    warning: "border-yellow-500 bg-yellow-50 text-yellow-900 placeholder-yellow-700 focus:border-yellow-500 focus:ring-yellow-500 dark:border-yellow-400 dark:bg-yellow-100 dark:focus:border-yellow-500 dark:focus:ring-yellow-500",
                                    success: "border-green-500 bg-green-50 text-green-900 placeholder-green-700 focus:border-green-500 focus:ring-green-500 dark:border-green-400 dark:bg-green-100 dark:focus:border-green-500 dark:focus:ring-green-500"
                                }
                            }
                        }
                    },
                    floatingLabel: {
                        input: {
                            default: {
                                filled: {
                                    sm: "peer block w-full appearance-none rounded-t-lg border-0 border-b-2 border-gray-300 bg-gray-50 px-2.5 pb-2.5 pt-5 text-xs text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:focus:border-blue-500",
                                    md: "peer block w-full appearance-none rounded-t-lg border-0 border-b-2 border-gray-300 bg-gray-50 px-2.5 pb-2.5 pt-5 text-sm text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:focus:border-blue-500"
                                },
                                outlined: {
                                    sm: "border-1 peer block w-full appearance-none rounded-lg border-gray-300 bg-transparent px-2.5 pb-2.5 pt-4 text-xs text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0 dark:border-gray-600 dark:text-white dark:focus:border-blue-500",
                                    md: "border-1 peer block w-full appearance-none rounded-lg border-gray-300 bg-transparent px-2.5 pb-2.5 pt-4 text-sm text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0 dark:border-gray-600 dark:text-white dark:focus:border-blue-500"
                                },
                                standard: {
                                    sm: "block py-2.5 px-0 w-full text-xs text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                                    md: "block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                                }
                            },
                            success: {
                                filled: {
                                    sm: "block rounded-t-lg px-2.5 pb-2.5 pt-5 w-full text-xs text-gray-900 bg-gray-50 dark:bg-gray-700 border-0 border-b-2 border-green-600 dark:border-green-500 appearance-none dark:text-white dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer",
                                    md: "block rounded-t-lg px-2.5 pb-2.5 pt-5 w-full text-sm text-gray-900 bg-gray-50 dark:bg-gray-700 border-0 border-b-2 border-green-600 dark:border-green-500 appearance-none dark:text-white dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer"
                                },
                                outlined: {
                                    sm: "block px-2.5 pb-2.5 pt-4 w-full text-xs text-gray-900 bg-transparent rounded-lg border-1 border-green-600 appearance-none dark:text-white dark:border-green-500 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer",
                                    md: "block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-green-600 appearance-none dark:text-white dark:border-green-500 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer"
                                },
                                standard: {
                                    sm: "block py-2.5 px-0 w-full text-xs text-gray-900 bg-transparent border-0 border-b-2 border-green-600 appearance-none dark:text-white dark:border-green-500 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer",
                                    md: "block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-green-600 appearance-none dark:text-white dark:border-green-500 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer"
                                }
                            },
                            error: {
                                filled: {
                                    sm: "block rounded-t-lg px-2.5 pb-2.5 pt-5 w-full text-xs text-gray-900 bg-gray-50 dark:bg-gray-700 border-0 border-b-2 appearance-none dark:text-white dark:border-red-500 focus:outline-none focus:ring-0 border-red-600 focus:border-red-600 dark:focus-border-red-500 peer",
                                    md: "block rounded-t-lg px-2.5 pb-2.5 pt-5 w-full text-sm text-gray-900 bg-gray-50 dark:bg-gray-700 border-0 border-b-2 appearance-none dark:text-white dark:border-red-500 focus:outline-none focus:ring-0 border-red-600 focus:border-red-600 dark:focus-border-red-500 peer"
                                },
                                outlined: {
                                    sm: "block px-2.5 pb-2.5 pt-4 w-full text-xs text-gray-900 bg-transparent rounded-lg border-1 appearance-none dark:text-white dark:border-red-500 border-red-600 dark:focus:border-red-500 focus:outline-none focus:ring-0 focus:border-red-600 peer",
                                    md: "block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 appearance-none dark:text-white dark:border-red-500 border-red-600 dark:focus:border-red-500 focus:outline-none focus:ring-0 focus:border-red-600 peer"
                                },
                                standard: {
                                    sm: "block py-2.5 px-0 w-full text-xs text-gray-900 bg-transparent border-0 border-b-2 border-red-600 appearance-none dark:text-white dark:border-red-500 dark:focus:border-red-500 focus:outline-none focus:ring-0 focus:border-red-600 peer",
                                    md: "block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-red-600 appearance-none dark:text-white dark:border-red-500 dark:focus:border-red-500 focus:outline-none focus:ring-0 focus:border-red-600 peer"
                                }
                            }
                        },
                        label: {
                            default: {
                                filled: {
                                    sm: "absolute left-2.5 top-4 z-10 origin-[0] -translate-y-4 scale-75 transition-transform text-xs text-gray-500  duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:text-blue-600 dark:text-gray-400 peer-focus:dark:text-blue-500",
                                    md: "absolute left-2.5 top-4 z-10 origin-[0] -translate-y-4 scale-75 transition-transform text-sm text-gray-500 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:text-blue-600 dark:text-gray-400 peer-focus:dark:text-blue-500"
                                },
                                outlined: {
                                    sm: "absolute left-1 top-2 z-10 origin-[0] -translate-y-4 scale-75 transition-transform bg-white px-2 text-xs text-gray-500 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 peer-focus:text-blue-600 dark:bg-gray-900 dark:text-gray-400 peer-focus:dark:text-blue-500",
                                    md: "absolute left-1 top-2 z-10 origin-[0] -translate-y-4 scale-75 transition-transform bg-white px-2 text-sm text-gray-500 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 peer-focus:text-blue-600 dark:bg-gray-900 dark:text-gray-400 peer-focus:dark:text-blue-500"
                                },
                                standard: {
                                    sm: "absolute text-xs text-gray-500 dark:text-gray-400  transition-transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] duration-300 peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                                    md: "absolute text-sm text-gray-500 dark:text-gray-400  transition-transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] duration-300 peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                                }
                            },
                            success: {
                                filled: {
                                    sm: "absolute left-2.5 top-4 z-10 origin-[0] -translate-y-4 scale-75 transition-transform text-sm text-green-600 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-4 peer-focus:scale-75 dark:text-green-500",
                                    md: "absolute left-2.5 top-4 z-10 origin-[0] -translate-y-4 scale-75 transition-transform text-sm text-green-600 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-4 peer-focus:scale-75 dark:text-green-500"
                                },
                                outlined: {
                                    sm: "absolute left-1 top-2 z-10 origin-[0] -translate-y-4 scale-75 transition-transform bg-white px-2 text-sm text-green-600 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 dark:bg-gray-900 dark:text-green-500",
                                    md: "absolute left-1 top-2 z-10 origin-[0] -translate-y-4 scale-75 transition-transform bg-white px-2 text-sm text-green-600 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 dark:bg-gray-900 dark:text-green-500"
                                },
                                standard: {
                                    sm: "absolute text-xs text-green-600 dark:text-green-500  transition-transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] duration-300 peer-focus:left-0 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                                    md: "absolute text-sm text-green-600 dark:text-green-500  transition-transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] duration-300 peer-focus:left-0 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                                }
                            },
                            error: {
                                filled: {
                                    sm: "absolute left-2.5 top-4 z-10 origin-[0] -translate-y-4 scale-75 transition-transform text-xs text-red-600 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-4 peer-focus:scale-75 dark:text-red-500",
                                    md: "absolute left-2.5 top-4 z-10 origin-[0] -translate-y-4 scale-75 transition-transform text-xs text-red-600 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-4 peer-focus:scale-75 dark:text-red-500"
                                },
                                outlined: {
                                    sm: "absolute left-1 top-2 z-10 origin-[0] -translate-y-4 scale-75 transition-transform bg-white px-2 text-xs text-red-600 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 dark:bg-gray-900 dark:text-red-500",
                                    md: "absolute left-1 top-2 z-10 origin-[0] -translate-y-4 scale-75 transition-transform bg-white px-2 text-xs text-red-600 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 dark:bg-gray-900 dark:text-red-500"
                                },
                                standard: {
                                    sm: "absolute text-xs text-red-600 dark:text-red-500  transition-transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] duration-300 peer-focus:left-0 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                                    md: "absolute text-sm text-red-600 dark:text-red-500  transition-transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] duration-300 peer-focus:left-0 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                                }
                            }
                        },
                        helperText: {
                            default: "mt-2 text-xs text-gray-600 dark:text-gray-400",
                            success: "mt-2 text-xs text-green-600 dark:text-green-400",
                            error: "mt-2 text-xs text-red-600 dark:text-red-400"
                        }
                    },
                    footer: {
                        root: {
                            base: "w-full rounded-lg bg-white shadow dark:bg-gray-800 md:flex md:items-center md:justify-between",
                            container: "w-full p-6",
                            bgDark: "bg-gray-800"
                        },
                        groupLink: {
                            base: "flex flex-wrap text-sm text-gray-500 dark:text-white",
                            link: {
                                base: "last:mr-0 md:mr-6 me-4",
                                href: "hover:underline"
                            },
                            col: "flex-col space-y-4"
                        },
                        icon: {
                            base: "text-gray-500 dark:hover:text-white",
                            size: "h-5 w-5"
                        },
                        title: {
                            base: "mb-6 text-sm font-semibold uppercase text-gray-500 dark:text-white"
                        },
                        divider: {
                            base: "w-full my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8"
                        },
                        copyright: {
                            base: "text-sm text-gray-500 dark:text-gray-400 sm:text-center",
                            href: "ml-1 hover:underline",
                            span: "ml-1"
                        },
                        brand: {
                            base: "mb-4 flex items-center sm:mb-0",
                            img: "mr-3 h-8",
                            span: "self-center whitespace-nowrap text-2xl font-semibold text-gray-800 dark:text-white"
                        }
                    },
                    helperText: {
                        root: {
                            base: "mt-2 text-sm",
                            colors: {
                                gray: "text-gray-500 dark:text-gray-400",
                                info: "text-cyan-700 dark:text-cyan-800",
                                success: "text-green-600 dark:text-green-500",
                                failure: "text-red-600 dark:text-red-500",
                                warning: "text-yellow-500 dark:text-yellow-600"
                            }
                        }
                    },
                    kbd: {
                        root: {
                            base: "px-2 py-1.5 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg dark:bg-gray-600 dark:text-gray-100 dark:border-gray-500",
                            icon: "inline-block"
                        }
                    },
                    label: {
                        root: {
                            base: "text-sm font-medium",
                            disabled: "opacity-50",
                            colors: {
                                default: "text-gray-900 dark:text-white",
                                info: "text-cyan-500 dark:text-cyan-600",
                                failure: "text-red-700 dark:text-red-500",
                                warning: "text-yellow-500 dark:text-yellow-600",
                                success: "text-green-700 dark:text-green-500"
                            }
                        }
                    },
                    listGroup: {
                        root: {
                            base: "list-none rounded-lg border border-gray-200 bg-white text-sm font-medium text-gray-900 dark:border-gray-600 dark:bg-gray-700 dark:text-white text-left"
                        },
                        item: {
                            base: "[&>*]:first:rounded-t-lg [&>*]:last:rounded-b-lg [&>*]:last:border-b-0",
                            link: {
                                base: "flex items-center w-full border-b border-gray-200 py-2 px-4 dark:border-gray-600",
                                active: {
                                    off: "hover:bg-gray-100 hover:text-cyan-700 focus:text-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-700 dark:border-gray-600 dark:hover:bg-gray-600 dark:hover:text-white dark:focus:text-white dark:focus:ring-gray-500",
                                    on: "bg-cyan-700 text-white dark:bg-gray-800"
                                },
                                disabled: {
                                    off: "",
                                    on: "hover:bg-gray-100 text-gray-900 hover:text-gray-900 focus:text-gray-900 bg-gray-100 cursor-not-allowed"
                                },
                                href: {
                                    off: "",
                                    on: ""
                                },
                                icon: "mr-2 h-4 w-4 fill-current"
                            }
                        }
                    },
                    list: {
                        root: {
                            base: "space-y-1 text-gray-500 list-inside dark:text-gray-400",
                            ordered: {
                                off: "list-disc",
                                on: "list-decimal"
                            },
                            horizontal: "flex flex-wrap items-center space-x-4 space-y-0 justify-center list-none",
                            unstyled: "list-none",
                            nested: "ps-5 mt-2"
                        }
                    },
                    modal: {
                        root: {
                            base: "fixed top-0 right-0 left-0 z-50 h-modal h-screen overflow-y-auto overflow-x-hidden md:inset-0 md:h-full",
                            show: {
                                on: "flex bg-gray-900 bg-opacity-50 dark:bg-opacity-80",
                                off: "hidden"
                            },
                            sizes: {
                                sm: "max-w-sm",
                                md: "max-w-md",
                                lg: "max-w-lg",
                                xl: "max-w-xl",
                                "2xl": "max-w-2xl",
                                "3xl": "max-w-3xl",
                                "4xl": "max-w-4xl",
                                "5xl": "max-w-5xl",
                                "6xl": "max-w-6xl",
                                "7xl": "max-w-7xl"
                            },
                            positions: {
                                "top-left": "items-start justify-start",
                                "top-center": "items-start justify-center",
                                "top-right": "items-start justify-end",
                                "center-left": "items-center justify-start",
                                center: "items-center justify-center",
                                "center-right": "items-center justify-end",
                                "bottom-right": "items-end justify-end",
                                "bottom-center": "items-end justify-center",
                                "bottom-left": "items-end justify-start"
                            }
                        },
                        content: {
                            base: "relative h-full w-full p-4 md:h-auto",
                            inner: "relative rounded-lg bg-white shadow dark:bg-gray-700 flex flex-col max-h-[90vh]"
                        },
                        body: {
                            base: "p-6 flex-1 overflow-auto",
                            popup: "pt-0"
                        },
                        header: {
                            base: "flex items-start justify-between rounded-t dark:border-gray-600 border-b p-5",
                            popup: "p-2 border-b-0",
                            title: "text-xl font-medium text-gray-900 dark:text-white",
                            close: {
                                base: "ml-auto inline-flex items-center rounded-lg bg-transparent p-1.5 text-sm text-gray-400 hover:bg-gray-200 hover:text-gray-900 dark:hover:bg-gray-600 dark:hover:text-white",
                                icon: "h-5 w-5"
                            }
                        },
                        footer: {
                            base: "flex items-center space-x-2 rounded-b border-gray-200 p-6 dark:border-gray-600",
                            popup: "border-t"
                        }
                    },
                    navbar: {
                        root: {
                            base: "bg-white px-2 py-2.5 dark:border-gray-700 dark:bg-gray-800 sm:px-4",
                            rounded: {
                                on: "rounded",
                                off: ""
                            },
                            bordered: {
                                on: "border",
                                off: ""
                            },
                            inner: {
                                base: "mx-auto flex flex-wrap items-center justify-between",
                                fluid: {
                                    on: "",
                                    off: "container"
                                }
                            }
                        },
                        brand: {
                            base: "flex items-center"
                        },
                        collapse: {
                            base: "w-full md:block md:w-auto",
                            list: "mt-4 flex flex-col md:mt-0 md:flex-row md:space-x-8 md:text-sm md:font-medium",
                            hidden: {
                                on: "hidden",
                                off: ""
                            }
                        },
                        link: {
                            base: "block py-2 pr-4 pl-3 md:p-0",
                            active: {
                                on: "bg-cyan-700 text-white dark:text-white md:bg-transparent md:text-cyan-700",
                                off: "border-b border-gray-100  text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white md:border-0 md:hover:bg-transparent md:hover:text-cyan-700 md:dark:hover:bg-transparent md:dark:hover:text-white"
                            },
                            disabled: {
                                on: "text-gray-400 hover:cursor-not-allowed dark:text-gray-600",
                                off: ""
                            }
                        },
                        toggle: {
                            base: "inline-flex items-center rounded-lg p-2 text-sm text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600 md:hidden",
                            icon: "h-6 w-6 shrink-0"
                        }
                    },
                    pagination: {
                        base: "",
                        layout: {
                            table: {
                                base: "text-sm text-gray-700 dark:text-gray-400",
                                span: "font-semibold text-gray-900 dark:text-white"
                            }
                        },
                        pages: {
                            base: "xs:mt-0 mt-2 inline-flex items-center -space-x-px",
                            showIcon: "inline-flex",
                            previous: {
                                base: "ml-0 rounded-l-lg border border-gray-300 bg-white py-2 px-3 leading-tight text-gray-500 enabled:hover:bg-gray-100 enabled:hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 enabled:dark:hover:bg-gray-700 enabled:dark:hover:text-white",
                                icon: "h-5 w-5"
                            },
                            next: {
                                base: "rounded-r-lg border border-gray-300 bg-white py-2 px-3 leading-tight text-gray-500 enabled:hover:bg-gray-100 enabled:hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 enabled:dark:hover:bg-gray-700 enabled:dark:hover:text-white",
                                icon: "h-5 w-5"
                            },
                            selector: {
                                base: "w-12 border border-gray-300 bg-white py-2 leading-tight text-gray-500 enabled:hover:bg-gray-100 enabled:hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 enabled:dark:hover:bg-gray-700 enabled:dark:hover:text-white",
                                active: "bg-cyan-50 text-cyan-600 hover:bg-cyan-100 hover:text-cyan-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white",
                                disabled: "opacity-50 cursor-normal"
                            }
                        }
                    },
                    progress: {
                        base: "w-full overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700",
                        label: "mb-1 flex justify-between font-medium dark:text-white",
                        bar: "rounded-full text-center font-medium leading-none text-cyan-300 dark:text-cyan-100 space-x-2",
                        color: {
                            dark: "bg-gray-600 dark:bg-gray-300",
                            blue: "bg-blue-600",
                            red: "bg-red-600 dark:bg-red-500",
                            green: "bg-green-600 dark:bg-green-500",
                            yellow: "bg-yellow-400",
                            indigo: "bg-indigo-600 dark:bg-indigo-500",
                            purple: "bg-purple-600 dark:bg-purple-500",
                            cyan: "bg-cyan-600",
                            gray: "bg-gray-500",
                            lime: "bg-lime-600",
                            pink: "bg-pink-500",
                            teal: "bg-teal-600"
                        },
                        size: {
                            sm: "h-1.5",
                            md: "h-2.5",
                            lg: "h-4",
                            xl: "h-6"
                        }
                    },
                    radio: {
                        root: {
                            base: "h-4 w-4 border border-gray-300 focus:ring-2 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:focus:bg-cyan-600 dark:focus:ring-cyan-600 text-cyan-600"
                        }
                    },
                    rangeSlider: {
                        root: {
                            base: "flex"
                        },
                        field: {
                            base: "relative w-full",
                            input: {
                                base: "w-full bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700",
                                sizes: {
                                    sm: "h-1 range-sm",
                                    md: "h-2",
                                    lg: "h-3 range-lg"
                                }
                            }
                        }
                    },
                    rating: {
                        root: {
                            base: "flex items-center"
                        },
                        star: {
                            empty: "text-gray-300 dark:text-gray-500",
                            filled: "text-yellow-400",
                            sizes: {
                                sm: "w-5 h-5",
                                md: "w-7 h-7",
                                lg: "w-10 h-10"
                            }
                        }
                    },
                    ratingAdvanced: {
                        base: "flex items-center",
                        label: "text-sm font-medium text-cyan-600 dark:text-cyan-500",
                        progress: {
                            base: "mx-4 h-5 w-2/4 rounded bg-gray-200 dark:bg-gray-700",
                            fill: "h-5 rounded bg-yellow-400",
                            label: "text-sm font-medium text-cyan-600 dark:text-cyan-500"
                        }
                    },
                    select: {
                        base: "flex",
                        addon: "inline-flex items-center rounded-l-md border border-r-0 border-gray-300 bg-gray-200 px-3 text-sm text-gray-900 dark:border-gray-600 dark:bg-gray-600 dark:text-gray-400",
                        field: {
                            base: "relative w-full",
                            icon: {
                                base: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3",
                                svg: "h-5 w-5 text-gray-500 dark:text-gray-400"
                            },
                            select: {
                                base: "block w-full border disabled:cursor-not-allowed disabled:opacity-50",
                                withIcon: {
                                    on: "pl-10",
                                    off: ""
                                },
                                withAddon: {
                                    on: "rounded-r-lg",
                                    off: "rounded-lg"
                                },
                                withShadow: {
                                    on: "shadow-sm dark:shadow-sm-light",
                                    off: ""
                                },
                                sizes: {
                                    sm: "p-2 sm:text-xs",
                                    md: "p-2.5 text-sm",
                                    lg: "sm:text-md p-4"
                                },
                                colors: {
                                    gray: "bg-gray-50 border-gray-300 text-gray-900 focus:border-cyan-500 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                                    info: "border-cyan-500 bg-cyan-50 text-cyan-900 placeholder-cyan-700 focus:border-cyan-500 focus:ring-cyan-500 dark:border-cyan-400 dark:bg-cyan-100 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                                    failure: "border-red-500 bg-red-50 text-red-900 placeholder-red-700 focus:border-red-500 focus:ring-red-500 dark:border-red-400 dark:bg-red-100 dark:focus:border-red-500 dark:focus:ring-red-500",
                                    warning: "border-yellow-500 bg-yellow-50 text-yellow-900 placeholder-yellow-700 focus:border-yellow-500 focus:ring-yellow-500 dark:border-yellow-400 dark:bg-yellow-100 dark:focus:border-yellow-500 dark:focus:ring-yellow-500",
                                    success: "border-green-500 bg-green-50 text-green-900 placeholder-green-700 focus:border-green-500 focus:ring-green-500 dark:border-green-400 dark:bg-green-100 dark:focus:border-green-500 dark:focus:ring-green-500"
                                }
                            }
                        }
                    },
                    textInput: {
                        base: "flex",
                        addon: "inline-flex items-center rounded-l-md border border-r-0 border-gray-300 bg-gray-200 px-3 text-sm text-gray-900 dark:border-gray-600 dark:bg-gray-600 dark:text-gray-400",
                        field: {
                            base: "relative w-full",
                            icon: {
                                base: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3",
                                svg: "h-5 w-5 text-gray-500 dark:text-gray-400"
                            },
                            rightIcon: {
                                base: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3",
                                svg: "h-5 w-5 text-gray-500 dark:text-gray-400"
                            },
                            input: {
                                base: "block w-full border disabled:cursor-not-allowed disabled:opacity-50",
                                sizes: {
                                    sm: "p-2 sm:text-xs",
                                    md: "p-2.5 text-sm",
                                    lg: "sm:text-md p-4"
                                },
                                colors: {
                                    gray: "bg-gray-50 border-gray-300 text-gray-900 focus:border-cyan-500 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                                    info: "border-cyan-500 bg-cyan-50 text-cyan-900 placeholder-cyan-700 focus:border-cyan-500 focus:ring-cyan-500 dark:border-cyan-400 dark:bg-cyan-100 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                                    failure: "border-red-500 bg-red-50 text-red-900 placeholder-red-700 focus:border-red-500 focus:ring-red-500 dark:border-red-400 dark:bg-red-100 dark:focus:border-red-500 dark:focus:ring-red-500",
                                    warning: "border-yellow-500 bg-yellow-50 text-yellow-900 placeholder-yellow-700 focus:border-yellow-500 focus:ring-yellow-500 dark:border-yellow-400 dark:bg-yellow-100 dark:focus:border-yellow-500 dark:focus:ring-yellow-500",
                                    success: "border-green-500 bg-green-50 text-green-900 placeholder-green-700 focus:border-green-500 focus:ring-green-500 dark:border-green-400 dark:bg-green-100 dark:focus:border-green-500 dark:focus:ring-green-500"
                                },
                                withRightIcon: {
                                    on: "pr-10",
                                    off: ""
                                },
                                withIcon: {
                                    on: "pl-10",
                                    off: ""
                                },
                                withAddon: {
                                    on: "rounded-r-lg",
                                    off: "rounded-lg"
                                },
                                withShadow: {
                                    on: "shadow-sm dark:shadow-sm-light",
                                    off: ""
                                }
                            }
                        }
                    },
                    textarea: {
                        base: "block w-full rounded-lg border disabled:cursor-not-allowed disabled:opacity-50 text-sm",
                        colors: {
                            gray: "bg-gray-50 border-gray-300 text-gray-900 focus:border-cyan-500 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                            info: "border-cyan-500 bg-cyan-50 text-cyan-900 placeholder-cyan-700 focus:border-cyan-500 focus:ring-cyan-500 dark:border-cyan-400 dark:bg-cyan-100 dark:focus:border-cyan-500 dark:focus:ring-cyan-500",
                            failure: "border-red-500 bg-red-50 text-red-900 placeholder-red-700 focus:border-red-500 focus:ring-red-500 dark:border-red-400 dark:bg-red-100 dark:focus:border-red-500 dark:focus:ring-red-500",
                            warning: "border-yellow-500 bg-yellow-50 text-yellow-900 placeholder-yellow-700 focus:border-yellow-500 focus:ring-yellow-500 dark:border-yellow-400 dark:bg-yellow-100 dark:focus:border-yellow-500 dark:focus:ring-yellow-500",
                            success: "border-green-500 bg-green-50 text-green-900 placeholder-green-700 focus:border-green-500 focus:ring-green-500 dark:border-green-400 dark:bg-green-100 dark:focus:border-green-500 dark:focus:ring-green-500"
                        },
                        withShadow: {
                            on: "shadow-sm dark:shadow-sm-light",
                            off: ""
                        }
                    },
                    toggleSwitch: {
                        root: {
                            base: "group relative flex items-center rounded-lg focus:outline-none",
                            active: {
                                on: "cursor-pointer",
                                off: "cursor-not-allowed opacity-50"
                            },
                            label: "ml-3 text-sm font-medium text-gray-900 dark:text-gray-300"
                        },
                        toggle: {
                            base: "toggle-bg rounded-full border group-focus:ring-4 group-focus:ring-cyan-500/25",
                            checked: {
                                on: "after:translate-x-full after:border-white",
                                off: "border-gray-200 bg-gray-200 dark:border-gray-600 dark:bg-gray-700",
                                color: {
                                    blue: " bg-cyan-700 border-cyan-700",
                                    dark: "bg-dark-700 border-dark-900",
                                    failure: "bg-red-700 border-red-900",
                                    gray: "bg-gray-500 border-gray-600",
                                    green: "bg-green-600 border-green-700",
                                    light: "bg-light-700 border-light-900",
                                    red: "bg-red-700 border-red-900",
                                    purple: "bg-purple-700 border-purple-900",
                                    success: "bg-green-500 border-green-500",
                                    yellow: "bg-yellow-400 border-yellow-400",
                                    warning: "bg-yellow-600 border-yellow-600",
                                    cyan: "bg-cyan-500 border-cyan-500",
                                    lime: "bg-lime-400 border-lime-400",
                                    indigo: "bg-indigo-400 border-indigo-400",
                                    teal: "bg-gradient-to-r from-teal-400 via-teal-500 to-teal-600 hover:bg-gradient-to-br focus:ring-4",
                                    info: "bg-cyan-600 border-cyan-600",
                                    pink: "bg-pink-600 border-pink-600"
                                }
                            },
                            sizes: {
                                sm: "w-9 h-5 after:absolute after:top-[2px] after:left-[2px] after:h-4 after:w-4",
                                md: "w-11 h-6 after:absolute after:top-[2px] after:left-[2px] after:h-5 after:w-5",
                                lg: "w-14 h-7 after:absolute after:top-0.5 after:left-[4px] after:h-6 after:w-6"
                            }
                        }
                    },
                    sidebar: {
                        root: {
                            base: "h-full",
                            collapsed: {
                                on: "w-16",
                                off: "w-64"
                            },
                            inner: "h-full overflow-y-auto overflow-x-hidden rounded bg-gray-50 py-4 px-3 dark:bg-gray-800"
                        },
                        collapse: {
                            button: "group flex w-full items-center rounded-lg p-2 text-base font-normal text-gray-900 transition duration-75 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700",
                            icon: {
                                base: "h-6 w-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white",
                                open: {
                                    off: "",
                                    on: "text-gray-900"
                                }
                            },
                            label: {
                                base: "ml-3 flex-1 whitespace-nowrap text-left",
                                icon: {
                                    base: "h-6 w-6 transition ease-in-out delay-0",
                                    open: {
                                        on: "rotate-180",
                                        off: ""
                                    }
                                }
                            },
                            list: "space-y-2 py-2"
                        },
                        cta: {
                            base: "mt-6 rounded-lg p-4 bg-gray-100 dark:bg-gray-700",
                            color: {
                                blue: "bg-cyan-50 dark:bg-cyan-900",
                                dark: "bg-dark-50 dark:bg-dark-900",
                                failure: "bg-red-50 dark:bg-red-900",
                                gray: "bg-alternative-50 dark:bg-alternative-900",
                                green: "bg-green-50 dark:bg-green-900",
                                light: "bg-light-50 dark:bg-light-900",
                                red: "bg-red-50 dark:bg-red-900",
                                purple: "bg-purple-50 dark:bg-purple-900",
                                success: "bg-green-50 dark:bg-green-900",
                                yellow: "bg-yellow-50 dark:bg-yellow-900",
                                warning: "bg-yellow-50 dark:bg-yellow-900"
                            }
                        },
                        item: {
                            base: "flex items-center justify-center rounded-lg p-2 text-base font-normal text-gray-900 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700",
                            active: "bg-gray-100 dark:bg-gray-700",
                            collapsed: {
                                insideCollapse: "group w-full pl-8 transition duration-75",
                                noIcon: "font-bold"
                            },
                            content: {
                                base: "px-3 flex-1 whitespace-nowrap"
                            },
                            icon: {
                                base: "h-6 w-6 flex-shrink-0 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white",
                                active: "text-gray-700 dark:text-gray-100"
                            },
                            label: "",
                            listItem: ""
                        },
                        items: {
                            base: ""
                        },
                        itemGroup: {
                            base: "mt-4 space-y-2 border-t border-gray-200 pt-4 first:mt-0 first:border-t-0 first:pt-0 dark:border-gray-700"
                        },
                        logo: {
                            base: "mb-5 flex items-center pl-2.5",
                            collapsed: {
                                on: "hidden",
                                off: "self-center whitespace-nowrap text-xl font-semibold dark:text-white"
                            },
                            img: "mr-3 h-6 sm:h-7"
                        }
                    },
                    spinner: {
                        base: "inline animate-spin text-gray-200",
                        color: {
                            failure: "fill-red-600",
                            gray: "fill-gray-600",
                            info: "fill-cyan-600",
                            pink: "fill-pink-600",
                            purple: "fill-purple-600",
                            success: "fill-green-500",
                            warning: "fill-yellow-400"
                        },
                        light: {
                            off: {
                                base: "dark:text-gray-600",
                                color: {
                                    failure: "",
                                    gray: "dark:fill-gray-300",
                                    info: "",
                                    pink: "",
                                    purple: "",
                                    success: "",
                                    warning: ""
                                }
                            },
                            on: {
                                base: "",
                                color: {
                                    failure: "",
                                    gray: "",
                                    info: "",
                                    pink: "",
                                    purple: "",
                                    success: "",
                                    warning: ""
                                }
                            }
                        },
                        size: {
                            xs: "w-3 h-3",
                            sm: "w-4 h-4",
                            md: "w-6 h-6",
                            lg: "w-8 h-8",
                            xl: "w-10 h-10"
                        }
                    },
                    table: {
                        root: {
                            base: "w-full text-left text-sm text-gray-500 dark:text-gray-400",
                            shadow: "absolute bg-white dark:bg-black w-full h-full top-0 left-0 rounded-lg drop-shadow-md -z-10",
                            wrapper: "relative"
                        },
                        body: {
                            base: "group/body",
                            cell: {
                                base: "group-first/body:group-first/row:first:rounded-tl-lg group-first/body:group-first/row:last:rounded-tr-lg group-last/body:group-last/row:first:rounded-bl-lg group-last/body:group-last/row:last:rounded-br-lg px-6 py-4"
                            }
                        },
                        head: {
                            base: "group/head text-xs uppercase text-gray-700 dark:text-gray-400",
                            cell: {
                                base: "group-first/head:first:rounded-tl-lg group-first/head:last:rounded-tr-lg bg-gray-50 dark:bg-gray-700 px-6 py-3"
                            }
                        },
                        row: {
                            base: "group/row",
                            hovered: "hover:bg-gray-50 dark:hover:bg-gray-600",
                            striped: "odd:bg-white even:bg-gray-50 odd:dark:bg-gray-800 even:dark:bg-gray-700"
                        }
                    },
                    tabs: {
                        base: "flex flex-col gap-2",
                        tablist: {
                            base: "flex text-center",
                            styles: {
                                default: "flex-wrap border-b border-gray-200 dark:border-gray-700",
                                underline: "flex-wrap -mb-px border-b border-gray-200 dark:border-gray-700",
                                pills: "flex-wrap font-medium text-sm text-gray-500 dark:text-gray-400 space-x-2",
                                fullWidth: "w-full text-sm font-medium divide-x divide-gray-200 shadow grid grid-flow-col dark:divide-gray-700 dark:text-gray-400 rounded-none"
                            },
                            tabitem: {
                                base: "flex items-center justify-center p-4 rounded-t-lg text-sm font-medium first:ml-0 disabled:cursor-not-allowed disabled:text-gray-400 disabled:dark:text-gray-500 focus:ring-4 focus:ring-cyan-300 focus:outline-none",
                                styles: {
                                    default: {
                                        base: "rounded-t-lg",
                                        active: {
                                            on: "bg-gray-100 text-cyan-600 dark:bg-gray-800 dark:text-cyan-500",
                                            off: "text-gray-500 hover:bg-gray-50 hover:text-gray-600 dark:text-gray-400 dark:hover:bg-gray-800  dark:hover:text-gray-300"
                                        }
                                    },
                                    underline: {
                                        base: "rounded-t-lg",
                                        active: {
                                            on: "text-cyan-600 rounded-t-lg border-b-2 border-cyan-600 active dark:text-cyan-500 dark:border-cyan-500",
                                            off: "border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300"
                                        }
                                    },
                                    pills: {
                                        base: "",
                                        active: {
                                            on: "rounded-lg bg-cyan-600 text-white",
                                            off: "rounded-lg hover:text-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800 dark:hover:text-white"
                                        }
                                    },
                                    fullWidth: {
                                        base: "ml-0 first:ml-0 w-full rounded-none flex",
                                        active: {
                                            on: "p-4 text-gray-900 bg-gray-100 active dark:bg-gray-700 dark:text-white rounded-none",
                                            off: "bg-white hover:text-gray-700 hover:bg-gray-50 dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700 rounded-none"
                                        }
                                    }
                                },
                                icon: "mr-2 h-5 w-5"
                            }
                        },
                        tabitemcontainer: {
                            base: "",
                            styles: {
                                default: "",
                                underline: "",
                                pills: "",
                                fullWidth: ""
                            }
                        },
                        tabpanel: "py-3"
                    },
                    timeline: {
                        root: {
                            direction: {
                                horizontal: "items-base sm:flex",
                                vertical: "relative border-l border-gray-200 dark:border-gray-700"
                            }
                        },
                        item: {
                            root: {
                                horizontal: "relative mb-6 sm:mb-0",
                                vertical: "mb-10 ml-6"
                            },
                            content: {
                                root: {
                                    base: "mt-3 sm:pr-8"
                                },
                                body: {
                                    base: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400"
                                },
                                time: {
                                    base: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"
                                },
                                title: {
                                    base: "text-lg font-semibold text-gray-900 dark:text-white"
                                }
                            },
                            point: {
                                horizontal: "flex items-center",
                                line: "hidden h-0.5 w-full bg-gray-200 dark:bg-gray-700 sm:flex",
                                marker: {
                                    base: {
                                        horizontal: "absolute -left-1.5 h-3 w-3 rounded-full border border-white bg-gray-200 dark:border-gray-900 dark:bg-gray-700",
                                        vertical: "absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border border-white bg-gray-200 dark:border-gray-900 dark:bg-gray-700"
                                    },
                                    icon: {
                                        base: "h-3 w-3 text-cyan-600 dark:text-cyan-300",
                                        wrapper: "absolute -left-3 flex h-6 w-6 items-center justify-center rounded-full bg-cyan-200 ring-8 ring-white dark:bg-cyan-900 dark:ring-gray-900"
                                    }
                                },
                                vertical: ""
                            }
                        }
                    },
                    toast: {
                        root: {
                            base: "flex w-full max-w-xs items-center rounded-lg bg-white p-4 text-gray-500 shadow dark:bg-gray-800 dark:text-gray-400",
                            closed: "opacity-0 ease-out"
                        },
                        toggle: {
                            base: "-mx-1.5 -my-1.5 ml-auto inline-flex h-8 w-8 rounded-lg bg-white p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-900 focus:ring-2 focus:ring-gray-300 dark:bg-gray-800 dark:text-gray-500 dark:hover:bg-gray-700 dark:hover:text-white",
                            icon: "h-5 w-5 shrink-0"
                        }
                    },
                    tooltip: {
                        target: "w-fit",
                        animation: "transition-opacity",
                        arrow: {
                            base: "absolute z-10 h-2 w-2 rotate-45",
                            style: {
                                dark: "bg-gray-900 dark:bg-gray-700",
                                light: "bg-white",
                                auto: "bg-white dark:bg-gray-700"
                            },
                            placement: "-4px"
                        },
                        base: "absolute inline-block z-10 rounded-lg py-2 px-3 text-sm font-medium shadow-sm",
                        hidden: "invisible opacity-0",
                        style: {
                            dark: "bg-gray-900 text-white dark:bg-gray-700",
                            light: "border border-gray-200 bg-white text-gray-900",
                            auto: "border border-gray-200 bg-white text-gray-900 dark:border-none dark:bg-gray-700 dark:text-white"
                        },
                        content: "relative z-20"
                    }
                },
                V = {
                    theme: U(K)
                };

            function X(e) {
                e && (V.theme = q(K, e))
            }

            function Z() {
                return U(V.theme)
            }
            let Q = (0, d.createContext)(void 0);

            function J() {
                let e = (0, d.useContext)(Q);
                if (!e) throw Error("useAccordionContext should be used within the AccordionPanelContext provider!");
                return e
            }
            let ee = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        isOpen: o
                    } = J(), a = q(Z().accordion.content, r);
                    return (0, s.jsx)("div", {
                        className: H(a.base, t),
                        "data-testid": "flowbite-accordion-content",
                        hidden: !o,
                        ...n,
                        children: e
                    })
                },
                et = ({
                    children: e,
                    ...t
                }) => {
                    let {
                        alwaysOpen: r
                    } = t, [n, o] = (0, d.useState)(t.isOpen), a = r ? { ...t,
                        isOpen: n,
                        setOpen: () => o(!n)
                    } : t;
                    return (0, s.jsx)(Q.Provider, {
                        value: a,
                        children: e
                    })
                },
                er = ({
                    as: e = "h2",
                    children: t,
                    className: r,
                    theme: n = {},
                    ...o
                }) => {
                    let {
                        arrowIcon: a,
                        flush: l,
                        isOpen: i,
                        setOpen: d
                    } = J(), c = q(Z().accordion.title, n);
                    return (0, s.jsxs)("button", {
                        className: H(c.base, c.flush[l ? "on" : "off"], c.open[i ? "on" : "off"], r),
                        onClick: () => void 0 !== d && d(),
                        type: "button",
                        ...o,
                        children: [(0, s.jsx)(e, {
                            className: c.heading,
                            "data-testid": "flowbite-accordion-heading",
                            children: t
                        }), a && (0, s.jsx)(a, {
                            "aria-hidden": !0,
                            className: H(c.arrow.base, c.arrow.open[i ? "on" : "off"]),
                            "data-testid": "flowbite-accordion-arrow"
                        })]
                    })
                },
                en = ({
                    alwaysOpen: e = !1,
                    arrowIcon: t = u.kWQ,
                    children: r,
                    flush: n = !1,
                    collapseAll: o = !1,
                    className: a,
                    theme: l = {},
                    ...i
                }) => {
                    let [c, g] = (0, d.useState)(o ? -1 : 0), f = (0, d.useMemo)(() => d.Children.map(r, (r, o) => (0, d.cloneElement)(r, {
                        alwaysOpen: e,
                        arrowIcon: t,
                        flush: n,
                        isOpen: c === o,
                        setOpen: () => g(c === o ? -1 : o)
                    })), [e, t, r, n, c]), b = q(Z().accordion.root, l);
                    return (0, s.jsx)("div", {
                        className: H(b.base, b.flush[n ? "on" : "off"], a),
                        "data-testid": "flowbite-accordion",
                        ...i,
                        children: f
                    })
                };
            en.displayName = "Accordion", et.displayName = "Accordion.Panel", er.displayName = "Accordion.Title", ee.displayName = "Accordion.Content", Object.assign(en, {
                Panel: et,
                Title: er,
                Content: ee
            });
            let eo = ({
                children: e,
                className: t,
                theme: r = {},
                ...n
            }) => {
                let o = q(Z().avatar.group, r);
                return (0, s.jsx)("div", {
                    "data-testid": "avatar-group-element",
                    className: H(o.base, t),
                    ...n,
                    children: e
                })
            };
            eo.displayName = "Avatar.Group";
            let ea = ({
                className: e,
                href: t,
                theme: r = {},
                total: n,
                ...o
            }) => {
                let a = q(Z().avatar.groupCounter, r);
                return (0, s.jsxs)("a", {
                    href: t,
                    className: H(a.base, e),
                    ...o,
                    children: ["+", n]
                })
            };
            ea.displayName = "Avatar.GroupCounter";
            let el = ({
                alt: e = "",
                bordered: t = !1,
                children: r,
                className: n,
                color: o = "light",
                img: a,
                placeholderInitials: l = "",
                rounded: i = !1,
                size: d = "md",
                stacked: c = !1,
                status: u,
                statusPosition: g = "top-left",
                theme: f = {},
                ...b
            }) => {
                let p = q(Z().avatar, f),
                    h = H(p.root.img.base, t && p.root.bordered, t && p.root.color[o], i && p.root.rounded, c && p.root.stacked, p.root.img.on, p.root.size[d]),
                    m = {
                        className: H(h, p.root.img.on),
                        "data-testid": "flowbite-avatar-img"
                    };
                return (0, s.jsxs)("div", {
                    className: H(p.root.base, n),
                    "data-testid": "flowbite-avatar",
                    ...b,
                    children: [(0, s.jsxs)("div", {
                        className: "relative",
                        children: [a ? "string" == typeof a ? (0, s.jsx)("img", {
                            alt: e,
                            src: a,
                            ...m
                        }) : a({
                            alt: e,
                            ...m
                        }) : l ? (0, s.jsx)("div", {
                            className: H(p.root.img.off, p.root.initials.base, c && p.root.stacked, t && p.root.bordered, t && p.root.color[o], p.root.size[d], i && p.root.rounded),
                            "data-testid": "flowbite-avatar-initials-placeholder",
                            children: (0, s.jsx)("span", {
                                className: H(p.root.initials.text),
                                "data-testid": "flowbite-avatar-initials-placeholder-text",
                                children: l
                            })
                        }) : (0, s.jsx)("div", {
                            className: H(h, p.root.img.off),
                            "data-testid": "flowbite-avatar-img",
                            children: (0, s.jsx)("svg", {
                                className: p.root.img.placeholder,
                                fill: "currentColor",
                                viewBox: "0 0 20 20",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: (0, s.jsx)("path", {
                                    fillRule: "evenodd",
                                    d: "M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z",
                                    clipRule: "evenodd"
                                })
                            })
                        }), u && (0, s.jsx)("span", {
                            "data-testid": "flowbite-avatar-status",
                            className: H(p.root.status.base, p.root.status[u], p.root.statusPosition[g])
                        })]
                    }), r && (0, s.jsx)("div", {
                        children: r
                    })]
                })
            };
            el.displayName = "Avatar", Object.assign(el, {
                Group: eo,
                Counter: ea
            });
            let ei = ({
                children: e,
                color: t = "info",
                href: r,
                icon: n,
                size: o = "xs",
                className: a,
                theme: l = {},
                ...i
            }) => {
                let d = q(Z().badge, l),
                    c = () => (0, s.jsxs)("span", {
                        className: H(d.root.base, d.root.color[t], d.root.size[o], d.icon[n ? "on" : "off"], a),
                        "data-testid": "flowbite-badge",
                        ...i,
                        children: [n && (0, s.jsx)(n, {
                            "aria-hidden": !0,
                            className: d.icon.size[o],
                            "data-testid": "flowbite-badge-icon"
                        }), e && (0, s.jsx)("span", {
                            children: e
                        })]
                    });
                return r ? (0, s.jsx)("a", {
                    className: d.root.href,
                    href: r,
                    children: (0, s.jsx)(c, {})
                }) : (0, s.jsx)(c, {})
            };
            ei.displayName = "Badge";
            let es = d.forwardRef,
                ed = ({
                    className: e,
                    color: t = "info",
                    light: r,
                    size: n = "md",
                    theme: o = {},
                    ...a
                }) => {
                    let l = q(Z().spinner, o);
                    return (0, s.jsx)("span", {
                        role: "status",
                        ...a,
                        children: (0, s.jsxs)("svg", {
                            fill: "none",
                            viewBox: "0 0 100 101",
                            className: H(l.base, l.color[t], l.light[r ? "on" : "off"].base, l.light[r ? "on" : "off"].color[t], l.size[n], e),
                            children: [(0, s.jsx)("path", {
                                d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                                fill: "currentColor"
                            }), (0, s.jsx)("path", {
                                d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                                fill: "currentFill"
                            })]
                        })
                    })
                };
            ed.displayName = "Spinner";
            let ec = es(({
                    children: e,
                    as: t,
                    href: r,
                    type: n = "button",
                    ...o
                }, a) => {
                    let l = t || (r ? "a" : "button");
                    return (0, d.createElement)(l, {
                        ref: a,
                        href: r,
                        type: n,
                        ...o
                    }, e)
                }),
                eu = ({
                    children: e,
                    className: t,
                    outline: r,
                    pill: n,
                    theme: o = {},
                    ...a
                }) => {
                    let l = (0, d.useMemo)(() => d.Children.map(e, (t, o) => (0, d.cloneElement)(t, {
                            outline: r,
                            pill: n,
                            positionInGroup: 0 === o ? "start" : o === e.length - 1 ? "end" : "middle"
                        })), [e, r, n]),
                        i = q(Z().buttonGroup, o);
                    return (0, s.jsx)("div", {
                        className: H(i.base, t),
                        role: "group",
                        ...a,
                        children: l
                    })
                };
            eu.displayName = "Button.Group";
            let eg = ({
                children: e,
                className: t,
                color: r = "info",
                disabled: n,
                fullSized: o,
                isProcessing: a = !1,
                processingLabel: l = "Loading...",
                processingSpinner: i,
                gradientDuoTone: d,
                gradientMonochrome: c,
                label: u,
                outline: g = !1,
                pill: f = !1,
                positionInGroup: b = "none",
                size: p = "md",
                theme: h = {},
                ...m
            }, y) => {
                let {
                    buttonGroup: x,
                    button: v
                } = Z(), w = q(v, h);
                return (0, s.jsx)(ec, {
                    ref: y,
                    disabled: n,
                    className: H(w.base, n && w.disabled, !d && !c && w.color[r], d && !c && w.gradientDuoTone[d], !d && c && w.gradient[c], g && (w.outline.color[r] ? ? w.outline.color.default), w.pill[f ? "on" : "off"], o && w.fullSized, x.position[b], t),
                    ...m,
                    children: (0, s.jsx)("span", {
                        className: H(w.inner.base, w.outline[g ? "on" : "off"], w.outline.pill[g && f ? "on" : "off"], w.size[p], g && !w.outline.color[r] && w.inner.outline, a && w.isProcessing, a && w.inner.isProcessingPadding[p], w.inner.position[b]),
                        children: (0, s.jsxs)(s.Fragment, {
                            children: [a && (0, s.jsx)("span", {
                                className: H(w.spinnerSlot, w.spinnerLeftPosition[p]),
                                children: i || (0, s.jsx)(ed, {
                                    size: p
                                })
                            }), void 0 !== e ? e : (0, s.jsx)("span", {
                                "data-testid": "flowbite-button-label",
                                className: H(w.label),
                                children: a ? l : u
                            })]
                        })
                    })
                })
            };
            eg.displayName = "Button";
            let ef = es(eg),
                eb = Object.assign(ef, {
                    Group: eu
                }),
                ep = ({
                    children: e,
                    ...t
                }) => (0, s.jsx)(eb, {
                    onClick: e => {
                        let t = e.target,
                            r = t.closest('[role="banner"]');
                        r ? .remove()
                    },
                    ...t,
                    children: e
                });
            ep.displayName = "Banner.CollapseButton";
            let eh = ({
                children: e,
                ...t
            }) => (0, s.jsx)("div", {
                "data-testid": "flowbite-banner",
                role: "banner",
                tabIndex: -1,
                ...t,
                children: e
            });
            eh.displayName = "Banner", Object.assign(eh, {
                CollapseButton: ep
            });
            let em = (0, d.forwardRef)(({
                children: e,
                className: t,
                href: r,
                icon: n,
                theme: o = {},
                ...a
            }, l) => {
                let i = void 0 !== r,
                    d = q(Z().breadcrumb.item, o);
                return (0, s.jsxs)("li", {
                    className: H(d.base, t),
                    ...a,
                    children: [(0, s.jsx)(u.yoF, {
                        "aria-hidden": !0,
                        className: d.chevron,
                        "data-testid": "flowbite-breadcrumb-separator"
                    }), (0, s.jsxs)(i ? "a" : "span", {
                        ref: l,
                        className: d.href[i ? "on" : "off"],
                        "data-testid": "flowbite-breadcrumb-item",
                        href: r,
                        children: [n && (0, s.jsx)(n, {
                            "aria-hidden": !0,
                            className: d.icon
                        }), e]
                    })]
                })
            });
            em.displayName = "Breadcrumb.Item";
            let ey = ({
                children: e,
                className: t,
                theme: r = {},
                ...n
            }) => {
                let o = q(Z().breadcrumb.root, r);
                return (0, s.jsx)("nav", {
                    "aria-label": "Breadcrumb",
                    className: H(o.base, t),
                    ...n,
                    children: (0, s.jsx)("ol", {
                        className: o.list,
                        children: e
                    })
                })
            };
            ey.displayName = "Breadcrumb", Object.assign(ey, {
                Item: em
            }), ex = ["renderImage", "imgSrc", "imgAlt", "children", "className", "horizontal", "href", "theme"], e => {
                let t = {};
                for (let r in e) ex.includes(r) || (t[r] = e[r]);
                return t
            };
            /*! *****************************************************************************
            Copyright (c) Microsoft Corporation.

            Permission to use, copy, modify, and/or distribute this software for any
            purpose with or without fee is hereby granted.

            THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
            REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
            AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
            INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
            LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
            OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
            PERFORMANCE OF THIS SOFTWARE.
            ***************************************************************************** */
            var ex, ev, ew, ek = function(e, t) {
                    return (ek = Object.setPrototypeOf || ({
                        __proto__: []
                    }) instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r])
                    })(e, t)
                },
                eN = (ev = ew = {
                    path: void 0,
                    exports: {},
                    require: function(e, t) {
                        return function() {
                            throw Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs")
                        }(null == t && ew.path)
                    }
                }, ew.exports, function() {
                    var e = {}.hasOwnProperty;

                    function t() {
                        for (var r = [], n = 0; n < arguments.length; n++) {
                            var o = arguments[n];
                            if (o) {
                                var a = typeof o;
                                if ("string" === a || "number" === a) r.push(o);
                                else if (Array.isArray(o) && o.length) {
                                    var l = t.apply(null, o);
                                    l && r.push(l)
                                } else if ("object" === a)
                                    for (var i in o) e.call(o, i) && o[i] && r.push(i)
                            }
                        }
                        return r.join(" ")
                    }
                    ev.exports ? (t.default = t, ev.exports = t) : window.classNames = t
                }(), ew.exports);

            function ej(e, t, r) {
                function n() {
                    var d = Date.now() - i;
                    d < t && d >= 0 ? o = setTimeout(n, t - d) : (o = null, r || (s = e.apply(l, a), l = a = null))
                }
                null == t && (t = 100);
                var o, a, l, i, s, d = function() {
                    l = this, a = arguments, i = Date.now();
                    var d = r && !o;
                    return o || (o = setTimeout(n, t)), d && (s = e.apply(l, a), l = a = null), s
                };
                return d.clear = function() {
                    o && (clearTimeout(o), o = null)
                }, d.flush = function() {
                    o && (s = e.apply(l, a), l = a = null, clearTimeout(o), o = null)
                }, d
            }
            ej.debounce = ej,
                function(e, t) {
                    void 0 === t && (t = {});
                    var r = t.insertAt;
                    if (e && "undefined" != typeof document) {
                        var n = document.head || document.getElementsByTagName("head")[0],
                            o = document.createElement("style");
                        o.type = "text/css", "top" === r && n.firstChild ? n.insertBefore(o, n.firstChild) : n.appendChild(o), o.styleSheet ? o.styleSheet.cssText = e : o.appendChild(document.createTextNode(e))
                    }
                }(".indiana-scroll-container {\n  overflow: auto; }\n  .indiana-scroll-container--dragging {\n    scroll-behavior: auto !important; }\n    .indiana-scroll-container--dragging > * {\n      pointer-events: none;\n      cursor: -webkit-grab;\n      cursor: grab; }\n  .indiana-scroll-container--hide-scrollbars {\n    overflow: hidden;\n    overflow: -moz-scrollbars-none;\n    -ms-overflow-style: none;\n    scrollbar-width: none; }\n    .indiana-scroll-container--hide-scrollbars::-webkit-scrollbar {\n      display: none !important;\n      height: 0 !important;\n      width: 0 !important;\n      background: transparent !important;\n      -webkit-appearance: none !important; }\n  .indiana-scroll-container--native-scroll {\n    overflow: auto; }\n\n.indiana-dragging {\n  cursor: -webkit-grab;\n  cursor: grab; }\n");
            var eE, eC = (eE = "indiana-scroll-container", function(e, t) {
                if (!e) return eE;
                "string" == typeof e ? r = e : t = e;
                var r, n = eE;
                return r && (n += "__" + r), n + (t ? Object.keys(t).reduce(function(e, r) {
                    var o = t[r];
                    return o && (e += " " + ("boolean" == typeof o ? n + "--" + r : n + "--" + r + "_" + o)), e
                }, "") : "")
            });
            ! function(e) {
                function t(t) {
                    var r = e.call(this, t) || this;
                    return r.onEndScroll = function() {
                        r.scrolling = !1, !r.pressed && r.started && r.processEnd()
                    }, r.onScroll = function(e) {
                        var t = r.container.current;
                        t.scrollLeft === r.scrollLeft && t.scrollTop === r.scrollTop || (r.scrolling = !0, r.processScroll(e), r.onEndScroll())
                    }, r.onTouchStart = function(e) {
                        var t = r.props.nativeMobileScroll;
                        if (r.isDraggable(e.target)) {
                            if (r.internal = !0, t && r.scrolling) r.pressed = !0;
                            else {
                                var n = e.touches[0];
                                r.processClick(e, n.clientX, n.clientY), !t && r.props.stopPropagation && e.stopPropagation()
                            }
                        }
                    }, r.onTouchEnd = function(e) {
                        var t = r.props.nativeMobileScroll;
                        r.pressed && (!r.started || r.scrolling && t ? r.pressed = !1 : r.processEnd(), r.forceUpdate())
                    }, r.onTouchMove = function(e) {
                        var t = r.props.nativeMobileScroll;
                        if (r.pressed && (!t || !r.isMobile)) {
                            var n = e.touches[0];
                            n && r.processMove(e, n.clientX, n.clientY), e.preventDefault(), r.props.stopPropagation && e.stopPropagation()
                        }
                    }, r.onMouseDown = function(e) {
                        r.isDraggable(e.target) && r.isScrollable() && (r.internal = !0, -1 !== r.props.buttons.indexOf(e.button) && (r.processClick(e, e.clientX, e.clientY), e.preventDefault(), r.props.stopPropagation && e.stopPropagation()))
                    }, r.onMouseMove = function(e) {
                        r.pressed && (r.processMove(e, e.clientX, e.clientY), e.preventDefault(), r.props.stopPropagation && e.stopPropagation())
                    }, r.onMouseUp = function(e) {
                        r.pressed && (r.started ? r.processEnd() : (r.internal = !1, r.pressed = !1, r.forceUpdate(), r.props.onClick && r.props.onClick(e)), e.preventDefault(), r.props.stopPropagation && e.stopPropagation())
                    }, r.container = d.createRef(), r.onEndScroll = ej(r.onEndScroll, 300), r.scrolling = !1, r.started = !1, r.pressed = !1, r.internal = !1, r.getRef = r.getRef.bind(r), r
                }(function(e, t) {
                    function r() {
                        this.constructor = e
                    }
                    ek(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
                })(t, e), t.prototype.componentDidMount = function() {
                    var e = this.props.nativeMobileScroll,
                        t = this.container.current;
                    window.addEventListener("mouseup", this.onMouseUp), window.addEventListener("mousemove", this.onMouseMove), window.addEventListener("touchmove", this.onTouchMove, {
                        passive: !1
                    }), window.addEventListener("touchend", this.onTouchEnd), t.addEventListener("touchstart", this.onTouchStart, {
                        passive: !1
                    }), t.addEventListener("mousedown", this.onMouseDown, {
                        passive: !1
                    }), e && (this.isMobile = this.isMobileDevice(), this.isMobile && this.forceUpdate())
                }, t.prototype.componentWillUnmount = function() {
                    window.removeEventListener("mouseup", this.onMouseUp), window.removeEventListener("mousemove", this.onMouseMove), window.removeEventListener("touchmove", this.onTouchMove), window.removeEventListener("touchend", this.onTouchEnd)
                }, t.prototype.getElement = function() {
                    return this.container.current
                }, t.prototype.isMobileDevice = function() {
                    return void 0 !== window.orientation || -1 !== navigator.userAgent.indexOf("IEMobile")
                }, t.prototype.isDraggable = function(e) {
                    var t = this.props.ignoreElements;
                    if (t) {
                        var r = e.closest(t);
                        return null === r || r.contains(this.getElement())
                    }
                    return !0
                }, t.prototype.isScrollable = function() {
                    var e = this.container.current;
                    return e && (e.scrollWidth > e.clientWidth || e.scrollHeight > e.clientHeight)
                }, t.prototype.processClick = function(e, t, r) {
                    var n = this.container.current;
                    this.scrollLeft = n.scrollLeft, this.scrollTop = n.scrollTop, this.clientX = t, this.clientY = r, this.pressed = !0
                }, t.prototype.processStart = function(e) {
                    void 0 === e && (e = !0);
                    var t = this.props.onStartScroll;
                    this.started = !0, e && document.body.classList.add("indiana-dragging"), t && t({
                        external: !this.internal
                    }), this.forceUpdate()
                }, t.prototype.processScroll = function(e) {
                    if (this.started) {
                        var t = this.props.onScroll;
                        t && t({
                            external: !this.internal
                        })
                    } else this.processStart(!1)
                }, t.prototype.processMove = function(e, t, r) {
                    var n = this.props,
                        o = n.horizontal,
                        a = n.vertical,
                        l = n.activationDistance,
                        i = n.onScroll,
                        s = this.container.current;
                    this.started ? (o && (s.scrollLeft -= t - this.clientX), a && (s.scrollTop -= r - this.clientY), i && i({
                        external: !this.internal
                    }), this.clientX = t, this.clientY = r, this.scrollLeft = s.scrollLeft, this.scrollTop = s.scrollTop) : (o && Math.abs(t - this.clientX) > l || a && Math.abs(r - this.clientY) > l) && (this.clientX = t, this.clientY = r, this.processStart())
                }, t.prototype.processEnd = function() {
                    var e = this.props.onEndScroll;
                    this.container.current && e && e({
                        external: !this.internal
                    }), this.pressed = !1, this.started = !1, this.scrolling = !1, this.internal = !1, document.body.classList.remove("indiana-dragging"), this.forceUpdate()
                }, t.prototype.getRef = function(e) {
                    [this.container, this.props.innerRef].forEach(function(t) {
                        t && ("function" == typeof t ? t(e) : t.current = e)
                    })
                }, t.prototype.render = function() {
                    var e = this.props,
                        t = e.children,
                        r = e.draggingClassName,
                        n = e.className,
                        o = e.style,
                        a = e.hideScrollbars,
                        l = e.component;
                    return d.createElement(l, {
                        className: eN(n, this.pressed && r, eC({
                            dragging: this.pressed,
                            "hide-scrollbars": a,
                            "native-scroll": this.isMobile
                        })),
                        style: o,
                        ref: this.getRef,
                        onScroll: this.onScroll
                    }, t)
                }, t.defaultProps = {
                    nativeMobileScroll: !0,
                    hideScrollbars: !0,
                    activationDistance: 10,
                    vertical: !0,
                    horizontal: !0,
                    stopPropagation: !1,
                    style: {},
                    component: "div",
                    buttons: [0]
                }
            }(d.PureComponent);
            let eT = () => "undefined" != typeof window,
                eR = (0, d.forwardRef)(({
                    className: e,
                    color: t = "default",
                    theme: r = {},
                    ...n
                }, o) => {
                    let a = q(Z().checkbox, r);
                    return (0, s.jsx)("input", {
                        ref: o,
                        type: "checkbox",
                        className: H(a.root.base, a.root.color[t], e),
                        ...n
                    })
                });
            eR.displayName = "Checkbox";
            let eS = ({
                    key: e,
                    onChange: t
                }) => {
                    function r({
                        key: r,
                        newValue: n
                    }) {
                        r === e && t(n)
                    }(0, d.useEffect)(() => (window.addEventListener("storage", r), () => window.removeEventListener("storage", r)), [])
                },
                eM = "light",
                eL = "flowbite-theme-mode",
                eI = "flowbite-theme-mode-sync",
                eD = () => {
                    let [e, t] = (0, d.useState)(eA(V.mode));
                    (0, d.useEffect)(() => {
                        ez(e), eO(e)
                    }, []), eS({
                        key: eL,
                        onChange(e) {
                            if (e) return r(e)
                        }
                    }), eP(e => t(e));
                    let r = e => {
                        t(e), ez(e), eO(e), document.dispatchEvent(new CustomEvent(eI, {
                            detail: e
                        }))
                    };
                    return {
                        mode: e,
                        computedMode: eF(e),
                        setMode: r,
                        toggleMode: () => {
                            let t = e;
                            "auto" === t && (t = eF(t)), r(t = "dark" === t ? "light" : "dark")
                        },
                        clearMode: () => {
                            let e = V.mode ? ? eM;
                            r(e)
                        }
                    }
                },
                eP = e => {
                    (0, d.useEffect)(() => {
                        function t(t) {
                            let r = t.detail;
                            e(r)
                        }
                        return document.addEventListener(eI, t), () => document.removeEventListener(eI, t)
                    }, [])
                },
                ez = e => localStorage.setItem(eL, e),
                eO = e => {
                    let t = eF(e);
                    "dark" === t ? document.documentElement.classList.add("dark") : document.documentElement.classList.remove("dark")
                },
                eA = e => {
                    if (!eT()) return eM;
                    let t = localStorage.getItem(eL);
                    return t ? ? e ? ? eM
                },
                eF = e => "auto" === e ? eB() : e,
                eB = () => window.matchMedia ? .("(prefers-color-scheme: dark)").matches ? "dark" : "light",
                eW = ({
                    children: e,
                    className: t,
                    color: r = "default",
                    theme: n = {},
                    value: o,
                    ...a
                }) => {
                    let l = q(Z().helperText, n);
                    return (0, s.jsx)("p", {
                        className: H(l.root.base, l.root.colors[r], t),
                        ...a,
                        children: o ? ? e ? ? ""
                    })
                };
            eW.displayName = "HelperText";
            let e_ = (0, d.forwardRef)(({
                addon: e,
                className: t,
                color: r = "gray",
                helperText: n,
                icon: o,
                rightIcon: a,
                shadow: l,
                sizing: i = "md",
                theme: d = {},
                ...c
            }, u) => {
                let g = q(Z().textInput, d);
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsxs)("div", {
                        className: H(g.base, t),
                        children: [e && (0, s.jsx)("span", {
                            className: g.addon,
                            children: e
                        }), (0, s.jsxs)("div", {
                            className: g.field.base,
                            children: [o && (0, s.jsx)("div", {
                                className: g.field.icon.base,
                                children: (0, s.jsx)(o, {
                                    className: g.field.icon.svg
                                })
                            }), a && (0, s.jsx)("div", {
                                "data-testid": "right-icon",
                                className: g.field.rightIcon.base,
                                children: (0, s.jsx)(a, {
                                    className: g.field.rightIcon.svg
                                })
                            }), (0, s.jsx)("input", {
                                className: H(g.field.input.base, g.field.input.colors[r], g.field.input.sizes[i], g.field.input.withIcon[o ? "on" : "off"], g.field.input.withRightIcon[a ? "on" : "off"], g.field.input.withAddon[e ? "on" : "off"], g.field.input.withShadow[l ? "on" : "off"]),
                                ...c,
                                ref: u
                            })]
                        })]
                    }), n && (0, s.jsx)(eW, {
                        color: r,
                        children: n
                    })]
                })
            });
            e_.displayName = "TextInput";
            let eY = (0, d.createContext)(void 0);

            function eG() {
                let e = (0, d.useContext)(eY);
                if (!e) throw Error("useDatePickerContext should be used within the DatePickerContext provider!");
                return e
            }(o = l || (l = {}))[o.Days = 0] = "Days", o[o.Months = 1] = "Months", o[o.Years = 2] = "Years", o[o.Decades = 3] = "Decades", (a = i || (i = {}))[a.Sunday = 0] = "Sunday", a[a.Monday = 1] = "Monday", a[a.Tuesday = 2] = "Tuesday", a[a.Wednesday = 3] = "Wednesday", a[a.Thursday = 4] = "Thursday", a[a.Friday = 5] = "Friday", a[a.Saturday = 6] = "Saturday";
            let eH = (e, t, r) => {
                    let n = new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime();
                    if (t && r) {
                        let e = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime(),
                            o = new Date(r.getFullYear(), r.getMonth(), r.getDate()).getTime();
                        return n >= e && n <= o
                    }
                    if (t) {
                        let e = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime();
                        return n >= e
                    }
                    if (r) {
                        let e = new Date(r.getFullYear(), r.getMonth(), r.getDate()).getTime();
                        return n <= e
                    }
                    return !0
                },
                e$ = (e, t) => (e = new Date(e.getFullYear(), e.getMonth(), e.getDate()), t = new Date(t.getFullYear(), t.getMonth(), t.getDate()), e.getTime() === t.getTime()),
                eU = (e, t, r) => (!eH(e, t, r) && (t && e < t ? e = t : r && e > r && (e = r)), e),
                eq = (e, t) => {
                    let r = new Date(e.getFullYear(), e.getMonth(), 1),
                        n = r.getDay(),
                        o = n - t;
                    return o < 0 && (o += 7), eV(r, -o)
                },
                eK = (e, t) => {
                    let r = [],
                        n = new Date(0);
                    n.setDate(n.getDate() - n.getDay() + t);
                    let o = new Intl.DateTimeFormat(e, {
                        weekday: "short"
                    });
                    for (let e = 0; e < 7; e++) r.push(o.format(eV(n, e)));
                    return r
                },
                eV = (e, t) => {
                    let r = new Date(e);
                    return r.setDate(r.getDate() + t), r
                },
                eX = (e, t) => {
                    let r = new Date(e);
                    return r.setMonth(r.getMonth() + t), r
                },
                eZ = (e, t) => {
                    let r = new Date(e);
                    return r.setFullYear(r.getFullYear() + t), r
                },
                eQ = (e, t, r) => {
                    let n = {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                    };
                    return r && (n = r), new Intl.DateTimeFormat(e, n).format(t)
                },
                eJ = (e, t) => {
                    let r = e.getFullYear();
                    return Math.floor(r / t) * t
                },
                e0 = (e, t) => {
                    let r = e.getFullYear();
                    return r >= t && r <= t + 9
                },
                e1 = ({
                    theme: e = {}
                }) => {
                    let {
                        theme: t,
                        weekStart: r,
                        minDate: n,
                        maxDate: o,
                        viewDate: a,
                        selectedDate: l,
                        changeSelectedDate: i,
                        language: d
                    } = eG(), c = q(t.views.days, e), u = eK(d, r), g = eq(a, r);
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("div", {
                            className: c.header.base,
                            children: u.map((e, t) => (0, s.jsx)("span", {
                                className: c.header.title,
                                children: e
                            }, t))
                        }), (0, s.jsx)("div", {
                            className: c.items.base,
                            children: [...Array(42)].map((e, t) => {
                                let r = eV(g, t),
                                    a = eQ(d, r, {
                                        day: "numeric"
                                    }),
                                    u = e$(l, r),
                                    f = !eH(r, n, o);
                                return (0, s.jsx)("button", {
                                    disabled: f,
                                    type: "button",
                                    className: H(c.items.item.base, u && c.items.item.selected, f && c.items.item.disabled),
                                    onClick: () => {
                                        f || i(r, !0)
                                    },
                                    children: a
                                }, t)
                            })
                        })]
                    })
                },
                e5 = ({
                    theme: e = {}
                }) => {
                    let {
                        theme: t,
                        selectedDate: r,
                        viewDate: n,
                        setViewDate: o,
                        setView: a
                    } = eG(), i = q(t.views.decades, e);
                    return (0, s.jsx)("div", {
                        className: i.items.base,
                        children: [...Array(12)].map((e, t) => {
                            let d = eJ(n, 100),
                                c = d - 10 + 10 * t,
                                u = new Date(c, 0, 1),
                                g = eZ(u, 9),
                                f = e0(n, c),
                                b = !eH(n, u, g);
                            return (0, s.jsx)("button", {
                                disabled: b,
                                type: "button",
                                className: H(i.items.item.base, f && i.items.item.selected, b && i.items.item.disabled),
                                onClick: () => {
                                    b || (o(eZ(n, c - r.getFullYear())), a(l.Years))
                                },
                                children: c
                            }, t)
                        })
                    })
                },
                e2 = ({
                    theme: e = {}
                }) => {
                    let {
                        theme: t,
                        minDate: r,
                        maxDate: n,
                        selectedDate: o,
                        viewDate: a,
                        language: i,
                        setViewDate: d,
                        setView: c
                    } = eG(), u = q(t.views.months, e);
                    return (0, s.jsx)("div", {
                        className: u.items.base,
                        children: [...Array(12)].map((e, t) => {
                            let g = new Date(a.getTime());
                            g.setMonth(t);
                            let f = eQ(i, g, {
                                    month: "short"
                                }),
                                b = e$(o, g),
                                p = !eH(g, r, n);
                            return (0, s.jsx)("button", {
                                disabled: p,
                                type: "button",
                                className: H(u.items.item.base, b && u.items.item.selected, p && u.items.item.disabled),
                                onClick: () => {
                                    p || (d(g), c(l.Days))
                                },
                                children: f
                            }, t)
                        })
                    })
                },
                e4 = ({
                    theme: e = {}
                }) => {
                    let {
                        theme: t,
                        selectedDate: r,
                        minDate: n,
                        maxDate: o,
                        viewDate: a,
                        setViewDate: i,
                        setView: d
                    } = eG(), c = q(t.views.years, e);
                    return (0, s.jsx)("div", {
                        className: c.items.base,
                        children: [...Array(12)].map((e, t) => {
                            let u = eJ(a, 10),
                                g = u - 1 + 1 * t,
                                f = new Date(a.getTime());
                            f.setFullYear(g);
                            let b = e$(r, f),
                                p = !eH(f, n, o);
                            return (0, s.jsx)("button", {
                                disabled: p,
                                type: "button",
                                className: H(c.items.item.base, b && c.items.item.selected, p && c.items.item.disabled),
                                onClick: () => {
                                    p || (i(f), d(l.Months))
                                },
                                children: g
                            }, t)
                        })
                    })
                },
                e6 = ({
                    title: e,
                    open: t,
                    inline: r = !1,
                    autoHide: n = !0,
                    showClearButton: o = !0,
                    labelClearButton: a = "Clear",
                    showTodayButton: c = !0,
                    labelTodayButton: g = "Today",
                    defaultDate: f = new Date,
                    minDate: b,
                    maxDate: p,
                    language: h = "en",
                    weekStart: m = i.Sunday,
                    className: y,
                    theme: x = {},
                    onSelectedDateChanged: v,
                    ...w
                }) => {
                    let k = q(Z().datepicker, x);
                    f = eU(f, b, p);
                    let [N, j] = (0, d.useState)(t), [E, C] = (0, d.useState)(l.Days), [T, R] = (0, d.useState)(f), [S, M] = (0, d.useState)(f), L = (0, d.useRef)(null), I = (0, d.useRef)(null), D = (e, t) => {
                        R(e), v && v(e), n && E === l.Days && !0 == t && !r && j(!1)
                    }, P = () => {
                        switch (E) {
                            case l.Days:
                                return l.Months;
                            case l.Months:
                                return l.Years;
                            case l.Years:
                                return l.Decades
                        }
                        return E
                    }, z = (e, t, r) => {
                        switch (e) {
                            case l.Days:
                                return new Date(eX(t, r));
                            case l.Months:
                                return new Date(eZ(t, r));
                            case l.Years:
                                return new Date(eZ(t, 10 * r));
                            case l.Decades:
                                return new Date(eZ(t, 100 * r));
                            default:
                                return new Date(eZ(t, 10 * r))
                        }
                    };
                    return (0, d.useEffect)(() => {
                        let e = e => {
                            let t = I ? .current ? .contains(e.target),
                                r = L ? .current ? .contains(e.target);
                            t || r || j(!1)
                        };
                        return document.addEventListener("mousedown", e), () => {
                            document.removeEventListener("mousedown", e)
                        }
                    }, [L, I, j]), (0, s.jsx)(eY.Provider, {
                        value: {
                            theme: k,
                            language: h,
                            minDate: b,
                            maxDate: p,
                            weekStart: m,
                            isOpen: N,
                            setIsOpen: j,
                            view: E,
                            setView: C,
                            viewDate: S,
                            setViewDate: M,
                            selectedDate: T,
                            setSelectedDate: R,
                            changeSelectedDate: D
                        },
                        children: (0, s.jsxs)("div", {
                            className: H(k.root.base, y),
                            children: [!r && (0, s.jsx)(e_, {
                                theme: k.root.input,
                                icon: u.IAP,
                                ref: L,
                                onFocus: () => {
                                    e$(S, T) || M(T), j(!0)
                                },
                                value: T && eQ(h, T),
                                readOnly: !0,
                                ...w
                            }), (N || r) && (0, s.jsx)("div", {
                                ref: I,
                                className: H(k.popup.root.base, r && k.popup.root.inline),
                                children: (0, s.jsxs)("div", {
                                    className: k.popup.root.inner,
                                    children: [(0, s.jsxs)("div", {
                                        className: k.popup.header.base,
                                        children: [e && (0, s.jsx)("div", {
                                            className: k.popup.header.title,
                                            children: e
                                        }), (0, s.jsxs)("div", {
                                            className: k.popup.header.selectors.base,
                                            children: [(0, s.jsx)("button", {
                                                type: "button",
                                                className: H(k.popup.header.selectors.button.base, k.popup.header.selectors.button.prev),
                                                onClick: () => M(z(E, S, -1)),
                                                children: (0, s.jsx)(u.jTe, {})
                                            }), (0, s.jsx)("button", {
                                                type: "button",
                                                className: H(k.popup.header.selectors.button.base, k.popup.header.selectors.button.view),
                                                onClick: () => C(P()),
                                                children: (() => {
                                                    switch (E) {
                                                        case l.Decades:
                                                            return `${eJ(S,100)} - ${eJ(S,100)+90}`;
                                                        case l.Years:
                                                            return `${eJ(S,10)} - ${eJ(S,10)+9}`;
                                                        case l.Months:
                                                            return eQ(h, S, {
                                                                year: "numeric"
                                                            });
                                                        case l.Days:
                                                        default:
                                                            return eQ(h, S, {
                                                                month: "long",
                                                                year: "numeric"
                                                            })
                                                    }
                                                })()
                                            }), (0, s.jsx)("button", {
                                                type: "button",
                                                className: H(k.popup.header.selectors.button.base, k.popup.header.selectors.button.next),
                                                onClick: () => M(z(E, S, 1)),
                                                children: (0, s.jsx)(u.WY3, {})
                                            })]
                                        })]
                                    }), (0, s.jsx)("div", {
                                        className: k.popup.view.base,
                                        children: (e => {
                                            switch (e) {
                                                case l.Decades:
                                                    return (0, s.jsx)(e5, {
                                                        theme: k.views.decades
                                                    });
                                                case l.Years:
                                                    return (0, s.jsx)(e4, {
                                                        theme: k.views.years
                                                    });
                                                case l.Months:
                                                    return (0, s.jsx)(e2, {
                                                        theme: k.views.months
                                                    });
                                                case l.Days:
                                                default:
                                                    return (0, s.jsx)(e1, {
                                                        theme: k.views.days
                                                    })
                                            }
                                        })(E)
                                    }), (o || c) && (0, s.jsxs)("div", {
                                        className: k.popup.footer.base,
                                        children: [c && (0, s.jsx)("button", {
                                            type: "button",
                                            className: H(k.popup.footer.button.base, k.popup.footer.button.today),
                                            onClick: () => {
                                                let e = new Date;
                                                D(e, !0), M(e)
                                            },
                                            children: g
                                        }), o && (0, s.jsx)("button", {
                                            type: "button",
                                            className: H(k.popup.footer.button.base, k.popup.footer.button.clear),
                                            onClick: () => {
                                                D(f, !0), f && M(f)
                                            },
                                            children: a
                                        })]
                                    })]
                                })
                            })]
                        })
                    })
                };

            function e7(e) {
                return e8(e) ? (e.nodeName || "").toLowerCase() : "#document"
            }

            function e9(e) {
                var t;
                return (null == e ? void 0 : null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
            }

            function e3(e) {
                var t;
                return null == (t = (e8(e) ? e.ownerDocument : e.document) || window.document) ? void 0 : t.documentElement
            }

            function e8(e) {
                return e instanceof Node || e instanceof e9(e).Node
            }

            function te(e) {
                return e instanceof Element || e instanceof e9(e).Element
            }

            function tt(e) {
                return e instanceof HTMLElement || e instanceof e9(e).HTMLElement
            }

            function tr(e) {
                return "undefined" != typeof ShadowRoot && (e instanceof ShadowRoot || e instanceof e9(e).ShadowRoot)
            }

            function tn(e) {
                let {
                    overflow: t,
                    overflowX: r,
                    overflowY: n,
                    display: o
                } = ti(e);
                return /auto|scroll|overlay|hidden|clip/.test(t + n + r) && !["inline", "contents"].includes(o)
            }

            function to(e) {
                let t = ta(),
                    r = ti(e);
                return "none" !== r.transform || "none" !== r.perspective || !!r.containerType && "normal" !== r.containerType || !t && !!r.backdropFilter && "none" !== r.backdropFilter || !t && !!r.filter && "none" !== r.filter || ["transform", "perspective", "filter"].some(e => (r.willChange || "").includes(e)) || ["paint", "layout", "strict", "content"].some(e => (r.contain || "").includes(e))
            }

            function ta() {
                return "undefined" != typeof CSS && !!CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")
            }

            function tl(e) {
                return ["html", "body", "#document"].includes(e7(e))
            }

            function ti(e) {
                return e9(e).getComputedStyle(e)
            }

            function ts(e) {
                return te(e) ? {
                    scrollLeft: e.scrollLeft,
                    scrollTop: e.scrollTop
                } : {
                    scrollLeft: e.pageXOffset,
                    scrollTop: e.pageYOffset
                }
            }

            function td(e) {
                if ("html" === e7(e)) return e;
                let t = e.assignedSlot || e.parentNode || tr(e) && e.host || e3(e);
                return tr(t) ? t.host : t
            }

            function tc(e, t, r) {
                var n;
                void 0 === t && (t = []), void 0 === r && (r = !0);
                let o = function e(t) {
                        let r = td(t);
                        return tl(r) ? t.ownerDocument ? t.ownerDocument.body : t.body : tt(r) && tn(r) ? r : e(r)
                    }(e),
                    a = o === (null == (n = e.ownerDocument) ? void 0 : n.body),
                    l = e9(o);
                return a ? t.concat(l, l.visualViewport || [], tn(o) ? o : [], l.frameElement && r ? tc(l.frameElement) : []) : t.concat(o, tc(o, [], r))
            }

            function tu(e) {
                let t = e.activeElement;
                for (;
                    (null == (r = t) || null == (r = r.shadowRoot) ? void 0 : r.activeElement) != null;) {
                    var r;
                    t = t.shadowRoot.activeElement
                }
                return t
            }

            function tg(e, t) {
                if (!e || !t) return !1;
                let r = t.getRootNode && t.getRootNode();
                if (e.contains(t)) return !0;
                if (r && tr(r)) {
                    let r = t;
                    for (; r;) {
                        if (e === r) return !0;
                        r = r.parentNode || r.host
                    }
                }
                return !1
            }

            function tf() {
                let e = navigator.userAgentData;
                return null != e && e.platform ? e.platform : navigator.platform
            }

            function tb(e) {
                return 0 === e.mozInputSource && !!e.isTrusted || (tm() && e.pointerType ? "click" === e.type && 1 === e.buttons : 0 === e.detail && !e.pointerType)
            }

            function tp(e) {
                return !tm() && 0 === e.width && 0 === e.height || 1 === e.width && 1 === e.height && 0 === e.pressure && 0 === e.detail && "mouse" === e.pointerType || e.width < 1 && e.height < 1 && 0 === e.pressure && 0 === e.detail
            }

            function th() {
                return /apple/i.test(navigator.vendor)
            }

            function tm() {
                let e = /android/i;
                return e.test(tf()) || e.test(function() {
                    let e = navigator.userAgentData;
                    return e && Array.isArray(e.brands) ? e.brands.map(e => {
                        let {
                            brand: t,
                            version: r
                        } = e;
                        return t + "/" + r
                    }).join(" ") : navigator.userAgent
                }())
            }

            function ty() {
                return tf().toLowerCase().startsWith("mac") && !navigator.maxTouchPoints
            }

            function tx(e, t) {
                let r = ["mouse", "pen"];
                return t || r.push("", void 0), r.includes(e)
            }

            function tv(e) {
                return (null == e ? void 0 : e.ownerDocument) || document
            }

            function tw(e, t) {
                return null != t && ("composedPath" in e ? e.composedPath().includes(t) : null != e.target && t.contains(e.target))
            }

            function tk(e) {
                return "composedPath" in e ? e.composedPath()[0] : e.target
            }

            function tN(e) {
                return tt(e) && e.matches("input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])")
            }

            function tj(e) {
                e.preventDefault(), e.stopPropagation()
            }

            function tE(e) {
                return !!e && "combobox" === e.getAttribute("role") && tN(e)
            }
            e6.displayName = "Datepicker";
            let tC = ["top", "right", "bottom", "left"].reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []),
                tT = Math.min,
                tR = Math.max,
                tS = Math.round,
                tM = Math.floor,
                tL = e => ({
                    x: e,
                    y: e
                }),
                tI = {
                    left: "right",
                    right: "left",
                    bottom: "top",
                    top: "bottom"
                },
                tD = {
                    start: "end",
                    end: "start"
                };

            function tP(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function tz(e) {
                return e.split("-")[0]
            }

            function tO(e) {
                return e.split("-")[1]
            }

            function tA(e) {
                return "x" === e ? "y" : "x"
            }

            function tF(e) {
                return "y" === e ? "height" : "width"
            }

            function tB(e) {
                return ["top", "bottom"].includes(tz(e)) ? "y" : "x"
            }

            function tW(e, t, r) {
                void 0 === r && (r = !1);
                let n = tO(e),
                    o = tA(tB(e)),
                    a = tF(o),
                    l = "x" === o ? n === (r ? "end" : "start") ? "right" : "left" : "start" === n ? "bottom" : "top";
                return t.reference[a] > t.floating[a] && (l = tY(l)), [l, tY(l)]
            }

            function t_(e) {
                return e.replace(/start|end/g, e => tD[e])
            }

            function tY(e) {
                return e.replace(/left|right|bottom|top/g, e => tI[e])
            }

            function tG(e) {
                return "number" != typeof e ? {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                    ...e
                } : {
                    top: e,
                    right: e,
                    bottom: e,
                    left: e
                }
            }

            function tH(e) {
                return { ...e,
                    top: e.y,
                    left: e.x,
                    right: e.x + e.width,
                    bottom: e.y + e.height
                }
            }

            function t$(e, t, r) {
                let n, {
                        reference: o,
                        floating: a
                    } = e,
                    l = tB(t),
                    i = tA(tB(t)),
                    s = tF(i),
                    d = tz(t),
                    c = "y" === l,
                    u = o.x + o.width / 2 - a.width / 2,
                    g = o.y + o.height / 2 - a.height / 2,
                    f = o[s] / 2 - a[s] / 2;
                switch (d) {
                    case "top":
                        n = {
                            x: u,
                            y: o.y - a.height
                        };
                        break;
                    case "bottom":
                        n = {
                            x: u,
                            y: o.y + o.height
                        };
                        break;
                    case "right":
                        n = {
                            x: o.x + o.width,
                            y: g
                        };
                        break;
                    case "left":
                        n = {
                            x: o.x - a.width,
                            y: g
                        };
                        break;
                    default:
                        n = {
                            x: o.x,
                            y: o.y
                        }
                }
                switch (tO(t)) {
                    case "start":
                        n[i] -= f * (r && c ? -1 : 1);
                        break;
                    case "end":
                        n[i] += f * (r && c ? -1 : 1)
                }
                return n
            }
            let tU = async (e, t, r) => {
                let {
                    placement: n = "bottom",
                    strategy: o = "absolute",
                    middleware: a = [],
                    platform: l
                } = r, i = a.filter(Boolean), s = await (null == l.isRTL ? void 0 : l.isRTL(t)), d = await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: o
                }), {
                    x: c,
                    y: u
                } = t$(d, n, s), g = n, f = {}, b = 0;
                for (let r = 0; r < i.length; r++) {
                    let {
                        name: a,
                        fn: p
                    } = i[r], {
                        x: h,
                        y: m,
                        data: y,
                        reset: x
                    } = await p({
                        x: c,
                        y: u,
                        initialPlacement: n,
                        placement: g,
                        strategy: o,
                        middlewareData: f,
                        rects: d,
                        platform: l,
                        elements: {
                            reference: e,
                            floating: t
                        }
                    });
                    if (c = null != h ? h : c, u = null != m ? m : u, f = { ...f,
                            [a]: { ...f[a],
                                ...y
                            }
                        }, x && b <= 50) {
                        b++, "object" == typeof x && (x.placement && (g = x.placement), x.rects && (d = !0 === x.rects ? await l.getElementRects({
                            reference: e,
                            floating: t,
                            strategy: o
                        }) : x.rects), {
                            x: c,
                            y: u
                        } = t$(d, g, s)), r = -1;
                        continue
                    }
                }
                return {
                    x: c,
                    y: u,
                    placement: g,
                    strategy: o,
                    middlewareData: f
                }
            };
            async function tq(e, t) {
                var r;
                void 0 === t && (t = {});
                let {
                    x: n,
                    y: o,
                    platform: a,
                    rects: l,
                    elements: i,
                    strategy: s
                } = e, {
                    boundary: d = "clippingAncestors",
                    rootBoundary: c = "viewport",
                    elementContext: u = "floating",
                    altBoundary: g = !1,
                    padding: f = 0
                } = tP(t, e), b = tG(f), p = i[g ? "floating" === u ? "reference" : "floating" : u], h = tH(await a.getClippingRect({
                    element: null == (r = await (null == a.isElement ? void 0 : a.isElement(p))) || r ? p : p.contextElement || await (null == a.getDocumentElement ? void 0 : a.getDocumentElement(i.floating)),
                    boundary: d,
                    rootBoundary: c,
                    strategy: s
                })), m = "floating" === u ? { ...l.floating,
                    x: n,
                    y: o
                } : l.reference, y = await (null == a.getOffsetParent ? void 0 : a.getOffsetParent(i.floating)), x = await (null == a.isElement ? void 0 : a.isElement(y)) && await (null == a.getScale ? void 0 : a.getScale(y)) || {
                    x: 1,
                    y: 1
                }, v = tH(a.convertOffsetParentRelativeRectToViewportRelativeRect ? await a.convertOffsetParentRelativeRectToViewportRelativeRect({
                    rect: m,
                    offsetParent: y,
                    strategy: s
                }) : m);
                return {
                    top: (h.top - v.top + b.top) / x.y,
                    bottom: (v.bottom - h.bottom + b.bottom) / x.y,
                    left: (h.left - v.left + b.left) / x.x,
                    right: (v.right - h.right + b.right) / x.x
                }
            }
            let tK = e => ({
                name: "arrow",
                options: e,
                async fn(t) {
                    let {
                        x: r,
                        y: n,
                        placement: o,
                        rects: a,
                        platform: l,
                        elements: i,
                        middlewareData: s
                    } = t, {
                        element: d,
                        padding: c = 0
                    } = tP(e, t) || {};
                    if (null == d) return {};
                    let u = tG(c),
                        g = {
                            x: r,
                            y: n
                        },
                        f = tA(tB(o)),
                        b = tF(f),
                        p = await l.getDimensions(d),
                        h = "y" === f,
                        m = h ? "clientHeight" : "clientWidth",
                        y = a.reference[b] + a.reference[f] - g[f] - a.floating[b],
                        x = g[f] - a.reference[f],
                        v = await (null == l.getOffsetParent ? void 0 : l.getOffsetParent(d)),
                        w = v ? v[m] : 0;
                    w && await (null == l.isElement ? void 0 : l.isElement(v)) || (w = i.floating[m] || a.floating[b]);
                    let k = w / 2 - p[b] / 2 - 1,
                        N = tT(u[h ? "top" : "left"], k),
                        j = tT(u[h ? "bottom" : "right"], k),
                        E = w - p[b] - j,
                        C = w / 2 - p[b] / 2 + (y / 2 - x / 2),
                        T = tR(N, tT(C, E)),
                        R = !s.arrow && null != tO(o) && C != T && a.reference[b] / 2 - (C < N ? N : j) - p[b] / 2 < 0,
                        S = R ? C < N ? C - N : C - E : 0;
                    return {
                        [f]: g[f] + S,
                        data: {
                            [f]: T,
                            centerOffset: C - T - S,
                            ...R && {
                                alignmentOffset: S
                            }
                        },
                        reset: R
                    }
                }
            });
            async function tV(e, t) {
                let {
                    placement: r,
                    platform: n,
                    elements: o
                } = e, a = await (null == n.isRTL ? void 0 : n.isRTL(o.floating)), l = tz(r), i = tO(r), s = "y" === tB(r), d = ["left", "top"].includes(l) ? -1 : 1, c = a && s ? -1 : 1, u = tP(t, e), {
                    mainAxis: g,
                    crossAxis: f,
                    alignmentAxis: b
                } = "number" == typeof u ? {
                    mainAxis: u,
                    crossAxis: 0,
                    alignmentAxis: null
                } : {
                    mainAxis: 0,
                    crossAxis: 0,
                    alignmentAxis: null,
                    ...u
                };
                return i && "number" == typeof b && (f = "end" === i ? -1 * b : b), s ? {
                    x: f * c,
                    y: g * d
                } : {
                    x: g * d,
                    y: f * c
                }
            }

            function tX(e) {
                let t = ti(e),
                    r = parseFloat(t.width) || 0,
                    n = parseFloat(t.height) || 0,
                    o = tt(e),
                    a = o ? e.offsetWidth : r,
                    l = o ? e.offsetHeight : n,
                    i = tS(r) !== a || tS(n) !== l;
                return i && (r = a, n = l), {
                    width: r,
                    height: n,
                    $: i
                }
            }

            function tZ(e) {
                return te(e) ? e : e.contextElement
            }

            function tQ(e) {
                let t = tZ(e);
                if (!tt(t)) return tL(1);
                let r = t.getBoundingClientRect(),
                    {
                        width: n,
                        height: o,
                        $: a
                    } = tX(t),
                    l = (a ? tS(r.width) : r.width) / n,
                    i = (a ? tS(r.height) : r.height) / o;
                return l && Number.isFinite(l) || (l = 1), i && Number.isFinite(i) || (i = 1), {
                    x: l,
                    y: i
                }
            }
            let tJ = tL(0);

            function t0(e) {
                let t = e9(e);
                return ta() && t.visualViewport ? {
                    x: t.visualViewport.offsetLeft,
                    y: t.visualViewport.offsetTop
                } : tJ
            }

            function t1(e, t, r, n) {
                var o;
                void 0 === t && (t = !1), void 0 === r && (r = !1);
                let a = e.getBoundingClientRect(),
                    l = tZ(e),
                    i = tL(1);
                t && (n ? te(n) && (i = tQ(n)) : i = tQ(e));
                let s = (void 0 === (o = r) && (o = !1), n && (!o || n === e9(l)) && o) ? t0(l) : tL(0),
                    d = (a.left + s.x) / i.x,
                    c = (a.top + s.y) / i.y,
                    u = a.width / i.x,
                    g = a.height / i.y;
                if (l) {
                    let e = e9(l),
                        t = n && te(n) ? e9(n) : n,
                        r = e.frameElement;
                    for (; r && n && t !== e;) {
                        let e = tQ(r),
                            t = r.getBoundingClientRect(),
                            n = ti(r),
                            o = t.left + (r.clientLeft + parseFloat(n.paddingLeft)) * e.x,
                            a = t.top + (r.clientTop + parseFloat(n.paddingTop)) * e.y;
                        d *= e.x, c *= e.y, u *= e.x, g *= e.y, d += o, c += a, r = e9(r).frameElement
                    }
                }
                return tH({
                    width: u,
                    height: g,
                    x: d,
                    y: c
                })
            }

            function t5(e) {
                return t1(e3(e)).left + ts(e).scrollLeft
            }

            function t2(e, t, r) {
                let n;
                if ("viewport" === t) n = function(e, t) {
                    let r = e9(e),
                        n = e3(e),
                        o = r.visualViewport,
                        a = n.clientWidth,
                        l = n.clientHeight,
                        i = 0,
                        s = 0;
                    if (o) {
                        a = o.width, l = o.height;
                        let e = ta();
                        (!e || e && "fixed" === t) && (i = o.offsetLeft, s = o.offsetTop)
                    }
                    return {
                        width: a,
                        height: l,
                        x: i,
                        y: s
                    }
                }(e, r);
                else if ("document" === t) n = function(e) {
                    let t = e3(e),
                        r = ts(e),
                        n = e.ownerDocument.body,
                        o = tR(t.scrollWidth, t.clientWidth, n.scrollWidth, n.clientWidth),
                        a = tR(t.scrollHeight, t.clientHeight, n.scrollHeight, n.clientHeight),
                        l = -r.scrollLeft + t5(e),
                        i = -r.scrollTop;
                    return "rtl" === ti(n).direction && (l += tR(t.clientWidth, n.clientWidth) - o), {
                        width: o,
                        height: a,
                        x: l,
                        y: i
                    }
                }(e3(e));
                else if (te(t)) n = function(e, t) {
                    let r = t1(e, !0, "fixed" === t),
                        n = r.top + e.clientTop,
                        o = r.left + e.clientLeft,
                        a = tt(e) ? tQ(e) : tL(1),
                        l = e.clientWidth * a.x,
                        i = e.clientHeight * a.y,
                        s = o * a.x,
                        d = n * a.y;
                    return {
                        width: l,
                        height: i,
                        x: s,
                        y: d
                    }
                }(t, r);
                else {
                    let r = t0(e);
                    n = { ...t,
                        x: t.x - r.x,
                        y: t.y - r.y
                    }
                }
                return tH(n)
            }

            function t4(e, t) {
                return tt(e) && "fixed" !== ti(e).position ? t ? t(e) : e.offsetParent : null
            }

            function t6(e, t) {
                let r = e9(e);
                if (!tt(e)) return r;
                let n = t4(e, t);
                for (; n && ["table", "td", "th"].includes(e7(n)) && "static" === ti(n).position;) n = t4(n, t);
                return n && ("html" === e7(n) || "body" === e7(n) && "static" === ti(n).position && !to(n)) ? r : n || function(e) {
                    let t = td(e);
                    for (; tt(t) && !tl(t);) {
                        if (to(t)) return t;
                        t = td(t)
                    }
                    return null
                }(e) || r
            }
            let t7 = async function(e) {
                    let {
                        reference: t,
                        floating: r,
                        strategy: n
                    } = e, o = this.getOffsetParent || t6, a = this.getDimensions;
                    return {
                        reference: function(e, t, r) {
                            let n = tt(t),
                                o = e3(t),
                                a = "fixed" === r,
                                l = t1(e, !0, a, t),
                                i = {
                                    scrollLeft: 0,
                                    scrollTop: 0
                                },
                                s = tL(0);
                            if (n || !n && !a) {
                                if (("body" !== e7(t) || tn(o)) && (i = ts(t)), n) {
                                    let e = t1(t, !0, a, t);
                                    s.x = e.x + t.clientLeft, s.y = e.y + t.clientTop
                                } else o && (s.x = t5(o))
                            }
                            return {
                                x: l.left + i.scrollLeft - s.x,
                                y: l.top + i.scrollTop - s.y,
                                width: l.width,
                                height: l.height
                            }
                        }(t, await o(r), n),
                        floating: {
                            x: 0,
                            y: 0,
                            ...await a(r)
                        }
                    }
                },
                t9 = {
                    convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
                        let {
                            rect: t,
                            offsetParent: r,
                            strategy: n
                        } = e, o = tt(r), a = e3(r);
                        if (r === a) return t;
                        let l = {
                                scrollLeft: 0,
                                scrollTop: 0
                            },
                            i = tL(1),
                            s = tL(0);
                        if ((o || !o && "fixed" !== n) && (("body" !== e7(r) || tn(a)) && (l = ts(r)), tt(r))) {
                            let e = t1(r);
                            i = tQ(r), s.x = e.x + r.clientLeft, s.y = e.y + r.clientTop
                        }
                        return {
                            width: t.width * i.x,
                            height: t.height * i.y,
                            x: t.x * i.x - l.scrollLeft * i.x + s.x,
                            y: t.y * i.y - l.scrollTop * i.y + s.y
                        }
                    },
                    getDocumentElement: e3,
                    getClippingRect: function(e) {
                        let {
                            element: t,
                            boundary: r,
                            rootBoundary: n,
                            strategy: o
                        } = e, a = "clippingAncestors" === r ? function(e, t) {
                            let r = t.get(e);
                            if (r) return r;
                            let n = tc(e, [], !1).filter(e => te(e) && "body" !== e7(e)),
                                o = null,
                                a = "fixed" === ti(e).position,
                                l = a ? td(e) : e;
                            for (; te(l) && !tl(l);) {
                                let t = ti(l),
                                    r = to(l);
                                r || "fixed" !== t.position || (o = null);
                                let i = a ? !r && !o : !r && "static" === t.position && !!o && ["absolute", "fixed"].includes(o.position) || tn(l) && !r && function e(t, r) {
                                    let n = td(t);
                                    return !(n === r || !te(n) || tl(n)) && ("fixed" === ti(n).position || e(n, r))
                                }(e, l);
                                i ? n = n.filter(e => e !== l) : o = t, l = td(l)
                            }
                            return t.set(e, n), n
                        }(t, this._c) : [].concat(r), l = [...a, n], i = l[0], s = l.reduce((e, r) => {
                            let n = t2(t, r, o);
                            return e.top = tR(n.top, e.top), e.right = tT(n.right, e.right), e.bottom = tT(n.bottom, e.bottom), e.left = tR(n.left, e.left), e
                        }, t2(t, i, o));
                        return {
                            width: s.right - s.left,
                            height: s.bottom - s.top,
                            x: s.left,
                            y: s.top
                        }
                    },
                    getOffsetParent: t6,
                    getElementRects: t7,
                    getClientRects: function(e) {
                        return Array.from(e.getClientRects())
                    },
                    getDimensions: function(e) {
                        return tX(e)
                    },
                    getScale: tQ,
                    isElement: te,
                    isRTL: function(e) {
                        return "rtl" === ti(e).direction
                    }
                };

            function t3(e, t, r, n) {
                let o;
                void 0 === n && (n = {});
                let {
                    ancestorScroll: a = !0,
                    ancestorResize: l = !0,
                    elementResize: i = "function" == typeof ResizeObserver,
                    layoutShift: s = "function" == typeof IntersectionObserver,
                    animationFrame: d = !1
                } = n, c = tZ(e), u = a || l ? [...c ? tc(c) : [], ...tc(t)] : [];
                u.forEach(e => {
                    a && e.addEventListener("scroll", r, {
                        passive: !0
                    }), l && e.addEventListener("resize", r)
                });
                let g = c && s ? function(e, t) {
                        let r, n = null,
                            o = e3(e);

                        function a() {
                            clearTimeout(r), n && n.disconnect(), n = null
                        }
                        return ! function l(i, s) {
                            void 0 === i && (i = !1), void 0 === s && (s = 1), a();
                            let {
                                left: d,
                                top: c,
                                width: u,
                                height: g
                            } = e.getBoundingClientRect();
                            if (i || t(), !u || !g) return;
                            let f = tM(c),
                                b = tM(o.clientWidth - (d + u)),
                                p = tM(o.clientHeight - (c + g)),
                                h = tM(d),
                                m = {
                                    rootMargin: -f + "px " + -b + "px " + -p + "px " + -h + "px",
                                    threshold: tR(0, tT(1, s)) || 1
                                },
                                y = !0;

                            function x(e) {
                                let t = e[0].intersectionRatio;
                                if (t !== s) {
                                    if (!y) return l();
                                    t ? l(!1, t) : r = setTimeout(() => {
                                        l(!1, 1e-7)
                                    }, 100)
                                }
                                y = !1
                            }
                            try {
                                n = new IntersectionObserver(x, { ...m,
                                    root: o.ownerDocument
                                })
                            } catch (e) {
                                n = new IntersectionObserver(x, m)
                            }
                            n.observe(e)
                        }(!0), a
                    }(c, r) : null,
                    f = -1,
                    b = null;
                i && (b = new ResizeObserver(e => {
                    let [n] = e;
                    n && n.target === c && b && (b.unobserve(t), cancelAnimationFrame(f), f = requestAnimationFrame(() => {
                        b && b.observe(t)
                    })), r()
                }), c && !d && b.observe(c), b.observe(t));
                let p = d ? t1(e) : null;
                return d && function t() {
                    let n = t1(e);
                    p && (n.x !== p.x || n.y !== p.y || n.width !== p.width || n.height !== p.height) && r(), p = n, o = requestAnimationFrame(t)
                }(), r(), () => {
                    u.forEach(e => {
                        a && e.removeEventListener("scroll", r), l && e.removeEventListener("resize", r)
                    }), g && g(), b && b.disconnect(), b = null, d && cancelAnimationFrame(o)
                }
            }
            let t8 = (e, t, r) => {
                let n = new Map,
                    o = {
                        platform: t9,
                        ...r
                    },
                    a = { ...o.platform,
                        _c: n
                    };
                return tU(e, t, { ...o,
                    platform: a
                })
            };
            var re = r(1293);
            let rt = e => ({
                name: "arrow",
                options: e,
                fn(t) {
                    let {
                        element: r,
                        padding: n
                    } = "function" == typeof e ? e(t) : e;
                    if (r && ({}).hasOwnProperty.call(r, "current")) {
                        if (null != r.current) return tK({
                            element: r.current,
                            padding: n
                        }).fn(t)
                    } else if (r) return tK({
                        element: r,
                        padding: n
                    }).fn(t);
                    return {}
                }
            });
            var rr = "undefined" != typeof document ? d.useLayoutEffect : d.useEffect;

            function rn(e, t) {
                let r, n, o;
                if (e === t) return !0;
                if (typeof e != typeof t) return !1;
                if ("function" == typeof e && e.toString() === t.toString()) return !0;
                if (e && t && "object" == typeof e) {
                    if (Array.isArray(e)) {
                        if ((r = e.length) != t.length) return !1;
                        for (n = r; 0 != n--;)
                            if (!rn(e[n], t[n])) return !1;
                        return !0
                    }
                    if ((r = (o = Object.keys(e)).length) !== Object.keys(t).length) return !1;
                    for (n = r; 0 != n--;)
                        if (!({}).hasOwnProperty.call(t, o[n])) return !1;
                    for (n = r; 0 != n--;) {
                        let r = o[n];
                        if (("_owner" !== r || !e.$$typeof) && !rn(e[r], t[r])) return !1
                    }
                    return !0
                }
                return e != e && t != t
            }

            function ro(e) {
                if ("undefined" == typeof window) return 1;
                let t = e.ownerDocument.defaultView || window;
                return t.devicePixelRatio || 1
            }

            function ra(e, t) {
                let r = ro(e);
                return Math.round(t * r) / r
            }

            function rl(e) {
                let t = d.useRef(e);
                return rr(() => {
                    t.current = e
                }), t
            }
            var ri = 'input:not([inert]),select:not([inert]),textarea:not([inert]),a[href]:not([inert]),button:not([inert]),[tabindex]:not(slot):not([inert]),audio[controls]:not([inert]),video[controls]:not([inert]),[contenteditable]:not([contenteditable="false"]):not([inert]),details>summary:first-of-type:not([inert]),details:not([inert])',
                rs = "undefined" == typeof Element,
                rd = rs ? function() {} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector,
                rc = !rs && Element.prototype.getRootNode ? function(e) {
                    var t;
                    return null == e ? void 0 : null === (t = e.getRootNode) || void 0 === t ? void 0 : t.call(e)
                } : function(e) {
                    return null == e ? void 0 : e.ownerDocument
                },
                ru = function e(t, r) {
                    void 0 === r && (r = !0);
                    var n, o = null == t ? void 0 : null === (n = t.getAttribute) || void 0 === n ? void 0 : n.call(t, "inert");
                    return "" === o || "true" === o || r && t && e(t.parentNode)
                },
                rg = function(e) {
                    var t, r = null == e ? void 0 : null === (t = e.getAttribute) || void 0 === t ? void 0 : t.call(e, "contenteditable");
                    return "" === r || "true" === r
                },
                rf = function(e, t, r) {
                    if (ru(e)) return [];
                    var n = Array.prototype.slice.apply(e.querySelectorAll(ri));
                    return t && rd.call(e, ri) && n.unshift(e), n = n.filter(r)
                },
                rb = function e(t, r, n) {
                    for (var o = [], a = Array.from(t); a.length;) {
                        var l = a.shift();
                        if (!ru(l, !1)) {
                            if ("SLOT" === l.tagName) {
                                var i = l.assignedElements(),
                                    s = e(i.length ? i : l.children, !0, n);
                                n.flatten ? o.push.apply(o, s) : o.push({
                                    scopeParent: l,
                                    candidates: s
                                })
                            } else {
                                rd.call(l, ri) && n.filter(l) && (r || !t.includes(l)) && o.push(l);
                                var d = l.shadowRoot || "function" == typeof n.getShadowRoot && n.getShadowRoot(l),
                                    c = !ru(d, !1) && (!n.shadowRootFilter || n.shadowRootFilter(l));
                                if (d && c) {
                                    var u = e(!0 === d ? l.children : d.children, !0, n);
                                    n.flatten ? o.push.apply(o, u) : o.push({
                                        scopeParent: l,
                                        candidates: u
                                    })
                                } else a.unshift.apply(a, l.children)
                            }
                        }
                    }
                    return o
                },
                rp = function(e) {
                    return !isNaN(parseInt(e.getAttribute("tabindex"), 10))
                },
                rh = function(e) {
                    if (!e) throw Error("No node provided");
                    return e.tabIndex < 0 && (/^(AUDIO|VIDEO|DETAILS)$/.test(e.tagName) || rg(e)) && !rp(e) ? 0 : e.tabIndex
                },
                rm = function(e, t) {
                    var r = rh(e);
                    return r < 0 && t && !rp(e) ? 0 : r
                },
                ry = function(e, t) {
                    return e.tabIndex === t.tabIndex ? e.documentOrder - t.documentOrder : e.tabIndex - t.tabIndex
                },
                rx = function(e) {
                    return "INPUT" === e.tagName
                },
                rv = function(e, t) {
                    for (var r = 0; r < e.length; r++)
                        if (e[r].checked && e[r].form === t) return e[r]
                },
                rw = function(e) {
                    if (!e.name) return !0;
                    var t, r = e.form || rc(e),
                        n = function(e) {
                            return r.querySelectorAll('input[type="radio"][name="' + e + '"]')
                        };
                    if ("undefined" != typeof window && void 0 !== window.CSS && "function" == typeof window.CSS.escape) t = n(window.CSS.escape(e.name));
                    else try {
                        t = n(e.name)
                    } catch (e) {
                        return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", e.message), !1
                    }
                    var o = rv(t, e.form);
                    return !o || o === e
                },
                rk = function(e) {
                    var t, r, n, o, a, l, i, s = e && rc(e),
                        d = null === (t = s) || void 0 === t ? void 0 : t.host,
                        c = !1;
                    if (s && s !== e)
                        for (c = !!(null !== (r = d) && void 0 !== r && null !== (n = r.ownerDocument) && void 0 !== n && n.contains(d) || null != e && null !== (o = e.ownerDocument) && void 0 !== o && o.contains(e)); !c && d;) c = !!(null !== (l = d = null === (a = s = rc(d)) || void 0 === a ? void 0 : a.host) && void 0 !== l && null !== (i = l.ownerDocument) && void 0 !== i && i.contains(d));
                    return c
                },
                rN = function(e) {
                    var t = e.getBoundingClientRect(),
                        r = t.width,
                        n = t.height;
                    return 0 === r && 0 === n
                },
                rj = function(e, t) {
                    var r = t.displayCheck,
                        n = t.getShadowRoot;
                    if ("hidden" === getComputedStyle(e).visibility) return !0;
                    var o = rd.call(e, "details>summary:first-of-type") ? e.parentElement : e;
                    if (rd.call(o, "details:not([open]) *")) return !0;
                    if (r && "full" !== r && "legacy-full" !== r) {
                        if ("non-zero-area" === r) return rN(e)
                    } else {
                        if ("function" == typeof n) {
                            for (var a = e; e;) {
                                var l = e.parentElement,
                                    i = rc(e);
                                if (l && !l.shadowRoot && !0 === n(l)) return rN(e);
                                e = e.assignedSlot ? e.assignedSlot : l || i === e.ownerDocument ? l : i.host
                            }
                            e = a
                        }
                        if (rk(e)) return !e.getClientRects().length;
                        if ("legacy-full" !== r) return !0
                    }
                    return !1
                },
                rE = function(e) {
                    if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(e.tagName))
                        for (var t = e.parentElement; t;) {
                            if ("FIELDSET" === t.tagName && t.disabled) {
                                for (var r = 0; r < t.children.length; r++) {
                                    var n = t.children.item(r);
                                    if ("LEGEND" === n.tagName) return !!rd.call(t, "fieldset[disabled] *") || !n.contains(e)
                                }
                                return !0
                            }
                            t = t.parentElement
                        }
                    return !1
                },
                rC = function(e, t) {
                    var r, n, o;
                    return !(rx(r = t) && "radio" === r.type && !rw(r) || 0 > rh(t)) && (n = e, !((o = t).disabled || ru(o) || rx(o) && "hidden" === o.type || rj(o, n) || "DETAILS" === o.tagName && Array.prototype.slice.apply(o.children).some(function(e) {
                        return "SUMMARY" === e.tagName
                    }) || rE(o)))
                },
                rT = function(e) {
                    var t = parseInt(e.getAttribute("tabindex"), 10);
                    return !!isNaN(t) || t >= 0
                },
                rR = function e(t) {
                    var r = [],
                        n = [];
                    return t.forEach(function(t, o) {
                        var a = !!t.scopeParent,
                            l = a ? t.scopeParent : t,
                            i = rm(l, a),
                            s = a ? e(t.candidates) : l;
                        0 === i ? a ? r.push.apply(r, s) : r.push(l) : n.push({
                            documentOrder: o,
                            tabIndex: i,
                            item: t,
                            isScope: a,
                            content: s
                        })
                    }), n.sort(ry).reduce(function(e, t) {
                        return t.isScope ? e.push.apply(e, t.content) : e.push(t.content), e
                    }, []).concat(r)
                },
                rS = function(e, t) {
                    return rR((t = t || {}).getShadowRoot ? rb([e], t.includeContainer, {
                        filter: rC.bind(null, t),
                        flatten: !1,
                        getShadowRoot: t.getShadowRoot,
                        shadowRootFilter: rT
                    }) : rf(e, t.includeContainer, rC.bind(null, t)))
                };
            let rM = c["useInsertionEffect".toString()],
                rL = rM || (e => e());

            function rI(e) {
                let t = d.useRef(() => {});
                return rL(() => {
                    t.current = e
                }), d.useCallback(function() {
                    for (var e = arguments.length, r = Array(e), n = 0; n < e; n++) r[n] = arguments[n];
                    return null == t.current ? void 0 : t.current(...r)
                }, [])
            }
            let rD = "ArrowUp",
                rP = "ArrowDown",
                rz = "ArrowLeft",
                rO = "ArrowRight";

            function rA(e, t, r) {
                return Math.floor(e / t) !== r
            }

            function rF(e, t) {
                return t < 0 || t >= e.current.length
            }

            function rB(e, t) {
                return r_(e, {
                    disabledIndices: t
                })
            }

            function rW(e, t) {
                return r_(e, {
                    decrement: !0,
                    startingIndex: e.current.length,
                    disabledIndices: t
                })
            }

            function r_(e, t) {
                let {
                    startingIndex: r = -1,
                    decrement: n = !1,
                    disabledIndices: o,
                    amount: a = 1
                } = void 0 === t ? {} : t, l = e.current, i = o ? e => o.includes(e) : e => {
                    let t = l[e];
                    return null == t || t.hasAttribute("disabled") || "true" === t.getAttribute("aria-disabled")
                }, s = r;
                do s += n ? -a : a; while (s >= 0 && s <= l.length - 1 && i(s));
                return s
            }
            let rY = 0;

            function rG(e, t) {
                void 0 === t && (t = {});
                let {
                    preventScroll: r = !1,
                    cancelPrevious: n = !0,
                    sync: o = !1
                } = t;
                n && cancelAnimationFrame(rY);
                let a = () => null == e ? void 0 : e.focus({
                    preventScroll: r
                });
                o ? a() : rY = requestAnimationFrame(a)
            }
            var rH = "undefined" != typeof document ? d.useLayoutEffect : d.useEffect;

            function r$(e, t) {
                let r = e.compareDocumentPosition(t);
                return r & Node.DOCUMENT_POSITION_FOLLOWING || r & Node.DOCUMENT_POSITION_CONTAINED_BY ? -1 : r & Node.DOCUMENT_POSITION_PRECEDING || r & Node.DOCUMENT_POSITION_CONTAINS ? 1 : 0
            }
            let rU = d.createContext({
                register: () => {},
                unregister: () => {},
                map: new Map,
                elementsRef: {
                    current: []
                }
            });

            function rq(e) {
                let {
                    children: t,
                    elementsRef: r,
                    labelsRef: n
                } = e, [o, a] = d.useState(() => new Map), l = d.useCallback(e => {
                    a(t => new Map(t).set(e, null))
                }, []), i = d.useCallback(e => {
                    a(t => {
                        let r = new Map(t);
                        return r.delete(e), r
                    })
                }, []);
                return rH(() => {
                    let e = new Map(o),
                        t = Array.from(e.keys()).sort(r$);
                    t.forEach((t, r) => {
                        e.set(t, r)
                    }), ! function(e, t) {
                        if (e.size !== t.size) return !1;
                        for (let [r, n] of e.entries())
                            if (n !== t.get(r)) return !1;
                        return !0
                    }(o, e) && a(e)
                }, [o]), d.createElement(rU.Provider, {
                    value: d.useMemo(() => ({
                        register: l,
                        unregister: i,
                        map: o,
                        elementsRef: r,
                        labelsRef: n
                    }), [l, i, o, r, n])
                }, t)
            }

            function rK() {
                return (rK = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            let rV = !1,
                rX = 0,
                rZ = () => "floating-ui-" + rX++,
                rQ = c["useId".toString()],
                rJ = rQ || function() {
                    let [e, t] = d.useState(() => rV ? rZ() : void 0);
                    return rH(() => {
                        null == e && t(rZ())
                    }, []), d.useEffect(() => {
                        rV || (rV = !0)
                    }, []), e
                },
                r0 = d.createContext(null),
                r1 = d.createContext(null),
                r5 = () => {
                    var e;
                    return (null == (e = d.useContext(r0)) ? void 0 : e.id) || null
                },
                r2 = () => d.useContext(r1);

            function r4(e) {
                return "data-floating-ui-" + e
            }

            function r6(e) {
                let t = (0, d.useRef)(e);
                return rH(() => {
                    t.current = e
                }), t
            }
            let r7 = r4("safe-polygon");

            function r9(e, t, r) {
                return r && !tx(r) ? 0 : "number" == typeof e ? e : null == e ? void 0 : e[t]
            }

            function r3(e, t) {
                let r = e.filter(e => {
                        var r;
                        return e.parentId === t && (null == (r = e.context) ? void 0 : r.open)
                    }),
                    n = r;
                for (; n.length;) n = e.filter(e => {
                    var t;
                    return null == (t = n) ? void 0 : t.some(t => {
                        var r;
                        return e.parentId === t.id && (null == (r = e.context) ? void 0 : r.open)
                    })
                }), r = r.concat(n);
                return r
            }
            let r8 = new WeakMap,
                ne = new WeakSet,
                nt = {},
                nr = 0,
                nn = () => "undefined" != typeof HTMLElement && "inert" in HTMLElement.prototype,
                no = e => e && (e.host || no(e.parentNode)),
                na = (e, t) => t.map(t => {
                    if (e.contains(t)) return t;
                    let r = no(t);
                    return e.contains(r) ? r : null
                }).filter(e => null != e);

            function nl(e, t, r) {
                void 0 === t && (t = !1), void 0 === r && (r = !1);
                let n = tv(e[0]).body;
                return function(e, t, r, n) {
                    let o = "data-floating-ui-inert",
                        a = n ? "inert" : r ? "aria-hidden" : null,
                        l = na(t, e),
                        i = new Set,
                        s = new Set(l),
                        d = [];
                    nt[o] || (nt[o] = new WeakMap);
                    let c = nt[o];
                    return l.forEach(function e(t) {
                            !(!t || i.has(t)) && (i.add(t), t.parentNode && e(t.parentNode))
                        }),
                        function e(t) {
                            !t || s.has(t) || Array.prototype.forEach.call(t.children, t => {
                                if (i.has(t)) e(t);
                                else {
                                    let e = a ? t.getAttribute(a) : null,
                                        r = null !== e && "false" !== e,
                                        n = (r8.get(t) || 0) + 1,
                                        l = (c.get(t) || 0) + 1;
                                    r8.set(t, n), c.set(t, l), d.push(t), 1 === n && r && ne.add(t), 1 === l && t.setAttribute(o, ""), !r && a && t.setAttribute(a, "true")
                                }
                            })
                        }(t), i.clear(), nr++, () => {
                            d.forEach(e => {
                                let t = (r8.get(e) || 0) - 1,
                                    r = (c.get(e) || 0) - 1;
                                r8.set(e, t), c.set(e, r), t || (!ne.has(e) && a && e.removeAttribute(a), ne.delete(e)), r || e.removeAttribute(o)
                            }), --nr || (r8 = new WeakMap, r8 = new WeakMap, ne = new WeakSet, nt = {})
                        }
                }(e.concat(Array.from(n.querySelectorAll("[aria-live]"))), n, t, r)
            }
            let ni = () => ({
                getShadowRoot: !0,
                displayCheck: "function" == typeof ResizeObserver && ResizeObserver.toString().includes("[native code]") ? "full" : "none"
            });

            function ns(e, t) {
                let r = rS(e, ni());
                "prev" === t && r.reverse();
                let n = r.indexOf(tu(tv(e))),
                    o = r.slice(n + 1);
                return o[0]
            }

            function nd() {
                return ns(document.body, "next")
            }

            function nc() {
                return ns(document.body, "prev")
            }

            function nu(e, t) {
                let r = t || e.currentTarget,
                    n = e.relatedTarget;
                return !n || !tg(r, n)
            }

            function ng(e) {
                let t = rS(e, ni());
                t.forEach(e => {
                    e.dataset.tabindex = e.getAttribute("tabindex") || "", e.setAttribute("tabindex", "-1")
                })
            }

            function nf(e) {
                let t = e.querySelectorAll("[data-tabindex]");
                t.forEach(e => {
                    let t = e.dataset.tabindex;
                    delete e.dataset.tabindex, t ? e.setAttribute("tabindex", t) : e.removeAttribute("tabindex")
                })
            }
            let nb = {
                border: 0,
                clip: "rect(0 0 0 0)",
                height: "1px",
                margin: "-1px",
                overflow: "hidden",
                padding: 0,
                position: "fixed",
                whiteSpace: "nowrap",
                width: "1px",
                top: 0,
                left: 0
            };

            function np(e) {
                "Tab" === e.key && (e.target, clearTimeout(n))
            }
            let nh = d.forwardRef(function(e, t) {
                    let [r, n] = d.useState();
                    rH(() => (th() && n("button"), document.addEventListener("keydown", np), () => {
                        document.removeEventListener("keydown", np)
                    }), []);
                    let o = {
                        ref: t,
                        tabIndex: 0,
                        role: r,
                        "aria-hidden": !r || void 0,
                        [r4("focus-guard")]: "",
                        style: nb
                    };
                    return d.createElement("span", rK({}, e, o))
                }),
                nm = d.createContext(null);

            function ny(e) {
                let {
                    children: t,
                    id: r,
                    root: n = null,
                    preserveTabOrder: o = !0
                } = e, a = function(e) {
                    let {
                        id: t,
                        root: r
                    } = void 0 === e ? {} : e, [n, o] = d.useState(null), a = rJ(), l = nx(), i = d.useMemo(() => ({
                        id: t,
                        root: r,
                        portalContext: l,
                        uniqueId: a
                    }), [t, r, l, a]), s = d.useRef();
                    return rH(() => () => {
                        null == n || n.remove()
                    }, [n, i]), rH(() => {
                        if (s.current === i) return;
                        s.current = i;
                        let {
                            id: e,
                            root: t,
                            portalContext: r,
                            uniqueId: n
                        } = i, a = e ? document.getElementById(e) : null, l = r4("portal");
                        if (a) {
                            let e = document.createElement("div");
                            e.id = n, e.setAttribute(l, ""), a.appendChild(e), o(e)
                        } else {
                            let a = t || (null == r ? void 0 : r.portalNode);
                            a && !te(a) && (a = a.current), a = a || document.body;
                            let i = null;
                            e && ((i = document.createElement("div")).id = e, a.appendChild(i));
                            let s = document.createElement("div");
                            s.id = n, s.setAttribute(l, ""), (a = i || a).appendChild(s), o(s)
                        }
                    }, [i]), n
                }({
                    id: r,
                    root: n
                }), [l, i] = d.useState(null), s = d.useRef(null), c = d.useRef(null), u = d.useRef(null), g = d.useRef(null), f = !!l && !l.modal && l.open && o && !!(n || a);
                return d.useEffect(() => {
                    if (a && o && (null == l || !l.modal)) return a.addEventListener("focusin", e, !0), a.addEventListener("focusout", e, !0), () => {
                        a.removeEventListener("focusin", e, !0), a.removeEventListener("focusout", e, !0)
                    };

                    function e(e) {
                        if (a && nu(e)) {
                            let t = "focusin" === e.type;
                            (t ? nf : ng)(a)
                        }
                    }
                }, [a, o, null == l ? void 0 : l.modal]), d.createElement(nm.Provider, {
                    value: d.useMemo(() => ({
                        preserveTabOrder: o,
                        beforeOutsideRef: s,
                        afterOutsideRef: c,
                        beforeInsideRef: u,
                        afterInsideRef: g,
                        portalNode: a,
                        setFocusManagerState: i
                    }), [o, a])
                }, f && a && d.createElement(nh, {
                    "data-type": "outside",
                    ref: s,
                    onFocus: e => {
                        if (nu(e, a)) {
                            var t;
                            null == (t = u.current) || t.focus()
                        } else {
                            let e = nc() || (null == l ? void 0 : l.refs.domReference.current);
                            null == e || e.focus()
                        }
                    }
                }), f && a && d.createElement("span", {
                    "aria-owns": a.id,
                    style: nb
                }), a && (0, re.createPortal)(t, a), f && a && d.createElement(nh, {
                    "data-type": "outside",
                    ref: c,
                    onFocus: e => {
                        if (nu(e, a)) {
                            var t;
                            null == (t = g.current) || t.focus()
                        } else {
                            let t = nd() || (null == l ? void 0 : l.refs.domReference.current);
                            null == t || t.focus(), (null == l ? void 0 : l.closeOnFocusOut) && (null == l || l.onOpenChange(!1, e.nativeEvent))
                        }
                    }
                }))
            }
            let nx = () => d.useContext(nm),
                nv = [];

            function nw(e) {
                nv = nv.filter(e => e.isConnected), e && "body" !== e7(e) && (nv.push(e), nv.length > 20 && (nv = nv.slice(-20)))
            }

            function nk() {
                return nv.slice().reverse().find(e => e.isConnected)
            }
            let nN = d.forwardRef(function(e, t) {
                return d.createElement("button", rK({}, e, {
                    type: "button",
                    ref: t,
                    tabIndex: -1,
                    style: nb
                }))
            });

            function nj(e) {
                let {
                    context: t,
                    children: r,
                    disabled: n = !1,
                    order: o = ["content"],
                    guards: a = !0,
                    initialFocus: l = 0,
                    returnFocus: i = !0,
                    modal: s = !0,
                    visuallyHiddenDismiss: c = !1,
                    closeOnFocusOut: u = !0
                } = e, {
                    open: g,
                    refs: f,
                    nodeId: b,
                    onOpenChange: p,
                    events: h,
                    dataRef: m,
                    elements: {
                        domReference: y,
                        floating: x
                    }
                } = t, v = "number" == typeof l && l < 0, w = tE(y) && v, k = !nn() || a, N = r6(o), j = r6(l), E = r6(i), C = r2(), T = nx(), R = d.useRef(null), S = d.useRef(null), M = d.useRef(!1), L = d.useRef(!1), I = null != T, D = d.useCallback(function(e) {
                    return void 0 === e && (e = x), e ? rS(e, ni()) : []
                }, [x]), P = d.useCallback(e => {
                    let t = D(e);
                    return N.current.map(e => y && "reference" === e ? y : x && "floating" === e ? x : t).filter(Boolean).flat()
                }, [y, x, N, D]);

                function z(e) {
                    return !n && c && s ? d.createElement(nN, {
                        ref: "start" === e ? R : S,
                        onClick: e => p(!1, e.nativeEvent)
                    }, "string" == typeof c ? c : "Dismiss") : null
                }
                d.useEffect(() => {
                    if (n || !s) return;

                    function e(e) {
                        if ("Tab" === e.key) {
                            tg(x, tu(tv(x))) && 0 === D().length && !w && tj(e);
                            let t = P(),
                                r = tk(e);
                            "reference" === N.current[0] && r === y && (tj(e), e.shiftKey ? rG(t[t.length - 1]) : rG(t[1])), "floating" === N.current[1] && r === x && e.shiftKey && (tj(e), rG(t[0]))
                        }
                    }
                    let t = tv(x);
                    return t.addEventListener("keydown", e), () => {
                        t.removeEventListener("keydown", e)
                    }
                }, [n, y, x, s, N, f, w, D, P]), d.useEffect(() => {
                    if (!n && u && x && tt(y)) return y.addEventListener("focusout", t), y.addEventListener("pointerdown", e), s || x.addEventListener("focusout", t), () => {
                        y.removeEventListener("focusout", t), y.removeEventListener("pointerdown", e), s || x.removeEventListener("focusout", t)
                    };

                    function e() {
                        L.current = !0, setTimeout(() => {
                            L.current = !1
                        })
                    }

                    function t(e) {
                        let t = e.relatedTarget;
                        queueMicrotask(() => {
                            let r = !(tg(y, t) || tg(x, t) || tg(t, x) || tg(null == T ? void 0 : T.portalNode, t) || null != t && t.hasAttribute(r4("focus-guard")) || C && (r3(C.nodesRef.current, b).find(e => {
                                var r, n;
                                return tg(null == (r = e.context) ? void 0 : r.elements.floating, t) || tg(null == (n = e.context) ? void 0 : n.elements.domReference, t)
                            }) || (function(e, t) {
                                var r;
                                let n = [],
                                    o = null == (r = e.find(e => e.id === t)) ? void 0 : r.parentId;
                                for (; o;) {
                                    let t = e.find(e => e.id === o);
                                    o = null == t ? void 0 : t.parentId, t && (n = n.concat(t))
                                }
                                return n
                            })(C.nodesRef.current, b).find(e => {
                                var r, n;
                                return (null == (r = e.context) ? void 0 : r.elements.floating) === t || (null == (n = e.context) ? void 0 : n.elements.domReference) === t
                            })));
                            t && r && !L.current && t !== nk() && (M.current = !0, p(!1, e))
                        })
                    }
                }, [n, y, x, s, b, C, T, p, u]), d.useEffect(() => {
                    var e;
                    if (n) return;
                    let t = Array.from((null == T || null == (e = T.portalNode) ? void 0 : e.querySelectorAll("[" + r4("portal") + "]")) || []);
                    if (x) {
                        let e = [x, ...t, R.current, S.current, N.current.includes("reference") || w ? y : null].filter(e => null != e),
                            r = s || w ? nl(e, k, !k) : nl(e);
                        return () => {
                            r()
                        }
                    }
                }, [n, y, x, s, N, T, w, k]), rH(() => {
                    if (n || !x) return;
                    let e = tv(x),
                        t = tu(e);
                    queueMicrotask(() => {
                        let e = P(x),
                            r = j.current,
                            n = ("number" == typeof r ? e[r] : r.current) || x,
                            o = tg(x, t);
                        v || o || !g || rG(n, {
                            preventScroll: n === x
                        })
                    })
                }, [n, g, x, v, P, j]), rH(() => {
                    if (n || !x) return;
                    let e = !1,
                        t = tv(x),
                        r = tu(t),
                        o = m.current;

                    function a(t) {
                        let {
                            reason: r,
                            event: n,
                            nested: o
                        } = t;
                        "escape-key" === r && f.domReference.current && nw(f.domReference.current), "hover" === r && "mouseleave" === n.type && (M.current = !0), "outside-press" === r && (o ? (M.current = !1, e = !0) : M.current = !(tb(n) || tp(n)))
                    }
                    return nw(r), h.on("openchange", a), () => {
                        h.off("openchange", a);
                        let r = tu(t),
                            n = tg(x, r) || C && r3(C.nodesRef.current, b).some(e => {
                                var t;
                                return tg(null == (t = e.context) ? void 0 : t.elements.floating, r)
                            }),
                            l = n || o.openEvent && ["click", "mousedown"].includes(o.openEvent.type);
                        l && f.domReference.current && nw(f.domReference.current);
                        let i = nk();
                        E.current && !M.current && tt(i) && (i === r || r === t.body || n) && rG(i, {
                            cancelPrevious: !1,
                            preventScroll: e
                        })
                    }
                }, [n, x, E, m, f, h, C, b]), rH(() => {
                    if (!n && T) return T.setFocusManagerState({
                        modal: s,
                        closeOnFocusOut: u,
                        open: g,
                        onOpenChange: p,
                        refs: f
                    }), () => {
                        T.setFocusManagerState(null)
                    }
                }, [n, T, s, g, p, f, u]), rH(() => {
                    if (n || !x || "function" != typeof MutationObserver || v) return;
                    let e = () => {
                        let e = x.getAttribute("tabindex");
                        N.current.includes("floating") || tu(tv(x)) !== f.domReference.current && 0 === D().length ? "0" !== e && x.setAttribute("tabindex", "0") : "-1" !== e && x.setAttribute("tabindex", "-1")
                    };
                    e();
                    let t = new MutationObserver(e);
                    return t.observe(x, {
                        childList: !0,
                        subtree: !0,
                        attributes: !0
                    }), () => {
                        t.disconnect()
                    }
                }, [n, x, f, N, D, v]);
                let O = !n && k && (I || s);
                return d.createElement(d.Fragment, null, O && d.createElement(nh, {
                    "data-type": "inside",
                    ref: null == T ? void 0 : T.beforeInsideRef,
                    onFocus: e => {
                        if (s) {
                            let e = P();
                            rG("reference" === o[0] ? e[0] : e[e.length - 1])
                        } else if (null != T && T.preserveTabOrder && T.portalNode) {
                            if (M.current = !1, nu(e, T.portalNode)) {
                                let e = nd() || y;
                                null == e || e.focus()
                            } else {
                                var t;
                                null == (t = T.beforeOutsideRef.current) || t.focus()
                            }
                        }
                    }
                }), !w && z("start"), r, z("end"), O && d.createElement(nh, {
                    "data-type": "inside",
                    ref: null == T ? void 0 : T.afterInsideRef,
                    onFocus: e => {
                        if (s) rG(P()[0]);
                        else if (null != T && T.preserveTabOrder && T.portalNode) {
                            if (u && (M.current = !0), nu(e, T.portalNode)) {
                                let e = nc() || y;
                                null == e || e.focus()
                            } else {
                                var t;
                                null == (t = T.afterOutsideRef.current) || t.focus()
                            }
                        }
                    }
                }))
            }
            let nE = new Set,
                nC = d.forwardRef(function(e, t) {
                    let {
                        lockScroll: r = !1,
                        ...n
                    } = e, o = rJ();
                    return rH(() => {
                        if (!r) return;
                        nE.add(o);
                        let e = /iP(hone|ad|od)|iOS/.test(tf()),
                            t = document.body.style,
                            n = Math.round(document.documentElement.getBoundingClientRect().left) + document.documentElement.scrollLeft,
                            a = n ? "paddingLeft" : "paddingRight",
                            l = window.innerWidth - document.documentElement.clientWidth,
                            i = t.left ? parseFloat(t.left) : window.pageXOffset,
                            s = t.top ? parseFloat(t.top) : window.pageYOffset;
                        if (t.overflow = "hidden", l && (t[a] = l + "px"), e) {
                            var d, c;
                            let e = (null == (d = window.visualViewport) ? void 0 : d.offsetLeft) || 0,
                                r = (null == (c = window.visualViewport) ? void 0 : c.offsetTop) || 0;
                            Object.assign(t, {
                                position: "fixed",
                                top: -(s - Math.floor(r)) + "px",
                                left: -(i - Math.floor(e)) + "px",
                                right: "0"
                            })
                        }
                        return () => {
                            nE.delete(o), 0 === nE.size && (Object.assign(t, {
                                overflow: "",
                                [a]: ""
                            }), e && (Object.assign(t, {
                                position: "",
                                top: "",
                                left: "",
                                right: ""
                            }), window.scrollTo(i, s)))
                        }
                    }, [o, r]), d.createElement("div", rK({
                        ref: t
                    }, n, {
                        style: {
                            position: "fixed",
                            overflow: "auto",
                            top: 0,
                            right: 0,
                            bottom: 0,
                            left: 0,
                            ...n.style
                        }
                    }))
                });

            function nT(e) {
                return tt(e.target) && "BUTTON" === e.target.tagName
            }

            function nR(e, t) {
                void 0 === t && (t = {});
                let {
                    open: r,
                    onOpenChange: n,
                    dataRef: o,
                    elements: {
                        domReference: a
                    }
                } = e, {
                    enabled: l = !0,
                    event: i = "click",
                    toggle: s = !0,
                    ignoreMouse: c = !1,
                    keyboardHandlers: u = !0
                } = t, g = d.useRef(), f = d.useRef(!1);
                return d.useMemo(() => l ? {
                    reference: {
                        onPointerDown(e) {
                            g.current = e.pointerType
                        },
                        onMouseDown(e) {
                            0 !== e.button || tx(g.current, !0) && c || "click" === i || (r && s && (!o.current.openEvent || "mousedown" === o.current.openEvent.type) ? n(!1, e.nativeEvent, "click") : (e.preventDefault(), n(!0, e.nativeEvent, "click")))
                        },
                        onClick(e) {
                            if ("mousedown" === i && g.current) {
                                g.current = void 0;
                                return
                            }
                            tx(g.current, !0) && c || (r && s && (!o.current.openEvent || "click" === o.current.openEvent.type) ? n(!1, e.nativeEvent, "click") : n(!0, e.nativeEvent, "click"))
                        },
                        onKeyDown(e) {
                            g.current = void 0, e.defaultPrevented || !u || nT(e) || (" " !== e.key || tN(a) || (e.preventDefault(), f.current = !0), "Enter" === e.key && (r && s ? n(!1, e.nativeEvent, "click") : n(!0, e.nativeEvent, "click")))
                        },
                        onKeyUp(e) {
                            !(e.defaultPrevented || !u || nT(e) || tN(a)) && " " === e.key && f.current && (f.current = !1, r && s ? n(!1, e.nativeEvent, "click") : n(!0, e.nativeEvent, "click"))
                        }
                    }
                } : {}, [l, o, i, c, u, a, s, r, n])
            }
            let nS = {
                    pointerdown: "onPointerDown",
                    mousedown: "onMouseDown",
                    click: "onClick"
                },
                nM = {
                    pointerdown: "onPointerDownCapture",
                    mousedown: "onMouseDownCapture",
                    click: "onClickCapture"
                },
                nL = e => {
                    var t, r;
                    return {
                        escapeKey: "boolean" == typeof e ? e : null != (t = null == e ? void 0 : e.escapeKey) && t,
                        outsidePress: "boolean" == typeof e ? e : null == (r = null == e ? void 0 : e.outsidePress) || r
                    }
                };

            function nI(e, t) {
                void 0 === t && (t = {});
                let {
                    open: r,
                    onOpenChange: n,
                    nodeId: o,
                    elements: {
                        reference: a,
                        domReference: l,
                        floating: i
                    },
                    dataRef: s
                } = e, {
                    enabled: c = !0,
                    escapeKey: u = !0,
                    outsidePress: g = !0,
                    outsidePressEvent: f = "pointerdown",
                    referencePress: b = !1,
                    referencePressEvent: p = "pointerdown",
                    ancestorScroll: h = !1,
                    bubbles: m,
                    capture: y
                } = t, x = r2(), v = rI("function" == typeof g ? g : () => !1), w = "function" == typeof g ? v : g, k = d.useRef(!1), N = d.useRef(!1), {
                    escapeKey: j,
                    outsidePress: E
                } = nL(m), {
                    escapeKey: C,
                    outsidePress: T
                } = nL(y), R = rI(e => {
                    if (!r || !c || !u || "Escape" !== e.key) return;
                    let t = x ? r3(x.nodesRef.current, o) : [];
                    if (!j && (e.stopPropagation(), t.length > 0)) {
                        let e = !0;
                        if (t.forEach(t => {
                                var r;
                                if (null != (r = t.context) && r.open && !t.context.dataRef.current.__escapeKeyBubbles) {
                                    e = !1;
                                    return
                                }
                            }), !e) return
                    }
                    n(!1, "nativeEvent" in e ? e.nativeEvent : e, "escape-key")
                }), S = rI(e => {
                    var t;
                    let r = () => {
                        var t;
                        R(e), null == (t = tk(e)) || t.removeEventListener("keydown", r)
                    };
                    null == (t = tk(e)) || t.addEventListener("keydown", r)
                }), M = rI(e => {
                    let t = k.current;
                    k.current = !1;
                    let r = N.current;
                    if (N.current = !1, "click" === f && r || t || "function" == typeof w && !w(e)) return;
                    let a = tk(e),
                        s = "[" + r4("inert") + "]",
                        d = tv(i).querySelectorAll(s),
                        c = te(a) ? a : null;
                    for (; c && !tl(c);) {
                        let e = td(c);
                        if (tl(e) || !te(e)) break;
                        c = e
                    }
                    if (d.length && te(a) && !a.matches("html,body") && !tg(a, i) && Array.from(d).every(e => !tg(c, e))) return;
                    if (tt(a) && i) {
                        let t = a.clientWidth > 0 && a.scrollWidth > a.clientWidth,
                            r = a.clientHeight > 0 && a.scrollHeight > a.clientHeight,
                            n = r && e.offsetX > a.clientWidth;
                        if (r) {
                            let t = "rtl" === ti(a).direction;
                            t && (n = e.offsetX <= a.offsetWidth - a.clientWidth)
                        }
                        if (n || t && e.offsetY > a.clientHeight) return
                    }
                    let u = x && r3(x.nodesRef.current, o).some(t => {
                        var r;
                        return tw(e, null == (r = t.context) ? void 0 : r.elements.floating)
                    });
                    if (tw(e, i) || tw(e, l) || u) return;
                    let g = x ? r3(x.nodesRef.current, o) : [];
                    if (g.length > 0) {
                        let e = !0;
                        if (g.forEach(t => {
                                var r;
                                if (null != (r = t.context) && r.open && !t.context.dataRef.current.__outsidePressBubbles) {
                                    e = !1;
                                    return
                                }
                            }), !e) return
                    }
                    n(!1, e, "outside-press")
                }), L = rI(e => {
                    var t;
                    let r = () => {
                        var t;
                        M(e), null == (t = tk(e)) || t.removeEventListener(f, r)
                    };
                    null == (t = tk(e)) || t.addEventListener(f, r)
                });
                return d.useEffect(() => {
                    if (!r || !c) return;

                    function e(e) {
                        n(!1, e, "ancestor-scroll")
                    }
                    s.current.__escapeKeyBubbles = j, s.current.__outsidePressBubbles = E;
                    let t = tv(i);
                    u && t.addEventListener("keydown", C ? S : R, C), w && t.addEventListener(f, T ? L : M, T);
                    let o = [];
                    return h && (te(l) && (o = tc(l)), te(i) && (o = o.concat(tc(i))), !te(a) && a && a.contextElement && (o = o.concat(tc(a.contextElement)))), (o = o.filter(e => {
                        var r;
                        return e !== (null == (r = t.defaultView) ? void 0 : r.visualViewport)
                    })).forEach(t => {
                        t.addEventListener("scroll", e, {
                            passive: !0
                        })
                    }), () => {
                        u && t.removeEventListener("keydown", C ? S : R, C), w && t.removeEventListener(f, T ? L : M, T), o.forEach(t => {
                            t.removeEventListener("scroll", e)
                        })
                    }
                }, [s, i, l, a, u, w, f, r, n, h, c, j, E, R, C, S, M, T, L]), d.useEffect(() => {
                    k.current = !1
                }, [w, f]), d.useMemo(() => c ? {
                    reference: {
                        onKeyDown: R,
                        [nS[p]]: e => {
                            b && n(!1, e.nativeEvent, "reference-press")
                        }
                    },
                    floating: {
                        onKeyDown: R,
                        onMouseDown() {
                            N.current = !0
                        },
                        onMouseUp() {
                            N.current = !0
                        },
                        [nM[f]]: () => {
                            k.current = !0
                        }
                    }
                } : {}, [c, b, f, p, n, R])
            }

            function nD(e) {
                var t;
                void 0 === e && (e = {});
                let {
                    open: r = !1,
                    onOpenChange: n,
                    nodeId: o
                } = e, [a, l] = d.useState(null), i = (null == (t = e.elements) ? void 0 : t.reference) || a, s = function(e) {
                    void 0 === e && (e = {});
                    let {
                        placement: t = "bottom",
                        strategy: r = "absolute",
                        middleware: n = [],
                        platform: o,
                        elements: {
                            reference: a,
                            floating: l
                        } = {},
                        transform: i = !0,
                        whileElementsMounted: s,
                        open: c
                    } = e, [u, g] = d.useState({
                        x: 0,
                        y: 0,
                        strategy: r,
                        placement: t,
                        middlewareData: {},
                        isPositioned: !1
                    }), [f, b] = d.useState(n);
                    rn(f, n) || b(n);
                    let [p, h] = d.useState(null), [m, y] = d.useState(null), x = d.useCallback(e => {
                        e != N.current && (N.current = e, h(e))
                    }, [h]), v = d.useCallback(e => {
                        e !== j.current && (j.current = e, y(e))
                    }, [y]), w = a || p, k = l || m, N = d.useRef(null), j = d.useRef(null), E = d.useRef(u), C = rl(s), T = rl(o), R = d.useCallback(() => {
                        if (!N.current || !j.current) return;
                        let e = {
                            placement: t,
                            strategy: r,
                            middleware: f
                        };
                        T.current && (e.platform = T.current), t8(N.current, j.current, e).then(e => {
                            let t = { ...e,
                                isPositioned: !0
                            };
                            S.current && !rn(E.current, t) && (E.current = t, re.flushSync(() => {
                                g(t)
                            }))
                        })
                    }, [f, t, r, T]);
                    rr(() => {
                        !1 === c && E.current.isPositioned && (E.current.isPositioned = !1, g(e => ({ ...e,
                            isPositioned: !1
                        })))
                    }, [c]);
                    let S = d.useRef(!1);
                    rr(() => (S.current = !0, () => {
                        S.current = !1
                    }), []), rr(() => {
                        if (w && (N.current = w), k && (j.current = k), w && k) {
                            if (C.current) return C.current(w, k, R);
                            R()
                        }
                    }, [w, k, R, C]);
                    let M = d.useMemo(() => ({
                            reference: N,
                            floating: j,
                            setReference: x,
                            setFloating: v
                        }), [x, v]),
                        L = d.useMemo(() => ({
                            reference: w,
                            floating: k
                        }), [w, k]),
                        I = d.useMemo(() => {
                            let e = {
                                position: r,
                                left: 0,
                                top: 0
                            };
                            if (!L.floating) return e;
                            let t = ra(L.floating, u.x),
                                n = ra(L.floating, u.y);
                            return i ? { ...e,
                                transform: "translate(" + t + "px, " + n + "px)",
                                ...ro(L.floating) >= 1.5 && {
                                    willChange: "transform"
                                }
                            } : {
                                position: r,
                                left: t,
                                top: n
                            }
                        }, [r, i, L.floating, u.x, u.y]);
                    return d.useMemo(() => ({ ...u,
                        update: R,
                        refs: M,
                        elements: L,
                        floatingStyles: I
                    }), [u, R, M, L, I])
                }(e), c = r2(), u = null != r5(), g = rI((e, t, r) => {
                    e && (b.current.openEvent = t), p.emit("openchange", {
                        open: e,
                        event: t,
                        reason: r,
                        nested: u
                    }), null == n || n(e, t, r)
                }), f = d.useRef(null), b = d.useRef({}), p = d.useState(() => (function() {
                    let e = new Map;
                    return {
                        emit(t, r) {
                            var n;
                            null == (n = e.get(t)) || n.forEach(e => e(r))
                        },
                        on(t, r) {
                            e.set(t, [...e.get(t) || [], r])
                        },
                        off(t, r) {
                            var n;
                            e.set(t, (null == (n = e.get(t)) ? void 0 : n.filter(e => e !== r)) || [])
                        }
                    }
                })())[0], h = rJ(), m = d.useCallback(e => {
                    let t = te(e) ? {
                        getBoundingClientRect: () => e.getBoundingClientRect(),
                        contextElement: e
                    } : e;
                    s.refs.setReference(t)
                }, [s.refs]), y = d.useCallback(e => {
                    (te(e) || null === e) && (f.current = e, l(e)), (te(s.refs.reference.current) || null === s.refs.reference.current || null !== e && !te(e)) && s.refs.setReference(e)
                }, [s.refs]), x = d.useMemo(() => ({ ...s.refs,
                    setReference: y,
                    setPositionReference: m,
                    domReference: f
                }), [s.refs, y, m]), v = d.useMemo(() => ({ ...s.elements,
                    domReference: i
                }), [s.elements, i]), w = d.useMemo(() => ({ ...s,
                    refs: x,
                    elements: v,
                    dataRef: b,
                    nodeId: o,
                    floatingId: h,
                    events: p,
                    open: r,
                    onOpenChange: g
                }), [s, o, h, p, r, g, x, v]);
                return rH(() => {
                    let e = null == c ? void 0 : c.nodesRef.current.find(e => e.id === o);
                    e && (e.context = w)
                }), d.useMemo(() => ({ ...s,
                    context: w,
                    refs: x,
                    elements: v
                }), [s, x, v, w])
            }
            let nP = "active",
                nz = "selected";

            function nO(e, t, r) {
                let n = new Map,
                    o = "item" === r,
                    a = e;
                if (o && e) {
                    let {
                        [nP]: t, [nz]: r, ...n
                    } = e;
                    a = n
                }
                return { ..."floating" === r && {
                        tabIndex: -1
                    },
                    ...a,
                    ...t.map(t => {
                        let n = t ? t[r] : null;
                        return "function" == typeof n ? e ? n(e) : null : n
                    }).concat(e).reduce((e, t) => (t && Object.entries(t).forEach(t => {
                        let [r, a] = t;
                        if (!(o && [nP, nz].includes(r))) {
                            if (0 === r.indexOf("on")) {
                                if (n.has(r) || n.set(r, []), "function" == typeof a) {
                                    var l;
                                    null == (l = n.get(r)) || l.push(a), e[r] = function() {
                                        for (var e, t = arguments.length, o = Array(t), a = 0; a < t; a++) o[a] = arguments[a];
                                        return null == (e = n.get(r)) ? void 0 : e.map(e => e(...o)).find(e => void 0 !== e)
                                    }
                                }
                            } else e[r] = a
                        }
                    }), e), {})
                }
            }

            function nA(e) {
                void 0 === e && (e = []);
                let t = e,
                    r = d.useCallback(t => nO(t, e, "reference"), t),
                    n = d.useCallback(t => nO(t, e, "floating"), t),
                    o = d.useCallback(t => nO(t, e, "item"), e.map(e => null == e ? void 0 : e.item));
                return d.useMemo(() => ({
                    getReferenceProps: r,
                    getFloatingProps: n,
                    getItemProps: o
                }), [r, n, o])
            }
            let nF = !1;

            function nB(e, t, r) {
                switch (e) {
                    case "vertical":
                        return t;
                    case "horizontal":
                        return r;
                    default:
                        return t || r
                }
            }

            function nW(e, t) {
                return nB(t, e === rD || e === rP, e === rz || e === rO)
            }

            function n_(e, t, r) {
                return nB(t, e === rP, r ? e === rz : e === rO) || "Enter" === e || " " == e || "" === e
            }

            function nY(e, t, r) {
                return nB(t, r ? e === rO : e === rz, e === rD)
            }
            let nG = new Map([
                ["select", "listbox"],
                ["combobox", "listbox"],
                ["label", !1]
            ]);

            function nH(e, t) {
                var r;
                void 0 === t && (t = {});
                let {
                    open: n,
                    floatingId: o
                } = e, {
                    enabled: a = !0,
                    role: l = "dialog"
                } = t, i = null != (r = nG.get(l)) ? r : l, s = rJ(), c = r5(), u = null != c;
                return d.useMemo(() => {
                    if (!a) return {};
                    let e = {
                        id: o,
                        ...i && {
                            role: i
                        }
                    };
                    return "tooltip" === i || "label" === l ? {
                        reference: {
                            ["aria-" + ("label" === l ? "labelledby" : "describedby")]: n ? o : void 0
                        },
                        floating: e
                    } : {
                        reference: {
                            "aria-expanded": n ? "true" : "false",
                            "aria-haspopup": "alertdialog" === i ? "dialog" : i,
                            "aria-controls": n ? o : void 0,
                            ..."listbox" === i && {
                                role: "combobox"
                            },
                            ..."menu" === i && {
                                id: s
                            },
                            ..."menu" === i && u && {
                                role: "menuitem"
                            },
                            ..."select" === l && {
                                "aria-autocomplete": "none"
                            },
                            ..."combobox" === l && {
                                "aria-autocomplete": "list"
                            }
                        },
                        floating: { ...e,
                            ..."menu" === i && {
                                "aria-labelledby": s
                            }
                        },
                        item(e) {
                            let {
                                active: t,
                                selected: r
                            } = e, n = {
                                role: "option",
                                ...t && {
                                    id: o + "-option"
                                }
                            };
                            switch (l) {
                                case "select":
                                    return { ...n,
                                        "aria-selected": t && r
                                    };
                                case "combobox":
                                    return { ...n,
                                        ...t && {
                                            "aria-selected": !0
                                        }
                                    }
                            }
                            return {}
                        }
                    }
                }, [a, l, i, n, o, s, u])
            }

            function n$(e, t) {
                let [r, n] = e, o = !1, a = t.length;
                for (let e = 0, l = a - 1; e < a; l = e++) {
                    let [a, i] = t[e] || [0, 0], [s, d] = t[l] || [0, 0], c = i >= n != d >= n && r <= (s - a) * (n - i) / (d - i) + a;
                    c && (o = !o)
                }
                return o
            }
            let nU = ({
                    arrowRef: e,
                    placement: t
                }) => {
                    var r, n, o;
                    let a = [];
                    return a.push({
                        name: "offset",
                        options: 8,
                        async fn(e) {
                            var t, r;
                            let {
                                x: n,
                                y: o,
                                placement: a,
                                middlewareData: l
                            } = e, i = await tV(e, 8);
                            return a === (null == (t = l.offset) ? void 0 : t.placement) && null != (r = l.arrow) && r.alignmentOffset ? {} : {
                                x: n + i.x,
                                y: o + i.y,
                                data: { ...i,
                                    placement: a
                                }
                            }
                        }
                    }), a.push("auto" === t ? (void 0 === r && (r = {}), {
                        name: "autoPlacement",
                        options: r,
                        async fn(e) {
                            var t, n, o;
                            let {
                                rects: a,
                                middlewareData: l,
                                placement: i,
                                platform: s,
                                elements: d
                            } = e, {
                                crossAxis: c = !1,
                                alignment: u,
                                allowedPlacements: g = tC,
                                autoAlignment: f = !0,
                                ...b
                            } = tP(r, e), p = void 0 !== u || g === tC ? function(e, t, r) {
                                let n = e ? [...r.filter(t => tO(t) === e), ...r.filter(t => tO(t) !== e)] : r.filter(e => tz(e) === e);
                                return n.filter(r => !e || tO(r) === e || !!t && t_(r) !== r)
                            }(u || null, f, g) : g, h = await tq(e, b), m = (null == (t = l.autoPlacement) ? void 0 : t.index) || 0, y = p[m];
                            if (null == y) return {};
                            let x = tW(y, a, await (null == s.isRTL ? void 0 : s.isRTL(d.floating)));
                            if (i !== y) return {
                                reset: {
                                    placement: p[0]
                                }
                            };
                            let v = [h[tz(y)], h[x[0]], h[x[1]]],
                                w = [...(null == (n = l.autoPlacement) ? void 0 : n.overflows) || [], {
                                    placement: y,
                                    overflows: v
                                }],
                                k = p[m + 1];
                            if (k) return {
                                data: {
                                    index: m + 1,
                                    overflows: w
                                },
                                reset: {
                                    placement: k
                                }
                            };
                            let N = w.map(e => {
                                    let t = tO(e.placement);
                                    return [e.placement, t && c ? e.overflows.slice(0, 2).reduce((e, t) => e + t, 0) : e.overflows[0], e.overflows]
                                }).sort((e, t) => e[1] - t[1]),
                                j = N.filter(e => e[2].slice(0, tO(e[0]) ? 2 : 3).every(e => e <= 0)),
                                E = (null == (o = j[0]) ? void 0 : o[0]) || N[0][0];
                            return E !== i ? {
                                data: {
                                    index: m + 1,
                                    overflows: w
                                },
                                reset: {
                                    placement: E
                                }
                            } : {}
                        }
                    }) : (void 0 === n && (n = {}), {
                        name: "flip",
                        options: n,
                        async fn(e) {
                            var t, r, o, a, l;
                            let {
                                placement: i,
                                middlewareData: s,
                                rects: d,
                                initialPlacement: c,
                                platform: u,
                                elements: g
                            } = e, {
                                mainAxis: f = !0,
                                crossAxis: b = !0,
                                fallbackPlacements: p,
                                fallbackStrategy: h = "bestFit",
                                fallbackAxisSideDirection: m = "none",
                                flipAlignment: y = !0,
                                ...x
                            } = tP(n, e);
                            if (null != (t = s.arrow) && t.alignmentOffset) return {};
                            let v = tz(i),
                                w = tz(c) === c,
                                k = await (null == u.isRTL ? void 0 : u.isRTL(g.floating)),
                                N = p || (w || !y ? [tY(c)] : function(e) {
                                    let t = tY(e);
                                    return [t_(e), t, t_(t)]
                                }(c));
                            p || "none" === m || N.push(... function(e, t, r, n) {
                                let o = tO(e),
                                    a = function(e, t, r) {
                                        let n = ["left", "right"],
                                            o = ["right", "left"];
                                        switch (e) {
                                            case "top":
                                            case "bottom":
                                                if (r) return t ? o : n;
                                                return t ? n : o;
                                            case "left":
                                            case "right":
                                                return t ? ["top", "bottom"] : ["bottom", "top"];
                                            default:
                                                return []
                                        }
                                    }(tz(e), "start" === r, n);
                                return o && (a = a.map(e => e + "-" + o), t && (a = a.concat(a.map(t_)))), a
                            }(c, y, m, k));
                            let j = [c, ...N],
                                E = await tq(e, x),
                                C = [],
                                T = (null == (r = s.flip) ? void 0 : r.overflows) || [];
                            if (f && C.push(E[v]), b) {
                                let e = tW(i, d, k);
                                C.push(E[e[0]], E[e[1]])
                            }
                            if (T = [...T, {
                                    placement: i,
                                    overflows: C
                                }], !C.every(e => e <= 0)) {
                                let e = ((null == (o = s.flip) ? void 0 : o.index) || 0) + 1,
                                    t = j[e];
                                if (t) return {
                                    data: {
                                        index: e,
                                        overflows: T
                                    },
                                    reset: {
                                        placement: t
                                    }
                                };
                                let r = null == (a = T.filter(e => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]) ? void 0 : a.placement;
                                if (!r) switch (h) {
                                    case "bestFit":
                                        {
                                            let e = null == (l = T.map(e => [e.placement, e.overflows.filter(e => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]) ? void 0 : l[0];e && (r = e);
                                            break
                                        }
                                    case "initialPlacement":
                                        r = c
                                }
                                if (i !== r) return {
                                    reset: {
                                        placement: r
                                    }
                                }
                            }
                            return {}
                        }
                    })), a.push({
                        name: "shift",
                        options: o = {
                            padding: 8
                        },
                        async fn(e) {
                            let {
                                x: t,
                                y: r,
                                placement: n
                            } = e, {
                                mainAxis: a = !0,
                                crossAxis: l = !1,
                                limiter: i = {
                                    fn: e => {
                                        let {
                                            x: t,
                                            y: r
                                        } = e;
                                        return {
                                            x: t,
                                            y: r
                                        }
                                    }
                                },
                                ...s
                            } = tP(o, e), d = {
                                x: t,
                                y: r
                            }, c = await tq(e, s), u = tB(tz(n)), g = tA(u), f = d[g], b = d[u];
                            if (a) {
                                let e = f + c["y" === g ? "top" : "left"],
                                    t = f - c["y" === g ? "bottom" : "right"];
                                f = tR(e, tT(f, t))
                            }
                            if (l) {
                                let e = "y" === u ? "top" : "left",
                                    t = "y" === u ? "bottom" : "right",
                                    r = b + c[e],
                                    n = b - c[t];
                                b = tR(r, tT(b, n))
                            }
                            let p = i.fn({ ...e,
                                [g]: f,
                                [u]: b
                            });
                            return { ...p,
                                data: {
                                    x: p.x - t,
                                    y: p.y - r
                                }
                            }
                        }
                    }), e ? .current && a.push(rt({
                        element: e.current
                    })), a
                },
                nq = ({
                    placement: e
                }) => "auto" === e ? void 0 : e,
                nK = ({
                    placement: e
                }) => ({
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                })[e.split("-")[0]],
                nV = ({
                    open: e,
                    arrowRef: t,
                    placement: r = "top",
                    setOpen: n
                }) => nD({
                    placement: nq({
                        placement: r
                    }),
                    open: e,
                    onOpenChange: n,
                    whileElementsMounted: t3,
                    middleware: nU({
                        placement: r,
                        arrowRef: t
                    })
                }),
                nX = ({
                    context: e,
                    trigger: t,
                    role: r = "tooltip",
                    interactions: n = []
                }) => nA([nR(e, {
                    enabled: "click" === t
                }), function(e, t) {
                    void 0 === t && (t = {});
                    let {
                        open: r,
                        onOpenChange: n,
                        dataRef: o,
                        events: a,
                        elements: {
                            domReference: l,
                            floating: i
                        },
                        refs: s
                    } = e, {
                        enabled: c = !0,
                        delay: u = 0,
                        handleClose: g = null,
                        mouseOnly: f = !1,
                        restMs: b = 0,
                        move: p = !0
                    } = t, h = r2(), m = r5(), y = r6(g), x = r6(u), v = d.useRef(), w = d.useRef(), k = d.useRef(), N = d.useRef(), j = d.useRef(!0), E = d.useRef(!1), C = d.useRef(() => {}), T = d.useCallback(() => {
                        var e;
                        let t = null == (e = o.current.openEvent) ? void 0 : e.type;
                        return (null == t ? void 0 : t.includes("mouse")) && "mousedown" !== t
                    }, [o]);
                    d.useEffect(() => {
                        if (c) return a.on("openchange", e), () => {
                            a.off("openchange", e)
                        };

                        function e(e) {
                            let {
                                open: t
                            } = e;
                            t || (clearTimeout(w.current), clearTimeout(N.current), j.current = !0)
                        }
                    }, [c, a]), d.useEffect(() => {
                        if (!c || !y.current || !r) return;

                        function e(e) {
                            T() && n(!1, e, "hover")
                        }
                        let t = tv(i).documentElement;
                        return t.addEventListener("mouseleave", e), () => {
                            t.removeEventListener("mouseleave", e)
                        }
                    }, [i, r, n, c, y, o, T]);
                    let R = d.useCallback(function(e, t, r) {
                            void 0 === t && (t = !0), void 0 === r && (r = "hover");
                            let o = r9(x.current, "close", v.current);
                            o && !k.current ? (clearTimeout(w.current), w.current = setTimeout(() => n(!1, e, r), o)) : t && (clearTimeout(w.current), n(!1, e, r))
                        }, [x, n]),
                        S = d.useCallback(() => {
                            C.current(), k.current = void 0
                        }, []),
                        M = d.useCallback(() => {
                            if (E.current) {
                                let e = tv(s.floating.current).body;
                                e.style.pointerEvents = "", e.removeAttribute(r7), E.current = !1
                            }
                        }, [s]);
                    return d.useEffect(() => {
                        if (c && te(l)) return r && l.addEventListener("mouseleave", d), null == i || i.addEventListener("mouseleave", d), p && l.addEventListener("mousemove", a, {
                            once: !0
                        }), l.addEventListener("mouseenter", a), l.addEventListener("mouseleave", s), () => {
                            r && l.removeEventListener("mouseleave", d), null == i || i.removeEventListener("mouseleave", d), p && l.removeEventListener("mousemove", a), l.removeEventListener("mouseenter", a), l.removeEventListener("mouseleave", s)
                        };

                        function t() {
                            return !!o.current.openEvent && ["click", "mousedown"].includes(o.current.openEvent.type)
                        }

                        function a(e) {
                            if (clearTimeout(w.current), j.current = !1, f && !tx(v.current) || b > 0 && 0 === r9(x.current, "open")) return;
                            let t = r9(x.current, "open", v.current);
                            t ? w.current = setTimeout(() => {
                                n(!0, e, "hover")
                            }, t) : n(!0, e, "hover")
                        }

                        function s(n) {
                            if (t()) return;
                            C.current();
                            let o = tv(i);
                            if (clearTimeout(N.current), y.current) {
                                r || clearTimeout(w.current), k.current = y.current({ ...e,
                                    tree: h,
                                    x: n.clientX,
                                    y: n.clientY,
                                    onClose() {
                                        M(), S(), R(n, !0, "safe-polygon")
                                    }
                                });
                                let t = k.current;
                                o.addEventListener("mousemove", t), C.current = () => {
                                    o.removeEventListener("mousemove", t)
                                };
                                return
                            }
                            let a = "touch" !== v.current || !tg(i, n.relatedTarget);
                            a && R(n)
                        }

                        function d(r) {
                            t() || null == y.current || y.current({ ...e,
                                tree: h,
                                x: r.clientX,
                                y: r.clientY,
                                onClose() {
                                    M(), S(), R(r)
                                }
                            })(r)
                        }
                    }, [l, i, c, e, f, b, p, R, S, M, n, r, h, x, y, o]), rH(() => {
                        var e, t;
                        if (c && r && null != (e = y.current) && e.__options.blockPointerEvents && T()) {
                            let e = tv(i).body;
                            if (e.setAttribute(r7, ""), e.style.pointerEvents = "none", E.current = !0, te(l) && i) {
                                let e = null == h || null == (t = h.nodesRef.current.find(e => e.id === m)) || null == (t = t.context) ? void 0 : t.elements.floating;
                                return e && (e.style.pointerEvents = ""), l.style.pointerEvents = "auto", i.style.pointerEvents = "auto", () => {
                                    l.style.pointerEvents = "", i.style.pointerEvents = ""
                                }
                            }
                        }
                    }, [c, r, m, i, l, h, y, o, T]), rH(() => {
                        r || (v.current = void 0, S(), M())
                    }, [r, S, M]), d.useEffect(() => () => {
                        S(), clearTimeout(w.current), clearTimeout(N.current), M()
                    }, [c, l, S, M]), d.useMemo(() => {
                        if (!c) return {};

                        function e(e) {
                            v.current = e.pointerType
                        }
                        return {
                            reference: {
                                onPointerDown: e,
                                onPointerEnter: e,
                                onMouseMove(e) {
                                    r || 0 === b || (clearTimeout(N.current), N.current = setTimeout(() => {
                                        j.current || n(!0, e.nativeEvent, "hover")
                                    }, b))
                                }
                            },
                            floating: {
                                onMouseEnter() {
                                    clearTimeout(w.current)
                                },
                                onMouseLeave(e) {
                                    R(e.nativeEvent, !1)
                                }
                            }
                        }
                    }, [c, b, r, n, R])
                }(e, {
                    enabled: "hover" === t,
                    handleClose: function(e) {
                        let t;
                        void 0 === e && (e = {});
                        let {
                            buffer: r = .5,
                            blockPointerEvents: n = !1,
                            requireIntent: o = !0
                        } = e, a = !1, l = null, i = null, s = performance.now(), d = e => {
                            let {
                                x: n,
                                y: d,
                                placement: c,
                                elements: u,
                                onClose: g,
                                nodeId: f,
                                tree: b
                            } = e;
                            return function(e) {
                                function p() {
                                    clearTimeout(t), g()
                                }
                                if (clearTimeout(t), !u.domReference || !u.floating || null == c || null == n || null == d) return;
                                let {
                                    clientX: h,
                                    clientY: m
                                } = e, y = [h, m], x = tk(e), v = "mouseleave" === e.type, w = tg(u.floating, x), k = tg(u.domReference, x), N = u.domReference.getBoundingClientRect(), j = u.floating.getBoundingClientRect(), E = c.split("-")[0], C = n > j.right - j.width / 2, T = d > j.bottom - j.height / 2, R = y[0] >= N.x && y[0] <= N.x + N.width && y[1] >= N.y && y[1] <= N.y + N.height, S = j.width > N.width, M = j.height > N.height, L = (S ? N : j).left, I = (S ? N : j).right, D = (M ? N : j).top, P = (M ? N : j).bottom;
                                if (w && (a = !0, !v)) return;
                                if (k && (a = !1), k && !v) {
                                    a = !0;
                                    return
                                }
                                if (v && te(e.relatedTarget) && tg(u.floating, e.relatedTarget) || b && r3(b.nodesRef.current, f).some(e => {
                                        let {
                                            context: t
                                        } = e;
                                        return null == t ? void 0 : t.open
                                    })) return;
                                if ("top" === E && d >= N.bottom - 1 || "bottom" === E && d <= N.top + 1 || "left" === E && n >= N.right - 1 || "right" === E && n <= N.left + 1) return p();
                                let z = [];
                                switch (E) {
                                    case "top":
                                        z = [
                                            [L, N.top + 1],
                                            [L, j.bottom - 1],
                                            [I, j.bottom - 1],
                                            [I, N.top + 1]
                                        ];
                                        break;
                                    case "bottom":
                                        z = [
                                            [L, j.top + 1],
                                            [L, N.bottom - 1],
                                            [I, N.bottom - 1],
                                            [I, j.top + 1]
                                        ];
                                        break;
                                    case "left":
                                        z = [
                                            [j.right - 1, P],
                                            [j.right - 1, D],
                                            [N.left + 1, D],
                                            [N.left + 1, P]
                                        ];
                                        break;
                                    case "right":
                                        z = [
                                            [N.right - 1, P],
                                            [N.right - 1, D],
                                            [j.left + 1, D],
                                            [j.left + 1, P]
                                        ]
                                }
                                if (!n$([h, m], z)) {
                                    if (a && !R) return p();
                                    if (!v && o) {
                                        let t = function(e, t) {
                                            let r = performance.now(),
                                                n = r - s;
                                            if (null === l || null === i || 0 === n) return l = e, i = t, s = r, null;
                                            let o = e - l,
                                                a = t - i;
                                            return l = e, i = t, s = r, Math.sqrt(o * o + a * a) / n
                                        }(e.clientX, e.clientY);
                                        if (null !== t && t < .1) return p()
                                    }
                                    n$([h, m], function(e) {
                                        let [t, n] = e;
                                        switch (E) {
                                            case "top":
                                                {
                                                    let e = [
                                                        [j.left, C ? j.bottom - r : S ? j.bottom - r : j.top],
                                                        [j.right, C ? S ? j.bottom - r : j.top : j.bottom - r]
                                                    ];
                                                    return [
                                                        [S ? t + r / 2 : C ? t + 4 * r : t - 4 * r, n + r + 1],
                                                        [S ? t - r / 2 : C ? t + 4 * r : t - 4 * r, n + r + 1], ...e
                                                    ]
                                                }
                                            case "bottom":
                                                {
                                                    let e = [
                                                        [j.left, C ? j.top + r : S ? j.top + r : j.bottom],
                                                        [j.right, C ? S ? j.top + r : j.bottom : j.top + r]
                                                    ];
                                                    return [
                                                        [S ? t + r / 2 : C ? t + 4 * r : t - 4 * r, n - r],
                                                        [S ? t - r / 2 : C ? t + 4 * r : t - 4 * r, n - r], ...e
                                                    ]
                                                }
                                            case "left":
                                                {
                                                    let e = [
                                                        [T ? j.right - r : M ? j.right - r : j.left, j.top],
                                                        [T ? M ? j.right - r : j.left : j.right - r, j.bottom]
                                                    ];
                                                    return [...e, [t + r + 1, M ? n + r / 2 : T ? n + 4 * r : n - 4 * r],
                                                        [t + r + 1, M ? n - r / 2 : T ? n + 4 * r : n - 4 * r]
                                                    ]
                                                }
                                            case "right":
                                                {
                                                    let e = [
                                                        [T ? j.left + r : M ? j.left + r : j.right, j.top],
                                                        [T ? M ? j.left + r : j.right : j.left + r, j.bottom]
                                                    ];
                                                    return [
                                                        [t - r, M ? n + r / 2 : T ? n + 4 * r : n - 4 * r],
                                                        [t - r, M ? n - r / 2 : T ? n + 4 * r : n - 4 * r], ...e
                                                    ]
                                                }
                                        }
                                    }([n, d])) ? !a && o && (t = window.setTimeout(p, 40)) : p()
                                }
                            }
                        };
                        return d.__options = {
                            blockPointerEvents: n
                        }, d
                    }()
                }), nI(e), nH(e, {
                    role: r
                }), ...n]),
                nZ = (0, d.createContext)(void 0);

            function nQ() {
                let e = (0, d.useContext)(nZ);
                if (!e) throw Error("useDropdownContext should be used within the DropdownContext provider!");
                return e
            }
            let nJ = ({
                    className: e,
                    theme: t = {},
                    ...r
                }) => {
                    let {
                        theme: n
                    } = nQ(), o = t.divider ? ? n.floating.divider;
                    return (0, s.jsx)("div", {
                        className: H(o, e),
                        ...r
                    })
                },
                n0 = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = nQ(), a = r.header ? ? o.floating.header;
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("div", {
                            className: H(a, t),
                            ...n,
                            children: e
                        }), (0, s.jsx)(nJ, {})]
                    })
                },
                n1 = {
                    top: u.lVW,
                    right: u.yoF,
                    bottom: u.kzR,
                    left: u.PSe
                },
                n5 = ({
                    refs: e,
                    children: t,
                    inline: r,
                    theme: n,
                    disabled: o,
                    setButtonWidth: a,
                    getReferenceProps: l,
                    renderTrigger: i,
                    ...c
                }) => {
                    let u = e.reference,
                        g = l();
                    if ((0, d.useEffect)(() => {
                            u.current && a ? .(u.current.clientWidth)
                        }, [u, a]), i) {
                        let t = i(n);
                        return (0, d.cloneElement)(t, {
                            ref: e.setReference,
                            disabled: o,
                            ...g,
                            ...t.props
                        })
                    }
                    return r ? (0, s.jsx)("button", {
                        type: "button",
                        ref: e.setReference,
                        className: n ? .inlineWrapper,
                        disabled: o,
                        ...g,
                        children: t
                    }) : (0, s.jsx)(eb, { ...c,
                        disabled: o,
                        type: "button",
                        ref: e.setReference,
                        ...g,
                        children: t
                    })
                },
                n2 = ({
                    children: e,
                    className: t,
                    dismissOnClick: r = !0,
                    theme: n = {},
                    renderTrigger: o,
                    ...a
                }) => {
                    let [l, i] = (0, d.useState)(!1), [c, g] = (0, d.useState)(null), [f, b] = (0, d.useState)(null), [p, h] = (0, d.useState)(void 0), m = (0, d.useRef)([]), y = (0, d.useRef)([]), x = q(Z().dropdown, n), v = a["data-testid"] || "flowbite-dropdown-target", {
                        placement: w = a.inline ? "bottom-start" : "bottom",
                        trigger: k = "click",
                        label: N,
                        inline: j,
                        arrowIcon: E = !0,
                        ...C
                    } = a, T = (0, d.useCallback)(e => {
                        b(e), i(!1)
                    }, []), R = (0, d.useCallback)(e => {
                        l ? g(e) : T(e)
                    }, [l, T]), {
                        context: S,
                        floatingStyles: M,
                        refs: L
                    } = nV({
                        open: l,
                        setOpen: i,
                        placement: w
                    }), I = function(e, t) {
                        let {
                            open: r,
                            onOpenChange: n,
                            refs: o,
                            elements: {
                                domReference: a,
                                floating: l
                            }
                        } = e, {
                            listRef: i,
                            activeIndex: s,
                            onNavigate: c = () => {},
                            enabled: u = !0,
                            selectedIndex: g = null,
                            allowEscape: f = !1,
                            loop: b = !1,
                            nested: p = !1,
                            rtl: h = !1,
                            virtual: m = !1,
                            focusItemOnOpen: y = "auto",
                            focusItemOnHover: x = !0,
                            openOnArrowKeyDown: v = !0,
                            disabledIndices: w,
                            orientation: k = "vertical",
                            cols: N = 1,
                            scrollItemIntoView: j = !0,
                            virtualItemRef: E
                        } = t, C = r5(), T = r2(), R = rI(c), S = d.useRef(y), M = d.useRef(null != g ? g : -1), L = d.useRef(null), I = d.useRef(!0), D = d.useRef(R), P = d.useRef(!!l), z = d.useRef(!1), O = d.useRef(!1), A = r6(w), F = r6(r), B = r6(j), [W, _] = d.useState(), [Y, G] = d.useState(), H = rI(function(e, t, r) {
                            void 0 === r && (r = !1);
                            let n = e.current[t.current];
                            n && (m ? (_(n.id), null == T || T.events.emit("virtualfocus", n), E && (E.current = n)) : rG(n, {
                                preventScroll: !0,
                                sync: !!(ty() && th()) && (nF || z.current)
                            }), requestAnimationFrame(() => {
                                let e = B.current,
                                    t = e && n && (r || !I.current);
                                t && (null == n.scrollIntoView || n.scrollIntoView("boolean" == typeof e ? {
                                    block: "nearest",
                                    inline: "nearest"
                                } : e))
                            }))
                        });
                        rH(() => {
                            document.createElement("div").focus({
                                get preventScroll() {
                                    return nF = !0, !1
                                }
                            })
                        }, []), rH(() => {
                            u && (r && l ? S.current && null != g && (O.current = !0, R(g)) : P.current && (M.current = -1, D.current(null)))
                        }, [u, r, l, g, R]), rH(() => {
                            if (u && r && l) {
                                if (null == s) {
                                    if (z.current = !1, null == g && (P.current && (M.current = -1, H(i, M)), !P.current && S.current && (null != L.current || !0 === S.current && null == L.current))) {
                                        let e = 0,
                                            t = () => {
                                                if (null == i.current[0]) {
                                                    if (e < 2) {
                                                        let r = e ? requestAnimationFrame : queueMicrotask;
                                                        r(t)
                                                    }
                                                    e++
                                                } else M.current = null == L.current || n_(L.current, k, h) || p ? rB(i, A.current) : rW(i, A.current), L.current = null, R(M.current)
                                            };
                                        t()
                                    }
                                } else rF(i, s) || (M.current = s, H(i, M, O.current), O.current = !1)
                            }
                        }, [u, r, l, s, g, p, i, k, h, R, H, A]), rH(() => {
                            var e;
                            if (!u || l || !T || m || !P.current) return;
                            let t = T.nodesRef.current,
                                r = null == (e = t.find(e => e.id === C)) || null == (e = e.context) ? void 0 : e.elements.floating,
                                n = tu(tv(l)),
                                o = t.some(e => e.context && tg(e.context.elements.floating, n));
                            r && !o && I.current && r.focus({
                                preventScroll: !0
                            })
                        }, [u, l, T, C, m]), rH(() => {
                            if (u && T && m && !C) return T.events.on("virtualfocus", e), () => {
                                T.events.off("virtualfocus", e)
                            };

                            function e(e) {
                                G(e.id), E && (E.current = e)
                            }
                        }, [u, T, m, C, E]), rH(() => {
                            D.current = R, P.current = !!l
                        }), rH(() => {
                            r || (L.current = null)
                        }, [r]);
                        let $ = null != s,
                            U = d.useMemo(() => {
                                function e(e) {
                                    if (!r) return;
                                    let t = i.current.indexOf(e); - 1 !== t && R(t)
                                }
                                let t = {
                                    onFocus(t) {
                                        let {
                                            currentTarget: r
                                        } = t;
                                        e(r)
                                    },
                                    onClick: e => {
                                        let {
                                            currentTarget: t
                                        } = e;
                                        return t.focus({
                                            preventScroll: !0
                                        })
                                    },
                                    ...x && {
                                        onMouseMove(t) {
                                            let {
                                                currentTarget: r
                                            } = t;
                                            e(r)
                                        },
                                        onPointerLeave(e) {
                                            let {
                                                pointerType: t
                                            } = e;
                                            I.current && "touch" !== t && (M.current = -1, H(i, M), R(null), m || rG(o.floating.current, {
                                                preventScroll: !0
                                            }))
                                        }
                                    }
                                };
                                return t
                            }, [r, o, H, x, i, R, m]);
                        return d.useMemo(() => {
                            if (!u) return {};
                            let e = A.current;

                            function t(t) {
                                if (I.current = !1, z.current = !0, !F.current && t.currentTarget === o.floating.current) return;
                                if (p && nY(t.key, k, h)) {
                                    tj(t), n(!1, t.nativeEvent, "list-navigation"), tt(a) && !m && a.focus();
                                    return
                                }
                                let l = M.current,
                                    s = rB(i, e),
                                    d = rW(i, e);
                                if ("Home" === t.key && (tj(t), M.current = s, R(M.current)), "End" === t.key && (tj(t), M.current = d, R(M.current)), (!(N > 1) || (M.current = function(e, t) {
                                        let {
                                            event: r,
                                            orientation: n,
                                            loop: o,
                                            cols: a,
                                            disabledIndices: l,
                                            minIndex: i,
                                            maxIndex: s,
                                            prevIndex: d,
                                            stopEvent: c = !1
                                        } = t, u = d;
                                        if (r.key === rD) {
                                            if (c && tj(r), -1 === d) u = s;
                                            else if (u = r_(e, {
                                                    startingIndex: u,
                                                    amount: a,
                                                    decrement: !0,
                                                    disabledIndices: l
                                                }), o && (d - a < i || u < 0)) {
                                                let e = d % a,
                                                    t = s % a,
                                                    r = s - (t - e);
                                                u = t === e ? s : t > e ? r : r - a
                                            }
                                            rF(e, u) && (u = d)
                                        }
                                        if (r.key === rP && (c && tj(r), -1 === d ? u = i : (u = r_(e, {
                                                startingIndex: d,
                                                amount: a,
                                                disabledIndices: l
                                            }), o && d + a > s && (u = r_(e, {
                                                startingIndex: d % a - a,
                                                amount: a,
                                                disabledIndices: l
                                            }))), rF(e, u) && (u = d)), "both" === n) {
                                            let t = tM(d / a);
                                            r.key === rO && (c && tj(r), d % a != a - 1 ? (u = r_(e, {
                                                startingIndex: d,
                                                disabledIndices: l
                                            }), o && rA(u, a, t) && (u = r_(e, {
                                                startingIndex: d - d % a - 1,
                                                disabledIndices: l
                                            }))) : o && (u = r_(e, {
                                                startingIndex: d - d % a - 1,
                                                disabledIndices: l
                                            })), rA(u, a, t) && (u = d)), r.key === rz && (c && tj(r), d % a != 0 ? (u = r_(e, {
                                                startingIndex: d,
                                                disabledIndices: l,
                                                decrement: !0
                                            }), o && rA(u, a, t) && (u = r_(e, {
                                                startingIndex: d + (a - d % a),
                                                decrement: !0,
                                                disabledIndices: l
                                            }))) : o && (u = r_(e, {
                                                startingIndex: d + (a - d % a),
                                                decrement: !0,
                                                disabledIndices: l
                                            })), rA(u, a, t) && (u = d));
                                            let n = tM(s / a) === t;
                                            rF(e, u) && (u = o && n ? r.key === rz ? s : r_(e, {
                                                startingIndex: d - d % a - 1,
                                                disabledIndices: l
                                            }) : d)
                                        }
                                        return u
                                    }(i, {
                                        event: t,
                                        orientation: k,
                                        loop: b,
                                        cols: N,
                                        disabledIndices: e,
                                        minIndex: s,
                                        maxIndex: d,
                                        prevIndex: M.current,
                                        stopEvent: !0
                                    }), R(M.current), "both" !== k)) && nW(t.key, k)) {
                                    if (tj(t), r && !m && tu(t.currentTarget.ownerDocument) === t.currentTarget) {
                                        M.current = n_(t.key, k, h) ? s : d, R(M.current);
                                        return
                                    }
                                    n_(t.key, k, h) ? b ? M.current = l >= d ? f && l !== i.current.length ? -1 : s : r_(i, {
                                        startingIndex: l,
                                        disabledIndices: e
                                    }) : M.current = Math.min(d, r_(i, {
                                        startingIndex: l,
                                        disabledIndices: e
                                    })) : b ? M.current = l <= s ? f && -1 !== l ? i.current.length : d : r_(i, {
                                        startingIndex: l,
                                        decrement: !0,
                                        disabledIndices: e
                                    }) : M.current = Math.max(s, r_(i, {
                                        startingIndex: l,
                                        decrement: !0,
                                        disabledIndices: e
                                    })), rF(i, M.current) ? R(null) : R(M.current)
                                }
                            }

                            function l(e) {
                                "auto" === y && tb(e.nativeEvent) && (S.current = !0)
                            }
                            let s = m && r && $ && {
                                    "aria-activedescendant": Y || W
                                },
                                d = i.current.find(e => (null == e ? void 0 : e.id) === W);
                            return {
                                reference: { ...s,
                                    onKeyDown(o) {
                                        var a, l, s, c, u, f;
                                        I.current = !1;
                                        let b = 0 === o.key.indexOf("Arrow"),
                                            y = (a = o.key, nB(k, h ? a === rz : a === rO, a === rP)),
                                            x = nY(o.key, k, h),
                                            w = nW(o.key, k),
                                            N = (p ? y : w) || "Enter" === o.key || "" === o.key.trim();
                                        if (m && r) {
                                            let e, r;
                                            let n = null == T ? void 0 : T.nodesRef.current.find(e => null == e.parentId),
                                                a = T && n ? (l = T.nodesRef.current, s = n.id, r = -1, ! function t(n, o) {
                                                    o > r && (e = n, r = o);
                                                    let a = r3(l, n);
                                                    a.forEach(e => {
                                                        t(e.id, o + 1)
                                                    })
                                                }(s, 0), l.find(t => t.id === e)) : null;
                                            if (b && a && E) {
                                                let e = new KeyboardEvent("keydown", {
                                                    key: o.key,
                                                    bubbles: !0
                                                });
                                                if (y || x) {
                                                    let t = (null == (c = a.context) ? void 0 : c.elements.domReference) === o.currentTarget,
                                                        r = x && !t ? null == (u = a.context) ? void 0 : u.elements.domReference : y ? d : null;
                                                    r && (tj(o), r.dispatchEvent(e), G(void 0))
                                                }
                                                if (w && a.context && a.context.open && a.parentId && o.currentTarget !== a.context.elements.domReference) {
                                                    tj(o), null == (f = a.context.elements.domReference) || f.dispatchEvent(e);
                                                    return
                                                }
                                            }
                                            return t(o)
                                        }
                                        if (r || v || !b) {
                                            if (N && (L.current = p && w ? null : o.key), p) {
                                                y && (tj(o), r ? (M.current = rB(i, e), R(M.current)) : n(!0, o.nativeEvent, "list-navigation"));
                                                return
                                            }
                                            w && (null != g && (M.current = g), tj(o), !r && v ? n(!0, o.nativeEvent, "list-navigation") : t(o), r && R(M.current))
                                        }
                                    },
                                    onFocus() {
                                        r && R(null)
                                    },
                                    onPointerDown: function(e) {
                                        S.current = y, "auto" === y && tp(e.nativeEvent) && (S.current = !0)
                                    },
                                    onMouseDown: l,
                                    onClick: l
                                },
                                floating: {
                                    "aria-orientation": "both" === k ? void 0 : k,
                                    ...!tE(a) && s,
                                    onKeyDown: t,
                                    onPointerMove() {
                                        I.current = !0
                                    }
                                },
                                item: U
                            }
                        }, [a, o, W, Y, A, F, i, u, k, h, m, r, $, p, g, v, f, N, b, y, R, n, U, T, E])
                    }(S, {
                        listRef: m,
                        activeIndex: c,
                        selectedIndex: f,
                        onNavigate: g
                    }), D = function(e, t) {
                        var r;
                        let {
                            open: n,
                            dataRef: o
                        } = e, {
                            listRef: a,
                            activeIndex: l,
                            onMatch: i,
                            onTypingChange: s,
                            enabled: c = !0,
                            findMatch: u = null,
                            resetMs: g = 750,
                            ignoreKeys: f = [],
                            selectedIndex: b = null
                        } = t, p = d.useRef(), h = d.useRef(""), m = d.useRef(null != (r = null != b ? b : l) ? r : -1), y = d.useRef(null), x = rI(i), v = rI(s), w = r6(u), k = r6(f);
                        return rH(() => {
                            n && (clearTimeout(p.current), y.current = null, h.current = "")
                        }, [n]), rH(() => {
                            if (n && "" === h.current) {
                                var e;
                                m.current = null != (e = null != b ? b : l) ? e : -1
                            }
                        }, [n, b, l]), d.useMemo(() => {
                            if (!c) return {};

                            function e(e) {
                                e ? o.current.typing || (o.current.typing = e, v(e)) : o.current.typing && (o.current.typing = e, v(e))
                            }

                            function t(e, t, r) {
                                let n = w.current ? w.current(t, r) : t.find(e => (null == e ? void 0 : e.toLocaleLowerCase().indexOf(r.toLocaleLowerCase())) === 0);
                                return n ? e.indexOf(n) : -1
                            }

                            function r(r) {
                                let o = a.current;
                                if (h.current.length > 0 && " " !== h.current[0] && (-1 === t(o, o, h.current) ? e(!1) : " " === r.key && tj(r)), null == o || k.current.includes(r.key) || 1 !== r.key.length || r.ctrlKey || r.metaKey || r.altKey) return;
                                n && " " !== r.key && (tj(r), e(!0));
                                let l = o.every(e => {
                                    var t, r;
                                    return !e || (null == (t = e[0]) ? void 0 : t.toLocaleLowerCase()) !== (null == (r = e[1]) ? void 0 : r.toLocaleLowerCase())
                                });
                                l && h.current === r.key && (h.current = "", m.current = y.current), h.current += r.key, clearTimeout(p.current), p.current = setTimeout(() => {
                                    h.current = "", m.current = y.current, e(!1)
                                }, g);
                                let i = m.current,
                                    s = t(o, [...o.slice((i || 0) + 1), ...o.slice(0, (i || 0) + 1)], h.current); - 1 !== s ? (x(s), y.current = s) : " " !== r.key && (h.current = "", e(!1))
                            }
                            return {
                                reference: {
                                    onKeyDown: r
                                },
                                floating: {
                                    onKeyDown: r,
                                    onKeyUp(t) {
                                        " " === t.key && e(!1)
                                    }
                                }
                            }
                        }, [c, n, o, a, g, k, w, x, v])
                    }(S, {
                        listRef: y,
                        activeIndex: c,
                        selectedIndex: f,
                        onMatch: R
                    }), {
                        getReferenceProps: P,
                        getFloatingProps: z,
                        getItemProps: O
                    } = nX({
                        context: S,
                        role: "menu",
                        trigger: k,
                        interactions: [I, D]
                    }), A = (0, d.useMemo)(() => {
                        let [e] = w.split("-");
                        return n1[e] ? ? u.kzR
                    }, [w]);
                    return (0, s.jsxs)(nZ.Provider, {
                        value: {
                            theme: x,
                            activeIndex: c,
                            dismissOnClick: r,
                            getItemProps: O,
                            handleSelect: T
                        },
                        children: [(0, s.jsxs)(n5, { ...C,
                            refs: L,
                            inline: j,
                            theme: x,
                            "data-testid": v,
                            className: H(x.floating.target, C.className),
                            setButtonWidth: h,
                            getReferenceProps: P,
                            renderTrigger: o,
                            children: [N, E && (0, s.jsx)(A, {
                                className: x.arrowIcon
                            })]
                        }), l && (0, s.jsx)(nj, {
                            context: S,
                            modal: !1,
                            children: (0, s.jsx)("div", {
                                ref: L.setFloating,
                                style: { ...M,
                                    minWidth: p
                                },
                                "data-testid": "flowbite-dropdown",
                                "aria-expanded": l,
                                ...z({
                                    className: H(x.floating.base, x.floating.animation, "duration-100", !l && x.floating.hidden, x.floating.style.auto, t)
                                }),
                                children: (0, s.jsx)(rq, {
                                    elementsRef: m,
                                    labelsRef: y,
                                    children: (0, s.jsx)("ul", {
                                        className: x.content,
                                        tabIndex: -1,
                                        children: e
                                    })
                                })
                            })
                        })]
                    })
                };
            n2.displayName = "Dropdown", n0.displayName = "Dropdown.Header", nJ.displayName = "Dropdown.Divider";
            let n4 = Object.assign(n2, {
                    Item: ({
                        children: e,
                        className: t,
                        icon: r,
                        onClick: n,
                        theme: o = {},
                        ...a
                    }) => {
                        let {
                            ref: l,
                            index: i
                        } = function(e) {
                            let {
                                label: t
                            } = void 0 === e ? {} : e, [r, n] = d.useState(null), o = d.useRef(null), {
                                register: a,
                                unregister: l,
                                map: i,
                                elementsRef: s,
                                labelsRef: c
                            } = d.useContext(rU), u = d.useCallback(e => {
                                if (o.current = e, null !== r && (s.current[r] = e, c)) {
                                    var n;
                                    let o = void 0 !== t;
                                    c.current[r] = o ? t : null != (n = null == e ? void 0 : e.textContent) ? n : null
                                }
                            }, [r, s, c, t]);
                            return rH(() => {
                                let e = o.current;
                                if (e) return a(e), () => {
                                    l(e)
                                }
                            }, [a, l]), rH(() => {
                                let e = o.current ? i.get(o.current) : null;
                                null != e && n(e)
                            }, [i]), d.useMemo(() => ({
                                ref: u,
                                index: null == r ? -1 : r
                            }), [r, u])
                        }({
                            label: "string" == typeof e ? e : void 0
                        }), {
                            theme: c,
                            activeIndex: u,
                            dismissOnClick: g,
                            getItemProps: f,
                            handleSelect: b
                        } = nQ(), p = q(c.floating.item, o);
                        return (0, s.jsx)("li", {
                            role: "menuitem",
                            className: p.container,
                            children: (0, s.jsxs)(ec, {
                                ref: l,
                                className: H(p.base, t),
                                ...a,
                                ...f({
                                    onClick: () => {
                                        n && n(), g && b(null)
                                    }
                                }),
                                tabIndex: u === i ? 0 : -1,
                                children: [r && (0, s.jsx)(r, {
                                    className: p.icon
                                }), e]
                            })
                        })
                    },
                    Header: n0,
                    Divider: nJ
                }),
                n6 = (0, d.forwardRef)(({
                    className: e,
                    color: t = "gray",
                    helperText: r,
                    sizing: n = "md",
                    theme: o = {},
                    ...a
                }, l) => {
                    let i = q(Z().fileInput, o);
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("div", {
                            className: H(i.root.base, e),
                            children: (0, s.jsx)("div", {
                                className: i.field.base,
                                children: (0, s.jsx)("input", {
                                    className: H(i.field.input.base, i.field.input.colors[t], i.field.input.sizes[n]),
                                    ...a,
                                    type: "file",
                                    ref: l
                                })
                            })
                        }), r && (0, s.jsx)(eW, {
                            color: t,
                            children: r
                        })]
                    })
                });
            n6.displayName = "FileInput";
            let n7 = (0, d.forwardRef)(({
                label: e,
                helperText: t,
                color: r = "default",
                sizing: n = "md",
                variant: o,
                disabled: a = !1,
                theme: l = {},
                className: i,
                ...c
            }, u) => {
                let g = (0, d.useId)(),
                    f = q(Z().floatingLabel, l);
                return (0, s.jsxs)("div", {
                    children: [(0, s.jsxs)("div", {
                        className: H("relative", "standard" === o ? "z-0" : ""),
                        children: [(0, s.jsx)("input", {
                            type: "text",
                            id: c.id ? c.id : "floatingLabel" + g,
                            "aria-describedby": "outlined_success_help",
                            className: H(f.input[r][o][n], i),
                            placeholder: " ",
                            "data-testid": "floating-label",
                            disabled: a,
                            ...c,
                            ref: u
                        }), (0, s.jsx)("label", {
                            htmlFor: c.id ? c.id : "floatingLabel" + g,
                            className: H(f.label[r][o][n], i),
                            children: e
                        })]
                    }), (0, s.jsx)("p", {
                        id: "outlined_helper_text" + g,
                        className: H(f.helperText[r], i),
                        children: t
                    })]
                })
            });
            n7.displayName = "FloatingLabel";
            let n9 = ({
                    alt: e,
                    className: t,
                    children: r,
                    href: n,
                    name: o,
                    src: a,
                    theme: l = {},
                    ...i
                }) => {
                    let d = q(Z().footer.brand, l);
                    return (0, s.jsx)("div", {
                        children: n ? (0, s.jsxs)("a", {
                            "data-testid": "flowbite-footer-brand",
                            href: n,
                            className: H(d.base, t),
                            ...i,
                            children: [(0, s.jsx)("img", {
                                alt: e,
                                src: a,
                                className: d.img
                            }), (0, s.jsx)("span", {
                                "data-testid": "flowbite-footer-brand-span",
                                className: d.span,
                                children: o
                            }), r]
                        }) : (0, s.jsx)("img", {
                            alt: e,
                            "data-testid": "flowbite-footer-brand",
                            src: a,
                            className: H(d.img, t),
                            ...i
                        })
                    })
                },
                n3 = ({
                    by: e,
                    className: t,
                    href: r,
                    theme: n = {},
                    year: o,
                    ...a
                }) => {
                    let l = q(Z().footer.copyright, n);
                    return (0, s.jsxs)("div", {
                        "data-testid": "flowbite-footer-copyright",
                        className: H(l.base, t),
                        ...a,
                        children: ["\xa9 ", o, r ? (0, s.jsx)("a", {
                            href: r,
                            className: l.href,
                            children: e
                        }) : (0, s.jsx)("span", {
                            "data-testid": "flowbite-footer-copyright-span",
                            className: l.span,
                            children: e
                        })]
                    })
                },
                n8 = ({
                    className: e,
                    theme: t = {},
                    ...r
                }) => {
                    let n = q(Z().footer.divider, t);
                    return (0, s.jsx)("hr", {
                        "data-testid": "footer-divider",
                        className: H(n.base, e),
                        ...r
                    })
                },
                oe = ({
                    ariaLabel: e,
                    className: t,
                    href: r,
                    icon: n,
                    theme: o = {},
                    ...a
                }) => {
                    let l = q(Z().footer.icon, o);
                    return (0, s.jsx)("div", {
                        children: r ? (0, s.jsx)("a", {
                            "aria-label": e,
                            "data-testid": "flowbite-footer-icon",
                            href: r,
                            className: H(l.base, t),
                            ...a,
                            children: (0, s.jsx)(n, {
                                className: l.size
                            })
                        }) : (0, s.jsx)(n, {
                            "data-testid": "flowbite-footer-icon",
                            className: l.size,
                            ...a
                        })
                    })
                },
                ot = ({
                    as: e = "a",
                    children: t,
                    className: r,
                    href: n,
                    theme: o = {},
                    ...a
                }) => {
                    let l = q(Z().footer.groupLink.link, o);
                    return (0, s.jsx)("li", {
                        className: H(l.base, r),
                        children: (0, s.jsx)(e, {
                            href: n,
                            className: l.href,
                            ...a,
                            children: t
                        })
                    })
                },
                or = ({
                    children: e,
                    className: t,
                    col: r = !1,
                    theme: n = {},
                    ...o
                }) => {
                    let a = q(Z().footer.groupLink, n);
                    return (0, s.jsx)("ul", {
                        "data-testid": "footer-groupLink",
                        className: H(a.base, r && a.col, t),
                        ...o,
                        children: e
                    })
                },
                on = ({
                    as: e = "h2",
                    className: t,
                    theme: r = {},
                    title: n,
                    ...o
                }) => {
                    let a = q(Z().footer.title, r);
                    return (0, s.jsx)(e, {
                        "data-testid": "flowbite-footer-title",
                        className: H(a.base, t),
                        ...o,
                        children: n
                    })
                },
                oo = ({
                    bgDark: e = !1,
                    children: t,
                    className: r,
                    container: n = !1,
                    theme: o = {},
                    ...a
                }) => {
                    let l = q(Z().footer, o);
                    return (0, s.jsx)("footer", {
                        "data-testid": "flowbite-footer",
                        className: H(l.root.base, e && l.root.bgDark, n && l.root.container, r),
                        ...a,
                        children: t
                    })
                };
            oo.displayName = "Footer", n3.displayName = "Footer.Copyright", ot.displayName = "Footer.Link", n9.displayName = "Footer.Brand", or.displayName = "Footer.LinkGroup", oe.displayName = "Footer.Icon", on.displayName = "Footer.Title", n8.displayName = "Footer.Divider", Object.assign(oo, {
                Copyright: n3,
                Link: ot,
                LinkGroup: or,
                Brand: n9,
                Icon: oe,
                Title: on,
                Divider: n8
            });
            let oa = ({
                    children: e,
                    className: t,
                    theme: r = {}
                }) => {
                    let n = q(Z().listGroup.item, r);
                    return (0, s.jsx)("li", {
                        className: H(n.base, t),
                        children: e
                    })
                },
                ol = ({
                    children: e,
                    className: t,
                    unstyled: r,
                    nested: n,
                    ordered: o,
                    horizontal: a,
                    theme: l = {},
                    ...i
                }) => {
                    let d = q(Z().list, l);
                    return (0, s.jsx)(o ? "ol" : "ul", {
                        className: H(d.root.base, d.root.ordered[o ? "on" : "off"], r && d.root.unstyled, n && d.root.nested, a && d.root.horizontal, t),
                        ...i,
                        children: e
                    })
                };
            ol.displayName = "List", oa.displayName = "List.Item", Object.assign(ol, {
                Item: oa
            });
            let oi = ({
                    active: e,
                    children: t,
                    className: r,
                    href: n,
                    icon: o,
                    onClick: a,
                    theme: l = {},
                    disabled: i,
                    ...d
                }) => {
                    let c = q(Z().listGroup.item, l),
                        u = void 0 !== n;
                    return (0, s.jsx)("li", {
                        className: H(c.base, r),
                        children: (0, s.jsxs)(u ? "a" : "button", {
                            href: n,
                            onClick: a,
                            type: u ? void 0 : "button",
                            disabled: i,
                            className: H(c.link.active[e ? "on" : "off"], c.link.disabled[i ? "on" : "off"], c.link.base, c.link.href[u ? "on" : "off"]),
                            ...d,
                            children: [o && (0, s.jsx)(o, {
                                "aria-hidden": !0,
                                "data-testid": "flowbite-list-group-item-icon",
                                className: c.link.icon
                            }), t]
                        })
                    })
                },
                os = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let o = q(Z().listGroup, r);
                    return (0, s.jsx)("ul", {
                        className: H(o.root.base, t),
                        ...n,
                        children: e
                    })
                };
            os.displayName = "ListGroup", oi.displayName = "ListGroup.Item", Object.assign(os, {
                Item: oi
            });
            let od = (0, d.createContext)(void 0);

            function oc() {
                let e = (0, d.useContext)(od);
                if (!e) throw Error("useModalContext should be used within the ModalContext provider!");
                return e
            }
            let ou = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o,
                        popup: a
                    } = oc(), l = q(o.body, r);
                    return (0, s.jsx)("div", {
                        className: H(l.base, a && [l.popup], t),
                        ...n,
                        children: e
                    })
                },
                og = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o,
                        popup: a
                    } = oc(), l = q(o.footer, r);
                    return (0, s.jsx)("div", {
                        className: H(l.base, !a && l.popup, t),
                        ...n,
                        children: e
                    })
                },
                of = ({
                    as: e = "h3",
                    children: t,
                    className: r,
                    theme: n = {},
                    id: o,
                    ...a
                }) => {
                    let l = (0, d.useId)(),
                        i = o || l,
                        {
                            theme: c,
                            popup: g,
                            onClose: f,
                            setHeaderId: b
                        } = oc(),
                        p = q(c.header, n);
                    return (0, d.useLayoutEffect)(() => (b(i), () => b(void 0)), [i, b]), (0, s.jsxs)("div", {
                        className: H(p.base, g && p.popup, r),
                        ...a,
                        children: [(0, s.jsx)(e, {
                            id: i,
                            className: p.title,
                            children: t
                        }), (0, s.jsx)("button", {
                            "aria-label": "Close",
                            className: p.close.base,
                            type: "button",
                            onClick: f,
                            children: (0, s.jsx)(u.fMW, {
                                "aria-hidden": !0,
                                className: p.close.icon
                            })
                        })]
                    })
                },
                ob = (0, d.forwardRef)(({
                    children: e,
                    className: t,
                    dismissible: r = !1,
                    onClose: n,
                    popup: o,
                    position: a = "center",
                    root: l,
                    show: i,
                    size: c = "2xl",
                    theme: u = {},
                    initialFocus: g,
                    ...f
                }, b) => {
                    var p;
                    let [h, m] = (0, d.useState)(void 0), y = q(Z().modal, u), {
                        context: x
                    } = nD({
                        open: i,
                        onOpenChange: () => n && n()
                    }), v = (p = [x.refs.setFloating, b], d.useMemo(() => p.every(e => null == e) ? null : e => {
                        p.forEach(t => {
                            "function" == typeof t ? t(e) : null != t && (t.current = e)
                        })
                    }, p)), w = nR(x), k = nI(x, {
                        outsidePressEvent: "mousedown",
                        enabled: r
                    }), N = nH(x), {
                        getFloatingProps: j
                    } = nA([w, k, N]);
                    return i ? (0, s.jsx)(od.Provider, {
                        value: {
                            theme: y,
                            popup: o,
                            onClose: n,
                            setHeaderId: m
                        },
                        children: (0, s.jsx)(ny, {
                            root: l,
                            children: (0, s.jsx)(nC, {
                                lockScroll: !0,
                                "data-testid": "modal-overlay",
                                className: H(y.root.base, y.root.positions[a], i ? y.root.show.on : y.root.show.off, t),
                                ...f,
                                children: (0, s.jsx)(nj, {
                                    context: x,
                                    initialFocus: g,
                                    children: (0, s.jsx)("div", {
                                        ref: v,
                                        ...j(f),
                                        "aria-labelledby": h,
                                        className: H(y.content.base, y.root.sizes[c]),
                                        children: (0, s.jsx)("div", {
                                            className: y.content.inner,
                                            children: e
                                        })
                                    })
                                })
                            })
                        })
                    }) : null
                });
            ob.displayName = "Modal", of .displayName = "Modal.Header", ou.displayName = "Modal.Body", og.displayName = "Modal.Footer";
            let op = Object.assign(ob, {
                    Header: of ,
                    Body: ou,
                    Footer: og
                }),
                oh = (0, d.createContext)(void 0);

            function om() {
                let e = (0, d.useContext)(oh);
                if (!e) throw Error("useNavBarContext should be used within the NavbarContext provider!");
                return e
            }
            let oy = ({
                    as: e = "a",
                    children: t,
                    className: r,
                    theme: n = {},
                    ...o
                }) => {
                    let {
                        theme: a
                    } = om(), l = q(a.brand, n);
                    return (0, s.jsx)(e, {
                        className: H(l.base, r),
                        ...o,
                        children: t
                    })
                },
                ox = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o,
                        isOpen: a
                    } = om(), l = q(o.collapse, r);
                    return (0, s.jsx)("div", {
                        "data-testid": "flowbite-navbar-collapse",
                        className: H(l.base, l.hidden[a ? "off" : "on"], t),
                        ...n,
                        children: (0, s.jsx)("ul", {
                            className: l.list,
                            children: e
                        })
                    })
                },
                ov = ({
                    active: e,
                    as: t = "a",
                    disabled: r,
                    children: n,
                    className: o,
                    theme: a = {},
                    ...l
                }) => {
                    let {
                        theme: i
                    } = om(), d = q(i.link, a);
                    return (0, s.jsx)("li", {
                        children: (0, s.jsx)(t, {
                            className: H(d.base, e && d.active.on, !e && !r && d.active.off, d.disabled[r ? "on" : "off"], o),
                            ...l,
                            children: n
                        })
                    })
                };
            var ow = r(5401);
            let ok = ({
                    barIcon: e = ow.Fm7,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o,
                        isOpen: a,
                        setIsOpen: l
                    } = om(), i = q(o.toggle, r);
                    return (0, s.jsxs)("button", {
                        "data-testid": "flowbite-navbar-toggle",
                        onClick: () => {
                            l(!a)
                        },
                        className: H(i.base, t),
                        ...n,
                        children: [(0, s.jsx)("span", {
                            className: "sr-only",
                            children: "Open main menu"
                        }), (0, s.jsx)(e, {
                            "aria-hidden": !0,
                            className: i.icon
                        })]
                    })
                },
                oN = ({
                    border: e,
                    children: t,
                    className: r,
                    fluid: n = !1,
                    menuOpen: o,
                    rounded: a,
                    theme: l = {},
                    ...i
                }) => {
                    let [c, u] = (0, d.useState)(o), g = q(Z().navbar, l);
                    return (0, s.jsx)(oh.Provider, {
                        value: {
                            theme: g,
                            isOpen: c,
                            setIsOpen: u
                        },
                        children: (0, s.jsx)("nav", {
                            className: H(g.root.base, g.root.bordered[e ? "on" : "off"], g.root.rounded[a ? "on" : "off"], r),
                            ...i,
                            children: (0, s.jsx)("div", {
                                className: H(g.root.inner.base, g.root.inner.fluid[n ? "on" : "off"]),
                                children: t
                            })
                        })
                    })
                };
            oN.displayName = "Navbar", oy.displayName = "Navbar.Brand", ox.displayName = "Navbar.Collapse", ov.displayName = "Navbar.Link", ok.displayName = "Navbar.Toggle", Object.assign(oN, {
                Brand: oy,
                Collapse: ox,
                Link: ov,
                Toggle: ok
            });
            let oj = ({
                active: e,
                children: t,
                className: r,
                onClick: n,
                theme: o = {},
                ...a
            }) => {
                let l = q(Z().pagination, o);
                return (0, s.jsx)("button", {
                    type: "button",
                    className: H(e && l.pages.selector.active, r),
                    onClick: n,
                    ...a,
                    children: t
                })
            };
            oj.displayName = "Pagination.Button";
            let oE = ({
                children: e,
                className: t,
                onClick: r,
                theme: n = {},
                disabled: o = !1,
                ...a
            }) => {
                let l = q(Z().pagination, n);
                return (0, s.jsx)("button", {
                    type: "button",
                    className: H(o && l.pages.selector.disabled, t),
                    disabled: o,
                    onClick: r,
                    ...a,
                    children: e
                })
            };
            oE.displayName = "Pagination.Navigation";
            let oC = (e, t) => e >= t ? [] : [...Array(t - e + 1).keys()].map(t => t + e),
                oT = ({
                    className: e,
                    currentPage: t,
                    layout: r = "pagination",
                    nextLabel: n = "Next",
                    onPageChange: o,
                    previousLabel: a = "Previous",
                    renderPaginationButton: l = e => (0, s.jsx)(oj, { ...e
                    }),
                    showIcons: i = !1,
                    theme: d = {},
                    totalPages: c,
                    ...g
                }) => {
                    let f = q(Z().pagination, d),
                        b = Math.min(Math.max("pagination" === r ? t + 2 : t + 4, 5), c),
                        p = Math.max(1, b - 4);
                    return (0, s.jsxs)("nav", {
                        className: H(f.base, e),
                        ...g,
                        children: ["table" === r && (0, s.jsxs)("div", {
                            className: f.layout.table.base,
                            children: ["Showing ", (0, s.jsx)("span", {
                                className: f.layout.table.span,
                                children: p
                            }), " to\xa0", (0, s.jsx)("span", {
                                className: f.layout.table.span,
                                children: b
                            }), " of\xa0", (0, s.jsx)("span", {
                                className: f.layout.table.span,
                                children: c
                            }), " Entries"]
                        }), (0, s.jsxs)("ul", {
                            className: f.pages.base,
                            children: [(0, s.jsx)("li", {
                                children: (0, s.jsxs)(oE, {
                                    className: H(f.pages.previous.base, i && f.pages.showIcon),
                                    onClick: () => {
                                        o(Math.max(t - 1, 1))
                                    },
                                    disabled: 1 === t,
                                    children: [i && (0, s.jsx)(u.DEl, {
                                        "aria-hidden": !0,
                                        className: f.pages.previous.icon
                                    }), a]
                                })
                            }), "pagination" === r && oC(p, b).map(e => (0, s.jsx)("li", {
                                "aria-current": e === t ? "page" : void 0,
                                children: l({
                                    className: H(f.pages.selector.base, t === e && f.pages.selector.active),
                                    active: e === t,
                                    onClick: () => o(e),
                                    children: e
                                })
                            }, e)), (0, s.jsx)("li", {
                                children: (0, s.jsxs)(oE, {
                                    className: H(f.pages.next.base, i && f.pages.showIcon),
                                    onClick: () => {
                                        o(Math.min(t + 1, c))
                                    },
                                    disabled: t === c,
                                    children: [n, i && (0, s.jsx)(u.MOd, {
                                        "aria-hidden": !0,
                                        className: f.pages.next.icon
                                    })]
                                })
                            })]
                        })]
                    })
                };
            oT.displayName = "Pagination", Object.assign(oT, {
                Button: oj
            });
            let oR = (0, d.forwardRef)(({
                className: e,
                theme: t = {},
                ...r
            }, n) => {
                let o = q(Z().radio, t);
                return (0, s.jsx)("input", {
                    ref: n,
                    type: "radio",
                    className: H(o.root.base, e),
                    ...r
                })
            });
            oR.displayName = "Radio";
            let oS = (0, d.forwardRef)(({
                className: e,
                sizing: t = "md",
                theme: r = {},
                ...n
            }, o) => {
                let a = q(Z().rangeSlider, r);
                return (0, s.jsx)(s.Fragment, {
                    children: (0, s.jsx)("div", {
                        "data-testid": "flowbite-range-slider",
                        className: H(a.root.base, e),
                        children: (0, s.jsx)("div", {
                            className: a.field.base,
                            children: (0, s.jsx)("input", {
                                ref: o,
                                type: "range",
                                className: H(a.field.input.base, a.field.input.sizes[t]),
                                ...n
                            })
                        })
                    })
                })
            });
            oS.displayName = "RangeSlider";
            let oM = ({
                    children: e,
                    className: t,
                    percentFilled: r = 0,
                    theme: n = {},
                    ...o
                }) => {
                    let a = q(Z().ratingAdvanced, n);
                    return (0, s.jsxs)("div", {
                        className: H(a.base, t),
                        ...o,
                        children: [(0, s.jsx)("span", {
                            className: a.label,
                            children: e
                        }), (0, s.jsx)("div", {
                            className: a.progress.base,
                            children: (0, s.jsx)("div", {
                                className: a.progress.fill,
                                "data-testid": "flowbite-rating-fill",
                                style: {
                                    width: `${r}%`
                                }
                            })
                        }), (0, s.jsx)("span", {
                            className: a.progress.label,
                            children: `${r}%`
                        })]
                    })
                },
                oL = (0, d.createContext)(void 0),
                oI = ({
                    className: e,
                    filled: t = !0,
                    starIcon: r = u.xiv,
                    theme: n = {},
                    ...o
                }) => {
                    let {
                        theme: a,
                        size: l = "sm"
                    } = function() {
                        let e = (0, d.useContext)(oL);
                        if (!e) throw Error("useRatingContext should be used within the RatingContext provider!");
                        return e
                    }(), i = q(a.star, n);
                    return (0, s.jsx)(r, {
                        "data-testid": "flowbite-rating-star",
                        className: H(i.sizes[l], i[t ? "filled" : "empty"], e),
                        ...o
                    })
                },
                oD = ({
                    children: e,
                    className: t,
                    size: r = "sm",
                    theme: n = {},
                    ...o
                }) => {
                    let a = q(Z().rating, n);
                    return (0, s.jsx)(oL.Provider, {
                        value: {
                            theme: a,
                            size: r
                        },
                        children: (0, s.jsx)("div", {
                            className: H(a.root.base, t),
                            ...o,
                            children: e
                        })
                    })
                };
            oD.displayName = "Rating", oI.displayName = "Rating.Star", oM.displayName = "Rating.Advanced", Object.assign(oD, {
                Star: oI,
                Advanced: oM
            });
            let oP = (0, d.forwardRef)(({
                addon: e,
                children: t,
                className: r,
                color: n = "gray",
                helperText: o,
                icon: a,
                shadow: l,
                sizing: i = "md",
                theme: d = {},
                ...c
            }, u) => {
                let g = q(Z().select, d);
                return (0, s.jsxs)("div", {
                    className: H(g.base, r),
                    children: [e && (0, s.jsx)("span", {
                        className: g.addon,
                        children: e
                    }), (0, s.jsxs)("div", {
                        className: g.field.base,
                        children: [a && (0, s.jsx)("div", {
                            className: g.field.icon.base,
                            children: (0, s.jsx)(a, {
                                className: g.field.icon.svg
                            })
                        }), (0, s.jsx)("select", {
                            className: H(g.field.select.base, g.field.select.colors[n], g.field.select.sizes[i], g.field.select.withIcon[a ? "on" : "off"], g.field.select.withAddon[e ? "on" : "off"], g.field.select.withShadow[l ? "on" : "off"]),
                            ...c,
                            ref: u,
                            children: t
                        }), o && (0, s.jsx)(eW, {
                            color: n,
                            children: o
                        })]
                    })]
                })
            });
            oP.displayName = "Select";
            let oz = (0, d.createContext)(void 0);

            function oO() {
                let e = (0, d.useContext)(oz);
                if (!e) throw Error("useSidebarContext should be used within the SidebarContext provider!");
                return e
            }
            let oA = ({
                children: e,
                color: t = "info",
                className: r,
                theme: n = {},
                ...o
            }) => {
                let {
                    theme: a,
                    isCollapsed: l
                } = oO(), i = q(a.cta, n);
                return (0, s.jsx)("div", {
                    "data-testid": "sidebar-cta",
                    hidden: l,
                    className: H(i.base, i.color[t], r),
                    ...o,
                    children: e
                })
            };
            oA.displayName = "Sidebar.CTA";
            let oF = ({
                    animation: e = "duration-300",
                    arrow: t = !0,
                    children: r,
                    className: n,
                    content: o,
                    placement: a = "top",
                    style: l = "dark",
                    theme: i,
                    trigger: c = "hover",
                    minWidth: u,
                    ...g
                }) => {
                    let f = (0, d.useRef)(null),
                        [b, p] = (0, d.useState)(!1),
                        h = nV({
                            open: b,
                            placement: a,
                            arrowRef: f,
                            setOpen: p
                        }),
                        {
                            context: m,
                            middlewareData: {
                                arrow: {
                                    x: y,
                                    y: x
                                } = {}
                            },
                            refs: v,
                            strategy: w,
                            update: k,
                            x: N,
                            y: j
                        } = h,
                        E = function(e, t) {
                            void 0 === t && (t = {});
                            let {
                                open: r,
                                onOpenChange: n,
                                events: o,
                                refs: a,
                                elements: {
                                    floating: l,
                                    domReference: i
                                }
                            } = e, {
                                enabled: s = !0,
                                visibleOnly: c = !0
                            } = t, u = d.useRef(!1), g = d.useRef(), f = d.useRef(!0);
                            return d.useEffect(() => {
                                if (!s) return;
                                let e = e9(i);

                                function t() {
                                    !r && tt(i) && i === tu(tv(i)) && (u.current = !0)
                                }

                                function n() {
                                    f.current = !0
                                }
                                return e.addEventListener("blur", t), e.addEventListener("keydown", n, !0), () => {
                                    e.removeEventListener("blur", t), e.removeEventListener("keydown", n, !0)
                                }
                            }, [l, i, r, s]), d.useEffect(() => {
                                if (s) return o.on("openchange", e), () => {
                                    o.off("openchange", e)
                                };

                                function e(e) {
                                    let {
                                        reason: t
                                    } = e;
                                    ("reference-press" === t || "escape-key" === t) && (u.current = !0)
                                }
                            }, [o, s]), d.useEffect(() => () => {
                                clearTimeout(g.current)
                            }, []), d.useMemo(() => s ? {
                                reference: {
                                    onPointerDown(e) {
                                        tp(e.nativeEvent) || (f.current = !1)
                                    },
                                    onMouseLeave() {
                                        u.current = !1
                                    },
                                    onFocus(e) {
                                        if (u.current) return;
                                        let t = tk(e.nativeEvent);
                                        if (c && te(t)) try {
                                            if (th() && ty()) throw Error();
                                            if (!t.matches(":focus-visible")) return
                                        } catch (e) {
                                            if (!f.current && !tN(t)) return
                                        }
                                        n(!0, e.nativeEvent, "focus")
                                    },
                                    onBlur(e) {
                                        u.current = !1;
                                        let t = e.relatedTarget,
                                            r = te(t) && t.hasAttribute(r4("focus-guard")) && "outside" === t.getAttribute("data-type");
                                        g.current = window.setTimeout(() => {
                                            let o = tu(i ? i.ownerDocument : document);
                                            if (t || o !== i) {
                                                if (tg(a.floating.current, t) || tg(i, t) || r) return;
                                                n(!1, e.nativeEvent, "focus")
                                            }
                                        })
                                    }
                                }
                            } : {}, [s, c, i, a, n])
                        }(m),
                        {
                            getFloatingProps: C,
                            getReferenceProps: T
                        } = nX({
                            context: m,
                            role: "tooltip",
                            trigger: c,
                            interactions: [E]
                        });
                    return (0, d.useEffect)(() => {
                        if (v.reference.current && v.floating.current && b) return t3(v.reference.current, v.floating.current, k)
                    }, [b, v.floating, v.reference, k]), (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("div", {
                            ref: v.setReference,
                            className: i.target,
                            "data-testid": "flowbite-tooltip-target",
                            ...T(),
                            children: r
                        }), (0, s.jsxs)("div", {
                            ref: v.setFloating,
                            "data-testid": "flowbite-tooltip",
                            ...C({
                                className: H(i.base, e && `${i.animation} ${e}`, !b && i.hidden, i.style[l], n),
                                style: {
                                    position: w,
                                    top: j ? ? " ",
                                    left: N ? ? " ",
                                    minWidth: u
                                },
                                ...g
                            }),
                            children: [(0, s.jsx)("div", {
                                className: i.content,
                                children: o
                            }), t && (0, s.jsx)("div", {
                                className: H(i.arrow.base, "dark" === l && i.arrow.style.dark, "light" === l && i.arrow.style.light, "auto" === l && i.arrow.style.auto),
                                "data-testid": "flowbite-tooltip-arrow",
                                ref: f,
                                style: {
                                    top: x ? ? " ",
                                    left: y ? ? " ",
                                    right: " ",
                                    bottom: " ",
                                    [nK({
                                        placement: h.placement
                                    })]: i.arrow.placement
                                },
                                children: "\xa0"
                            })]
                        })]
                    })
                },
                oB = ({
                    animation: e = "duration-300",
                    arrow: t = !0,
                    children: r,
                    className: n,
                    content: o,
                    placement: a = "top",
                    style: l = "dark",
                    theme: i = {},
                    trigger: d = "hover",
                    ...c
                }) => {
                    let u = q(Z().tooltip, i);
                    return (0, s.jsx)(oF, {
                        animation: e,
                        arrow: t,
                        content: o,
                        placement: a,
                        style: l,
                        theme: u,
                        trigger: d,
                        className: n,
                        ...c,
                        children: r
                    })
                };
            oB.displayName = "Tooltip";
            let oW = (0, d.createContext)(void 0),
                o_ = ({
                    children: e,
                    className: t,
                    icon: r,
                    label: n,
                    chevronIcon: o = u.kWQ,
                    renderChevronIcon: a,
                    open: l = !1,
                    theme: i = {},
                    ...c
                }) => {
                    let g = (0, d.useId)(),
                        [f, b] = (0, d.useState)(l),
                        {
                            theme: p,
                            isCollapsed: h
                        } = oO(),
                        m = q(p.collapse, i);
                    return (0, d.useEffect)(() => b(l), [l]), (0, s.jsxs)(({
                        children: e
                    }) => (0, s.jsx)("li", {
                        children: h && !f ? (0, s.jsx)(oB, {
                            content: n,
                            placement: "right",
                            children: e
                        }) : e
                    }), {
                        children: [(0, s.jsxs)("button", {
                            id: `flowbite-sidebar-collapse-${g}`,
                            onClick: () => b(!f),
                            title: n,
                            type: "button",
                            className: H(m.button, t),
                            ...c,
                            children: [r && (0, s.jsx)(r, {
                                "aria-hidden": !0,
                                "data-testid": "flowbite-sidebar-collapse-icon",
                                className: H(m.icon.base, m.icon.open[f ? "on" : "off"])
                            }), h ? (0, s.jsx)("span", {
                                className: "sr-only",
                                children: n
                            }) : (0, s.jsxs)(s.Fragment, {
                                children: [(0, s.jsx)("span", {
                                    "data-testid": "flowbite-sidebar-collapse-label",
                                    className: m.label.base,
                                    children: n
                                }), a ? a(m, f) : (0, s.jsx)(o, {
                                    "aria-hidden": !0,
                                    className: H(m.label.icon.base, m.label.icon.open[f ? "on" : "off"])
                                })]
                            })]
                        }), (0, s.jsx)("ul", {
                            "aria-labelledby": `flowbite-sidebar-collapse-${g}`,
                            hidden: !f,
                            className: m.list,
                            children: (0, s.jsx)(oW.Provider, {
                                value: {
                                    isInsideCollapse: !0
                                },
                                children: e
                            })
                        })]
                    })
                };
            o_.displayName = "Sidebar.Collapse";
            let oY = ({
                    id: e,
                    theme: t,
                    isCollapsed: r,
                    tooltipChildren: n,
                    children: o,
                    ...a
                }) => (0, s.jsx)("li", { ...a,
                    children: r ? (0, s.jsx)(oB, {
                        content: (0, s.jsx)(oG, {
                            id: e,
                            theme: t,
                            children: n
                        }),
                        placement: "right",
                        children: o
                    }) : o
                }),
                oG = ({
                    id: e,
                    theme: t,
                    children: r
                }) => (0, s.jsx)("span", {
                    "data-testid": "flowbite-sidebar-item-content",
                    id: `flowbite-sidebar-item-${e}`,
                    className: H(t.content.base),
                    children: r
                }),
                oH = (0, d.forwardRef)(({
                    active: e,
                    as: t = "a",
                    children: r,
                    className: n,
                    icon: o,
                    label: a,
                    labelColor: l = "info",
                    theme: i = {},
                    ...c
                }, u) => {
                    let g = (0, d.useId)(),
                        {
                            theme: f,
                            isCollapsed: b
                        } = oO(),
                        {
                            isInsideCollapse: p
                        } = function() {
                            let e = (0, d.useContext)(oW);
                            if (!e) throw Error("useSidebarItemContext should be used within the SidebarItemContext provider!");
                            return e
                        }(),
                        h = q(f.item, i);
                    return (0, s.jsx)(oY, {
                        theme: h,
                        className: h.listItem,
                        id: g,
                        isCollapsed: b,
                        tooltipChildren: r,
                        children: (0, s.jsxs)(t, {
                            "aria-labelledby": `flowbite-sidebar-item-${g}`,
                            ref: u,
                            className: H(h.base, e && h.active, !b && p && h.collapsed ? .insideCollapse, n),
                            ...c,
                            children: [o && (0, s.jsx)(o, {
                                "aria-hidden": !0,
                                "data-testid": "flowbite-sidebar-item-icon",
                                className: H(h.icon ? .base, e && h.icon ? .active)
                            }), b && !o && (0, s.jsx)("span", {
                                className: h.collapsed ? .noIcon,
                                children: r.charAt(0).toLocaleUpperCase() ? ? "?"
                            }), !b && (0, s.jsx)(oG, {
                                id: g,
                                theme: h,
                                children: r
                            }), !b && a && (0, s.jsx)(ei, {
                                color: l,
                                "data-testid": "flowbite-sidebar-label",
                                hidden: b,
                                className: h.label,
                                children: a
                            })]
                        })
                    })
                });
            oH.displayName = "Sidebar.Item";
            let o$ = ({
                children: e,
                className: t,
                theme: r = {},
                ...n
            }) => {
                let {
                    theme: o
                } = oO(), a = q(o.itemGroup, r);
                return (0, s.jsx)("ul", {
                    "data-testid": "flowbite-sidebar-item-group",
                    className: H(a.base, t),
                    ...n,
                    children: (0, s.jsx)(oW.Provider, {
                        value: {
                            isInsideCollapse: !1
                        },
                        children: e
                    })
                })
            };
            o$.displayName = "Sidebar.ItemGroup";
            let oU = ({
                children: e,
                className: t,
                theme: r = {},
                ...n
            }) => {
                let {
                    theme: o
                } = oO(), a = q(o.items, r);
                return (0, s.jsx)("div", {
                    className: H(a.base, t),
                    "data-testid": "flowbite-sidebar-items",
                    ...n,
                    children: e
                })
            };
            oU.displayName = "Sidebar.Items";
            let oq = ({
                children: e,
                className: t,
                href: r,
                img: n,
                imgAlt: o = "",
                theme: a = {},
                ...l
            }) => {
                let i = (0, d.useId)(),
                    {
                        theme: c,
                        isCollapsed: u
                    } = oO(),
                    g = q(c.logo, a);
                return (0, s.jsxs)("a", {
                    "aria-labelledby": `flowbite-sidebar-logo-${i}`,
                    href: r,
                    className: H(g.base, t),
                    ...l,
                    children: [(0, s.jsx)("img", {
                        alt: o,
                        src: n,
                        className: g.img
                    }), (0, s.jsx)("span", {
                        className: g.collapsed[u ? "on" : "off"],
                        id: `flowbite-sidebar-logo-${i}`,
                        children: e
                    })]
                })
            };
            oq.displayName = "Sidebar.Logo";
            let oK = ({
                children: e,
                as: t = "nav",
                collapseBehavior: r = "collapse",
                collapsed: n = !1,
                theme: o = {},
                className: a,
                ...l
            }) => {
                let i = q(Z().sidebar, o);
                return (0, s.jsx)(oz.Provider, {
                    value: {
                        theme: i,
                        isCollapsed: n
                    },
                    children: (0, s.jsx)(t, {
                        "aria-label": "Sidebar",
                        hidden: n && "hide" === r,
                        className: H(i.root.base, i.root.collapsed[n ? "on" : "off"], a),
                        ...l,
                        children: (0, s.jsx)("div", {
                            className: i.root.inner,
                            children: e
                        })
                    })
                })
            };
            oK.displayName = "Sidebar", Object.assign(oK, {
                Collapse: o_,
                CTA: oA,
                Item: oH,
                Items: oU,
                ItemGroup: o$,
                Logo: oq
            });
            let oV = (0, d.createContext)(void 0),
                oX = (0, d.createContext)(void 0);

            function oZ() {
                let e = (0, d.useContext)(oX);
                if (!e) throw Error("useTableContext should be used within the TableContext provider!");
                return e
            }
            let oQ = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = oZ(), a = q(o.body, r);
                    return (0, s.jsx)(oV.Provider, {
                        value: {
                            theme: a
                        },
                        children: (0, s.jsx)("tbody", {
                            className: H(a.base, t),
                            ...n,
                            children: e
                        })
                    })
                },
                oJ = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = function() {
                        let e = (0, d.useContext)(oV);
                        if (!e) throw Error("useTableBodyContext should be used within the TableBodyContext provider!");
                        return e
                    }(), a = q(o.cell, r);
                    return (0, s.jsx)("td", {
                        className: H(a.base, t),
                        ...n,
                        children: e
                    })
                },
                o0 = (0, d.createContext)(void 0),
                o1 = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = oZ(), a = q(o.head, r);
                    return (0, s.jsx)(o0.Provider, {
                        value: {
                            theme: a
                        },
                        children: (0, s.jsx)("thead", {
                            className: H(a.base, t),
                            ...n,
                            children: (0, s.jsx)("tr", {
                                children: e
                            })
                        })
                    })
                },
                o5 = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = function() {
                        let e = (0, d.useContext)(o0);
                        if (!e) throw Error("useTableHeadContext should be used within the TableHeadContext provider!");
                        return e
                    }(), a = q(o.cell, r);
                    return (0, s.jsx)("th", {
                        className: H(a.base, t),
                        ...n,
                        children: e
                    })
                },
                o2 = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o,
                        hoverable: a,
                        striped: l
                    } = oZ(), i = q(o.row, r);
                    return (0, s.jsx)("tr", {
                        "data-testid": "table-row-element",
                        className: H(i.base, l && i.striped, a && i.hovered, t),
                        ...n,
                        children: e
                    })
                },
                o4 = ({
                    children: e,
                    className: t,
                    striped: r,
                    hoverable: n,
                    theme: o = {},
                    ...a
                }) => {
                    let l = q(Z().table, o);
                    return (0, s.jsx)("div", {
                        "data-testid": "table-element",
                        className: H(l.root.wrapper),
                        children: (0, s.jsxs)(oX.Provider, {
                            value: {
                                theme: l,
                                striped: r,
                                hoverable: n
                            },
                            children: [(0, s.jsx)("div", {
                                className: H(l.root.shadow, t)
                            }), (0, s.jsx)("table", {
                                className: H(l.root.base, t),
                                ...a,
                                children: e
                            })]
                        })
                    })
                };
            o4.displayName = "Table", o1.displayName = "Table.Head", oQ.displayName = "Table.Body", o2.displayName = "Table.Row", oJ.displayName = "Table.Cell", o5.displayName = "Table.HeadCell", Object.assign(o4, {
                Head: o1,
                Body: oQ,
                Row: o2,
                Cell: oJ,
                HeadCell: o5
            });
            let o6 = ({
                children: e,
                className: t
            }) => (0, s.jsx)("div", {
                className: t,
                children: e
            });
            o6.displayName = "Tabs.Item";
            let o7 = (0, d.forwardRef)(({
                children: e,
                className: t,
                onActiveTabChange: r,
                style: n = "default",
                theme: o = {},
                ...a
            }, l) => {
                let i = q(Z().tabs, o),
                    c = (0, d.useId)(),
                    u = (0, d.useMemo)(() => d.Children.map(d.Children.toArray(e), ({
                        props: e
                    }) => e), [e]),
                    g = (0, d.useRef)([]),
                    [f, b] = (0, d.useState)(Math.max(0, u.findIndex(e => e.active))),
                    [p, h] = (0, d.useState)(-1),
                    m = e => {
                        b(e), r && r(e)
                    },
                    y = ({
                        target: e
                    }) => {
                        m(e), h(e)
                    },
                    x = ({
                        event: e,
                        target: t
                    }) => {
                        "ArrowLeft" === e.key && h(Math.max(0, p - 1)), "ArrowRight" === e.key && h(Math.min(u.length - 1, p + 1)), "Enter" === e.key && (m(t), h(t))
                    },
                    v = i.tablist.tabitem.styles[n],
                    w = i.tabitemcontainer.styles[n];
                return (0, d.useEffect)(() => {
                    g.current[p] ? .focus()
                }, [p]), (0, d.useImperativeHandle)(l, () => ({
                    setActiveTab: m
                })), (0, s.jsxs)("div", {
                    className: H(i.base, t),
                    children: [(0, s.jsx)("div", {
                        "aria-label": "Tabs",
                        role: "tablist",
                        className: H(i.tablist.base, i.tablist.styles[n], t),
                        ...a,
                        children: u.map((e, t) => (0, s.jsxs)("button", {
                            type: "button",
                            "aria-controls": `${c}-tabpanel-${t}`,
                            "aria-selected": t === f,
                            className: H(i.tablist.tabitem.base, v.base, t === f && v.active.on, t !== f && !e.disabled && v.active.off),
                            disabled: e.disabled,
                            id: `${c}-tab-${t}`,
                            onClick: () => y({
                                target: t
                            }),
                            onKeyDown: e => x({
                                event: e,
                                target: t
                            }),
                            ref: e => g.current[t] = e,
                            role: "tab",
                            tabIndex: t === p ? 0 : -1,
                            style: {
                                zIndex: t === p ? 2 : 1
                            },
                            children: [e.icon && (0, s.jsx)(e.icon, {
                                className: i.tablist.tabitem.icon
                            }), e.title]
                        }, t))
                    }), (0, s.jsx)("div", {
                        className: H(i.tabitemcontainer.base, w),
                        children: u.map((e, t) => (0, s.jsx)("div", {
                            "aria-labelledby": `${c}-tab-${t}`,
                            className: i.tabpanel,
                            hidden: t !== f,
                            id: `${c}-tabpanel-${t}`,
                            role: "tabpanel",
                            tabIndex: 0,
                            children: e.children
                        }, t))
                    })]
                })
            });
            o7.displayName = "Tabs", Object.assign(o7, {
                Item: o6
            });
            let o9 = (0, d.forwardRef)(({
                className: e,
                color: t = "gray",
                helperText: r,
                shadow: n,
                theme: o = {},
                ...a
            }, l) => {
                let i = q(Z().textarea, o);
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("textarea", {
                        ref: l,
                        className: H(i.base, i.colors[t], i.withShadow[n ? "on" : "off"], e),
                        ...a
                    }), r && (0, s.jsx)(eW, {
                        color: t,
                        children: r
                    })]
                })
            });
            o9.displayName = "Textarea";
            let o3 = (0, d.createContext)(void 0);

            function o8() {
                let e = (0, d.useContext)(o3);
                if (!e) throw Error("useTimelineContentContext should be used within the TimelineContentContext provider!");
                return e
            }
            let ae = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = o8(), a = q(o.body, r);
                    return (0, s.jsx)("div", {
                        className: H(a.base, t),
                        ...n,
                        children: e
                    })
                },
                at = (0, d.createContext)(void 0);

            function ar() {
                let e = (0, d.useContext)(at);
                if (!e) throw Error("useTimelineContext should be used within the TimelineContext provider!");
                return e
            }
            let an = (0, d.createContext)(void 0);

            function ao() {
                let e = (0, d.useContext)(an);
                if (!e) throw Error("useTimelineItemContext should be used within the TimelineItemContext provider!");
                return e
            }
            let aa = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        horizontal: o
                    } = ar(), {
                        theme: a
                    } = ao(), l = q(a.content, r);
                    return (0, s.jsx)(o3.Provider, {
                        value: {
                            theme: l
                        },
                        children: (0, s.jsx)("div", {
                            "data-testid": "timeline-content",
                            className: H(o && l.root.base, t),
                            ...n,
                            children: e
                        })
                    })
                },
                al = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o,
                        horizontal: a
                    } = ar(), l = q(o.item, r);
                    return (0, s.jsx)(an.Provider, {
                        value: {
                            theme: l
                        },
                        children: (0, s.jsx)("li", {
                            "data-testid": "timeline-item",
                            className: H(a && l.root.horizontal, !a && l.root.vertical, t),
                            ...n,
                            children: e
                        })
                    })
                },
                ai = ({
                    children: e,
                    className: t,
                    icon: r,
                    theme: n = {},
                    ...o
                }) => {
                    let {
                        horizontal: a
                    } = ar(), {
                        theme: l
                    } = ao(), i = q(l.point, n);
                    return (0, s.jsxs)("div", {
                        "data-testid": "timeline-point",
                        className: H(a && i.horizontal, !a && i.vertical, t),
                        ...o,
                        children: [e, r ? (0, s.jsx)("span", {
                            className: H(i.marker.icon.wrapper),
                            children: (0, s.jsx)(r, {
                                "aria-hidden": !0,
                                className: H(i.marker.icon.base)
                            })
                        }) : (0, s.jsx)("div", {
                            className: H(a && i.marker.base.horizontal, !a && i.marker.base.vertical)
                        }), a && (0, s.jsx)("div", {
                            className: H(i.line)
                        })]
                    })
                },
                as = ({
                    children: e,
                    className: t,
                    theme: r = {},
                    ...n
                }) => {
                    let {
                        theme: o
                    } = o8(), a = q(o.time, r);
                    return (0, s.jsx)("time", {
                        className: H(a.base, t),
                        ...n,
                        children: e
                    })
                },
                ad = ({
                    as: e = "h3",
                    children: t,
                    className: r,
                    theme: n = {},
                    ...o
                }) => {
                    let {
                        theme: a
                    } = o8(), l = q(a.title, n);
                    return (0, s.jsx)(e, {
                        className: H(l.base, r),
                        ...o,
                        children: t
                    })
                },
                ac = ({
                    children: e,
                    className: t,
                    horizontal: r,
                    theme: n = {},
                    ...o
                }) => {
                    let a = q(Z().timeline, n);
                    return (0, s.jsx)(at.Provider, {
                        value: {
                            theme: a,
                            horizontal: r
                        },
                        children: (0, s.jsx)("ol", {
                            "data-testid": "timeline-component",
                            className: H(r && a.root.direction.horizontal, !r && a.root.direction.vertical, t),
                            ...o,
                            children: e
                        })
                    })
                };
            ac.displayName = "Timeline", al.displayName = "Timeline.Item", ai.displayName = "Timeline.Point", aa.displayName = "Timeline.Content", as.displayName = "Timeline.Time", ad.displayName = "Timeline.Title", ae.displayName = "Timeline.Body", Object.assign(ac, {
                Item: al,
                Point: ai,
                Content: aa,
                Time: as,
                Title: ad,
                Body: ae
            });
            let au = (0, d.createContext)(void 0),
                ag = ({
                    className: e,
                    onClick: t,
                    theme: r = {},
                    xIcon: n = u.apv,
                    onDismiss: o,
                    ...a
                }) => {
                    let {
                        theme: l,
                        duration: i,
                        isClosed: c,
                        isRemoved: g,
                        setIsClosed: f,
                        setIsRemoved: b
                    } = function() {
                        let e = (0, d.useContext)(au);
                        if (!e) throw Error("useToastContext should be used within the ToastContext provider!");
                        return e
                    }(), p = q(l.toggle, r);
                    return (0, s.jsx)("button", {
                        "aria-label": "Close",
                        onClick: e => {
                            if (t && t(e), o) {
                                o();
                                return
                            }
                            f(!c), setTimeout(() => b(!g), i)
                        },
                        type: "button",
                        className: H(p.base, e),
                        ...a,
                        children: (0, s.jsx)(n, {
                            "aria-hidden": !0,
                            className: p.icon
                        })
                    })
                },
                af = {
                    75: "duration-75",
                    100: "duration-100",
                    150: "duration-150",
                    200: "duration-200",
                    300: "duration-300",
                    500: "duration-500",
                    700: "duration-700",
                    1e3: "duration-1000"
                },
                ab = ({
                    children: e,
                    className: t,
                    duration: r = 300,
                    theme: n = {},
                    ...o
                }) => {
                    let [a, l] = (0, d.useState)(!1), [i, c] = (0, d.useState)(!1), u = q(Z().toast, n);
                    return i ? null : (0, s.jsx)(au.Provider, {
                        value: {
                            theme: u,
                            duration: r,
                            isClosed: a,
                            isRemoved: i,
                            setIsClosed: l,
                            setIsRemoved: c
                        },
                        children: (0, s.jsx)("div", {
                            "data-testid": "flowbite-toast",
                            role: "alert",
                            className: H(u.root.base, af[r], a && u.root.closed, t),
                            ...o,
                            children: e
                        })
                    })
                };
            ab.displayName = "Toast", ag.displayName = "Toast.Toggle";
            let ap = Object.assign(ab, {
                Toggle: ag
            })
        },
        5347: function(e, t, r) {
            r.d(t, {
                w_: function() {
                    return s
                }
            });
            var n = r(2386),
                o = {
                    color: void 0,
                    size: void 0,
                    className: void 0,
                    style: void 0,
                    attr: void 0
                },
                a = n.createContext && n.createContext(o),
                l = function() {
                    return (l = Object.assign || function(e) {
                        for (var t, r = 1, n = arguments.length; r < n; r++)
                            for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }).apply(this, arguments)
                },
                i = function(e, t) {
                    var r = {};
                    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && 0 > t.indexOf(n) && (r[n] = e[n]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var o = 0, n = Object.getOwnPropertySymbols(e); o < n.length; o++) 0 > t.indexOf(n[o]) && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]]);
                    return r
                };

            function s(e) {
                return function(t) {
                    return n.createElement(d, l({
                        attr: l({}, e.attr)
                    }, t), function e(t) {
                        return t && t.map(function(t, r) {
                            return n.createElement(t.tag, l({
                                key: r
                            }, t.attr), e(t.child))
                        })
                    }(e.child))
                }
            }

            function d(e) {
                var t = function(t) {
                    var r, o = e.attr,
                        a = e.size,
                        s = e.title,
                        d = i(e, ["attr", "size", "title"]),
                        c = a || t.size || "1em";
                    return t.className && (r = t.className), e.className && (r = (r ? r + " " : "") + e.className), n.createElement("svg", l({
                        stroke: "currentColor",
                        fill: "currentColor",
                        strokeWidth: "0"
                    }, t.attr, o, d, {
                        className: r,
                        style: l(l({
                            color: e.color || t.color
                        }, t.style), e.style),
                        height: c,
                        width: c,
                        xmlns: "http://www.w3.org/2000/svg"
                    }), s && n.createElement("title", null, s), e.children)
                };
                return void 0 !== a ? n.createElement(a.Consumer, null, function(e) {
                    return t(e)
                }) : t(o)
            }
        }
    }
]);