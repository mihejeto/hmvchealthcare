(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1893], {
        4538: function(n, e, t) {
            Promise.resolve().then(t.bind(t, 6983))
        },
        6987: function(n, e, t) {
            "use strict";
            t.d(e, {
                F: function() {
                    return u
                }
            });
            var s = t(2066),
                i = t(2846),
                a = t(4426);

            function r() {
                let n = (0, s._)(["\n  query Query($siteUrl: String!) {\n    checkDraftDuplicateSiteUrl(siteUrl: $siteUrl)\n  }\n"]);
                return r = function() {
                    return n
                }, n
            }
            let o = (0, a.Ps)(r()),
                l = null,
                u = async n => (null == l || l.abort(), l = new AbortController, (0, i.S)({
                    signal: l.signal
                }).request(o, {
                    siteUrl: n
                }))
        },
        9223: function(n, e, t) {
            "use strict";
            t.d(e, {
                D: function() {
                    return l
                }
            });
            var s = t(2066),
                i = t(2846),
                a = t(4426);

            function r() {
                let n = (0, s._)(["\n  query Query {\n    loadWebPageDraft {\n      contactMenu {\n        title\n        description\n        requiredPhoneNumber\n        requiredYourMessage\n        showPhoneNumber\n        showYourMessage\n      }\n      ctaMenu {\n        button {\n          isEnable\n          link\n          placeholder\n          text\n          type\n        }\n        description\n        heading\n        showCta\n        subheading\n      }\n      customMenu {\n        businessName\n        customCode\n        googleAnalytics4\n        googleTagManager\n        siteUrl\n      }\n      faqMenu {\n        questions {\n          answer\n          isEnable\n          question\n        }\n        showFaq\n      }\n      headerMenu {\n        logo\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n        phoneNumber {\n          isEnable\n          phoneNumber\n        }\n        siteName\n        socialIcons {\n          icons {\n            iconName\n            iconSrc\n            linkSrc\n            provider\n          }\n          isEnable\n        }\n      }\n      introMenu {\n        heading\n        imageDescription\n        imageSrc {\n          small\n          regular\n          downloadLocation\n          userHtml\n          username\n        }\n        subheading\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n      }\n      locationMenu {\n        address\n        heading\n        showLocation\n        showSubheading\n        subheading\n        lat\n        lng\n      }\n      quoteMenu {\n        quotos {\n          imageDescription\n          label\n          name\n          profileImageSrc {\n            thumb\n            downloadLocation\n            userHtml\n            username\n          }\n          showFiveStarRating\n          showQuote\n          text\n        }\n      }\n      serviceMenu {\n        services {\n          heading\n          imageDescription\n          description\n          imageSrc {\n            small\n            regular\n            downloadLocation\n            userHtml\n            username\n          }\n          button {\n            isEnable\n            text\n            link\n            type\n          }\n        }\n      }\n      webSiteMenu {\n        faviconSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        logoSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        seoDescription\n        seoTitle\n        siteName\n        showFooterLink\n        socialImageSrc {\n          small\n          downloadLocation\n          userHtml\n          username\n        }\n      }\n    }\n  }\n"]);
                return r = function() {
                    return n
                }, n
            }
            let o = (0, a.Ps)(r()),
                l = async () => (0, i.S)().request(o)
        },
        661: function(n, e, t) {
            "use strict";
            t.d(e, {
                s: function() {
                    return l
                }
            });
            var s = t(2066),
                i = t(2846),
                a = t(4426);

            function r() {
                let n = (0, s._)(["\n  mutation SaveWebPageDraft($input: IDraft!) {\n    saveWebPageDraft(input: $input) {\n      contactMenu {\n        title\n        description\n        requiredPhoneNumber\n        requiredYourMessage\n        showPhoneNumber\n        showYourMessage\n      }\n      ctaMenu {\n        button {\n          isEnable\n          link\n          placeholder\n          text\n          type\n        }\n        description\n        heading\n        showCta\n        subheading\n      }\n      customMenu {\n        businessName\n        customCode\n        googleAnalytics4\n        googleTagManager\n        siteUrl\n      }\n      faqMenu {\n        questions {\n          answer\n          isEnable\n          question\n        }\n        showFaq\n      }\n      headerMenu {\n        logo\n        phoneNumber {\n          isEnable\n          phoneNumber\n        }\n        siteName\n        socialIcons {\n          icons {\n            iconName\n            iconSrc\n            linkSrc\n            provider\n          }\n          isEnable\n        }\n      }\n      introMenu {\n        heading\n        imageDescription\n        imageSrc {\n          small\n          downloadLocation\n          userHtml\n          username\n        }\n        subheading\n        button {\n          isEnable\n          link\n          placeholder\n          text\n          type\n        }\n      }\n      locationMenu {\n        address\n        heading\n        showLocation\n        showSubheading\n        subheading\n        lat\n        lng\n      }\n      quoteMenu {\n        quotos {\n          imageDescription\n          label\n          name\n          profileImageSrc {\n            thumb\n            downloadLocation\n            userHtml\n            username\n          }\n          showFiveStarRating\n          showQuote\n          text\n        }\n      }\n      serviceMenu {\n        services {\n          button {\n            isEnable\n            link\n            placeholder\n            text\n            type\n          }\n          description\n          heading\n          imageDescription\n          isEnable\n        }\n      }\n      webSiteMenu {\n        faviconSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        logoSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        seoDescription\n        seoTitle\n        siteName\n        socialImageSrc {\n          small\n\n          downloadLocation\n          userHtml\n          username\n        }\n      }\n    }\n  }\n"]);
                return r = function() {
                    return n
                }, n
            }
            let o = (0, a.Ps)(r()),
                l = n => (0, i.S)().request(o, {
                    input: n
                })
        },
        4703: function(n, e, t) {
            "use strict";
            t.d(e, {
                d: function() {
                    return l
                }
            });
            var s = t(2066),
                i = t(2846),
                a = t(4426);

            function r() {
                let n = (0, s._)(["\n  mutation Mutation {\n    saveWebPageMenus {\n      contactMenu {\n        title\n        description\n        requiredPhoneNumber\n        requiredYourMessage\n        showPhoneNumber\n        showYourMessage\n      }\n      ctaMenu {\n        button {\n          isEnable\n          link\n          placeholder\n          text\n          type\n        }\n        description\n        heading\n        showCta\n        subheading\n      }\n      customMenu {\n        businessName\n        customCode\n        googleAnalytics4\n        googleTagManager\n        siteUrl\n      }\n      faqMenu {\n        questions {\n          answer\n          isEnable\n          question\n        }\n        showFaq\n      }\n      headerMenu {\n        logo\n        phoneNumber {\n          isEnable\n          phoneNumber\n        }\n        siteName\n        socialIcons {\n          icons {\n            iconName\n            iconSrc\n            linkSrc\n            provider\n          }\n          isEnable\n        }\n      }\n      introMenu {\n        heading\n        imageDescription\n        imageSrc {\n          small\n          downloadLocation\n          userHtml\n          username\n        }\n        subheading\n        button {\n          isEnable\n          link\n          placeholder\n          text\n          type\n        }\n      }\n      locationMenu {\n        address\n        heading\n        showLocation\n        showSubheading\n        subheading\n        lat\n        lng\n      }\n      quoteMenu {\n        quotos {\n          imageDescription\n          label\n          name\n          profileImageSrc {\n            thumb\n            downloadLocation\n            userHtml\n            username\n          }\n          showFiveStarRating\n          showQuote\n          text\n        }\n      }\n      serviceMenu {\n        services {\n          button {\n            isEnable\n            link\n            placeholder\n            text\n            type\n          }\n          description\n          heading\n          imageDescription\n          isEnable\n        }\n      }\n      webSiteMenu {\n        faviconSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        logoSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        seoDescription\n        seoTitle\n        siteName\n        socialImageSrc {\n          small\n\n          downloadLocation\n          userHtml\n          username\n        }\n      }\n    }\n  }\n"]);
                return r = function() {
                    return n
                }, n
            }
            let o = (0, a.Ps)(r()),
                l = () => (0, i.S)().request(o)
        },
        6619: function(n, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                default: function() {
                    return l
                }
            });
            var s = t(5689),
                i = t(8244),
                a = t.n(i),
                r = t(8720),
                o = t(3532);

            function l(n) {
                let {
                    handleError: e = () => {
                        window.history.back()
                    },
                    buttonText: t = "Go back",
                    helpText: i = "Oops, something went wrong!"
                } = n;
                return (0, s.jsxs)("div", {
                    className: "mx-auto flex h-screen flex-col items-center justify-center px-6 xl:px-0",
                    children: [(0, s.jsx)("div", {
                        className: "block md:max-w-lg",
                        children: (0, s.jsx)(a(), {
                            src: r.Z,
                            alt: "astronaut image",
                            title: "astronaut image",
                            className: "align-middle",
                            style: {
                                height: "auto",
                                maxWidth: "100%"
                            },
                            width: 0,
                            height: 0
                        })
                    }), (0, s.jsxs)("div", {
                        className: "max-w-md text-center xl:max-w-4xl",
                        children: [(0, s.jsx)("h1", {
                            className: "mb-3 block text-2xl font-bold leading-8 text-gray-900 sm:text-4xl sm:leading-10 ",
                            children: i
                        }), (0, s.jsx)("p", {
                            className: " mb-5 text-base font-normal leading-6 text-gray-500 md:text-lg md:leading-7",
                            children: "Well this is embarrassing but something broke. Hit the button below to go back and try again."
                        }), (0, s.jsx)("div", {
                            className: "inline-block",
                            children: (0, s.jsx)(o.Z, {
                                text: t,
                                buttonSize: "base",
                                iconStyle: (0, s.jsx)("svg", {
                                    "aria-hidden": "true",
                                    className: "ml-[-.25rem] mr-2 h-5 w-5",
                                    fill: "currentColor",
                                    viewBox: "0 0 20 20",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: (0, s.jsx)("path", {
                                        fillRule: "evenodd",
                                        d: "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z",
                                        clipRule: "evenodd"
                                    })
                                }),
                                iconDirection: "left",
                                onClick: () => {
                                    e()
                                }
                            })
                        })]
                    })]
                })
            }
        },
        6983: function(n, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                BusinessName: function() {
                    return k
                }
            });
            var s = t(5689),
                i = t(2386),
                a = t(5041),
                r = t(7637),
                o = t(5324),
                l = t(1703),
                u = t(6619),
                c = t(661),
                d = t(4703),
                m = t(6612),
                h = t(7305),
                g = t(7323),
                b = t(8244),
                w = t.n(b),
                x = t(3911),
                f = t.n(x),
                p = t(3532),
                v = t(4886),
                A = {
                    src: "https://builder.bookipi.com/_next/static/media/onboarding-2.0a253973.png",
                    height: 1025,
                    width: 434,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAMAAAALMbVOAAAAJFBMVEVpUERZSUZmVlCCbmdjWVdlXF4xKi1MQD9FQ0hTODFqSDWHWD55fASVAAAAAXRSTlP+GuMHfQAAAAlwSFlzAAALEwAACxMBAJqcGAAAACRJREFUeJwFwYcBADAIwzCHDf3/30o8ht1A1nQIc2PkVB2Z/gEHzQB2ZpAMawAAAABJRU5ErkJggg==",
                    blurWidth: 3,
                    blurHeight: 8
                };

            function y(n) {
                let {
                    onSubmit: e,
                    businessName: t
                } = n;
                return (0, s.jsx)("div", {
                    className: "bg-white py-8 dark:bg-gray-900 lg:py-0",
                    children: (0, s.jsxs)("div", {
                        className: "lg:flex",
                        children: [(0, s.jsx)("aside", {
                            className: "hidden w-full max-w-md items-center justify-center overflow-hidden bg-white lg:flex lg:h-screen",
                            children: (0, s.jsx)(w(), {
                                src: A.src,
                                width: 0,
                                height: 0,
                                className: "h-auto min-h-full w-auto min-w-full flex-shrink-0 object-cover",
                                alt: "a window with a sign on it"
                            })
                        }), (0, s.jsx)("section", {
                            className: "mx-auto flex items-center px-4 md:w-[42rem] md:px-8 xl:px-0",
                            children: (0, s.jsxs)("div", {
                                className: "w-full",
                                children: [(0, s.jsx)("div", {
                                    className: "mb-8 flex items-center justify-center space-x-4 lg:hidden",
                                    children: (0, s.jsx)("a", {
                                        href: "#",
                                        className: "flex items-center text-2xl font-semibold"
                                    })
                                }), (0, s.jsxs)("form", {
                                    onSubmit: e,
                                    children: [(0, s.jsxs)(f(), {
                                        href: "/about",
                                        className: "hover:gray-500 mb-6 inline-flex items-center text-base font-normal text-gray-500",
                                        children: [(0, s.jsx)("svg", {
                                            "aria-hidden": "true",
                                            className: "mr-1 h-6 w-6",
                                            fill: "currentColor",
                                            viewBox: "0 0 20 20",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: (0, s.jsx)("path", {
                                                fillRule: "evenodd",
                                                d: "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z",
                                                clipRule: "evenodd"
                                            })
                                        }), "Back"]
                                    }), (0, s.jsx)("h1", {
                                        className: "mb-4 text-2xl font-semibold leading-tight tracking-tight text-gray-900 dark:text-white sm:mb-6",
                                        children: "What's your business name?"
                                    }), (0, s.jsx)("div", {
                                        className: "mb-6",
                                        children: (0, s.jsx)(v.Z, {
                                            placeholder: "Enter your business name",
                                            label: "Enter your business name",
                                            id: "business-name",
                                            defaultValue: t,
                                            type: "text",
                                            iconStyle: (0, s.jsx)("svg", {
                                                width: "14",
                                                height: "17",
                                                viewBox: "0 0 14 17",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: (0, s.jsx)("path", {
                                                    d: "M12.5 14.5V15H13C13.1326 15 13.2598 15.0527 13.3536 15.1464C13.4473 15.2402 13.5 15.3674 13.5 15.5C13.5 15.6326 13.4473 15.7598 13.3536 15.8536C13.2598 15.9473 13.1326 16 13 16H10C9.86739 16 9.74021 15.9473 9.64645 15.8536C9.55268 15.7598 9.5 15.6326 9.5 15.5V13.5C9.5 13.1022 9.34196 12.7206 9.06066 12.4393C8.77936 12.158 8.39783 12 8 12H6C5.60218 12 5.22064 12.158 4.93934 12.4393C4.65804 12.7206 4.5 13.1022 4.5 13.5V15.5C4.5 15.6326 4.44732 15.7598 4.35355 15.8536C4.25979 15.9473 4.13261 16 4 16H1C0.867391 16 0.740214 15.9473 0.646446 15.8536C0.552679 15.7598 0.5 15.6326 0.5 15.5C0.5 15.3674 0.552679 15.2402 0.646446 15.1464C0.740214 15.0527 0.867391 15 1 15H1.5V14.5V2.5C1.5 2.10218 1.65804 1.72064 1.93934 1.43934C2.22064 1.15804 2.60218 1 3 1H11C11.3978 1 11.7794 1.15804 12.0607 1.43934C12.342 1.72064 12.5 2.10218 12.5 2.5V14.5ZM4 3H3.5V3.5V5.5V6H4H6H6.5V5.5V3.5V3H6H4ZM6.5 7.5V7H6H4H3.5V7.5V9.5V10H4H6H6.5V9.5V7.5ZM8 3H7.5V3.5V5.5V6H8H10H10.5V5.5V3.5V3H10H8ZM10.5 7.5V7H10H8H7.5V7.5V9.5V10H8H10H10.5V9.5V7.5Z",
                                                    fill: "#6B7280",
                                                    stroke: "#6B7280"
                                                })
                                            }),
                                            autoFocus: !0
                                        })
                                    }), (0, s.jsx)(p.Z, {
                                        text: "Create Website for Free",
                                        textTransform: "normal-case",
                                        buttonSize: "l",
                                        type: "submit",
                                        disabled: !1,
                                        className: "create-website-button",
                                        iconStyle: (0, s.jsx)("svg", {
                                            "aria-hidden": "true",
                                            className: "-mr-1 ml-2 h-5 w-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 20 20",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: (0, s.jsx)("path", {
                                                fillRule: "evenodd",
                                                d: "M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z",
                                                clipRule: "evenodd"
                                            })
                                        }),
                                        iconDirection: "right"
                                    })]
                                })]
                            })
                        })]
                    })
                })
            }
            var N = t(6105),
                C = t(3056),
                M = t(4614),
                H = t(9311);

            function S(n) {
                let {
                    businessName: e,
                    onSubmit: t
                } = n, i = (0, a.useSearchParams)(), r = i.get("returnUrl") || "https://bookipi.com/";
                return (0, s.jsxs)("div", {
                    className: "relative flex h-full w-full items-center justify-center bg-gray-100 py-8 dark:bg-gray-900 lg:py-0",
                    children: [(0, s.jsxs)("div", {
                        className: "absolute left-0 top-0 flex w-full justify-between px-[30px] py-7",
                        children: [(0, s.jsx)(f(), {
                            href: "/about?".concat(i),
                            children: (0, s.jsx)(H.J, {
                                className: "bg-white hover:bg-white/70",
                                children: (0, s.jsx)(w(), {
                                    src: N.Z,
                                    alt: "Arrw left icon",
                                    className: "align-middle",
                                    width: 16,
                                    height: 16
                                })
                            })
                        }), (0, s.jsx)(f(), {
                            href: r,
                            children: (0, s.jsx)(H.J, {
                                className: "bg-white hover:bg-white/70",
                                children: (0, s.jsx)(w(), {
                                    src: M.Z,
                                    alt: "Close icon",
                                    className: "align-middle",
                                    width: 16,
                                    height: 16
                                })
                            })
                        })]
                    }), (0, s.jsxs)("section", {
                        className: "flex flex-col items-center gap-8 rounded-lg bg-white p-10 md:w-[47rem]",
                        children: [(0, s.jsx)(H.J, {
                            className: "mx-auto bg-blue-100 p-3",
                            children: (0, s.jsx)(w(), {
                                src: C.Z,
                                alt: "Building icon",
                                className: "align-middle",
                                width: 28,
                                height: 28
                            })
                        }), (0, s.jsx)("h1", {
                            className: "text-center text-2xl font-semibold leading-tight tracking-tight text-gray-900 dark:text-white",
                            children: "What’s your business name?"
                        }), (0, s.jsxs)("form", {
                            onSubmit: t,
                            className: "flex w-full flex-col items-center justify-center gap-8",
                            children: [(0, s.jsxs)("div", {
                                className: "relative w-full",
                                children: [(0, s.jsx)("svg", {
                                    className: "absolute left-3 top-3",
                                    width: "14",
                                    height: "17",
                                    viewBox: "0 0 14 17",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: (0, s.jsx)("path", {
                                        d: "M12.5 14.5V15H13C13.1326 15 13.2598 15.0527 13.3536 15.1464C13.4473 15.2402 13.5 15.3674 13.5 15.5C13.5 15.6326 13.4473 15.7598 13.3536 15.8536C13.2598 15.9473 13.1326 16 13 16H10C9.86739 16 9.74021 15.9473 9.64645 15.8536C9.55268 15.7598 9.5 15.6326 9.5 15.5V13.5C9.5 13.1022 9.34196 12.7206 9.06066 12.4393C8.77936 12.158 8.39783 12 8 12H6C5.60218 12 5.22064 12.158 4.93934 12.4393C4.65804 12.7206 4.5 13.1022 4.5 13.5V15.5C4.5 15.6326 4.44732 15.7598 4.35355 15.8536C4.25979 15.9473 4.13261 16 4 16H1C0.867391 16 0.740214 15.9473 0.646446 15.8536C0.552679 15.7598 0.5 15.6326 0.5 15.5C0.5 15.3674 0.552679 15.2402 0.646446 15.1464C0.740214 15.0527 0.867391 15 1 15H1.5V14.5V2.5C1.5 2.10218 1.65804 1.72064 1.93934 1.43934C2.22064 1.15804 2.60218 1 3 1H11C11.3978 1 11.7794 1.15804 12.0607 1.43934C12.342 1.72064 12.5 2.10218 12.5 2.5V14.5ZM4 3H3.5V3.5V5.5V6H4H6H6.5V5.5V3.5V3H6H4ZM6.5 7.5V7H6H4H3.5V7.5V9.5V10H4H6H6.5V9.5V7.5ZM8 3H7.5V3.5V5.5V6H8H10H10.5V5.5V3.5V3H10H8ZM10.5 7.5V7H10H8H7.5V7.5V9.5V10H8H10H10.5V9.5V7.5Z",
                                        fill: "#6B7280",
                                        stroke: "#6B7280"
                                    })
                                }), (0, s.jsx)("input", {
                                    type: "text",
                                    name: "business-name",
                                    defaultValue: e,
                                    autoFocus: !0,
                                    className: "inline-block w-full rounded-lg border border-gray-300 bg-gray-50 pl-10 text-gray-900 focus:border-blue-500 focus:ring-blue-500   dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                                })]
                            }), (0, s.jsx)("button", {
                                type: "submit",
                                style: {
                                    background: "linear-gradient(95deg, #1C64F2 -8.2%, #5E46EF 87.28%)"
                                },
                                className: "flex h-[56px] w-[372px] items-center justify-center rounded-lg text-base font-semibold text-white",
                                children: "Generate Proposal"
                            })]
                        })]
                    })]
                })
            }
            let j = {
                    description: "Oops, something went wrong!",
                    button: "Go back"
                },
                V = {
                    401: {
                        description: "An error occurred during authentication. Please try again",
                        button: "Go back home"
                    }
                };

            function k() {
                let n = (0, a.useRouter)(),
                    e = (0, l.useToastContext)(),
                    t = (0, r.useBusinessInfo)(),
                    b = (0, m.i)(),
                    w = (0, a.useSearchParams)(),
                    x = w.get("type") || "aiwb",
                    f = x.includes("proposal"),
                    p = (0, o.useDraftPage)(),
                    [v, A] = (0, i.useState)(null),
                    {
                        businessInfo: N
                    } = t,
                    C = async e => {
                        try {
                            let t = {
                                    businessName: e,
                                    businessLocation: N.city ? "".concat(N.city, ", ").concat(N.country) : "".concat(N.country),
                                    businessDescription: N.businessDescription
                                },
                                s = await p.generatePage(t, N.location);
                            if (!f) return n.push("/dashboard");
                            await (0, c.s)(s), await (0, d.d)();
                            let i = w.get("returnUrl");
                            if (i) return window.location.href = i;
                            window.location.href = "https://bookipi.com/"
                        } catch (n) {
                            var t, s;
                            console.error(n), A((null == n ? void 0 : null === (t = n.reponse) || void 0 === t ? void 0 : null === (s = t.errors) || void 0 === s ? void 0 : s.length) ? n.reponse.errors[0].originalError : {
                                message: "Something went wrong, Please try again.",
                                statusCode: 400
                            }), p.setGenerating(!1)
                        }
                    },
                    M = async n => {
                        n.preventDefault();
                        let t = new FormData(n.currentTarget),
                            s = t.get("business-name").trim();
                        if (s) {
                            let n = location.href.includes("proposal");
                            return n ? b.trackEvent("Proposal AI Company Name Entered") : b.trackEvent("Web Builder Onboarding Name Completed"), C(s)
                        }
                        null == e || e.showToast("Please enter your business name or click generate", h.Ix.WARNING)
                    };
                if (v) {
                    var H;
                    let e = null !== (H = V[v.statusCode]) && void 0 !== H ? H : j;
                    return (0, s.jsx)(u.default, {
                        handleError: () => {
                            if (401 === v.statusCode) return n.push("https://web.bookipi.com/");
                            A(null)
                        },
                        buttonText: e.button,
                        helpText: e.description
                    })
                }
                return p.generating ? (0, s.jsx)(g.Z, {}) : f ? (0, s.jsx)(S, {
                    businessName: t.businessInfo.businessName,
                    onSubmit: M
                }) : (0, s.jsx)(y, {
                    businessName: t.businessInfo.businessName,
                    onSubmit: M
                })
            }
        },
        7323: function(n, e, t) {
            "use strict";
            t.d(e, {
                Z: function() {
                    return c
                }
            });
            var s = t(5689),
                i = t(8244),
                a = t.n(i),
                r = {
                    src: "https://builder.bookipi.com/_next/static/media/onboarding-3.73257a46.png",
                    height: 1025,
                    width: 448,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAMAAAALMbVOAAAAG1BMVEUFBwcXFhQfHBgpIBktKSFbSztSPCQQFBM4Mypxzl5EAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIklEQVR4nAXBhwEAMAjDMGcA/f/iSgBUx8RMwD32ia2I/AEEaQBMEsfevAAAAABJRU5ErkJggg==",
                    blurWidth: 3,
                    blurHeight: 8
                },
                o = t(8159),
                l = t(5041);

            function u() {
                let n = (0, l.useSearchParams)(),
                    e = (0, l.usePathname)(),
                    t = n.get("type") || "aiwb",
                    i = [t, e].includes("proposal"),
                    a = i ? o.jq : o.iU;
                return (0, s.jsx)("div", {
                    className: "flex h-full w-full flex-col justify-center",
                    children: (0, s.jsx)("div", {
                        className: "text-center",
                        children: (0, s.jsxs)("div", {
                            role: "status",
                            className: "inline-flex w-full items-center justify-center",
                            children: [(0, s.jsxs)("svg", {
                                "aria-hidden": "true",
                                className: "mr-5 inline h-8 w-8 animate-spin fill-blue-600 text-gray-200 dark:text-gray-600",
                                viewBox: "0 0 100 101",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: [(0, s.jsx)("path", {
                                    d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                                    fill: "currentColor"
                                }), (0, s.jsx)("path", {
                                    d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                                    fill: "currentFill"
                                })]
                            }), (0, s.jsx)("div", {
                                className: "h-8 overflow-hidden",
                                children: a.map(n => (0, s.jsx)("span", {
                                    style: {
                                        animation: "20s 0.7s forwards spin_words"
                                    },
                                    className: "block h-full text-2xl font-semibold text-gray-900",
                                    children: n
                                }, n))
                            })]
                        })
                    })
                })
            }
            var c = () => (0, s.jsx)("div", {
                className: "fixed inset-0 z-50 bg-white py-8 dark:bg-gray-900 lg:py-0",
                children: (0, s.jsxs)("div", {
                    className: "lg:flex",
                    children: [(0, s.jsx)("aside", {
                        className: "hidden w-full max-w-md items-center justify-center overflow-hidden bg-white lg:flex lg:h-screen",
                        children: (0, s.jsx)(a(), {
                            src: r.src,
                            width: 0,
                            height: 0,
                            className: "h-auto min-h-full w-auto min-w-full flex-shrink-0 object-cover",
                            alt: "A person working on a machine"
                        })
                    }), (0, s.jsx)("section", {
                        className: "mx-auto flex items-center px-4 md:w-[42rem] md:px-8 xl:px-0",
                        children: (0, s.jsxs)("div", {
                            className: "h-screen w-full",
                            children: [(0, s.jsx)("div", {
                                className: "mb-8 flex items-center justify-center space-x-4 lg:hidden"
                            }), (0, s.jsx)(u, {})]
                        })
                    })]
                })
            })
        },
        5324: function(n, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                DraftPageContext: function() {
                    return p
                },
                DraftPageContextProvider: function() {
                    return A
                },
                REQUIRED_DASHBOARD_FIELDS: function() {
                    return v
                },
                useDraftPage: function() {
                    return y
                }
            });
            var s = t(5689),
                i = t(2386),
                a = t(8159),
                r = t(9223),
                o = t(2066),
                l = t(4426),
                u = t(2846);

            function c() {
                let n = (0, o._)(["\n  query Query(\n    $businessName: String!\n    $businessLocation: String!\n    $businessDescription: String!\n  ) {\n    generatePage(\n      businessName: $businessName\n      businessLocation: $businessLocation\n      businessDescription: $businessDescription\n    ) {\n      webSiteMenu {\n        siteName\n        logoSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        faviconSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        seoTitle\n        seoDescription\n        socialImageSrc {\n          small\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        showFooterLink\n      }\n      introMenu {\n        heading\n        subheading\n        imageSrc {\n          regular\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n      }\n      serviceMenu {\n        services {\n          heading\n          imageDescription\n          description\n          imageSrc {\n            regular\n            downloadLocation\n            userHtml\n            username\n          }\n          button {\n            isEnable\n            text\n            link\n            type\n          }\n        }\n      }\n      quoteMenu {\n        quotos {\n          showQuote\n          text\n          name\n          label\n          imageDescription\n          profileImageSrc {\n            thumb\n            downloadLocation\n            userHtml\n            username\n          }\n          showFiveStarRating\n        }\n      }\n      faqMenu {\n        showFaq\n        questions {\n          answer\n          question\n        }\n      }\n      headerMenu {\n        logo\n        siteName\n        socialIcons {\n          icons {\n            iconName\n            iconSrc\n            linkSrc\n            provider\n          }\n          isEnable\n        }\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n        phoneNumber {\n          isEnable\n          phoneNumber\n        }\n      }\n      ctaMenu {\n        heading\n        subheading\n        showCta\n        description\n        button {\n          isEnable\n          type\n          text\n          link\n        }\n      }\n      locationMenu {\n        showLocation\n        heading\n        showSubheading\n        subheading\n        address\n        lat\n        lng\n      }\n      customMenu {\n        siteUrl\n        googleAnalytics4\n        googleTagManager\n        customCode\n      }\n      contactMenu {\n        title\n        description\n        showPhoneNumber\n        showYourMessage\n        requiredPhoneNumber\n        requiredYourMessage\n      }\n    }\n  }\n"]);
                return c = function() {
                    return n
                }, n
            }
            let d = (0, l.Ps)(c()),
                m = async n => (0, u.S)().request(d, n);
            var h = t(6987),
                g = t(7105),
                b = t(5794),
                w = t(3130),
                x = t(5041),
                f = t(7637);
            let p = (0, i.createContext)({
                    pageContents: a.wL,
                    setPageContents: n => {},
                    loading: !0,
                    generating: !1,
                    setGenerating: n => {},
                    setLoading: n => {},
                    saveDraft: () => {},
                    generatePage: async (n, e) => a.wL,
                    setMenu: n => n => {},
                    hasChanges: !1
                }),
                v = [{
                    menuType: "webSiteMenu",
                    field: "siteName"
                }, {
                    menuType: "customMenu",
                    field: "siteUrl"
                }];

            function A(n) {
                let {
                    children: e
                } = n, [t, o] = (0, i.useState)(a.wL), [l, u] = (0, i.useState)(!0), [c, d] = (0, i.useState)(!1), [v, A] = (0, i.useState)(JSON.stringify(t)), y = (0, x.useSearchParams)(), N = (0, x.usePathname)(), C = (0, x.useRouter)(), M = y.get("type") || "aiwb", H = N.includes("proposal") || M.includes("proposal"), {
                    businessInfo: {
                        isPublished: S
                    }
                } = (0, f.useBusinessInfo)(), j = async (n, e) => {
                    d(!0);
                    let {
                        generatePage: t
                    } = await m(n), {
                        customMenu: s,
                        locationMenu: i
                    } = t, a = (0, b.Ew)(s.siteUrl), r = await (0, h.F)(a);
                    s.siteUrl = r.checkDraftDuplicateSiteUrl ? "".concat(a, "-").concat(Date.now()) : a;
                    let l = { ...t,
                        locationMenu: { ...i,
                            ...e,
                            address: n.businessLocation
                        }
                    };
                    return o(l), l
                };
                (0, g.q)(async () => {
                    try {
                        let {
                            loadWebPageDraft: n
                        } = await (0, r.D)();
                        n || S || C.push("/about"), o(n), A(JSON.stringify(n))
                    } catch (n) {
                        (0, w.Y)(n)
                    }
                    u(!1)
                });
                let V = v !== JSON.stringify(t);
                return (0, i.useEffect)(() => {
                    if (!H && !l && V) return window.onbeforeunload = n => {
                        n.preventDefault(), n.returnValue = !0
                    }, () => {
                        window.onbeforeunload = null
                    }
                }, [l, V, H]), (0, s.jsx)(p.Provider, {
                    value: {
                        pageContents: t,
                        setPageContents: o,
                        setMenu: n => e => {
                            o(t => ({ ...t,
                                [n]: { ...t[n],
                                    ...e(t[n])
                                }
                            }))
                        },
                        loading: l,
                        generating: c,
                        setGenerating: d,
                        setLoading: u,
                        saveDraft: () => {
                            A(JSON.stringify(t))
                        },
                        generatePage: j,
                        hasChanges: V
                    },
                    children: e
                })
            }
            let y = () => (0, i.useContext)(p)
        },
        8720: function(n, e) {
            "use strict";
            e.Z = {
                src: "https://builder.bookipi.com/_next/static/media/astronaut.042754ad.svg",
                height: 1e3,
                width: 1e3,
                blurWidth: 0,
                blurHeight: 0
            }
        }
    },
    function(n) {
        n.O(0, [6404, 8330, 3166, 3463, 5396, 2682, 2927, 8244, 5346, 7786, 8053, 3911, 2988, 9986, 9056, 3392, 8343, 1744], function() {
            return n(n.s = 4538)
        }), _N_E = n.O()
    }
]);