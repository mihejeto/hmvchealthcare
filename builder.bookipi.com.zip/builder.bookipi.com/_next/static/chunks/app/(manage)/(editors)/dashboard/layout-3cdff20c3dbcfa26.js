(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1219], {
        9634: function(e, t, i) {
            Promise.resolve().then(i.bind(i, 8647)), Promise.resolve().then(i.bind(i, 8349)), Promise.resolve().then(i.bind(i, 129))
        },
        4828: function(e, t, i) {
            "use strict";
            i.d(t, {
                i: function() {
                    return n
                }
            });
            var s = i(5689),
                r = i(4279);

            function n(e) {
                let {
                    fullWidth: t = !1,
                    hidden: i = !1,
                    className: n,
                    compact: o = !1
                } = e;
                return (0, s.jsx)("hr", {
                    className: (0, r.Z)({
                        "mx-0 my-0": t,
                        "mx-3": !t
                    }, {
                        "my-4": !t || !o,
                        "!my-0": o
                    }, {
                        hidden: i
                    }, {
                        "border-t-1 h-0 border-t-gray-200  dark:border-t-gray-700": !i
                    }, n)
                })
            }
        },
        9868: function(e, t, i) {
            "use strict";
            i.d(t, {
                i: function() {
                    return s.i
                }
            });
            var s = i(4828)
        },
        129: function(e, t, i) {
            "use strict";
            i.r(t), i.d(t, {
                CONFIG_STATUS: function() {
                    return H
                },
                PublishedModal: function() {
                    return q
                }
            });
            var s = i(5689),
                r = i(8159),
                n = i(8986),
                o = i(4053),
                l = i(7637),
                a = i(5324),
                c = i(2917),
                u = i(6612),
                d = i(983),
                h = i(4279),
                m = i(4868),
                p = i(9868),
                f = i(8244),
                x = i.n(f),
                g = i(1355),
                b = i(6966),
                y = i(5794),
                v = i(3175),
                _ = {
                    src: "https://builder.bookipi.com/_next/static/media/copy.75fd5039.svg",
                    height: 15,
                    width: 14,
                    blurWidth: 0,
                    blurHeight: 0
                },
                j = {
                    src: "https://builder.bookipi.com/_next/static/media/link.b0826275.svg",
                    height: 17,
                    width: 16,
                    blurWidth: 0,
                    blurHeight: 0
                },
                S = {
                    src: "https://builder.bookipi.com/_next/static/media/small-check.12d5ca87.svg",
                    height: 17,
                    width: 16,
                    blurWidth: 0,
                    blurHeight: 0
                };

            function w(e) {
                let {
                    children: t,
                    className: i = ""
                } = e;
                return (0, s.jsx)("p", {
                    className: (0, h.Z)({
                        "flex items-start gap-1 text-sm": !i
                    }, i),
                    children: t
                })
            }
            var N = {
                src: "https://builder.bookipi.com/_next/static/media/alert.f0869c83.svg",
                height: 17,
                width: 16,
                blurWidth: 0,
                blurHeight: 0
            };

            function k() {
                return (0, s.jsxs)(w, {
                    children: [(0, s.jsx)(x(), {
                        src: N,
                        alt: "active",
                        title: "active",
                        className: "mt-[2.5px] align-middle",
                        style: {
                            height: "auto"
                        },
                        width: 14,
                        height: 14
                    }), (0, s.jsxs)("span", {
                        className: "mt-[3px] text-xs text-gray-500",
                        children: ["An error occurred with your domain. Need support? Click", " ", (0, s.jsx)("a", {
                            href: "https://bookipi.com/support/",
                            target: "_blank",
                            className: "text-primary-700",
                            children: "here"
                        })]
                    })]
                })
            }
            var C = i(2355),
                E = i(3906),
                F = {
                    src: "https://builder.bookipi.com/_next/static/media/clock.262f8bb4.svg",
                    height: 16,
                    width: 16,
                    blurWidth: 0,
                    blurHeight: 0
                };
            let R = {
                not_connected: function() {
                    let {
                        loading: e
                    } = (0, C.useEntri)(), {
                        onGetDomain: t,
                        onConnectDomain: i
                    } = (0, E.f)(o.AMPLITUDE_EVENT_SOURCES.SIDEBAR);
                    return (0, s.jsxs)("div", {
                        className: "flex flex-col items-start justify-center gap-2",
                        children: [(0, s.jsxs)("span", {
                            className: "text-xs text-gray-500",
                            children: ["Connect to a custom domain.", " ", (0, s.jsx)("a", {
                                href: "https://bookipi.com/support/",
                                className: "text-primary-700",
                                children: "Learn more"
                            })]
                        }), (0, s.jsxs)("div", {
                            className: "flex w-full flex-col gap-3",
                            children: [(0, s.jsx)("button", {
                                className: "flex w-full flex-grow items-center justify-center gap-2 rounded-lg border border-primary-700 bg-primary-700 px-4 py-2 text-sm text-white disabled:cursor-not-allowed disabled:opacity-50",
                                onClick: t,
                                disabled: e,
                                children: "Get a domain"
                            }), (0, s.jsx)("button", {
                                className: "flex w-full flex-grow items-center justify-center gap-2 rounded-lg border border-primary-700 px-4 py-2 text-sm text-primary-700 disabled:cursor-not-allowed disabled:opacity-50",
                                onClick: i,
                                disabled: e,
                                children: "Connect my domain"
                            })]
                        })]
                    })
                },
                [r.Fu.PENDING]: function(e) {
                    let {
                        isPublished: t = !1
                    } = e;
                    return t ? (0, s.jsxs)(w, {
                        children: [(0, s.jsx)(x(), {
                            src: F,
                            alt: "clock",
                            title: "clock",
                            className: "mt-[2.5px] align-middle",
                            style: {
                                height: "auto"
                            },
                            width: 14,
                            height: 14
                        }), (0, s.jsx)("span", {
                            className: "mt-[3px] text-xs text-gray-500",
                            children: "Setup in progress. You can check the status of your domain from Custom Menu > Your Domain"
                        })]
                    }) : (0, s.jsxs)(w, {
                        children: [(0, s.jsx)(x(), {
                            src: F,
                            alt: "clock",
                            title: "clock",
                            className: "mt-[2.5px] align-middle",
                            style: {
                                height: "auto"
                            },
                            width: 14,
                            height: 14
                        }), (0, s.jsx)("span", {
                            className: "mt-[3px] text-xs text-gray-500",
                            children: "Setup in progress. You can still publish your website."
                        })]
                    })
                },
                [r.Fu.SUCCESS]: function() {
                    return (0, s.jsxs)(w, {
                        className: "flex items-center gap-1 text-xs",
                        children: [(0, s.jsx)(x(), {
                            src: S,
                            alt: "active",
                            title: "active",
                            className: "align-middle",
                            style: {
                                width: "auto",
                                height: "auto"
                            },
                            width: 16,
                            height: 16
                        }), (0, s.jsxs)("span", {
                            className: "text-xs text-gray-500",
                            children: ["Your domain is active. Need support? Click", (0, s.jsx)("a", {
                                href: "https://bookipi.com/support/",
                                target: "_blank",
                                className: "ml-[2px] text-primary-700",
                                children: "here"
                            })]
                        })]
                    })
                },
                [r.Fu.FAILURE]: k,
                [r.Fu.EXEMPT]: k,
                expired: function() {
                    return (0, s.jsxs)(w, {
                        children: [(0, s.jsx)(x(), {
                            src: N,
                            alt: "active",
                            title: "active",
                            className: "mt-[2.5px] align-middle",
                            style: {
                                height: "auto"
                            },
                            width: 14,
                            height: 14
                        }), (0, s.jsx)("span", {
                            className: "mt-[3px] text-xs text-gray-500",
                            children: "Subscription expired. Please renew to publish to custom domain"
                        })]
                    })
                }
            };

            function I(e) {
                let {
                    isPublished: t
                } = e, {
                    copyToClipboard: i
                } = (0, b.m)(), n = (0, l.useBusinessInfo)(), {
                    businessInfo: o,
                    isDomainConnected: a
                } = n, c = o.domain ? o.domainStatus : "not_connected", u = [r.Fu.FAILURE, r.Fu.EXEMPT].includes(n.businessInfo.domainStatus);
                if (t && "not_connected" === c) return null;
                let d = R[c],
                    m = (0, y.J6)((0, y.z5)(o.domain));
                return (0, s.jsxs)("div", {
                    className: (0, h.Z)("flex flex-col gap-1 rounded-lg px-4 py-5", {
                        "bg-gray-50": t
                    }),
                    children: [(0, s.jsxs)("div", {
                        className: "flex items-center gap-2 text-sm",
                        children: [(0, s.jsx)(x(), {
                            src: j,
                            alt: "link",
                            title: "link",
                            className: "align-middle",
                            style: {
                                width: "auto",
                                height: "auto"
                            },
                            width: 14,
                            height: 8
                        }), (0, s.jsx)("span", {
                            className: "font-[500]",
                            children: "Custom domain"
                        }), t && (0, s.jsx)("button", {
                            onClick: i(m),
                            children: (0, s.jsx)(x(), {
                                src: _,
                                alt: "check",
                                title: "check",
                                className: "align-middle",
                                style: {
                                    height: "auto"
                                },
                                width: 12,
                                height: 12
                            })
                        }), (0, s.jsx)(v.y, {})]
                    }), a && (0, s.jsx)("a", {
                        href: m,
                        target: "_blank",
                        className: (0, h.Z)("block text-sm font-semibold", {
                            "text-gray-300": u,
                            "text-primary-700": !u
                        }),
                        children: m
                    }), (0, s.jsx)(d, {
                        isPublished: t
                    })]
                })
            }
            let P = e => {
                let {
                    isPublished: t,
                    siteURL: i
                } = e, {
                    copyToClipboard: r
                } = (0, b.m)();
                return (0, s.jsxs)("div", {
                    className: (0, h.Z)("flex flex-col gap-1 rounded-lg px-4 py-5", {
                        "bg-gray-50": t
                    }),
                    children: [(0, s.jsxs)("p", {
                        className: "flex items-center gap-2 text-sm",
                        children: [(0, s.jsx)(x(), {
                            src: j,
                            alt: "link",
                            title: "link",
                            className: "align-middle",
                            style: {
                                height: "auto"
                            },
                            width: 14,
                            height: 8
                        }), (0, s.jsx)("span", {
                            className: "font-[500]",
                            children: "URL"
                        }), (0, s.jsx)("button", {
                            onClick: r(i),
                            children: (0, s.jsx)(x(), {
                                src: _,
                                alt: "check",
                                title: "check",
                                className: (0, h.Z)("ml-1 align-middle", {
                                    hidden: !t
                                }),
                                style: {
                                    height: "auto"
                                },
                                width: 12,
                                height: 12
                            })
                        })]
                    }), (0, s.jsx)("a", {
                        href: i,
                        target: "_blank",
                        className: "text-sm font-semibold text-primary-700",
                        children: i
                    })]
                })
            };
            var T = {
                    src: "https://builder.bookipi.com/_next/static/media/arrow.f1b8a747.svg",
                    height: 16,
                    width: 16,
                    blurWidth: 0,
                    blurHeight: 0
                },
                A = {
                    src: "https://builder.bookipi.com/_next/static/media/being-productive.10258dfa.svg",
                    height: 148,
                    width: 148,
                    blurWidth: 0,
                    blurHeight: 0
                },
                z = {
                    src: "https://builder.bookipi.com/_next/static/media/no-connect.928fedb5.svg",
                    height: 148,
                    width: 148,
                    blurWidth: 0,
                    blurHeight: 0
                };
            let O = e => {
                    let {
                        siteURL: t,
                        isPublished: i,
                        isDomainConnected: r,
                        isDomainBlocked: o
                    } = e;
                    return o || !r ? (0, s.jsx)(P, {
                        isPublished: i,
                        siteURL: t
                    }) : (0, s.jsx)(g.e, {
                        feature: n.y8.customDomain,
                        children: (0, s.jsx)(I, {
                            isPublished: i
                        })
                    })
                },
                D = e => {
                    let {
                        domain: t,
                        isPublished: i,
                        isDomainBlocked: r,
                        siteUrl: n,
                        onConnect: o,
                        onRenew: l,
                        isDomainConnected: a
                    } = e;
                    return (0, s.jsxs)("div", {
                        className: "flex flex-col gap-8 px-6",
                        children: [(0, s.jsx)("section", {
                            className: "",
                            children: (0, s.jsx)(O, {
                                siteURL: n,
                                isPublished: i,
                                isDomainConnected: a,
                                isDomainBlocked: r
                            })
                        }), r && (0, s.jsxs)("section", {
                            className: " flex flex-col gap-6 rounded-lg border border-gray-200 px-6 py-4 sm:flex-row",
                            children: [(0, s.jsx)(x(), {
                                src: z,
                                width: 430,
                                height: 148,
                                alt: "Personalise your website",
                                className: "max-h-[200px]"
                            }), (0, s.jsxs)("div", {
                                className: "flex flex-col gap-3",
                                children: [(0, s.jsx)("h4", {
                                    className: "text-base font-semibold text-gray-900",
                                    children: "Your custom domain is deactivated"
                                }), (0, s.jsx)("p", {
                                    className: " text-sm font-normal text-gray-900",
                                    children: "An active subscription to AI Web Builder Pro is required to use a custom domain."
                                }), (0, s.jsxs)("button", {
                                    onClick: l,
                                    className: " flex flex-row items-center gap-2 text-sm font-medium text-primary-600",
                                    children: ["Renew subscription", (0, s.jsx)(x(), {
                                        src: T,
                                        width: 16,
                                        height: 16,
                                        alt: "Renew subscription"
                                    })]
                                })]
                            })]
                        }), "" === t && (0, s.jsxs)("section", {
                            className: " flex flex-col gap-6 rounded-lg border border-gray-200 px-6 py-4 sm:flex-row",
                            children: [(0, s.jsx)(x(), {
                                src: A,
                                width: 430,
                                height: 148,
                                alt: "Personalise your website",
                                className: "max-h-[200px]"
                            }), (0, s.jsxs)("div", {
                                className: "flex flex-col gap-3",
                                children: [(0, s.jsx)("h4", {
                                    className: "text-base font-semibold text-gray-900",
                                    children: "Personalise your website"
                                }), (0, s.jsx)("p", {
                                    className: " text-sm font-normal text-gray-900",
                                    children: "Make your business more professional by publishing your website to a custom domain."
                                }), (0, s.jsxs)("button", {
                                    onClick: o,
                                    className: " flex flex-row items-center gap-2 text-sm font-medium text-primary-600",
                                    children: ["Connect now", (0, s.jsx)(x(), {
                                        src: T,
                                        width: 16,
                                        height: 16,
                                        alt: "connect now"
                                    })]
                                })]
                            })]
                        })]
                    })
                },
                U = e => {
                    let {
                        hasError: t,
                        isExpired: i,
                        isCancelled: r,
                        onClose: n,
                        onManageSubscription: o,
                        onContactSupport: l
                    } = e;
                    return (0, s.jsxs)("div", {
                        className: "flex flex-col gap-3 px-6 pb-6",
                        children: [t && (0, s.jsx)(d.Button, {
                            onClick: l,
                            children: "Contact support"
                        }), (i || r) && (0, s.jsx)(d.Button, {
                            onClick: o,
                            children: "Manage subscription"
                        }), (0, s.jsx)(d.Button, {
                            outline: i || r || t,
                            onClick: n,
                            className: "border border-gray-200 bg-white text-gray-800 hover:bg-gray-200/20",
                            children: "Close"
                        })]
                    })
                },
                B = e => {
                    let {
                        status: t
                    } = e;
                    return (0, s.jsx)("header", {
                        className: "pt-6",
                        children: (0, s.jsx)(x(), {
                            src: H[t].src,
                            alt: H[t].title,
                            className: "align-middle",
                            width: 48,
                            height: 48
                        })
                    })
                },
                L = e => {
                    let {
                        status: t,
                        hasError: i
                    } = e;
                    return (0, s.jsx)("div", {
                        className: "mt-4 text-center",
                        children: (0, s.jsxs)("div", {
                            className: "flex flex-col items-center gap-2",
                            children: [(0, s.jsx)("h2", {
                                className: "text-2xl font-semibold text-gray-900",
                                children: H[t].title
                            }), (0, s.jsx)("p", {
                                className: "px-10 text-sm font-normal text-gray-900",
                                children: H[t].description
                            }), i && (0, s.jsxs)("p", {
                                className: "-mt-2 mb-2 rounded-lg bg-red-50 px-5 py-3 text-center text-sm text-gray-900",
                                children: ["Sorry, we couldn’t publish to your custom domain.", " ", (0, s.jsx)("a", {
                                    href: "https://bookipi.com/support/",
                                    target: "_blank",
                                    className: "text-primary-700",
                                    children: "Get help"
                                })]
                            })]
                        })
                    })
                },
                W = {
                    src: {
                        src: "https://builder.bookipi.com/_next/static/media/error.a016b9f0.svg",
                        height: 48,
                        width: 49,
                        blurWidth: 0,
                        blurHeight: 0
                    },
                    title: "Error",
                    description: "Sorry, we couldn’t publish to your custom domain"
                },
                M = {
                    src: {
                        src: "https://builder.bookipi.com/_next/static/media/check-circle.01b43d6c.svg",
                        height: 48,
                        width: 48,
                        blurWidth: 0,
                        blurHeight: 0
                    },
                    title: "Active",
                    description: "Your website was successfully published to"
                },
                H = {
                    [r.Fu.PENDING]: {
                        src: {
                            src: "https://builder.bookipi.com/_next/static/media/clock.2d169ab8.svg",
                            height: 48,
                            width: 48,
                            blurWidth: 0,
                            blurHeight: 0
                        },
                        title: "Pending",
                        description: "Your website will be published after domain setup is completed"
                    },
                    [r.Fu.SUCCESS]: M,
                    cancelled: M,
                    [r.Fu.EXPIRED]: M,
                    [r.Fu.FAILURE]: W,
                    [r.Fu.EXEMPT]: W
                },
                q = () => {
                    let {
                        publishedModalProps: e,
                        customDomainModalProps: t,
                        businessInfo: {
                            domain: i,
                            domainStatus: f,
                            isPublished: x
                        },
                        isDomainConnected: g
                    } = (0, l.useBusinessInfo)(), {
                        subscription: {
                            isYearly: b
                        },
                        isSubscribed: y,
                        paywallModalProps: v,
                        paywallEventProperties: _,
                        setPaywallEventProperties: j,
                        isExpired: S,
                        showIFrame: w,
                        isCancelled: N,
                        isDomainBlocked: k
                    } = (0, c.useSubscription)(), C = (0, a.useDraftPage)(), {
                        trackEvent: E
                    } = (0, u.i)(), {
                        PUBLISH_MODAL_CONNECT_NOW_BUTTON: F
                    } = o.AMPLITUDE_EVENT_SOURCES, {
                        pageContents: R
                    } = C, {
                        customMenu: I
                    } = R, P = "".concat(n._n).concat(null == I ? void 0 : I.siteUrl), T = () => S ? r.Fu.EXPIRED : N ? "cancelled" : i && f ? f : r.Fu.SUCCESS, A = f === r.Fu.FAILURE || f === r.Fu.EXEMPT;
                    return (0, s.jsx)(m.A, {
                        isOpen: e.isOpen,
                        isToggling: e.isToggling,
                        closeModal: e.close,
                        children: (0, s.jsx)(d.Modal, {
                            showHeader: !1,
                            showFooter: !1,
                            className: (0, h.Z)("h-auto bg-white pt-6 md:h-auto"),
                            size: "s",
                            children: (0, s.jsxs)("div", {
                                className: "relative flex w-full flex-col items-center",
                                children: [(0, s.jsx)(B, {
                                    status: T()
                                }), (0, s.jsx)(L, {
                                    status: T(),
                                    hasError: A
                                }), (0, s.jsxs)("div", {
                                    className: "flex w-full flex-col gap-6 pt-8",
                                    children: [(0, s.jsx)(D, {
                                        domain: i,
                                        isPublished: x,
                                        isDomainBlocked: k,
                                        isDomainConnected: g,
                                        siteUrl: P,
                                        onConnect: () => {
                                            if (E("Web Builder Connect Now Button Clicked"), y) return e.close(), t.toggle();
                                            v.toggle();
                                            let i = { ..._,
                                                source_action: F
                                            };
                                            j(i), E("Web Builder Paywall Modal Viewed", i)
                                        },
                                        onRenew: () => w("/edit")
                                    }), (0, s.jsx)(p.i, {
                                        fullWidth: !0
                                    }), (0, s.jsx)(U, {
                                        hasError: A,
                                        isExpired: f === r.Fu.EXPIRED,
                                        isCancelled: N,
                                        onClose: e.close,
                                        onManageSubscription: () => {
                                            e.close(), w("/edit")
                                        },
                                        onContactSupport: () => window.open("https://bookipi.com/support/", "_blank")
                                    })]
                                })]
                            })
                        })
                    })
                }
        },
        6966: function(e, t, i) {
            "use strict";
            i.d(t, {
                m: function() {
                    return o
                }
            });
            var s = i(9239),
                r = i(1703),
                n = i(7305);
            let o = () => {
                let e = (0, r.useToastContext)();
                return {
                    copyToClipboard: t => async () => {
                        try {
                            await navigator.clipboard.writeText(t), null == e || e.showToast(s.Pw.LINK_COPIED, n.Ix.SUCCESS)
                        } catch (t) {
                            e.showToast(s.RZ.FAILED_TO_COPY_LINK, n.Ix.WARNING)
                        }
                    }
                }
            }
        },
        8647: function(e, t, i) {
            "use strict";
            i.r(t), i.d(t, {
                default: function() {
                    return o
                }
            });
            var s = i(5689),
                r = i(474),
                n = i.n(r);

            function o() {
                return (0, s.jsx)(n(), {
                    strategy: "afterInteractive",
                    type: "text/javascript",
                    src: "https://cdn.goentri.com/entri.js",
                    id: "entri-script"
                })
            }
        },
        8349: function(e, t, i) {
            "use strict";
            i.r(t), i.d(t, {
                IntercomFeature: function() {
                    return x
                },
                default: function() {
                    return p
                }
            });
            var s = i(5689),
                r = i(6074),
                n = i.n(r),
                o = i(1355),
                l = i(8986),
                a = i(7637),
                c = i(2917),
                u = i(2808),
                d = i(474),
                h = i.n(d),
                m = i(2386);

            function p() {
                let {
                    businessInfo: e,
                    isDomainConnected: t
                } = (0, a.useBusinessInfo)(), {
                    isSubscribed: i
                } = (0, c.useSubscription)();
                return (0, m.useEffect)(() => {
                    e && (window.intercomSettings = {
                        api_base: "https://api-iam.intercom.io",
                        app_id: "mye7q9g5",
                        aiwbId: e.id,
                        aiwbName: e.businessName,
                        aiwbDescription: e.businessDescription,
                        aiwbExistingCustomDomainUser: !i && t
                    })
                }, [e]), (0, s.jsx)(h(), {
                    strategy: "afterInteractive",
                    id: "intercom",
                    children: "(function(){var w=window;var ic=w.Intercom;if(typeof ic===\"function\"){ic('reattach_activator');ic('update',w.intercomSettings);}else{var d=document;var i=function(){i.c(arguments);};i.q=[];i.c=function(args){i.q.push(args);};w.Intercom=i;var l=function(){var s=d.createElement('script');s.type='text/javascript';s.async=true;\n         s.src='https://widget.intercom.io/widget/".concat("mye7q9g5", "';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);};if(document.readyState==='complete'){l();}else if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();\n       ")
                })
            }

            function f() {
                return (0, s.jsx)(n(), {
                    id: "fc450f60b2591b4e",
                    children: ".intercom-lightweight-app{display:none}"
                })
            }

            function x() {
                let e = (0, u.U)();
                return (0, s.jsxs)(o.e, {
                    feature: l.y8.intercom,
                    children: [e && (0, s.jsx)(f, {}), (0, s.jsx)(p, {})]
                })
            }
        },
        1483: function(e, t, i) {
            var s = i(982);
            i(1438);
            var r = i(2386),
                n = r && "object" == typeof r && "default" in r ? r : {
                    default: r
                };

            function o(e, t) {
                for (var i = 0; i < t.length; i++) {
                    var s = t[i];
                    s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(e, s.key, s)
                }
            }
            var l = void 0 !== s && s.env && !0,
                a = function(e) {
                    return "[object String]" === Object.prototype.toString.call(e)
                },
                c = function() {
                    function e(e) {
                        var t = void 0 === e ? {} : e,
                            i = t.name,
                            s = void 0 === i ? "stylesheet" : i,
                            r = t.optimizeForSpeed,
                            n = void 0 === r ? l : r;
                        u(a(s), "`name` must be a string"), this._name = s, this._deletedRulePlaceholder = "#" + s + "-deleted-rule____{}", u("boolean" == typeof n, "`optimizeForSpeed` must be a boolean"), this._optimizeForSpeed = n, this._serverSheet = void 0, this._tags = [], this._injected = !1, this._rulesCount = 0;
                        var o = document.querySelector('meta[property="csp-nonce"]');
                        this._nonce = o ? o.getAttribute("content") : null
                    }
                    var t, i = e.prototype;
                    return i.setOptimizeForSpeed = function(e) {
                        u("boolean" == typeof e, "`setOptimizeForSpeed` accepts a boolean"), u(0 === this._rulesCount, "optimizeForSpeed cannot be when rules have already been inserted"), this.flush(), this._optimizeForSpeed = e, this.inject()
                    }, i.isOptimizeForSpeed = function() {
                        return this._optimizeForSpeed
                    }, i.inject = function() {
                        var e = this;
                        if (u(!this._injected, "sheet already injected"), this._injected = !0, this._optimizeForSpeed) {
                            this._tags[0] = this.makeStyleTag(this._name), this._optimizeForSpeed = "insertRule" in this.getSheet(), this._optimizeForSpeed || (l || console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."), this.flush(), this._injected = !0);
                            return
                        }
                        this._serverSheet = {
                            cssRules: [],
                            insertRule: function(t, i) {
                                return "number" == typeof i ? e._serverSheet.cssRules[i] = {
                                    cssText: t
                                } : e._serverSheet.cssRules.push({
                                    cssText: t
                                }), i
                            },
                            deleteRule: function(t) {
                                e._serverSheet.cssRules[t] = null
                            }
                        }
                    }, i.getSheetForTag = function(e) {
                        if (e.sheet) return e.sheet;
                        for (var t = 0; t < document.styleSheets.length; t++)
                            if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t]
                    }, i.getSheet = function() {
                        return this.getSheetForTag(this._tags[this._tags.length - 1])
                    }, i.insertRule = function(e, t) {
                        if (u(a(e), "`insertRule` accepts only strings"), this._optimizeForSpeed) {
                            var i = this.getSheet();
                            "number" != typeof t && (t = i.cssRules.length);
                            try {
                                i.insertRule(e, t)
                            } catch (t) {
                                return l || console.warn("StyleSheet: illegal rule: \n\n" + e + "\n\nSee https://stackoverflow.com/q/20007992 for more info"), -1
                            }
                        } else {
                            var s = this._tags[t];
                            this._tags.push(this.makeStyleTag(this._name, e, s))
                        }
                        return this._rulesCount++
                    }, i.replaceRule = function(e, t) {
                        if (this._optimizeForSpeed) {
                            var i = this.getSheet();
                            if (t.trim() || (t = this._deletedRulePlaceholder), !i.cssRules[e]) return e;
                            i.deleteRule(e);
                            try {
                                i.insertRule(t, e)
                            } catch (s) {
                                l || console.warn("StyleSheet: illegal rule: \n\n" + t + "\n\nSee https://stackoverflow.com/q/20007992 for more info"), i.insertRule(this._deletedRulePlaceholder, e)
                            }
                        } else {
                            var s = this._tags[e];
                            u(s, "old rule at index `" + e + "` not found"), s.textContent = t
                        }
                        return e
                    }, i.deleteRule = function(e) {
                        if (this._optimizeForSpeed) this.replaceRule(e, "");
                        else {
                            var t = this._tags[e];
                            u(t, "rule at index `" + e + "` not found"), t.parentNode.removeChild(t), this._tags[e] = null
                        }
                    }, i.flush = function() {
                        this._injected = !1, this._rulesCount = 0, this._tags.forEach(function(e) {
                            return e && e.parentNode.removeChild(e)
                        }), this._tags = []
                    }, i.cssRules = function() {
                        var e = this;
                        return this._tags.reduce(function(t, i) {
                            return i ? t = t.concat(Array.prototype.map.call(e.getSheetForTag(i).cssRules, function(t) {
                                return t.cssText === e._deletedRulePlaceholder ? null : t
                            })) : t.push(null), t
                        }, [])
                    }, i.makeStyleTag = function(e, t, i) {
                        t && u(a(t), "makeStyleTag accepts only strings as second parameter");
                        var s = document.createElement("style");
                        this._nonce && s.setAttribute("nonce", this._nonce), s.type = "text/css", s.setAttribute("data-" + e, ""), t && s.appendChild(document.createTextNode(t));
                        var r = document.head || document.getElementsByTagName("head")[0];
                        return i ? r.insertBefore(s, i) : r.appendChild(s), s
                    }, o(e.prototype, [{
                        key: "length",
                        get: function() {
                            return this._rulesCount
                        }
                    }]), t && o(e, t), e
                }();

            function u(e, t) {
                if (!e) throw Error("StyleSheet: " + t + ".")
            }
            var d = function(e) {
                    for (var t = 5381, i = e.length; i;) t = 33 * t ^ e.charCodeAt(--i);
                    return t >>> 0
                },
                h = {};

            function m(e, t) {
                if (!t) return "jsx-" + e;
                var i = String(t),
                    s = e + i;
                return h[s] || (h[s] = "jsx-" + d(e + "-" + i)), h[s]
            }

            function p(e, t) {
                var i = e + t;
                return h[i] || (h[i] = t.replace(/__jsx-style-dynamic-selector/g, e)), h[i]
            }
            var f = function() {
                    function e(e) {
                        var t = void 0 === e ? {} : e,
                            i = t.styleSheet,
                            s = void 0 === i ? null : i,
                            r = t.optimizeForSpeed,
                            n = void 0 !== r && r;
                        this._sheet = s || new c({
                            name: "styled-jsx",
                            optimizeForSpeed: n
                        }), this._sheet.inject(), s && "boolean" == typeof n && (this._sheet.setOptimizeForSpeed(n), this._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), this._fromServer = void 0, this._indices = {}, this._instancesCounts = {}
                    }
                    var t = e.prototype;
                    return t.add = function(e) {
                        var t = this;
                        void 0 === this._optimizeForSpeed && (this._optimizeForSpeed = Array.isArray(e.children), this._sheet.setOptimizeForSpeed(this._optimizeForSpeed), this._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), this._fromServer || (this._fromServer = this.selectFromServer(), this._instancesCounts = Object.keys(this._fromServer).reduce(function(e, t) {
                            return e[t] = 0, e
                        }, {}));
                        var i = this.getIdAndRules(e),
                            s = i.styleId,
                            r = i.rules;
                        if (s in this._instancesCounts) {
                            this._instancesCounts[s] += 1;
                            return
                        }
                        var n = r.map(function(e) {
                            return t._sheet.insertRule(e)
                        }).filter(function(e) {
                            return -1 !== e
                        });
                        this._indices[s] = n, this._instancesCounts[s] = 1
                    }, t.remove = function(e) {
                        var t = this,
                            i = this.getIdAndRules(e).styleId;
                        if (function(e, t) {
                                if (!e) throw Error("StyleSheetRegistry: " + t + ".")
                            }(i in this._instancesCounts, "styleId: `" + i + "` not found"), this._instancesCounts[i] -= 1, this._instancesCounts[i] < 1) {
                            var s = this._fromServer && this._fromServer[i];
                            s ? (s.parentNode.removeChild(s), delete this._fromServer[i]) : (this._indices[i].forEach(function(e) {
                                return t._sheet.deleteRule(e)
                            }), delete this._indices[i]), delete this._instancesCounts[i]
                        }
                    }, t.update = function(e, t) {
                        this.add(t), this.remove(e)
                    }, t.flush = function() {
                        this._sheet.flush(), this._sheet.inject(), this._fromServer = void 0, this._indices = {}, this._instancesCounts = {}
                    }, t.cssRules = function() {
                        var e = this,
                            t = this._fromServer ? Object.keys(this._fromServer).map(function(t) {
                                return [t, e._fromServer[t]]
                            }) : [],
                            i = this._sheet.cssRules();
                        return t.concat(Object.keys(this._indices).map(function(t) {
                            return [t, e._indices[t].map(function(e) {
                                return i[e].cssText
                            }).join(e._optimizeForSpeed ? "" : "\n")]
                        }).filter(function(e) {
                            return !!e[1]
                        }))
                    }, t.styles = function(e) {
                        var t, i;
                        return t = this.cssRules(), void 0 === (i = e) && (i = {}), t.map(function(e) {
                            var t = e[0],
                                s = e[1];
                            return n.default.createElement("style", {
                                id: "__" + t,
                                key: "__" + t,
                                nonce: i.nonce ? i.nonce : void 0,
                                dangerouslySetInnerHTML: {
                                    __html: s
                                }
                            })
                        })
                    }, t.getIdAndRules = function(e) {
                        var t = e.children,
                            i = e.dynamic,
                            s = e.id;
                        if (i) {
                            var r = m(s, i);
                            return {
                                styleId: r,
                                rules: Array.isArray(t) ? t.map(function(e) {
                                    return p(r, e)
                                }) : [p(r, t)]
                            }
                        }
                        return {
                            styleId: m(s),
                            rules: Array.isArray(t) ? t : [t]
                        }
                    }, t.selectFromServer = function() {
                        return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e, t) {
                            return e[t.id.slice(2)] = t, e
                        }, {})
                    }, e
                }(),
                x = r.createContext(null);
            x.displayName = "StyleSheetContext";
            var g = n.default.useInsertionEffect || n.default.useLayoutEffect,
                b = new f;

            function y(e) {
                var t = b || r.useContext(x);
                return t && g(function() {
                    return t.add(e),
                        function() {
                            t.remove(e)
                        }
                }, [e.id, String(e.dynamic)]), null
            }
            y.dynamic = function(e) {
                return e.map(function(e) {
                    return m(e[0], e[1])
                }).join(" ")
            }, t.style = y
        },
        6074: function(e, t, i) {
            "use strict";
            e.exports = i(1483).style
        },
        1438: function() {},
        474: function(e, t, i) {
            e.exports = i(7491)
        }
    },
    function(e) {
        e.O(0, [6404, 8330, 3166, 3463, 5396, 2682, 2927, 8244, 5346, 7786, 8053, 2912, 3949, 245, 2988, 1450, 7379, 9056, 3392, 8343, 1744], function() {
            return e(e.s = 9634)
        }), _N_E = e.O()
    }
]);