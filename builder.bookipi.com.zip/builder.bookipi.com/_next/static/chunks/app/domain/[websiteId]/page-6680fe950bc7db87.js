(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1233], {
        3190: function(e, t, n) {
            Promise.resolve().then(n.bind(n, 6619)), Promise.resolve().then(n.bind(n, 599)), Promise.resolve().then(n.bind(n, 4450)), Promise.resolve().then(n.bind(n, 6025))
        },
        6619: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return l
                }
            });
            var r = n(5689),
                i = n(8244),
                a = n.n(i),
                o = n(8720),
                s = n(3532);

            function l(e) {
                let {
                    handleError: t = () => {
                        window.history.back()
                    },
                    buttonText: n = "Go back",
                    helpText: i = "Oops, something went wrong!"
                } = e;
                return (0, r.jsxs)("div", {
                    className: "mx-auto flex h-screen flex-col items-center justify-center px-6 xl:px-0",
                    children: [(0, r.jsx)("div", {
                        className: "block md:max-w-lg",
                        children: (0, r.jsx)(a(), {
                            src: o.Z,
                            alt: "astronaut image",
                            title: "astronaut image",
                            className: "align-middle",
                            style: {
                                height: "auto",
                                maxWidth: "100%"
                            },
                            width: 0,
                            height: 0
                        })
                    }), (0, r.jsxs)("div", {
                        className: "max-w-md text-center xl:max-w-4xl",
                        children: [(0, r.jsx)("h1", {
                            className: "mb-3 block text-2xl font-bold leading-8 text-gray-900 sm:text-4xl sm:leading-10 ",
                            children: i
                        }), (0, r.jsx)("p", {
                            className: " mb-5 text-base font-normal leading-6 text-gray-500 md:text-lg md:leading-7",
                            children: "Well this is embarrassing but something broke. Hit the button below to go back and try again."
                        }), (0, r.jsx)("div", {
                            className: "inline-block",
                            children: (0, r.jsx)(s.Z, {
                                text: n,
                                buttonSize: "base",
                                iconStyle: (0, r.jsx)("svg", {
                                    "aria-hidden": "true",
                                    className: "ml-[-.25rem] mr-2 h-5 w-5",
                                    fill: "currentColor",
                                    viewBox: "0 0 20 20",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: (0, r.jsx)("path", {
                                        fillRule: "evenodd",
                                        d: "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z",
                                        clipRule: "evenodd"
                                    })
                                }),
                                iconDirection: "left",
                                onClick: () => {
                                    t()
                                }
                            })
                        })]
                    })]
                })
            }
        },
        4450: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                CookieBanner: function() {
                    return c
                }
            });
            var r = n(5689),
                i = n(1593),
                a = n(6332),
                o = n(5041),
                s = n(2386),
                l = n(982);

            function c() {
                let e = (0, o.usePathname)(),
                    [t, n] = (0, s.useState)(!1),
                    c = () => {
                        a.Z.set("cookieConsent", "all", {
                            path: e,
                            expires: 365
                        }), (0, i.enableClarity)(), n(!1)
                    };
                return ((0, s.useEffect)(() => {
                    let e = a.Z.get("cookieConsent");
                    n(!("all" === e || "none" === e))
                }, []), t) ? (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("div", {
                        className: "fixed inset-0 z-20 h-full w-full overflow-y-auto bg-gray-600 bg-opacity-50"
                    }), (0, r.jsx)("div", {
                        id: "banner",
                        tabIndex: -1,
                        "aria-hidden": "false",
                        className: "fixed inset-0 z-50 w-full overflow-y-auto overflow-x-hidden md:h-full",
                        children: (0, r.jsx)("div", {
                            className: "fixed bottom-0 h-full w-full md:h-auto",
                            children: (0, r.jsx)("div", {
                                className: "fixed bottom-0 bg-white shadow dark:bg-gray-800",
                                children: (0, r.jsxs)("div", {
                                    className: "w-screen items-center justify-between p-5 lg:flex",
                                    children: [(0, r.jsxs)("p", {
                                        className: "mb-4 text-sm text-gray-500 dark:text-white lg:mb-0",
                                        children: ['We use our own cookies as well as third-party cookies on our website to enhance your experience, analyze our traffic, and for security and marketing. Select "Accept All" to allow them to be used. Read our ', (0, r.jsx)("a", {
                                            target: "_blank",
                                            href: l.env.NEXT_PUBLIC_BOOKIPI_PRIVACY_POLICY_URL,
                                            className: "font-medium text-gray-900 hover:underline dark:text-white",
                                            children: "Privacy Policy"
                                        }), "."]
                                    }), (0, r.jsxs)("div", {
                                        className: "shrink-0 items-center space-y-4 sm:flex sm:space-x-4 sm:space-y-0 lg:pl-10",
                                        children: [(0, r.jsx)("button", {
                                            id: "block-cookies",
                                            type: "button",
                                            onClick: () => {
                                                a.Z.set("cookieConsent", "none", {
                                                    path: e,
                                                    expires: 365
                                                }), n(!1)
                                            },
                                            className: "w-full rounded-lg bg-primary-700 px-4 py-2 text-center text-sm font-medium text-white hover:bg-primary-800 focus:outline-none focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 sm:w-auto",
                                            children: "Block all cookies"
                                        }), (0, r.jsx)("button", {
                                            id: "accept-cookies",
                                            type: "button",
                                            onClick: c,
                                            className: "w-full rounded-lg bg-primary-700 px-4 py-2 text-center text-sm font-medium text-white hover:bg-primary-800 focus:outline-none focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 sm:w-auto",
                                            children: "Accept all"
                                        }), (0, r.jsx)("button", {
                                            id: "close-modal",
                                            type: "button",
                                            onClick: c,
                                            className: "ml-auto inline-flex items-center rounded-lg bg-transparent p-1.5 text-sm text-gray-400 hover:bg-gray-200 hover:text-gray-900 dark:hover:bg-gray-600 dark:hover:text-white md:flex",
                                            children: (0, r.jsx)("svg", {
                                                className: "h-5 w-5",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: (0, r.jsx)("path", {
                                                    fillRule: "evenodd",
                                                    d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                    clipRule: "evenodd"
                                                })
                                            })
                                        })]
                                    })]
                                })
                            })
                        })
                    })]
                }) : null
            }
        },
        1593: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                enableClarity: function() {
                    return c
                }
            });
            var r = n(5689),
                i = n(6332),
                a = n(5041),
                o = n(474),
                s = n.n(o),
                l = n(2386);
            let c = () => {
                window.clarity && window.clarity("consent")
            };
            t.default = () => {
                let e = (0, a.usePathname)(),
                    t = () => {
                        window.clarity && window.clarity("stop")
                    };
                return (0, l.useEffect)(() => {
                    t()
                }, []), (0, l.useEffect)(() => {
                    let t = !!e.includes("/pages/"),
                        n = i.Z.get("cookieConsent");
                    t ? "all" === n && c() : c()
                }, []), (0, r.jsx)(s(), {
                    strategy: "afterInteractive",
                    id: "ms_clarity",
                    children: '\n          (function(c,l,a,r,i,t,y){\n              c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};\n              t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;\n              y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);\n          })(window, document, "clarity", "script", "'.concat("iexshfwvte", '");')
                })
            }
        },
        8720: function(e, t) {
            "use strict";
            t.Z = {
                src: "https://builder.bookipi.com/_next/static/media/astronaut.042754ad.svg",
                height: 1e3,
                width: 1e3,
                blurWidth: 0,
                blurHeight: 0
            }
        },
        599: function(e, t, n) {
            "use strict";
            n.r(t), t.default = {
                src: "https://builder.bookipi.com/_next/static/media/favicon.c71c81ea.png",
                height: 96,
                width: 96,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAKlBMVEX////v7Pj79vzy3fORcMfGbtHpteSfkdfJvebWruXsvurUyO/b0PLj5PPZa1f4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAALklEQVR4nGXKSQoAIAzAwHTRuv7/u1IEL84xBH6mgAB1wJqAlt4iK+a+7yV5PAcNygBp7MmgrwAAAABJRU5ErkJggg==",
                blurWidth: 8,
                blurHeight: 8
            }
        },
        6332: function(e, t, n) {
            "use strict"; /*! js-cookie v3.0.5 | MIT */
            function r(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var r in n) e[r] = n[r]
                }
                return e
            }
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var i = function e(t, n) {
                function i(e, i, a) {
                    if ("undefined" != typeof document) {
                        "number" == typeof(a = r({}, n, a)).expires && (a.expires = new Date(Date.now() + 864e5 * a.expires)), a.expires && (a.expires = a.expires.toUTCString()), e = encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                        var o = "";
                        for (var s in a) a[s] && (o += "; " + s, !0 !== a[s] && (o += "=" + a[s].split(";")[0]));
                        return document.cookie = e + "=" + t.write(i, e) + o
                    }
                }
                return Object.create({
                    set: i,
                    get: function(e) {
                        if ("undefined" != typeof document && (!arguments.length || e)) {
                            for (var n = document.cookie ? document.cookie.split("; ") : [], r = {}, i = 0; i < n.length; i++) {
                                var a = n[i].split("="),
                                    o = a.slice(1).join("=");
                                try {
                                    var s = decodeURIComponent(a[0]);
                                    if (r[s] = t.read(o, s), e === s) break
                                } catch (e) {}
                            }
                            return e ? r[e] : r
                        }
                    },
                    remove: function(e, t) {
                        i(e, "", r({}, t, {
                            expires: -1
                        }))
                    },
                    withAttributes: function(t) {
                        return e(this.converter, r({}, this.attributes, t))
                    },
                    withConverter: function(t) {
                        return e(r({}, this.converter, t), this.attributes)
                    }
                }, {
                    attributes: {
                        value: Object.freeze(n)
                    },
                    converter: {
                        value: Object.freeze(t)
                    }
                })
            }({
                read: function(e) {
                    return '"' === e[0] && (e = e.slice(1, -1)), e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
                },
                write: function(e) {
                    return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
                }
            }, {
                path: "/"
            })
        }
    },
    function(e) {
        e.O(0, [6404, 8330, 3166, 3463, 5396, 2682, 2927, 8244, 5346, 5072, 2988, 6025, 9056, 3392, 8343, 1744], function() {
            return e(e.s = 3190)
        }), _N_E = e.O()
    }
]);