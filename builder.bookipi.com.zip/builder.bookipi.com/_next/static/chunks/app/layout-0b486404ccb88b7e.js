(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3185], {
        9756: function(e, t, n) {
            Promise.resolve().then(n.bind(n, 1703)), Promise.resolve().then(n.bind(n, 6865)), Promise.resolve().then(n.bind(n, 599)), Promise.resolve().then(n.bind(n, 9300)), Promise.resolve().then(n.bind(n, 260)), Promise.resolve().then(n.bind(n, 1593)), Promise.resolve().then(n.bind(n, 2429)), Promise.resolve().then(n.t.bind(n, 7491, 23)), Promise.resolve().then(n.bind(n, 327)), Promise.resolve().then(n.t.bind(n, 4691, 23)), Promise.resolve().then(n.t.bind(n, 8114, 23)), Promise.resolve().then(n.t.bind(n, 2210, 23))
        },
        327: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                GlobalThisScript: function() {
                    return s
                }
            });
            var r = n(5689),
                i = n(5415),
                o = n.n(i);

            function s() {
                return (0, r.jsx)(o(), {
                    children: (0, r.jsx)("script", {
                        dangerouslySetInnerHTML: {
                            __html: '!function(t){function e(){var e=this||self;e.globalThis=e,delete t.prototype._T_}"object"!=typeof globalThis&&(this?e():(t.defineProperty(t.prototype,"_T_",{configurable:!0,get:e}),_T_))}(Object);'
                        }
                    })
                })
            }
        },
        8986: function(e, t, n) {
            "use strict";
            n.d(t, {
                TN: function() {
                    return a
                },
                _n: function() {
                    return o
                },
                kh: function() {
                    return i
                },
                y8: function() {
                    return s
                }
            });
            var r = n(982);
            let i = {
                    LIMITS: {
                        SERVICES: 5,
                        FAQS: 15
                    }
                },
                o = "https://builder.bookipi.com/pages/",
                s = {
                    intercom: "aiwb-intercom",
                    nolt: "aiwb-nolt",
                    customDomain: "aiwb-custom-domain",
                    subscription: "aiwb-subscription"
                },
                a = {
                    dev: {
                        NEXT_PUBLIC_ENV: "dev",
                        NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY: "sdk-Q3sGw8cYPZiVt4XQ",
                        NEXT_PUBLIC_HOME_PAGE_URL: "builder.bkpi.co"
                    },
                    production: {
                        NEXT_PUBLIC_ENV: "production",
                        NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY: "sdk-lVVnx6wT0H931nJT",
                        NEXT_PUBLIC_HOME_PAGE_URL: "builder.bookipi.com"
                    }
                };
            r.env.NEXT_PUBLIC_ENV
        },
        6865: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                ModalContext: function() {
                    return s
                },
                ModalContextProvider: function() {
                    return a
                },
                useModalContext: function() {
                    return u
                }
            });
            var r = n(5689),
                i = n(983),
                o = n(2386);
            let s = (0, o.createContext)({
                    contactFormModal: {
                        isOpen: !1,
                        isToggling: !1,
                        toggle: () => {},
                        close: () => {}
                    }
                }),
                a = e => {
                    let {
                        children: t
                    } = e, n = (0, i.usePopup)({
                        defaultOpen: !1,
                        duration: 100
                    });
                    return (0, r.jsx)(s.Provider, {
                        value: {
                            contactFormModal: n
                        },
                        children: t
                    })
                },
                u = () => (0, o.useContext)(s)
        },
        1703: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                ToastContext: function() {
                    return l
                },
                ToastContextProvider: function() {
                    return f
                },
                useToastContext: function() {
                    return h
                }
            });
            var r = n(5689),
                i = n(2386),
                o = n(7305),
                s = n(4279),
                a = n(1123);
            let u = {
                [o.Ix.SUCCESS]: (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, r.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M16.707 5.29279C16.8945 5.48031 16.9998 5.73462 16.9998 5.99979C16.9998 6.26495 16.8945 6.51926 16.707 6.70679L8.70698 14.7068C8.51945 14.8943 8.26514 14.9996 7.99998 14.9996C7.73482 14.9996 7.48051 14.8943 7.29298 14.7068L3.29298 10.7068C3.11082 10.5182 3.01003 10.2656 3.01231 10.0034C3.01458 9.74119 3.11975 9.49038 3.30516 9.30497C3.49057 9.11956 3.74138 9.01439 4.00358 9.01211C4.26578 9.00983 4.51838 9.11063 4.70698 9.29279L7.99998 12.5858L15.293 5.29279C15.4805 5.10532 15.7348 5 16 5C16.2651 5 16.5195 5.10532 16.707 5.29279Z"
                        })
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Success icon"
                    })]
                }),
                [o.Ix.WARNING]: (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, r.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM10 15a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm1-4a1 1 0 0 1-2 0V6a1 1 0 0 1 2 0v5Z"
                        })
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Warning icon"
                    })]
                }),
                [o.Ix.DANGER]: (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, r.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 11.793a1 1 0 1 1-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 0 1-1.414-1.414L8.586 10 6.293 7.707a1 1 0 0 1 1.414-1.414L10 8.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 10l2.293 2.293Z"
                        })
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Error icon"
                    })]
                })
            };

            function c(e) {
                let {
                    status: t,
                    message: n,
                    closeToast: i
                } = e;
                return (0, r.jsxs)(a.FN, {
                    className: "pointer-events-auto mt-2 min-w-[300px] max-w-md items-center pr-2",
                    children: [(0, r.jsx)("div", {
                        className: (0, s.Z)("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", {
                            "bg-red-100 text-red-500 dark:bg-red-800 dark:text-red-200": t === o.Ix.DANGER,
                            "bg-orange-100 text-orange-500 dark:bg-orange-700 dark:text-orange-200": t === o.Ix.WARNING,
                            "bg-primary-100 text-primary-500 dark:bg-primary-700 dark:text-primary-200": t === o.Ix.SUCCESS
                        }),
                        children: t in u && u[t]
                    }), (0, r.jsx)("div", {
                        className: "mx-3 flex-grow text-sm font-normal",
                        children: n
                    }), (0, r.jsx)(a.FN.Toggle, {
                        onClick: i,
                        className: "flex items-center justify-center p-0 [&_svg]:h-[18px] [&_svg]:w-[18px]"
                    })]
                })
            }
            let l = (0, i.createContext)({
                    toast: [],
                    showToast: (e, t) => {}
                }),
                d = () => {
                    let e = Date.now(),
                        t = Math.random().toString(36).substring(7);
                    return [t, e].join("-")
                },
                f = e => {
                    let {
                        children: t
                    } = e, [n, o] = (0, i.useState)([]);
                    return (0, r.jsxs)(l.Provider, {
                        value: {
                            toast: n,
                            showToast: (e, t) => {
                                let n = d(),
                                    r = () => {
                                        o(e => e.filter(e => e.id !== n)), clearTimeout(i)
                                    },
                                    i = setTimeout(r, 3e3),
                                    s = {
                                        id: n,
                                        message: e,
                                        status: t,
                                        clear: r
                                    };
                                o(e => [...e, s])
                            }
                        },
                        children: [t, (0, r.jsx)("div", {
                            role: "alert",
                            className: "pointer-events-none fixed left-0 top-0 z-50 flex h-full w-full justify-center",
                            children: (0, r.jsx)("div", {
                                className: "mt-14",
                                children: n.map(e => (0, r.jsx)(c, {
                                    message: e.message,
                                    status: e.status,
                                    closeToast: e.clear
                                }, e.id))
                            })
                        })]
                    })
                },
                h = () => (0, i.useContext)(l)
        },
        6612: function(e, t, n) {
            "use strict";
            n.d(t, {
                i: function() {
                    return c
                }
            });
            var r = n(5794),
                i = n(8053),
                o = n(5041),
                s = n(2386),
                a = n(2808);
            let u = e => e ? "app" : (0, r.gA)() ? "mobile" : "web";

            function c() {
                let e = (0, a.U)(),
                    [t] = (0, s.useState)(() => u(e)),
                    n = (0, o.usePathname)(),
                    r = n.includes("proposal"),
                    c = r ? "Proposal" : "Web Builder";
                return {
                    trackAction: function(e) {
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = {
                                platform: t,
                                ...n
                            };
                        (0, i.j)("".concat(c, " ").concat(e), r)
                    },
                    trackEvent: function(e) {
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = {
                                platform: t,
                                ...n
                            };
                        (0, i.j)(e, r)
                    }
                }
            }
        },
        2808: function(e, t, n) {
            "use strict";
            n.d(t, {
                U: function() {
                    return s
                }
            });
            var r = n(5041),
                i = n(2386);
            let o = e => {
                if (e.has("is_from_app")) {
                    let t = "true" == e.get("is_from_app");
                    return sessionStorage.setItem("is_from_app", String(Number(t))), t
                }
                return "1" == sessionStorage.getItem("is_from_app")
            };

            function s() {
                let e = (0, r.useSearchParams)(),
                    [t] = (0, i.useState)(() => o(e));
                return t
            }
        },
        260: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(6612),
                i = n(8053),
                o = n(5041),
                s = n(2386);
            let a = {
                "/": "Web Builder Onboarding Started",
                "/dashboard/": "Web Builder Dashboard Viewed",
                "/preview/": "Web Builder Preview Viewed",
                "/proposal/": "Proposal Dashboard Viewed"
            };
            t.default = () => {
                let e = (0, o.usePathname)(),
                    t = (0, o.useSearchParams)(),
                    [n, u] = (0, s.useState)(!1),
                    {
                        trackEvent: c
                    } = (0, r.i)();
                return (0, s.useEffect)(() => {
                    (0, i.S1)("5897b6213e64717140a87e9a7ce442d8", void 0, {
                        defaultTracking: !1
                    }), u(!0)
                }, []), (0, s.useEffect)(() => {
                    if (n) {
                        let n = !!e.includes("/pages/"),
                            r = t.has("contacts");
                        !n && e in a && !r && c(a[e])
                    }
                }, [n, e, t]), null
            }
        },
        1593: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                enableClarity: function() {
                    return c
                }
            });
            var r = n(5689),
                i = n(6332),
                o = n(5041),
                s = n(474),
                a = n.n(s),
                u = n(2386);
            let c = () => {
                window.clarity && window.clarity("consent")
            };
            t.default = () => {
                let e = (0, o.usePathname)(),
                    t = () => {
                        window.clarity && window.clarity("stop")
                    };
                return (0, u.useEffect)(() => {
                    t()
                }, []), (0, u.useEffect)(() => {
                    let t = !!e.includes("/pages/"),
                        n = i.Z.get("cookieConsent");
                    t ? "all" === n && c() : c()
                }, []), (0, r.jsx)(a(), {
                    strategy: "afterInteractive",
                    id: "ms_clarity",
                    children: '\n          (function(c,l,a,r,i,t,y){\n              c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};\n              t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;\n              y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);\n          })(window, document, "clarity", "script", "'.concat("iexshfwvte", '");')
                })
            }
        },
        2429: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return u
                }
            });
            var r = n(5689),
                i = n(8986),
                o = n(3949),
                s = n(2386),
                a = n(982);

            function u(e) {
                let {
                    children: t
                } = e, [n, u] = (0, s.useState)(!1), c = window.location.href;
                (0, s.useEffect)(() => {
                    u(c.includes(i.TN.production.NEXT_PUBLIC_HOME_PAGE_URL))
                }, [c]);
                let l = i.TN[n ? "production" : "dev"].NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY,
                    d = (0, s.useMemo)(() => new o.Gr({
                        apiHost: a.env.NEXT_PUBLIC_GROWTHBOOK_API_HOST,
                        clientKey: l,
                        enableDevMode: !0,
                        subscribeToChanges: !0
                    }), [l]);
                return (0, s.useEffect)(() => {
                    d.loadFeatures({
                        timeout: 500
                    })
                }, [d]), (0, r.jsx)(o.Ny, {
                    growthbook: d,
                    children: t
                })
            }
        },
        9300: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(5689),
                i = n(1729),
                o = n(7040),
                s = n(7220),
                a = n(5041),
                u = n(2386);
            t.default = function(e) {
                let {
                    children: t
                } = e, [n] = u.useState(new i.S({
                    defaultOptions: {
                        queries: {
                            refetchOnWindowFocus: !1,
                            staleTime: 6e4,
                            retry: 1
                        }
                    }
                })), c = (0, a.usePathname)(), l = !c.startsWith("/editor-preview");
                return (0, r.jsxs)(o.aH, {
                    client: n,
                    children: [t, l && (0, r.jsx)(s.t, {
                        initialIsOpen: !0
                    })]
                })
            }
        },
        7305: function(e, t, n) {
            "use strict";
            var r, i, o, s;
            n.d(t, {
                Ix: function() {
                    return r
                }
            }), n(2386), (o = r || (r = {})).SUCCESS = "success", o.WARNING = "warning", o.DANGER = "danger", (s = i || (i = {})).REGENERATE = "regenerate", s.PUBLISH = "publish", s.UNPUBLISH = "unpublish"
        },
        5794: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ds: function() {
                    return o
                },
                Ew: function() {
                    return d
                },
                J6: function() {
                    return h
                },
                as: function() {
                    return a
                },
                gA: function() {
                    return u
                },
                gj: function() {
                    return c
                },
                kl: function() {
                    return s
                },
                s2: function() {
                    return l
                },
                vV: function() {
                    return i
                },
                z5: function() {
                    return f
                }
            });
            var r = n(4305);
            let {
                isValidEmail: i
            } = r.util;

            function o(e) {
                let t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 250;
                return function() {
                    for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
                    clearTimeout(t), t = setTimeout(() => e(...i), n)
                }
            }

            function s(e) {
                let t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 250;
                return function() {
                    for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
                    return new Promise((r, o) => {
                        clearTimeout(t), t = setTimeout(async () => {
                            try {
                                r(await e(...i))
                            } catch (e) {
                                o(e)
                            }
                        }, n)
                    })
                }
            }

            function a(e, t) {
                return e || t
            }

            function u() {
                return !!/android|iPad|iPhone|iPod/i.test(navigator.userAgent)
            }

            function c(e) {
                return (null == e ? void 0 : e.regular) || (null == e ? void 0 : e.small) || ""
            }

            function l() {
                let e = navigator.userAgent.toLowerCase();
                return /android|iPad|iPhone|iPod/i.test(e)
            }

            function d(e) {
                return e.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "")
            }

            function f(e) {
                return e.split(".").length > 2 ? e : "www.".concat(e)
            }

            function h(e) {
                return "https://".concat(e)
            }
        },
        4691: function() {},
        599: function(e, t, n) {
            "use strict";
            n.r(t), t.default = {
                src: "https://builder.bookipi.com/_next/static/media/favicon.c71c81ea.png",
                height: 96,
                width: 96,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAKlBMVEX////v7Pj79vzy3fORcMfGbtHpteSfkdfJvebWruXsvurUyO/b0PLj5PPZa1f4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAALklEQVR4nGXKSQoAIAzAwHTRuv7/u1IEL84xBH6mgAB1wJqAlt4iK+a+7yV5PAcNygBp7MmgrwAAAABJRU5ErkJggg==",
                blurWidth: 8,
                blurHeight: 8
            }
        }
    },
    function(e) {
        e.O(0, [6404, 8330, 3166, 3463, 5396, 2682, 2927, 5346, 8053, 2912, 3949, 6106, 9056, 3392, 8343, 1744], function() {
            return e(e.s = 9756)
        }), _N_E = e.O()
    }
]);