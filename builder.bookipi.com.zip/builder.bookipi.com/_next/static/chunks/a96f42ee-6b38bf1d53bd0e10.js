"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5396], {
        5401: function(c, t, n) {
            n.d(t, {
                Fm7: function() {
                    return a
                }
            });
            var u = n(5347);

            function a(c) {
                return (0, u.w_)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 448 512"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            d: "M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"
                        }
                    }]
                })(c)
            }
        }
    }
]);