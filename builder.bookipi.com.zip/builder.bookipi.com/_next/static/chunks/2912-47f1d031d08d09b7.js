"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2912], {
        9752: function(n, t, e) {
            e.d(t, {
                j: function() {
                    return u
                }
            });
            var r = e(9345),
                i = e(8517);
            class o extends r.l {
                constructor() {
                    super(), this.setup = n => {
                        if (!i.sk && window.addEventListener) {
                            let t = () => n();
                            return window.addEventListener("visibilitychange", t, !1), window.addEventListener("focus", t, !1), () => {
                                window.removeEventListener("visibilitychange", t), window.removeEventListener("focus", t)
                            }
                        }
                    }
                }
                onSubscribe() {
                    this.cleanup || this.setEventListener(this.setup)
                }
                onUnsubscribe() {
                    if (!this.hasListeners()) {
                        var n;
                        null == (n = this.cleanup) || n.call(this), this.cleanup = void 0
                    }
                }
                setEventListener(n) {
                    var t;
                    this.setup = n, null == (t = this.cleanup) || t.call(this), this.cleanup = n(n => {
                        "boolean" == typeof n ? this.setFocused(n) : this.onFocus()
                    })
                }
                setFocused(n) {
                    let t = this.focused !== n;
                    t && (this.focused = n, this.onFocus())
                }
                onFocus() {
                    this.listeners.forEach(({
                        listener: n
                    }) => {
                        n()
                    })
                }
                isFocused() {
                    return "boolean" == typeof this.focused ? this.focused : "undefined" == typeof document || [void 0, "visible", "prerender"].includes(document.visibilityState)
                }
            }
            let u = new o
        },
        9461: function(n, t, e) {
            e.d(t, {
                V: function() {
                    return i
                }
            });
            var r = e(8517);
            let i = function() {
                let n = [],
                    t = 0,
                    e = n => {
                        n()
                    },
                    i = n => {
                        n()
                    },
                    o = i => {
                        t ? n.push(i) : (0, r.A4)(() => {
                            e(i)
                        })
                    },
                    u = () => {
                        let t = n;
                        n = [], t.length && (0, r.A4)(() => {
                            i(() => {
                                t.forEach(n => {
                                    e(n)
                                })
                            })
                        })
                    };
                return {
                    batch: n => {
                        let e;
                        t++;
                        try {
                            e = n()
                        } finally {
                            --t || u()
                        }
                        return e
                    },
                    batchCalls: n => (...t) => {
                        o(() => {
                            n(...t)
                        })
                    },
                    schedule: o,
                    setNotifyFunction: n => {
                        e = n
                    },
                    setBatchNotifyFunction: n => {
                        i = n
                    }
                }
            }()
        },
        1364: function(n, t, e) {
            e.d(t, {
                N: function() {
                    return s
                }
            });
            var r = e(9345),
                i = e(8517);
            let o = ["online", "offline"];
            class u extends r.l {
                constructor() {
                    super(), this.setup = n => {
                        if (!i.sk && window.addEventListener) {
                            let t = () => n();
                            return o.forEach(n => {
                                window.addEventListener(n, t, !1)
                            }), () => {
                                o.forEach(n => {
                                    window.removeEventListener(n, t)
                                })
                            }
                        }
                    }
                }
                onSubscribe() {
                    this.cleanup || this.setEventListener(this.setup)
                }
                onUnsubscribe() {
                    if (!this.hasListeners()) {
                        var n;
                        null == (n = this.cleanup) || n.call(this), this.cleanup = void 0
                    }
                }
                setEventListener(n) {
                    var t;
                    this.setup = n, null == (t = this.cleanup) || t.call(this), this.cleanup = n(n => {
                        "boolean" == typeof n ? this.setOnline(n) : this.onOnline()
                    })
                }
                setOnline(n) {
                    let t = this.online !== n;
                    t && (this.online = n, this.onOnline())
                }
                onOnline() {
                    this.listeners.forEach(({
                        listener: n
                    }) => {
                        n()
                    })
                }
                isOnline() {
                    return "boolean" == typeof this.online ? this.online : "undefined" == typeof navigator || void 0 === navigator.onLine || navigator.onLine
                }
            }
            let s = new u
        },
        3245: function(n, t, e) {
            e.d(t, {
                DV: function() {
                    return c
                },
                Kw: function() {
                    return s
                },
                Mz: function() {
                    return f
                }
            });
            var r = e(9752),
                i = e(1364),
                o = e(8517);

            function u(n) {
                return Math.min(1e3 * 2 ** n, 3e4)
            }

            function s(n) {
                return (null != n ? n : "online") !== "online" || i.N.isOnline()
            }
            class l {
                constructor(n) {
                    this.revert = null == n ? void 0 : n.revert, this.silent = null == n ? void 0 : n.silent
                }
            }

            function c(n) {
                return n instanceof l
            }

            function f(n) {
                let t, e, c, f = !1,
                    a = 0,
                    h = !1,
                    d = new Promise((n, t) => {
                        e = n, c = t
                    }),
                    y = () => !r.j.isFocused() || "always" !== n.networkMode && !i.N.isOnline(),
                    v = r => {
                        h || (h = !0, null == n.onSuccess || n.onSuccess(r), null == t || t(), e(r))
                    },
                    p = e => {
                        h || (h = !0, null == n.onError || n.onError(e), null == t || t(), c(e))
                    },
                    b = () => new Promise(e => {
                        t = n => {
                            let t = h || !y();
                            return t && e(n), t
                        }, null == n.onPause || n.onPause()
                    }).then(() => {
                        t = void 0, h || null == n.onContinue || n.onContinue()
                    }),
                    w = () => {
                        let t;
                        if (!h) {
                            try {
                                t = n.fn()
                            } catch (n) {
                                t = Promise.reject(n)
                            }
                            Promise.resolve(t).then(v).catch(t => {
                                var e, r;
                                if (h) return;
                                let i = null != (e = n.retry) ? e : 3,
                                    s = null != (r = n.retryDelay) ? r : u,
                                    l = "function" == typeof s ? s(a, t) : s,
                                    c = !0 === i || "number" == typeof i && a < i || "function" == typeof i && i(a, t);
                                if (f || !c) {
                                    p(t);
                                    return
                                }
                                a++, null == n.onFail || n.onFail(a, t), (0, o.Gh)(l).then(() => {
                                    if (y()) return b()
                                }).then(() => {
                                    f ? p(t) : w()
                                })
                            })
                        }
                    };
                return s(n.networkMode) ? w() : b().then(w), {
                    promise: d,
                    cancel: t => {
                        h || (p(new l(t)), null == n.abort || n.abort())
                    },
                    continue: () => {
                        let n = null == t ? void 0 : t();
                        return n ? d : Promise.resolve()
                    },
                    cancelRetry: () => {
                        f = !0
                    },
                    continueRetry: () => {
                        f = !1
                    }
                }
            }
        },
        9345: function(n, t, e) {
            e.d(t, {
                l: function() {
                    return r
                }
            });
            class r {
                constructor() {
                    this.listeners = new Set, this.subscribe = this.subscribe.bind(this)
                }
                subscribe(n) {
                    let t = {
                        listener: n
                    };
                    return this.listeners.add(t), this.onSubscribe(), () => {
                        this.listeners.delete(t), this.onUnsubscribe()
                    }
                }
                hasListeners() {
                    return this.listeners.size > 0
                }
                onSubscribe() {}
                onUnsubscribe() {}
            }
        },
        8517: function(n, t, e) {
            e.d(t, {
                A4: function() {
                    return L
                },
                G9: function() {
                    return O
                },
                Gh: function() {
                    return C
                },
                I6: function() {
                    return c
                },
                Kp: function() {
                    return s
                },
                PN: function() {
                    return u
                },
                Rm: function() {
                    return h
                },
                SE: function() {
                    return o
                },
                VS: function() {
                    return p
                },
                X7: function() {
                    return a
                },
                ZT: function() {
                    return i
                },
                _v: function() {
                    return l
                },
                _x: function() {
                    return f
                },
                oE: function() {
                    return g
                },
                sk: function() {
                    return r
                },
                to: function() {
                    return y
                },
                yF: function() {
                    return d
                }
            });
            let r = "undefined" == typeof window || "Deno" in window;

            function i() {}

            function o(n, t) {
                return "function" == typeof n ? n(t) : n
            }

            function u(n) {
                return "number" == typeof n && n >= 0 && n !== 1 / 0
            }

            function s(n, t) {
                return Math.max(n + (t || 0) - Date.now(), 0)
            }

            function l(n, t, e) {
                return m(n) ? "function" == typeof t ? { ...e,
                    queryKey: n,
                    queryFn: t
                } : { ...t,
                    queryKey: n
                } : n
            }

            function c(n, t, e) {
                return m(n) ? [{ ...t,
                    queryKey: n
                }, e] : [n || {}, t]
            }

            function f(n, t) {
                let {
                    type: e = "all",
                    exact: r,
                    fetchStatus: i,
                    predicate: o,
                    queryKey: u,
                    stale: s
                } = n;
                if (m(u)) {
                    if (r) {
                        if (t.queryHash !== h(u, t.options)) return !1
                    } else {
                        if (!v(t.queryKey, u)) return !1
                    }
                }
                if ("all" !== e) {
                    let n = t.isActive();
                    if ("active" === e && !n || "inactive" === e && n) return !1
                }
                return ("boolean" != typeof s || t.isStale() === s) && (void 0 === i || i === t.state.fetchStatus) && (!o || !!o(t))
            }

            function a(n, t) {
                let {
                    exact: e,
                    fetching: r,
                    predicate: i,
                    mutationKey: o
                } = n;
                if (m(o)) {
                    if (!t.options.mutationKey) return !1;
                    if (e) {
                        if (d(t.options.mutationKey) !== d(o)) return !1
                    } else {
                        if (!v(t.options.mutationKey, o)) return !1
                    }
                }
                return ("boolean" != typeof r || "loading" === t.state.status === r) && (!i || !!i(t))
            }

            function h(n, t) {
                let e = (null == t ? void 0 : t.queryKeyHashFn) || d;
                return e(n)
            }

            function d(n) {
                return JSON.stringify(n, (n, t) => w(t) ? Object.keys(t).sort().reduce((n, e) => (n[e] = t[e], n), {}) : t)
            }

            function y(n, t) {
                return v(n, t)
            }

            function v(n, t) {
                return n === t || typeof n == typeof t && !!n && !!t && "object" == typeof n && "object" == typeof t && !Object.keys(t).some(e => !v(n[e], t[e]))
            }

            function p(n, t) {
                if (n && !t || t && !n) return !1;
                for (let e in n)
                    if (n[e] !== t[e]) return !1;
                return !0
            }

            function b(n) {
                return Array.isArray(n) && n.length === Object.keys(n).length
            }

            function w(n) {
                if (!E(n)) return !1;
                let t = n.constructor;
                if (void 0 === t) return !0;
                let e = t.prototype;
                return !!(E(e) && e.hasOwnProperty("isPrototypeOf"))
            }

            function E(n) {
                return "[object Object]" === Object.prototype.toString.call(n)
            }

            function m(n) {
                return Array.isArray(n)
            }

            function C(n) {
                return new Promise(t => {
                    setTimeout(t, n)
                })
            }

            function L(n) {
                C(0).then(n)
            }

            function O() {
                if ("function" == typeof AbortController) return new AbortController
            }

            function g(n, t, e) {
                return null != e.isDataEqual && e.isDataEqual(n, t) ? n : "function" == typeof e.structuralSharing ? e.structuralSharing(n, t) : !1 !== e.structuralSharing ? function n(t, e) {
                    if (t === e) return t;
                    let r = b(t) && b(e);
                    if (r || w(t) && w(e)) {
                        let i = r ? t.length : Object.keys(t).length,
                            o = r ? e : Object.keys(e),
                            u = o.length,
                            s = r ? [] : {},
                            l = 0;
                        for (let i = 0; i < u; i++) {
                            let u = r ? i : o[i];
                            s[u] = n(t[u], e[u]), s[u] === t[u] && l++
                        }
                        return i === u && l === i ? t : s
                    }
                    return e
                }(n, t) : t
            }
        },
        7040: function(n, t, e) {
            e.d(t, {
                NL: function() {
                    return s
                },
                aH: function() {
                    return l
                }
            });
            var r = e(2386);
            let i = r.createContext(void 0),
                o = r.createContext(!1);

            function u(n, t) {
                return n || (t && "undefined" != typeof window ? (window.ReactQueryClientContext || (window.ReactQueryClientContext = i), window.ReactQueryClientContext) : i)
            }
            let s = ({
                    context: n
                } = {}) => {
                    let t = r.useContext(u(n, r.useContext(o)));
                    if (!t) throw Error("No QueryClient set, use QueryClientProvider to set one");
                    return t
                },
                l = ({
                    client: n,
                    children: t,
                    context: e,
                    contextSharing: i = !1
                }) => {
                    r.useEffect(() => (n.mount(), () => {
                        n.unmount()
                    }), [n]);
                    let s = u(e, i);
                    return r.createElement(o.Provider, {
                        value: !e && i
                    }, r.createElement(s.Provider, {
                        value: n
                    }, t))
                }
        }
    }
]);