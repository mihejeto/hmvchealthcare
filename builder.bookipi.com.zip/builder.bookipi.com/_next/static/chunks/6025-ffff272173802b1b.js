"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6025], {
        3532: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return s
                }
            });
            var n = r(5689),
                a = r(4279);

            function s(e) {
                let {
                    type: t = "button",
                    textTransform: r = "capitalize",
                    outline: s = !1,
                    text: l,
                    buttonSize: i,
                    iconStyle: o,
                    iconDirection: c = "left",
                    disabled: d = !1,
                    className: u,
                    onClick: x,
                    href: m = "#",
                    as: h = "button"
                } = e;
                return (0, n.jsxs)(h, {
                    href: m,
                    type: t,
                    onClick: x,
                    disabled: d,
                    target: "_blank",
                    className: (0, a.Z)("inline-flex w-full items-center justify-center rounded-lg text-center focus:outline-none focus:ring-4 focus:ring-primary-300 disabled:bg-gray-100 disabled:text-gray-300 dark:bg-primary-600 \n        dark:hover:bg-primary-700 dark:focus:ring-primary-800", s ? "border border-blue-700 text-blue-700 hover:border-primary-300 focus:ring-4 focus:ring-primary-300 dark:border-primary-600 dark:text-primary-600 dark:hover:border-primary-700 dark:hover:text-primary-700 dark:focus:ring-primary-800" : "bg-blue-700 text-white hover:bg-primary-700 focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800", u, r, {
                        "px-3 py-2 text-sm font-medium": "xs" === i || "sm" === i,
                        "px-[20px] py-[10px] text-sm font-medium": "base" === i,
                        "px-5 py-3 text-base font-medium sm:py-3.5": "l" === i,
                        "px-6 py-[14px] text-base font-medium": "xl" === i
                    }),
                    children: [c && o && "left" === c && o, l, c && o && "right" === c && o]
                })
            }
        },
        9314: function(e, t, r) {
            r.d(t, {
                t: function() {
                    return d
                }
            });
            var n = r(5689),
                a = r(8159),
                s = r(983),
                l = r(4279),
                i = r(2386),
                o = r(4886),
                c = r(6230);

            function d(e) {
                let {
                    onSubmit: t,
                    contactMenu: r,
                    className: d,
                    closeModal: u
                } = e, x = (0, i.useRef)(null);
                return (0, n.jsx)(s.Modal, {
                    showHeader: !0,
                    modalHeaderProps: {
                        onClose: null != u ? u : () => {},
                        showLeftIcon: !1,
                        title: r.title || "Contact Us"
                    },
                    showFooter: !0,
                    modalFooterProps: {
                        style: "vertical",
                        showPrimaryButton: !0,
                        showSecondaryButton: !1,
                        primaryButtonProps: {
                            children: "Send message",
                            onClick: () => {
                                x.current && t && t(x.current)
                            }
                        }
                    },
                    size: "s",
                    className: (0, l.Z)(d || "h-auto w-full max-w-[480px] bg-white md:h-auto"),
                    children: (0, n.jsxs)("form", {
                        ref: x,
                        onSubmit: () => {
                            x.current && t && t(x.current)
                        },
                        className: "relative flex flex-col gap-5 overflow-hidden bg-white  p-6 dark:bg-gray-800 sm:rounded-lg",
                        children: [(0, n.jsx)("p", {
                            className: "text-center text-base font-normal text-gray-500",
                            children: r.description || a.dL.description
                        }), (0, n.jsx)(o.Z, {
                            id: "full_name",
                            placeholder: "Bonnie",
                            type: "text",
                            label: "Full name",
                            labelHidden: !1,
                            size: "large",
                            autoComplete: "off",
                            required: !0
                        }), (0, n.jsx)(o.Z, {
                            placeholder: "name@example.com",
                            id: "email",
                            type: "email",
                            label: "email",
                            labelHidden: !1,
                            size: "large",
                            autoComplete: "off",
                            required: !0
                        }), r.showPhoneNumber && (0, n.jsx)(o.Z, {
                            placeholder: "+(12) 345 6789",
                            id: "phone_number",
                            type: "tel",
                            label: "phone number",
                            labelHidden: !1,
                            size: "large",
                            autoComplete: "off",
                            required: r.requiredPhoneNumber
                        }), r.showYourMessage && (0, n.jsx)(c.Z, {
                            id: "message",
                            rows: 7,
                            placeholder: "",
                            label: "Your message",
                            labelHidden: !1,
                            required: r.requiredYourMessage
                        })]
                    })
                })
            }
        },
        4886: function(e, t, r) {
            var n = r(5689),
                a = r(4279),
                s = r(2386),
                l = r(1646);
            let i = (0, s.forwardRef)((e, t) => {
                let {
                    id: r,
                    iconStyle: s,
                    label: i,
                    labelHidden: o = !0,
                    size: c = "regular",
                    helperText: d,
                    tooltipContent: u,
                    className: x = "",
                    ...m
                } = e;
                return (0, n.jsxs)("div", {
                    children: [(0, n.jsxs)("label", {
                        htmlFor: r,
                        className: (0, a.Z)({
                            "sr-only": o,
                            asterisk: !!m.required
                        }, u ? "inline-flex items-center" : "flex", "mb-2 gap-2"),
                        children: [(0, n.jsx)("span", {
                            className: "text-sm font-medium text-gray-900 dark:text-white",
                            children: i
                        }), u && (0, n.jsx)(l.u, {
                            content: u,
                            children: (0, n.jsx)("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "0.875em",
                                viewBox: "0 0 512 512",
                                children: (0, n.jsx)("path", {
                                    d: "M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336h24V272H216c-13.3 0-24-10.7-24-24s10.7-24 24-24h48c13.3 0 24 10.7 24 24v88h8c13.3 0 24 10.7 24 24s-10.7 24-24 24H216c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
                                })
                            })
                        })]
                    }), (0, n.jsxs)("div", {
                        className: "relative",
                        children: [s && (0, n.jsx)("div", {
                            className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4",
                            children: s
                        }), (0, n.jsx)("input", {
                            ref: t,
                            name: r,
                            style: { ...s && {
                                    paddingLeft: "46px"
                                }
                            },
                            className: (0, a.Z)({
                                "p-2.5 text-sm font-normal": "regular" === c,
                                "px-4 py-[14px] text-base font-normal": "large" === c,
                                "cursor-not-allowed": !!(m.disabled || m.readOnly)
                            }, "inline-block w-full rounded-lg border border-gray-300 bg-gray-50 text-gray-900 focus:border-blue-500 focus:ring-blue-500   dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500", x),
                            ...m
                        })]
                    }), d && (0, n.jsx)("p", {
                        id: "standard_error_help",
                        className: "mt-2 text-xs text-red-600 dark:text-red-400",
                        children: d
                    })]
                })
            });
            i.displayName = "Input", t.Z = i
        },
        4868: function(e, t, r) {
            r.d(t, {
                A: function() {
                    return a
                }
            });
            var n = r(5689);

            function a(e) {
                let {
                    children: t,
                    isOpen: r,
                    isToggling: a,
                    closeModal: s
                } = e;
                return (0, n.jsxs)("div", {
                    className: "fixed left-0 top-0 z-modal flex h-full w-screen items-center justify-center",
                    style: {
                        visibility: r ? "visible" : "hidden"
                    },
                    children: [(0, n.jsx)("div", {
                        className: "fixed inset-0 z-20 h-full w-full overflow-y-auto bg-gray-600 bg-opacity-50",
                        onClick: s,
                        style: {
                            opacity: a ? 0 : .8
                        }
                    }), t]
                })
            }
        },
        6025: function(e, t, r) {
            r.r(t), r.d(t, {
                SiteView: function() {
                    return es
                }
            });
            var n = r(5689),
                a = r(2878),
                s = r(5041),
                l = r(2386);

            function i(e) {
                let {
                    GA_TRACKING_ID: t,
                    GTM_ID: r
                } = e, i = (0, s.usePathname)();
                return (0, l.useLayoutEffect)(() => {
                    if (i && t) {
                        var e;
                        null === (e = window.gtag) || void 0 === e || e.call(window, "config", t, {
                            page_path: i
                        })
                    }
                }, [i, t]), (0, n.jsxs)(n.Fragment, {
                    children: [r && (0, n.jsx)(a.GoogleTagManager, {
                        gtmId: "GTM-".concat(r)
                    }), t && (0, n.jsx)(a.GoogleAnalytics, {
                        gaId: "G-".concat(t)
                    })]
                })
            }
            var o = r(4279);
            r(7043), r(9994);
            var c = r(9198);
            let d = (0, c.Z)("8152d43796d00a562ec1b9391e99c668b3843191");
            var u = r(1703),
                x = r(3532),
                m = r(4886),
                h = r(7305),
                g = r(5794);
            let f = ["/preview/", "/editor-preview/"];

            function p() {
                let e = (0, s.usePathname)();
                return f.includes(e)
            }
            var b = r(9239);

            function w(e) {
                let {
                    button: t
                } = e, r = p(), a = (0, s.useParams)(), l = a.siteUrl, i = (0, u.useToastContext)(), o = async e => {
                    if (e.preventDefault(), r) {
                        i.showToast(b.hi.CONTACT_FORM_SUBMIT_IN_PREVIEW, h.Ix.WARNING);
                        return
                    }
                    let t = new FormData(e.currentTarget),
                        n = t.get("email").trim();
                    if (n && g.vV(n)) {
                        let t = l || window.location.hostname;
                        try {
                            await d(t, {
                                id: "",
                                name: "",
                                phone: "",
                                message: "",
                                email: n,
                                submitted: new Date().toString()
                            }), i.showToast("Contact added", h.Ix.SUCCESS), e.target.reset()
                        } catch (e) {
                            var a, s, o;
                            i.showToast(null === (a = e.response) || void 0 === a ? void 0 : null === (s = a.errors) || void 0 === s ? void 0 : null === (o = s[0]) || void 0 === o ? void 0 : o.message, h.Ix.DANGER)
                        }
                        return
                    }
                    i.showToast("Please enter a valid email address", h.Ix.DANGER)
                };
                return (0, n.jsx)("form", {
                    className: "md:max-w-ful w-full",
                    onSubmit: o,
                    children: (0, n.jsxs)("div", {
                        className: "flex flex-col justify-center gap-3 md:flex-row md:items-center md:gap-0",
                        children: ["Email form" === t.type && (0, n.jsx)("div", {
                            className: "relative w-full flex-1 md:mr-3",
                            children: (0, n.jsx)(m.Z, {
                                placeholder: "Enter your e-mail address",
                                id: "email",
                                type: "email",
                                label: "Email address",
                                labelHidden: !0,
                                size: "large",
                                autoComplete: "on"
                            })
                        }), (0, n.jsx)("div", {
                            className: "m-1 md:w-fit",
                            children: (0, n.jsx)(x.Z, {
                                className: "email-form-button",
                                type: "submit",
                                text: t.text,
                                buttonSize: "xl"
                            })
                        })]
                    })
                })
            }
            let j = e => {
                if (y(e)) return e;
                let t = "https://".concat(e);
                return y(t) ? t : "#"
            };

            function y(e) {
                try {
                    return new URL(e), !0
                } catch (e) {
                    return !1
                }
            }
            var v = r(6865),
                N = r(983);

            function k(e) {
                let {
                    button: t,
                    contactMenu: r,
                    ...a
                } = e, {
                    contactFormModal: s
                } = (0, v.useModalContext)();
                return (0, n.jsx)(n.Fragment, {
                    children: (0, n.jsx)(N.Button, {
                        color: "primary",
                        onClick: () => "Contact popup" === t.type ? s.toggle() : "Link" === t.type && t.link && (y(t.link) || y("https://".concat(t.link))) ? window.open(j(t.link), "_blank") : void 0,
                        size: "m",
                        children: t.text
                    })
                })
            }

            function C(e) {
                let {
                    className: t = "m-1"
                } = e, r = "Email form" === e.button.type;
                return (0, n.jsx)("div", {
                    className: "flex w-full flex-col justify-center gap-3 md:max-w-full md:flex-row md:items-center md:gap-0",
                    children: (0, n.jsx)("div", {
                        className: (0, o.Z)("w-full md:w-fit", t),
                        children: r ? (0, n.jsx)(w, { ...e
                        }) : (0, n.jsx)(k, { ...e
                        })
                    })
                })
            }

            function E(e) {
                let {
                    ctaMenu: t,
                    contactMenu: r
                } = e, {
                    heading: a = "",
                    description: s = ""
                } = t, l = Object.assign({
                    isEnable: !1,
                    type: "Link",
                    text: "Submit",
                    link: ""
                }, t.button);
                return (0, n.jsx)("section", {
                    id: "cta",
                    className: "grid-full-width w-full bg-gray-50",
                    children: (0, n.jsx)("div", {
                        className: "contents-container",
                        children: (0, n.jsxs)("div", {
                            className: "medium-center flex flex-col items-center justify-center gap-6",
                            children: [(0, n.jsx)("h3", {
                                className: "text-center text-3xl font-extrabold leading-tight md:text-4xl",
                                children: a
                            }), (0, n.jsx)("p", {
                                className: "max-w-[960px] self-stretch text-center text-base font-normal leading-6 text-gray-500 md:text-2xl md:text-xl md:leading-[30px]",
                                children: s
                            }), (0, n.jsx)("div", {
                                className: "flex w-full justify-center",
                                children: (0, n.jsx)(C, {
                                    button: l,
                                    contactMenu: r
                                })
                            })]
                        })
                    })
                })
            }

            function M(e) {
                let {
                    questions: t
                } = e, [r, a] = (0, l.useState)(null);
                return (0, n.jsxs)("section", {
                    id: "faq",
                    className: "contents-container bg-white dark:bg-gray-900",
                    children: [(0, n.jsx)("h3", {
                        className: "mb-8 text-center text-3xl font-extrabold leading-tight tracking-tight text-gray-900 md:tracking-[-0.36px] lg:mb-8 lg:text-4xl",
                        children: "Frequently asked questions"
                    }), (0, n.jsx)("div", {
                        className: "medium-center",
                        children: (0, n.jsx)("ul", {
                            className: "px-4",
                            id: "accordion-flush",
                            "data-accordion": "collapse",
                            "data-active-classes": "bg-white dark:bg-gray-900 text-gray-900",
                            "data-inactive-classes": "text-gray-500",
                            children: t.map((e, t) => {
                                let {
                                    question: s,
                                    answer: l
                                } = e, i = r === t;
                                return (0, n.jsxs)("li", {
                                    children: [(0, n.jsx)("div", {
                                        id: "accordion-flush-heading-".concat(t),
                                        children: (0, n.jsxs)("button", {
                                            type: "button",
                                            className: "flex w-full items-center justify-between border-b border-gray-200  bg-white py-6 text-left text-lg font-medium leading-tight text-gray-900 md:leading-none",
                                            "data-accordion-target": "#accordion-flush-body-".concat(t),
                                            "aria-expanded": i,
                                            "aria-controls": "accordion-flush-body-".concat(t),
                                            onClick: () => a(e => e === t ? null : t),
                                            children: [(0, n.jsx)("span", {
                                                children: s
                                            }), (0, n.jsx)("svg", {
                                                "data-accordion-icon": "",
                                                className: (0, o.Z)("h-6 w-6  shrink-0", {
                                                    "rotate-180": i
                                                }),
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: (0, n.jsx)("path", {
                                                    fillRule: "evenodd",
                                                    d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z",
                                                    clipRule: "evenodd"
                                                })
                                            })]
                                        })
                                    }), i && (0, n.jsx)("div", {
                                        id: "accordion-flush-body-".concat(t),
                                        className: "",
                                        "aria-labelledby": "accordion-flush-heading-".concat(t),
                                        children: (0, n.jsx)("div", {
                                            className: "border-b border-gray-200 py-5 dark:border-gray-700",
                                            children: (0, n.jsx)("p", {
                                                className: "mb-2 text-gray-500 dark:text-gray-400",
                                                children: l
                                            })
                                        })
                                    })]
                                }, "faq-".concat(t))
                            })
                        })
                    })]
                })
            }
            var I = r(8244),
                _ = r.n(I);

            function S(e) {
                let {
                    introMenu: t,
                    contactMenu: r
                } = e, {
                    heading: a = "",
                    subheading: s = "",
                    imageDescription: l = ""
                } = t, i = (0, g.gj)(t.imageSrc), o = Object.assign({
                    isEnable: !1,
                    type: "Link",
                    text: "Submit",
                    link: ""
                }, t.button);
                return (0, n.jsx)("section", {
                    id: "intro",
                    className: "bg-white",
                    children: (0, n.jsxs)("article", {
                        className: "contents-container flex w-full flex-col items-center justify-center gap-0 md:flex-row md:gap-8",
                        children: [(0, n.jsxs)("div", {
                            className: "mx-auto flex h-full w-full max-w-screen-md flex-col justify-center",
                            children: [(0, n.jsxs)("div", {
                                id: "text-group",
                                children: [(0, n.jsx)("h2", {
                                    style: {
                                        lineHeight: "1.1"
                                    },
                                    className: "mb-5 text-center text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-left md:mb-6 md:text-3xl md:text-6xl",
                                    children: a
                                }), (0, n.jsx)("p", {
                                    className: "mb-10 text-center text-lg font-normal leading-[150%] text-gray-500 sm:text-left md:mb-10 md:text-xl md:leading-[30px]",
                                    children: s
                                })]
                            }), (null == o ? void 0 : o.isEnable) && o.text && (0, n.jsx)("div", {
                                className: "w-full md:w-fit",
                                children: (0, n.jsx)(C, {
                                    contactMenu: r,
                                    button: t.button,
                                    className: "hide-on-proposal"
                                })
                            })]
                        }), i && (0, n.jsx)("div", {
                            className: "mt-4 w-auto items-center justify-center sm:flex md:mt-12",
                            children: (0, n.jsx)(_(), {
                                className: "w-full rounded-lg object-contain shadow-lg dark:hidden",
                                src: i,
                                alt: l,
                                title: l,
                                width: 0,
                                height: 0,
                                style: {
                                    width: "100%",
                                    maxWidth: "100%",
                                    height: "auto",
                                    objectFit: "cover"
                                },
                                priority: !0
                            })
                        })]
                    })
                })
            }
            var T = r(7105),
                A = r(474),
                L = r.n(A);
            let R = async (e, t) => {
                    var r, n, a;
                    if (!e || ![t.lat, t.lng].every(e => !!e)) return;
                    let s = window.google;
                    if (!s || (null == s ? void 0 : null === (r = s.maps) || void 0 === r ? void 0 : r.Map) === void 0 || (null == s ? void 0 : null === (n = s.maps) || void 0 === n ? void 0 : null === (a = n.marker) || void 0 === a ? void 0 : a.AdvancedMarkerElement) === void 0) return;
                    let l = new s.maps.Map(e, {
                        zoom: 13,
                        center: t,
                        mapId: "DEMO_MAP_ID"
                    });
                    new s.maps.marker.AdvancedMarkerElement({
                        position: t,
                        map: l
                    })
                },
                P = new URLSearchParams({
                    key: "AIzaSyCTFHTStUuRngOrwspHtUHOGJcz88Fm5VA",
                    callback: "initMap",
                    loading: "async",
                    v: "weekly",
                    libraries: "marker"
                }),
                F = "https://maps.googleapis.com/maps/api/js?".concat(P.toString());

            function Z(e) {
                let {
                    coordinates: t
                } = e, r = (0, l.useRef)(null);
                return (0, l.useEffect)(() => {
                    R(r.current, t)
                }, [t]), (0, T.q)(() => {
                    window.initMap = () => R(r.current, t)
                }), (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)(L(), {
                        src: F,
                        async: !0,
                        defer: !0
                    }), (0, n.jsx)("div", {
                        ref: r,
                        className: "h-[300px] w-full max-w-[1280px] md:h-[450px]"
                    })]
                })
            }

            function U(e) {
                let {
                    data: t
                } = e;
                return (0, n.jsxs)("section", {
                    id: "location",
                    className: "contents-container mx-auto flex w-full flex-col items-center gap-6 overflow-hidden",
                    children: [(0, n.jsx)("h3", {
                        className: "self-stretch text-center text-3xl font-extrabold leading-[100%] md:text-4xl md:leading-tight md:tracking-[-0.36px]",
                        children: t.heading
                    }), t.showSubheading && (0, n.jsx)("span", {
                        className: "text-lg font-normal leading-[150%] text-gray-500 md:text-xl",
                        children: t.subheading
                    }), (0, n.jsx)("address", {
                        className: "self-stretch text-center text-lg font-normal not-italic leading-[150%] text-gray-500 underline md:text-xl",
                        children: t.address
                    }), (0, n.jsx)(Z, {
                        coordinates: {
                            lat: Number(t.lat),
                            lng: Number(t.lng)
                        }
                    })]
                })
            }
            let G = e => !!(e % 2),
                O = e => {
                    let {
                        services: t
                    } = e;
                    return (0, n.jsx)("section", {
                        id: "services",
                        className: "contents-container flex w-full flex-col items-center bg-white dark:bg-gray-900",
                        children: (0, n.jsx)("ul", {
                            className: "flex flex-col gap-8 bg-white md:gap-16",
                            children: t.map((e, t) => {
                                var r;
                                if (![e.description, e.heading, e.button.text].some(e => e && e.trim().length)) return null;
                                let {
                                    heading: a,
                                    description: s,
                                    imageDescription: l,
                                    button: {
                                        link: i,
                                        text: c,
                                        isEnable: d
                                    }
                                } = e, u = (0, g.gj)(e.imageSrc);
                                return (0, n.jsx)("li", {
                                    children: (0, n.jsxs)("article", {
                                        className: "max-w-screen-xl grid-cols-1 items-center gap-8 bg-white dark:bg-gray-900 md:grid md:grid-cols-2 lg:gap-20",
                                        children: [(0, n.jsx)("div", {
                                            className: (0, o.Z)("flex items-center justify-center", G(t) ? "order-2" : "order-1"),
                                            children: u && (0, n.jsx)(_(), {
                                                className: "max-h-[294px] w-full rounded-lg object-contain shadow-lg dark:hidden md:max-h-[485px]",
                                                src: u,
                                                width: 0,
                                                height: 0,
                                                alt: l,
                                                title: l,
                                                style: {
                                                    width: "100%",
                                                    maxWidth: "100%",
                                                    height: "auto",
                                                    objectFit: "cover"
                                                },
                                                priority: !0
                                            })
                                        }), (0, n.jsxs)("div", {
                                            className: (0, o.Z)(G(t) ? "order-1" : "order-2", "mt-4 md:mt-0"),
                                            children: [(0, n.jsx)("h3", {
                                                className: "mb-6 break-words text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white",
                                                children: a
                                            }), (0, n.jsx)("p", {
                                                className: "mb-6 break-words font-light text-gray-500 dark:text-gray-400 md:text-lg",
                                                children: s
                                            }), d && !!(null == c ? void 0 : null === (r = c.trim) || void 0 === r ? void 0 : r.call(c).length) && (0, n.jsx)("div", {
                                                className: "m-1 inline-block",
                                                children: (0, n.jsx)(x.Z, {
                                                    className: "service-button hide-on-proposal",
                                                    text: c,
                                                    buttonSize: "base",
                                                    onClick: e => {
                                                        i && (y(i) || y("https://".concat(i))) && (e.preventDefault(), window.open(j(i), "_blank"))
                                                    }
                                                })
                                            })]
                                        })]
                                    })
                                }, t)
                            })
                        })
                    })
                };

            function D(e) {
                let {
                    quotos: t
                } = e;
                return (0, n.jsx)(n.Fragment, {
                    children: t.slice(0, 1).map((e, t) => (0, n.jsx)(z, { ...e
                    }, t))
                })
            }

            function z(e) {
                let {
                    text: t,
                    name: r,
                    label: a,
                    profileImageSrc: s,
                    imageDescription: l,
                    showFiveStarRating: i
                } = e;
                return (0, n.jsx)("section", {
                    id: "quote",
                    className: "content-grid full-width grid-full-width w-full bg-gray-50 dark:bg-gray-900",
                    children: (0, n.jsx)("div", {
                        className: "contents-container",
                        children: (0, n.jsxs)("figure", {
                            className: "medium-center",
                            children: [(0, n.jsx)("svg", {
                                className: "mx-auto mb-3 h-12 text-gray-400 dark:text-gray-600",
                                viewBox: "0 0 24 27",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: (0, n.jsx)("path", {
                                    d: "M14.017 18L14.017 10.609C14.017 4.905 17.748 1.039 23 0L23.995 2.151C21.563 3.068 20 5.789 20 8H24V18H14.017ZM0 18V10.609C0 4.905 3.748 1.038 9 0L9.996 2.151C7.563 3.068 6 5.789 6 8H9.983L9.983 18L0 18Z",
                                    fill: "currentColor"
                                })
                            }), (0, n.jsx)("blockquote", {
                                children: (0, n.jsx)("p", {
                                    className: "text-center text-2xl font-semibold leading-relaxed text-gray-900 ",
                                    children: t
                                })
                            }), (0, n.jsxs)("figcaption", {
                                className: "mt-6 flex items-center justify-center gap-[9px]",
                                children: [(null == s ? void 0 : s.thumb) && (0, n.jsx)(_(), {
                                    width: 0,
                                    height: 0,
                                    className: "h-6 w-6 rounded-full",
                                    src: (null == s ? void 0 : s.thumb) || "",
                                    alt: l,
                                    title: l
                                }), (0, n.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, n.jsx)("span", {
                                        className: "text-center font-medium text-gray-900 dark:text-white",
                                        children: r
                                    }), (0, n.jsx)("span", {
                                        className: "text-base font-semibold leading-tight",
                                        children: "/"
                                    }), (0, n.jsx)("span", {
                                        className: "text-sm font-normal leading-tight text-gray-500 dark:text-gray-400",
                                        children: a
                                    })]
                                })]
                            }), i && (0, n.jsx)("div", {
                                className: "mt-[10px] flex items-center justify-center space-x-1",
                                children: Array.from({
                                    length: 5
                                }).map((e, t) => (0, n.jsx)("svg", {
                                    className: "h-4 w-4 text-yellow-300",
                                    "aria-hidden": "true",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "currentColor",
                                    viewBox: "0 0 22 20",
                                    children: (0, n.jsx)("path", {
                                        d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                    })
                                }, t))
                            })]
                        })
                    })
                })
            }

            function q(e) {
                let {
                    data: t,
                    type: r = "website"
                } = e, {
                    customMenu: a,
                    introMenu: l,
                    serviceMenu: o,
                    quoteMenu: c,
                    faqMenu: d,
                    locationMenu: u,
                    ctaMenu: x,
                    contactMenu: m
                } = t, h = (0, s.usePathname)(), g = h.includes("preview"), f = "proposal" === r || h.startsWith("/p/"), p = [{
                    visible: !0,
                    Component: S,
                    props: {
                        introMenu: l,
                        contactMenu: m
                    }
                }, {
                    visible: !!o.services.length,
                    Component: O,
                    props: {
                        services: o.services
                    }
                }, {
                    visible: c.quotos.some(e => e.showQuote),
                    Component: D,
                    props: {
                        quotos: c.quotos
                    }
                }, {
                    visible: d.showFaq && d.questions.length > 0,
                    Component: M,
                    props: {
                        questions: d.questions
                    }
                }, {
                    visible: u.showLocation,
                    Component: U,
                    props: {
                        data: u
                    }
                }, {
                    visible: x.showCta,
                    Component: E,
                    props: {
                        ctaMenu: x,
                        contactMenu: m
                    }
                }], b = f ? p.slice(0, -2) : p;
                return (0, n.jsxs)(n.Fragment, {
                    children: [!g && (0, n.jsx)(i, {
                        GA_TRACKING_ID: a.googleAnalytics4,
                        GTM_ID: a.googleTagManager
                    }), (0, n.jsx)("section", {
                        className: "grid-full-width w-full gap-6 bg-white md:gap-0",
                        children: b.map(e => {
                            let {
                                visible: t,
                                Component: r,
                                props: a
                            } = e;
                            return t ? (0, n.jsx)(r, { ...a
                            }, r.name) : null
                        })
                    })]
                })
            }
            var H = r(8159);
            let B = {
                    facebook: "https://facebook.com/",
                    instagram: "https://instagram.com/",
                    twitter: "https://x.com/",
                    pinterest: "https://pinterest.com/",
                    tiktok: "https://tiktok.com/",
                    linkedin: "https://linkedin.com/in/"
                },
                W = e => {
                    try {
                        let t = new URL(e);
                        return t
                    } catch (e) {}
                    return !1
                },
                V = e => {
                    if (e.startsWith("/")) return e.slice(1);
                    if (e.includes("/")) {
                        let t = e.lastIndexOf("/");
                        return e.slice(t)
                    }
                    return e
                },
                Y = (e, t) => {
                    if (e in B) {
                        let r = B[e],
                            n = W(t);
                        if (n) return n.href;
                        let a = V(t);
                        try {
                            let e = new URL(a, r);
                            return e.href
                        } catch (e) {
                            console.error("An error occured while constructing a URL", e)
                        }
                        return "".concat(r).concat(a)
                    }
                    return t
                };

            function K() {
                return (0, n.jsx)(n.Fragment, {
                    children: H.RL.map(e => {
                        let {
                            label: t,
                            value: r,
                            icon: a
                        } = e;
                        return (0, n.jsxs)("li", {
                            children: [a, (0, n.jsx)("span", {
                                className: "sr-only",
                                children: t
                            })]
                        }, r)
                    })
                })
            }
            let X = H.RL.reduce((e, t) => {
                let {
                    value: r,
                    icon: n
                } = t;
                return e[r] = n, e
            }, {});

            function J(e) {
                let {
                    icons: t
                } = e;
                return (0, n.jsx)(n.Fragment, {
                    children: t.map((e, t) => {
                        let {
                            iconName: r,
                            provider: a,
                            linkSrc: s
                        } = e;
                        return (0, n.jsx)("li", {
                            className: "",
                            children: (0, n.jsxs)("a", {
                                href: Y(a, s),
                                target: "_blank",
                                children: [X[a], (0, n.jsx)("span", {
                                    className: "sr-only",
                                    children: r
                                })]
                            })
                        }, "".concat(t, "-").concat(a))
                    })
                })
            }
            let Q = e => {
                    let {
                        icons: t
                    } = e;
                    return (0, n.jsx)("ul", {
                        className: "flex flex-row items-center justify-center gap-4",
                        children: t.length ? (0, n.jsx)(J, {
                            icons: t
                        }) : (0, n.jsx)(K, {})
                    })
                },
                $ = new Date().getFullYear();

            function ee(e) {
                var t;
                let {
                    data: {
                        customMenu: r,
                        headerMenu: a,
                        websiteMenu: s
                    }
                } = e;
                return (0, n.jsxs)("footer", {
                    id: "footer",
                    className: "grid-full-width contents-container flex flex-col gap-5 bg-white",
                    children: [(0, n.jsxs)("span", {
                        className: "text-center text-sm text-gray-500",
                        children: ["\xa9 ", $, " ", (0, n.jsx)("a", {
                            href: "".concat("https://builder.bookipi.com/pages/").concat(r.siteUrl),
                            className: "hover:underline",
                            target: "_blank",
                            children: r.businessName
                        }), ". All rights reserved."]
                    }), s.showFooterLink && (0, n.jsxs)("span", {
                        className: "text-center text-sm text-gray-500 dark:text-gray-400",
                        children: ["Powered by", " ", (0, n.jsxs)("a", {
                            href: "https://bookipi.com/",
                            target: "_blank",
                            className: "font-bold hover:underline",
                            children: ["Bookipi ", "❤️"]
                        })]
                    }), (0, n.jsx)("div", {
                        className: "flex items-center justify-center space-x-1",
                        children: (null === (t = a.socialIcons) || void 0 === t ? void 0 : t.isEnable) && (0, n.jsx)(Q, {
                            icons: a.socialIcons.icons
                        })
                    })]
                })
            }

            function et(e) {
                var t;
                let {
                    data: r
                } = e, {
                    headerMenu: a,
                    websiteMenu: s
                } = r, l = s.imageDescription || s.siteName;
                return (0, n.jsx)("nav", {
                    id: "header",
                    className: "grid-full-width flex w-full flex-row justify-between bg-white px-4 py-6 @4xl:px-16",
                    children: (0, n.jsxs)("div", {
                        className: "flex w-full flex-col-reverse flex-wrap gap-6 overflow-x-hidden @4xl:flex-row @4xl:flex-nowrap @4xl:justify-between @4xl:gap-4",
                        children: [(0, n.jsxs)("div", {
                            id: "logo-siteName-button-group",
                            className: "flex flex-row flex-wrap justify-between ",
                            children: [(0, n.jsxs)("div", {
                                id: "logo-siteName-group",
                                className: "flex flex-1 flex-row items-center gap-3 overflow-hidden whitespace-nowrap",
                                children: [a.logo && s.logoSrc.thumb && (0, n.jsx)("div", {
                                    className: "inline-block w-8 min-w-[32px]",
                                    children: (0, n.jsx)(_(), {
                                        src: s.logoSrc.thumb,
                                        alt: l,
                                        title: l,
                                        height: 32,
                                        width: 32,
                                        style: {
                                            width: "32px",
                                            height: "32px"
                                        },
                                        className: "rounded-full object-cover"
                                    })
                                }), !!a.siteName && (0, n.jsx)("h1", {
                                    className: "overflow-hidden overflow-ellipsis whitespace-nowrap break-words text-2xl font-semibold text-gray-900 @sm:max-w-none dark:text-gray-300",
                                    children: r.websiteMenu.siteName
                                })]
                            }), a.button.isEnable && a.button.text && (0, n.jsx)("div", {
                                id: "button-group",
                                className: "order-3 m-1 justify-center @sm:inline-flex @4xl:hidden",
                                children: (0, n.jsx)(C, {
                                    text: a.button.text,
                                    className: "shop-now-button hide-on-proposal",
                                    button: a.button,
                                    contactMenu: r.contactMenu,
                                    buttonSize: "base"
                                })
                            })]
                        }), (0, n.jsxs)("ul", {
                            id: "phone-social-group",
                            className: "flex w-full flex-row items-center justify-between @4xl:flex-1 @4xl:justify-end @4xl:gap-5",
                            children: [a.phoneNumber.isEnable && (0, n.jsx)("li", {
                                children: (0, n.jsx)("a", {
                                    href: "tel:".concat(a.phoneNumber.phoneNumber),
                                    className: "whitespace-nowrap text-sm font-medium text-gray-900 @sm:inline-block dark:text-gray-300",
                                    children: a.phoneNumber.phoneNumber || "000-0000-0000"
                                })
                            }), (null === (t = a.socialIcons) || void 0 === t ? void 0 : t.isEnable) && (0, n.jsx)("li", {
                                className: "inline-flex justify-end",
                                children: (0, n.jsx)(Q, {
                                    icons: a.socialIcons.icons
                                })
                            }), a.button.isEnable && a.button.text && (0, n.jsx)("li", {
                                id: "button-group-desktop",
                                className: "hide-on-proposal hidden justify-center @4xl:inline-flex",
                                children: (0, n.jsx)(C, {
                                    text: a.button.text,
                                    className: "shop-now-button",
                                    button: a.button,
                                    contactMenu: r.contactMenu,
                                    buttonSize: "base"
                                })
                            })]
                        })]
                    })
                })
            }
            var er = r(4868),
                en = r(9314);

            function ea(e) {
                let {
                    contactMenu: t
                } = e, r = (0, u.useToastContext)(), a = p(), {
                    contactFormModal: l
                } = (0, v.useModalContext)(), i = (0, s.useParams)(), o = i.siteUrl, c = async e => {
                    let t = new FormData(e);
                    if (a) {
                        r.showToast(b.hi.CONTACT_FORM_SUBMIT_IN_PREVIEW, h.Ix.WARNING), l.close();
                        return
                    }
                    let n = (0, g.as)(t.get("full_name"), "").trim(),
                        s = (0, g.as)(t.get("email"), "").trim(),
                        i = (0, g.as)(t.get("phone_number"), "").trim(),
                        c = (0, g.as)(t.get("message"), "").trim(),
                        u = o || window.location.hostname;
                    try {
                        await d(u, {
                            id: "",
                            email: s,
                            name: n,
                            phone: i,
                            message: c,
                            submitted: new Date().toString()
                        }), r.showToast("Message sent", h.Ix.SUCCESS), l.toggle()
                    } catch (e) {
                        var x, m, f;
                        r.showToast(null === (x = e.response) || void 0 === x ? void 0 : null === (m = x.errors) || void 0 === m ? void 0 : null === (f = m[0]) || void 0 === f ? void 0 : f.message, h.Ix.DANGER)
                    }
                };
                return (0, n.jsx)(er.A, {
                    isOpen: l.isOpen,
                    isToggling: l.isToggling,
                    closeModal: l.close,
                    children: (0, n.jsx)(en.t, {
                        className: "p-0 text-center shadow-none",
                        contactMenu: t,
                        onSubmit: c,
                        closeModal: l.close
                    })
                })
            }

            function es(e) {
                let {
                    data: t,
                    type: r = "website",
                    ...a
                } = e, s = "proposal" === r;
                return (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)(ea, {
                        contactMenu: t.contactMenu
                    }), (0, n.jsxs)("div", {
                        className: (0, o.Z)("content-grid mx-auto w-full @container", {
                            "is-proposal": s
                        }),
                        ...a,
                        children: [(0, n.jsx)(et, {
                            data: {
                                headerMenu: t.headerMenu,
                                websiteMenu: t.webSiteMenu,
                                contactMenu: t.contactMenu
                            }
                        }), (0, n.jsx)(q, {
                            data: t,
                            type: r
                        }), !s && (0, n.jsx)(ee, {
                            data: {
                                headerMenu: t.headerMenu,
                                customMenu: t.customMenu,
                                websiteMenu: t.webSiteMenu
                            }
                        })]
                    })]
                })
            }
        },
        6230: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return l
                }
            });
            var n = r(5689),
                a = r(4279),
                s = r(1646);

            function l(e) {
                let {
                    id: t,
                    rows: r,
                    placeholder: l,
                    label: i,
                    labelHidden: o = !0,
                    helperText: c,
                    tooltipContent: d,
                    autoFocus: u = !1,
                    className: x = "",
                    ...m
                } = e;
                return (0, n.jsxs)("div", {
                    className: "text-left",
                    children: [(0, n.jsxs)("label", {
                        htmlFor: t,
                        className: (0, a.Z)({
                            "sr-only": o,
                            asterisk: !!m.required
                        }, d ? "inline-flex items-center" : "flex", "mb-2 gap-2"),
                        children: [(0, n.jsx)("span", {
                            className: "text-sm font-medium text-gray-900 dark:text-white",
                            children: i
                        }), d && (0, n.jsx)(s.u, {
                            content: d,
                            children: (0, n.jsx)("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "0.875em",
                                viewBox: "0 0 512 512",
                                children: (0, n.jsx)("path", {
                                    d: "M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336h24V272H216c-13.3 0-24-10.7-24-24s10.7-24 24-24h48c13.3 0 24 10.7 24 24v88h8c13.3 0 24 10.7 24 24s-10.7 24-24 24H216c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
                                })
                            })
                        })]
                    }), c && (0, n.jsx)("span", {
                        className: "mb-2 inline-block text-xs font-normal text-gray-500",
                        children: c
                    }), (0, n.jsx)("textarea", {
                        id: t,
                        rows: r,
                        className: (0, a.Z)("block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500", x),
                        name: t,
                        placeholder: l,
                        ...m
                    })]
                })
            }
        },
        1646: function(e, t, r) {
            r.d(t, {
                u: function() {
                    return l
                }
            });
            var n = r(5689),
                a = r(4279),
                s = r(1123);

            function l(e) {
                let {
                    children: t,
                    content: r = "Sample tooltip content",
                    className: l = "",
                    ...i
                } = e;
                return (0, n.jsx)(s.u, {
                    content: r,
                    className: (0, a.Z)(l, "z-50"),
                    ...i,
                    children: t
                })
            }
        },
        9239: function(e, t, r) {
            r.d(t, {
                J1: function() {
                    return i
                },
                Pw: function() {
                    return s
                },
                RZ: function() {
                    return n
                },
                eK: function() {
                    return l
                },
                hi: function() {
                    return a
                }
            });
            let n = {
                    FAILED_TO_COPY_LINK: "Failed to copy link, please try again",
                    FAILED_TO_PUBLISH_WEBSITE: "Failed to publish website, please try again",
                    PAGE_REG: "Failed to regenerate page, please try again",
                    PAGE_UNP: "Failed to unpublish website, please try again",
                    FAILED_TO_FETCH_ENTRI_TOKEN: "Failed to fetch Entri token"
                },
                a = {
                    CONTACT_FORM_SUBMIT_IN_PREVIEW: "This feature is not active in preview. Please test in your published URL",
                    FIX_ERRORS_IN_MENU: "Please fix errors in the menu"
                },
                s = {
                    PAGE_REG: "Page regenerated",
                    PAGE_UNP: "Website unpublished",
                    LINK_COPIED: "Link copied"
                },
                l = {
                    EMPTY: "URL field cannot be empty",
                    VALID: "",
                    INVALID_VALUE: "Your Site URL can only include alphanumeric characters (abc123) and hyphens (-)",
                    DUPLICATE: "Duplicate URL"
                },
                i = {
                    MESSAGES: {
                        PROPOSAL_REG: "Are you sure you want to regenerate this proposal?",
                        PAGE_REG: "Are you sure you want to regenerate this page?",
                        PAGE_UNP: "Are you sure you want to unpublish this page?",
                        CONTACT_FORM_DELETE: "Are you sure you want to delete this?"
                    },
                    CONFIRM_TEXT: "Yes, I am sure",
                    CANCEL_TEXT: "No, cancel"
                }
        },
        6865: function(e, t, r) {
            r.r(t), r.d(t, {
                ModalContext: function() {
                    return l
                },
                ModalContextProvider: function() {
                    return i
                },
                useModalContext: function() {
                    return o
                }
            });
            var n = r(5689),
                a = r(983),
                s = r(2386);
            let l = (0, s.createContext)({
                    contactFormModal: {
                        isOpen: !1,
                        isToggling: !1,
                        toggle: () => {},
                        close: () => {}
                    }
                }),
                i = e => {
                    let {
                        children: t
                    } = e, r = (0, a.usePopup)({
                        defaultOpen: !1,
                        duration: 100
                    });
                    return (0, n.jsx)(l.Provider, {
                        value: {
                            contactFormModal: r
                        },
                        children: t
                    })
                },
                o = () => (0, s.useContext)(l)
        },
        1703: function(e, t, r) {
            r.r(t), r.d(t, {
                ToastContext: function() {
                    return d
                },
                ToastContextProvider: function() {
                    return x
                },
                useToastContext: function() {
                    return m
                }
            });
            var n = r(5689),
                a = r(2386),
                s = r(7305),
                l = r(4279),
                i = r(1123);
            let o = {
                [s.Ix.SUCCESS]: (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M16.707 5.29279C16.8945 5.48031 16.9998 5.73462 16.9998 5.99979C16.9998 6.26495 16.8945 6.51926 16.707 6.70679L8.70698 14.7068C8.51945 14.8943 8.26514 14.9996 7.99998 14.9996C7.73482 14.9996 7.48051 14.8943 7.29298 14.7068L3.29298 10.7068C3.11082 10.5182 3.01003 10.2656 3.01231 10.0034C3.01458 9.74119 3.11975 9.49038 3.30516 9.30497C3.49057 9.11956 3.74138 9.01439 4.00358 9.01211C4.26578 9.00983 4.51838 9.11063 4.70698 9.29279L7.99998 12.5858L15.293 5.29279C15.4805 5.10532 15.7348 5 16 5C16.2651 5 16.5195 5.10532 16.707 5.29279Z"
                        })
                    }), (0, n.jsx)("span", {
                        className: "sr-only",
                        children: "Success icon"
                    })]
                }),
                [s.Ix.WARNING]: (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, n.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM10 15a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm1-4a1 1 0 0 1-2 0V6a1 1 0 0 1 2 0v5Z"
                        })
                    }), (0, n.jsx)("span", {
                        className: "sr-only",
                        children: "Warning icon"
                    })]
                }),
                [s.Ix.DANGER]: (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, n.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 11.793a1 1 0 1 1-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 0 1-1.414-1.414L8.586 10 6.293 7.707a1 1 0 0 1 1.414-1.414L10 8.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 10l2.293 2.293Z"
                        })
                    }), (0, n.jsx)("span", {
                        className: "sr-only",
                        children: "Error icon"
                    })]
                })
            };

            function c(e) {
                let {
                    status: t,
                    message: r,
                    closeToast: a
                } = e;
                return (0, n.jsxs)(i.FN, {
                    className: "pointer-events-auto mt-2 min-w-[300px] max-w-md items-center pr-2",
                    children: [(0, n.jsx)("div", {
                        className: (0, l.Z)("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", {
                            "bg-red-100 text-red-500 dark:bg-red-800 dark:text-red-200": t === s.Ix.DANGER,
                            "bg-orange-100 text-orange-500 dark:bg-orange-700 dark:text-orange-200": t === s.Ix.WARNING,
                            "bg-primary-100 text-primary-500 dark:bg-primary-700 dark:text-primary-200": t === s.Ix.SUCCESS
                        }),
                        children: t in o && o[t]
                    }), (0, n.jsx)("div", {
                        className: "mx-3 flex-grow text-sm font-normal",
                        children: r
                    }), (0, n.jsx)(i.FN.Toggle, {
                        onClick: a,
                        className: "flex items-center justify-center p-0 [&_svg]:h-[18px] [&_svg]:w-[18px]"
                    })]
                })
            }
            let d = (0, a.createContext)({
                    toast: [],
                    showToast: (e, t) => {}
                }),
                u = () => {
                    let e = Date.now(),
                        t = Math.random().toString(36).substring(7);
                    return [t, e].join("-")
                },
                x = e => {
                    let {
                        children: t
                    } = e, [r, s] = (0, a.useState)([]);
                    return (0, n.jsxs)(d.Provider, {
                        value: {
                            toast: r,
                            showToast: (e, t) => {
                                let r = u(),
                                    n = () => {
                                        s(e => e.filter(e => e.id !== r)), clearTimeout(a)
                                    },
                                    a = setTimeout(n, 3e3),
                                    l = {
                                        id: r,
                                        message: e,
                                        status: t,
                                        clear: n
                                    };
                                s(e => [...e, l])
                            }
                        },
                        children: [t, (0, n.jsx)("div", {
                            role: "alert",
                            className: "pointer-events-none fixed left-0 top-0 z-50 flex h-full w-full justify-center",
                            children: (0, n.jsx)("div", {
                                className: "mt-14",
                                children: r.map(e => (0, n.jsx)(c, {
                                    message: e.message,
                                    status: e.status,
                                    closeToast: e.clear
                                }, e.id))
                            })
                        })]
                    })
                },
                m = () => (0, a.useContext)(d)
        },
        7305: function(e, t, r) {
            var n, a, s, l;
            r.d(t, {
                Ix: function() {
                    return n
                }
            }), r(2386), (s = n || (n = {})).SUCCESS = "success", s.WARNING = "warning", s.DANGER = "danger", (l = a || (a = {})).REGENERATE = "regenerate", l.PUBLISH = "publish", l.UNPUBLISH = "unpublish"
        }
    }
]);