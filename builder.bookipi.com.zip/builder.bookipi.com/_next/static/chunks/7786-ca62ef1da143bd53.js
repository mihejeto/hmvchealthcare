(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7786], {
        2554: function(e, t) {
            var i = "undefined" != typeof self ? self : this,
                r = function() {
                    function e() {
                        this.fetch = !1, this.DOMException = i.DOMException
                    }
                    return e.prototype = i, new e
                }();
            (function(e) {
                var t = {
                    searchParams: "URLSearchParams" in r,
                    iterable: "Symbol" in r && "iterator" in Symbol,
                    blob: "FileReader" in r && "Blob" in r && function() {
                        try {
                            return new Blob, !0
                        } catch (e) {
                            return !1
                        }
                    }(),
                    formData: "FormData" in r,
                    arrayBuffer: "ArrayBuffer" in r
                };
                if (t.arrayBuffer) var i = ["[object Int8Array]", "[object Uint8Array]", "[object Uint8ClampedArray]", "[object Int16Array]", "[object Uint16Array]", "[object Int32Array]", "[object Uint32Array]", "[object Float32Array]", "[object Float64Array]"],
                    n = ArrayBuffer.isView || function(e) {
                        return e && i.indexOf(Object.prototype.toString.call(e)) > -1
                    };

                function s(e) {
                    if ("string" != typeof e && (e = String(e)), /[^a-z0-9\-#$%&'*+.^_`|~]/i.test(e)) throw TypeError("Invalid character in header field name");
                    return e.toLowerCase()
                }

                function o(e) {
                    return "string" != typeof e && (e = String(e)), e
                }

                function a(e) {
                    var i = {
                        next: function() {
                            var t = e.shift();
                            return {
                                done: void 0 === t,
                                value: t
                            }
                        }
                    };
                    return t.iterable && (i[Symbol.iterator] = function() {
                        return i
                    }), i
                }

                function l(e) {
                    this.map = {}, e instanceof l ? e.forEach(function(e, t) {
                        this.append(t, e)
                    }, this) : Array.isArray(e) ? e.forEach(function(e) {
                        this.append(e[0], e[1])
                    }, this) : e && Object.getOwnPropertyNames(e).forEach(function(t) {
                        this.append(t, e[t])
                    }, this)
                }

                function u(e) {
                    if (e.bodyUsed) return Promise.reject(TypeError("Already read"));
                    e.bodyUsed = !0
                }

                function c(e) {
                    return new Promise(function(t, i) {
                        e.onload = function() {
                            t(e.result)
                        }, e.onerror = function() {
                            i(e.error)
                        }
                    })
                }

                function h(e) {
                    var t = new FileReader,
                        i = c(t);
                    return t.readAsArrayBuffer(e), i
                }

                function p(e) {
                    if (e.slice) return e.slice(0);
                    var t = new Uint8Array(e.byteLength);
                    return t.set(new Uint8Array(e)), t.buffer
                }

                function d() {
                    return this.bodyUsed = !1, this._initBody = function(e) {
                        if (this._bodyInit = e, e) {
                            if ("string" == typeof e) this._bodyText = e;
                            else if (t.blob && Blob.prototype.isPrototypeOf(e)) this._bodyBlob = e;
                            else if (t.formData && FormData.prototype.isPrototypeOf(e)) this._bodyFormData = e;
                            else if (t.searchParams && URLSearchParams.prototype.isPrototypeOf(e)) this._bodyText = e.toString();
                            else {
                                var i;
                                t.arrayBuffer && t.blob && (i = e) && DataView.prototype.isPrototypeOf(i) ? (this._bodyArrayBuffer = p(e.buffer), this._bodyInit = new Blob([this._bodyArrayBuffer])) : t.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(e) || n(e)) ? this._bodyArrayBuffer = p(e) : this._bodyText = e = Object.prototype.toString.call(e)
                            }
                        } else this._bodyText = "";
                        !this.headers.get("content-type") && ("string" == typeof e ? this.headers.set("content-type", "text/plain;charset=UTF-8") : this._bodyBlob && this._bodyBlob.type ? this.headers.set("content-type", this._bodyBlob.type) : t.searchParams && URLSearchParams.prototype.isPrototypeOf(e) && this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"))
                    }, t.blob && (this.blob = function() {
                        var e = u(this);
                        if (e) return e;
                        if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
                        if (this._bodyArrayBuffer) return Promise.resolve(new Blob([this._bodyArrayBuffer]));
                        if (!this._bodyFormData) return Promise.resolve(new Blob([this._bodyText]));
                        throw Error("could not read FormData body as blob")
                    }, this.arrayBuffer = function() {
                        return this._bodyArrayBuffer ? u(this) || Promise.resolve(this._bodyArrayBuffer) : this.blob().then(h)
                    }), this.text = function() {
                        var e, t, i, r = u(this);
                        if (r) return r;
                        if (this._bodyBlob) return e = this._bodyBlob, i = c(t = new FileReader), t.readAsText(e), i;
                        if (this._bodyArrayBuffer) return Promise.resolve(function(e) {
                            for (var t = new Uint8Array(e), i = Array(t.length), r = 0; r < t.length; r++) i[r] = String.fromCharCode(t[r]);
                            return i.join("")
                        }(this._bodyArrayBuffer));
                        if (!this._bodyFormData) return Promise.resolve(this._bodyText);
                        throw Error("could not read FormData body as text")
                    }, t.formData && (this.formData = function() {
                        return this.text().then(E)
                    }), this.json = function() {
                        return this.text().then(JSON.parse)
                    }, this
                }
                l.prototype.append = function(e, t) {
                    e = s(e), t = o(t);
                    var i = this.map[e];
                    this.map[e] = i ? i + ", " + t : t
                }, l.prototype.delete = function(e) {
                    delete this.map[s(e)]
                }, l.prototype.get = function(e) {
                    return e = s(e), this.has(e) ? this.map[e] : null
                }, l.prototype.has = function(e) {
                    return this.map.hasOwnProperty(s(e))
                }, l.prototype.set = function(e, t) {
                    this.map[s(e)] = o(t)
                }, l.prototype.forEach = function(e, t) {
                    for (var i in this.map) this.map.hasOwnProperty(i) && e.call(t, this.map[i], i, this)
                }, l.prototype.keys = function() {
                    var e = [];
                    return this.forEach(function(t, i) {
                        e.push(i)
                    }), a(e)
                }, l.prototype.values = function() {
                    var e = [];
                    return this.forEach(function(t) {
                        e.push(t)
                    }), a(e)
                }, l.prototype.entries = function() {
                    var e = [];
                    return this.forEach(function(t, i) {
                        e.push([i, t])
                    }), a(e)
                }, t.iterable && (l.prototype[Symbol.iterator] = l.prototype.entries);
                var f = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];

                function y(e, t) {
                    var i, r, n = (t = t || {}).body;
                    if (e instanceof y) {
                        if (e.bodyUsed) throw TypeError("Already read");
                        this.url = e.url, this.credentials = e.credentials, t.headers || (this.headers = new l(e.headers)), this.method = e.method, this.mode = e.mode, this.signal = e.signal, n || null == e._bodyInit || (n = e._bodyInit, e.bodyUsed = !0)
                    } else this.url = String(e);
                    if (this.credentials = t.credentials || this.credentials || "same-origin", (t.headers || !this.headers) && (this.headers = new l(t.headers)), this.method = (r = (i = t.method || this.method || "GET").toUpperCase(), f.indexOf(r) > -1 ? r : i), this.mode = t.mode || this.mode || null, this.signal = t.signal || this.signal, this.referrer = null, ("GET" === this.method || "HEAD" === this.method) && n) throw TypeError("Body not allowed for GET or HEAD requests");
                    this._initBody(n)
                }

                function E(e) {
                    var t = new FormData;
                    return e.trim().split("&").forEach(function(e) {
                        if (e) {
                            var i = e.split("="),
                                r = i.shift().replace(/\+/g, " "),
                                n = i.join("=").replace(/\+/g, " ");
                            t.append(decodeURIComponent(r), decodeURIComponent(n))
                        }
                    }), t
                }

                function m(e, t) {
                    t || (t = {}), this.type = "default", this.status = void 0 === t.status ? 200 : t.status, this.ok = this.status >= 200 && this.status < 300, this.statusText = "statusText" in t ? t.statusText : "OK", this.headers = new l(t.headers), this.url = t.url || "", this._initBody(e)
                }
                y.prototype.clone = function() {
                    return new y(this, {
                        body: this._bodyInit
                    })
                }, d.call(y.prototype), d.call(m.prototype), m.prototype.clone = function() {
                    return new m(this._bodyInit, {
                        status: this.status,
                        statusText: this.statusText,
                        headers: new l(this.headers),
                        url: this.url
                    })
                }, m.error = function() {
                    var e = new m(null, {
                        status: 0,
                        statusText: ""
                    });
                    return e.type = "error", e
                };
                var T = [301, 302, 303, 307, 308];
                m.redirect = function(e, t) {
                    if (-1 === T.indexOf(t)) throw RangeError("Invalid status code");
                    return new m(null, {
                        status: t,
                        headers: {
                            location: e
                        }
                    })
                }, e.DOMException = r.DOMException;
                try {
                    new e.DOMException
                } catch (t) {
                    e.DOMException = function(e, t) {
                        this.message = e, this.name = t;
                        var i = Error(e);
                        this.stack = i.stack
                    }, e.DOMException.prototype = Object.create(Error.prototype), e.DOMException.prototype.constructor = e.DOMException
                }

                function v(i, r) {
                    return new Promise(function(n, s) {
                        var o = new y(i, r);
                        if (o.signal && o.signal.aborted) return s(new e.DOMException("Aborted", "AbortError"));
                        var a = new XMLHttpRequest;

                        function u() {
                            a.abort()
                        }
                        a.onload = function() {
                            var e, t, i = {
                                status: a.status,
                                statusText: a.statusText,
                                headers: (e = a.getAllResponseHeaders() || "", t = new l, e.replace(/\r?\n[\t ]+/g, " ").split(/\r?\n/).forEach(function(e) {
                                    var i = e.split(":"),
                                        r = i.shift().trim();
                                    if (r) {
                                        var n = i.join(":").trim();
                                        t.append(r, n)
                                    }
                                }), t)
                            };
                            i.url = "responseURL" in a ? a.responseURL : i.headers.get("X-Request-URL");
                            var r = "response" in a ? a.response : a.responseText;
                            n(new m(r, i))
                        }, a.onerror = function() {
                            s(TypeError("Network request failed"))
                        }, a.ontimeout = function() {
                            s(TypeError("Network request failed"))
                        }, a.onabort = function() {
                            s(new e.DOMException("Aborted", "AbortError"))
                        }, a.open(o.method, o.url, !0), "include" === o.credentials ? a.withCredentials = !0 : "omit" === o.credentials && (a.withCredentials = !1), "responseType" in a && t.blob && (a.responseType = "blob"), o.headers.forEach(function(e, t) {
                            a.setRequestHeader(t, e)
                        }), o.signal && (o.signal.addEventListener("abort", u), a.onreadystatechange = function() {
                            4 === a.readyState && o.signal.removeEventListener("abort", u)
                        }), a.send(void 0 === o._bodyInit ? null : o._bodyInit)
                    })
                }
                v.polyfill = !0, r.fetch || (r.fetch = v, r.Headers = l, r.Request = y, r.Response = m), e.Headers = l, e.Request = y, e.Response = m, e.fetch = v, Object.defineProperty(e, "__esModule", {
                    value: !0
                })
            })({}), r.fetch.ponyfill = !0, delete r.fetch.polyfill, (t = r.fetch).default = r.fetch, t.fetch = r.fetch, t.Headers = r.Headers, t.Request = r.Request, t.Response = r.Response, e.exports = t
        },
        2066: function(e, t, i) {
            "use strict";

            function r(e, t) {
                return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(t)
                    }
                }))
            }
            i.d(t, {
                _: function() {
                    return r
                }
            })
        },
        4426: function(e, t, i) {
            "use strict";
            i.d(t, {
                g6: function() {
                    return eE
                },
                Ps: function() {
                    return eI
                }
            });
            let r = JSON,
                n = e => e.toUpperCase(),
                s = e => {
                    let t = {};
                    return e.forEach((e, i) => {
                        t[i] = e
                    }), t
                },
                o = (e, t, i) => e.document ? e : {
                    document: e,
                    variables: t,
                    requestHeaders: i,
                    signal: void 0
                },
                a = (e, t, i) => e.query ? e : {
                    query: e,
                    variables: t,
                    requestHeaders: i,
                    signal: void 0
                },
                l = (e, t) => e.documents ? e : {
                    documents: e,
                    requestHeaders: t,
                    signal: void 0
                },
                u = /\r\n|[\n\r]/g;

            function c(e, t) {
                let i = 0,
                    r = 1;
                for (let n of e.body.matchAll(u)) {
                    if ("number" == typeof n.index || function(e, t) {
                            if (!e) throw Error(null != t ? t : "Unexpected invariant triggered.")
                        }(!1), n.index >= t) break;
                    i = n.index + n[0].length, r += 1
                }
                return {
                    line: r,
                    column: t + 1 - i
                }
            }

            function h(e, t) {
                let i = e.locationOffset.column - 1,
                    r = "".padStart(i) + e.body,
                    n = t.line - 1,
                    s = e.locationOffset.line - 1,
                    o = t.line + s,
                    a = 1 === t.line ? i : 0,
                    l = t.column + a,
                    u = `${e.name}:${o}:${l}
`,
                    c = r.split(/\r\n|[\n\r]/g),
                    h = c[n];
                if (h.length > 120) {
                    let e = Math.floor(l / 80),
                        t = l % 80,
                        i = [];
                    for (let e = 0; e < h.length; e += 80) i.push(h.slice(e, e + 80));
                    return u + p([
                        [`${o} |`, i[0]], ...i.slice(1, e + 1).map(e => ["|", e]), ["|", "^".padStart(t)],
                        ["|", i[e + 1]]
                    ])
                }
                return u + p([
                    [`${o-1} |`, c[n - 1]],
                    [`${o} |`, h],
                    ["|", "^".padStart(l)],
                    [`${o+1} |`, c[n + 1]]
                ])
            }

            function p(e) {
                let t = e.filter(([e, t]) => void 0 !== t),
                    i = Math.max(...t.map(([e]) => e.length));
                return t.map(([e, t]) => e.padStart(i) + (t ? " " + t : "")).join("\n")
            }
            class d extends Error {
                constructor(e, ...t) {
                    var i, r, n, s;
                    let {
                        nodes: o,
                        source: a,
                        positions: l,
                        path: u,
                        originalError: h,
                        extensions: p
                    } = function(e) {
                        let t = e[0];
                        return null == t || "kind" in t || "length" in t ? {
                            nodes: t,
                            source: e[1],
                            positions: e[2],
                            path: e[3],
                            originalError: e[4],
                            extensions: e[5]
                        } : t
                    }(t);
                    super(e), this.name = "GraphQLError", this.path = null != u ? u : void 0, this.originalError = null != h ? h : void 0, this.nodes = f(Array.isArray(o) ? o : o ? [o] : void 0);
                    let y = f(null === (i = this.nodes) || void 0 === i ? void 0 : i.map(e => e.loc).filter(e => null != e));
                    this.source = null != a ? a : null == y ? void 0 : null === (r = y[0]) || void 0 === r ? void 0 : r.source, this.positions = null != l ? l : null == y ? void 0 : y.map(e => e.start), this.locations = l && a ? l.map(e => c(a, e)) : null == y ? void 0 : y.map(e => c(e.source, e.start));
                    let E = "object" == typeof(s = null == h ? void 0 : h.extensions) && null !== s ? null == h ? void 0 : h.extensions : void 0;
                    this.extensions = null !== (n = null != p ? p : E) && void 0 !== n ? n : Object.create(null), Object.defineProperties(this, {
                        message: {
                            writable: !0,
                            enumerable: !0
                        },
                        name: {
                            enumerable: !1
                        },
                        nodes: {
                            enumerable: !1
                        },
                        source: {
                            enumerable: !1
                        },
                        positions: {
                            enumerable: !1
                        },
                        originalError: {
                            enumerable: !1
                        }
                    }), null != h && h.stack ? Object.defineProperty(this, "stack", {
                        value: h.stack,
                        writable: !0,
                        configurable: !0
                    }) : Error.captureStackTrace ? Error.captureStackTrace(this, d) : Object.defineProperty(this, "stack", {
                        value: Error().stack,
                        writable: !0,
                        configurable: !0
                    })
                }
                get[Symbol.toStringTag]() {
                    return "GraphQLError"
                }
                toString() {
                    let e = this.message;
                    if (this.nodes) {
                        for (let i of this.nodes)
                            if (i.loc) {
                                var t;
                                e += "\n\n" + h((t = i.loc).source, c(t.source, t.start))
                            }
                    } else if (this.source && this.locations)
                        for (let t of this.locations) e += "\n\n" + h(this.source, t);
                    return e
                }
                toJSON() {
                    let e = {
                        message: this.message
                    };
                    return null != this.locations && (e.locations = this.locations), null != this.path && (e.path = this.path), null != this.extensions && Object.keys(this.extensions).length > 0 && (e.extensions = this.extensions), e
                }
            }

            function f(e) {
                return void 0 === e || 0 === e.length ? void 0 : e
            }

            function y(e, t, i) {
                return new d(`Syntax Error: ${i}`, {
                    source: e,
                    positions: [t]
                })
            }
            class E {
                constructor(e, t, i) {
                    this.start = e.start, this.end = t.end, this.startToken = e, this.endToken = t, this.source = i
                }
                get[Symbol.toStringTag]() {
                    return "Location"
                }
                toJSON() {
                    return {
                        start: this.start,
                        end: this.end
                    }
                }
            }
            class m {
                constructor(e, t, i, r, n, s) {
                    this.kind = e, this.start = t, this.end = i, this.line = r, this.column = n, this.value = s, this.prev = null, this.next = null
                }
                get[Symbol.toStringTag]() {
                    return "Token"
                }
                toJSON() {
                    return {
                        kind: this.kind,
                        value: this.value,
                        line: this.line,
                        column: this.column
                    }
                }
            }
            let T = {
                    Name: [],
                    Document: ["definitions"],
                    OperationDefinition: ["name", "variableDefinitions", "directives", "selectionSet"],
                    VariableDefinition: ["variable", "type", "defaultValue", "directives"],
                    Variable: ["name"],
                    SelectionSet: ["selections"],
                    Field: ["alias", "name", "arguments", "directives", "selectionSet"],
                    Argument: ["name", "value"],
                    FragmentSpread: ["name", "directives"],
                    InlineFragment: ["typeCondition", "directives", "selectionSet"],
                    FragmentDefinition: ["name", "variableDefinitions", "typeCondition", "directives", "selectionSet"],
                    IntValue: [],
                    FloatValue: [],
                    StringValue: [],
                    BooleanValue: [],
                    NullValue: [],
                    EnumValue: [],
                    ListValue: ["values"],
                    ObjectValue: ["fields"],
                    ObjectField: ["name", "value"],
                    Directive: ["name", "arguments"],
                    NamedType: ["name"],
                    ListType: ["type"],
                    NonNullType: ["type"],
                    SchemaDefinition: ["description", "directives", "operationTypes"],
                    OperationTypeDefinition: ["type"],
                    ScalarTypeDefinition: ["description", "name", "directives"],
                    ObjectTypeDefinition: ["description", "name", "interfaces", "directives", "fields"],
                    FieldDefinition: ["description", "name", "arguments", "type", "directives"],
                    InputValueDefinition: ["description", "name", "type", "defaultValue", "directives"],
                    InterfaceTypeDefinition: ["description", "name", "interfaces", "directives", "fields"],
                    UnionTypeDefinition: ["description", "name", "directives", "types"],
                    EnumTypeDefinition: ["description", "name", "directives", "values"],
                    EnumValueDefinition: ["description", "name", "directives"],
                    InputObjectTypeDefinition: ["description", "name", "directives", "fields"],
                    DirectiveDefinition: ["description", "name", "arguments", "locations"],
                    SchemaExtension: ["directives", "operationTypes"],
                    ScalarTypeExtension: ["name", "directives"],
                    ObjectTypeExtension: ["name", "interfaces", "directives", "fields"],
                    InterfaceTypeExtension: ["name", "interfaces", "directives", "fields"],
                    UnionTypeExtension: ["name", "directives", "types"],
                    EnumTypeExtension: ["name", "directives", "values"],
                    InputObjectTypeExtension: ["name", "directives", "fields"]
                },
                v = new Set(Object.keys(T));

            function N(e) {
                let t = null == e ? void 0 : e.kind;
                return "string" == typeof t && v.has(t)
            }

            function I(e) {
                return 9 === e || 32 === e
            }

            function A(e) {
                return e >= 48 && e <= 57
            }

            function O(e) {
                return e >= 97 && e <= 122 || e >= 65 && e <= 90
            }

            function _(e) {
                return O(e) || 95 === e
            }(et = es || (es = {})).QUERY = "query", et.MUTATION = "mutation", et.SUBSCRIPTION = "subscription", (ei = eo || (eo = {})).QUERY = "QUERY", ei.MUTATION = "MUTATION", ei.SUBSCRIPTION = "SUBSCRIPTION", ei.FIELD = "FIELD", ei.FRAGMENT_DEFINITION = "FRAGMENT_DEFINITION", ei.FRAGMENT_SPREAD = "FRAGMENT_SPREAD", ei.INLINE_FRAGMENT = "INLINE_FRAGMENT", ei.VARIABLE_DEFINITION = "VARIABLE_DEFINITION", ei.SCHEMA = "SCHEMA", ei.SCALAR = "SCALAR", ei.OBJECT = "OBJECT", ei.FIELD_DEFINITION = "FIELD_DEFINITION", ei.ARGUMENT_DEFINITION = "ARGUMENT_DEFINITION", ei.INTERFACE = "INTERFACE", ei.UNION = "UNION", ei.ENUM = "ENUM", ei.ENUM_VALUE = "ENUM_VALUE", ei.INPUT_OBJECT = "INPUT_OBJECT", ei.INPUT_FIELD_DEFINITION = "INPUT_FIELD_DEFINITION", (er = ea || (ea = {})).NAME = "Name", er.DOCUMENT = "Document", er.OPERATION_DEFINITION = "OperationDefinition", er.VARIABLE_DEFINITION = "VariableDefinition", er.SELECTION_SET = "SelectionSet", er.FIELD = "Field", er.ARGUMENT = "Argument", er.FRAGMENT_SPREAD = "FragmentSpread", er.INLINE_FRAGMENT = "InlineFragment", er.FRAGMENT_DEFINITION = "FragmentDefinition", er.VARIABLE = "Variable", er.INT = "IntValue", er.FLOAT = "FloatValue", er.STRING = "StringValue", er.BOOLEAN = "BooleanValue", er.NULL = "NullValue", er.ENUM = "EnumValue", er.LIST = "ListValue", er.OBJECT = "ObjectValue", er.OBJECT_FIELD = "ObjectField", er.DIRECTIVE = "Directive", er.NAMED_TYPE = "NamedType", er.LIST_TYPE = "ListType", er.NON_NULL_TYPE = "NonNullType", er.SCHEMA_DEFINITION = "SchemaDefinition", er.OPERATION_TYPE_DEFINITION = "OperationTypeDefinition", er.SCALAR_TYPE_DEFINITION = "ScalarTypeDefinition", er.OBJECT_TYPE_DEFINITION = "ObjectTypeDefinition", er.FIELD_DEFINITION = "FieldDefinition", er.INPUT_VALUE_DEFINITION = "InputValueDefinition", er.INTERFACE_TYPE_DEFINITION = "InterfaceTypeDefinition", er.UNION_TYPE_DEFINITION = "UnionTypeDefinition", er.ENUM_TYPE_DEFINITION = "EnumTypeDefinition", er.ENUM_VALUE_DEFINITION = "EnumValueDefinition", er.INPUT_OBJECT_TYPE_DEFINITION = "InputObjectTypeDefinition", er.DIRECTIVE_DEFINITION = "DirectiveDefinition", er.SCHEMA_EXTENSION = "SchemaExtension", er.SCALAR_TYPE_EXTENSION = "ScalarTypeExtension", er.OBJECT_TYPE_EXTENSION = "ObjectTypeExtension", er.INTERFACE_TYPE_EXTENSION = "InterfaceTypeExtension", er.UNION_TYPE_EXTENSION = "UnionTypeExtension", er.ENUM_TYPE_EXTENSION = "EnumTypeExtension", er.INPUT_OBJECT_TYPE_EXTENSION = "InputObjectTypeExtension", (en = el || (el = {})).SOF = "<SOF>", en.EOF = "<EOF>", en.BANG = "!", en.DOLLAR = "$", en.AMP = "&", en.PAREN_L = "(", en.PAREN_R = ")", en.SPREAD = "...", en.COLON = ":", en.EQUALS = "=", en.AT = "@", en.BRACKET_L = "[", en.BRACKET_R = "]", en.BRACE_L = "{", en.PIPE = "|", en.BRACE_R = "}", en.NAME = "Name", en.INT = "Int", en.FLOAT = "Float", en.STRING = "String", en.BLOCK_STRING = "BlockString", en.COMMENT = "Comment";
            class x {
                constructor(e) {
                    let t = new m(el.SOF, 0, 0, 0, 0);
                    this.source = e, this.lastToken = t, this.token = t, this.line = 1, this.lineStart = 0
                }
                get[Symbol.toStringTag]() {
                    return "Lexer"
                }
                advance() {
                    this.lastToken = this.token;
                    let e = this.token = this.lookahead();
                    return e
                }
                lookahead() {
                    let e = this.token;
                    if (e.kind !== el.EOF)
                        do
                            if (e.next) e = e.next;
                            else {
                                let t = function(e, t) {
                                    let i = e.source.body,
                                        r = i.length,
                                        n = t;
                                    for (; n < r;) {
                                        let t = i.charCodeAt(n);
                                        switch (t) {
                                            case 65279:
                                            case 9:
                                            case 32:
                                            case 44:
                                                ++n;
                                                continue;
                                            case 10:
                                                ++n, ++e.line, e.lineStart = n;
                                                continue;
                                            case 13:
                                                10 === i.charCodeAt(n + 1) ? n += 2 : ++n, ++e.line, e.lineStart = n;
                                                continue;
                                            case 35:
                                                return function(e, t) {
                                                    let i = e.source.body,
                                                        r = i.length,
                                                        n = t + 1;
                                                    for (; n < r;) {
                                                        let e = i.charCodeAt(n);
                                                        if (10 === e || 13 === e) break;
                                                        if (b(e)) ++n;
                                                        else if (D(i, n)) n += 2;
                                                        else break
                                                    }
                                                    return k(e, el.COMMENT, t, n, i.slice(t + 1, n))
                                                }(e, n);
                                            case 33:
                                                return k(e, el.BANG, n, n + 1);
                                            case 36:
                                                return k(e, el.DOLLAR, n, n + 1);
                                            case 38:
                                                return k(e, el.AMP, n, n + 1);
                                            case 40:
                                                return k(e, el.PAREN_L, n, n + 1);
                                            case 41:
                                                return k(e, el.PAREN_R, n, n + 1);
                                            case 46:
                                                if (46 === i.charCodeAt(n + 1) && 46 === i.charCodeAt(n + 2)) return k(e, el.SPREAD, n, n + 3);
                                                break;
                                            case 58:
                                                return k(e, el.COLON, n, n + 1);
                                            case 61:
                                                return k(e, el.EQUALS, n, n + 1);
                                            case 64:
                                                return k(e, el.AT, n, n + 1);
                                            case 91:
                                                return k(e, el.BRACKET_L, n, n + 1);
                                            case 93:
                                                return k(e, el.BRACKET_R, n, n + 1);
                                            case 123:
                                                return k(e, el.BRACE_L, n, n + 1);
                                            case 124:
                                                return k(e, el.PIPE, n, n + 1);
                                            case 125:
                                                return k(e, el.BRACE_R, n, n + 1);
                                            case 34:
                                                if (34 === i.charCodeAt(n + 1) && 34 === i.charCodeAt(n + 2)) return function(e, t) {
                                                    let i = e.source.body,
                                                        r = i.length,
                                                        n = e.lineStart,
                                                        s = t + 3,
                                                        o = s,
                                                        a = "",
                                                        l = [];
                                                    for (; s < r;) {
                                                        let r = i.charCodeAt(s);
                                                        if (34 === r && 34 === i.charCodeAt(s + 1) && 34 === i.charCodeAt(s + 2)) {
                                                            a += i.slice(o, s), l.push(a);
                                                            let r = k(e, el.BLOCK_STRING, t, s + 3, (function(e) {
                                                                var t, i;
                                                                let r = Number.MAX_SAFE_INTEGER,
                                                                    n = null,
                                                                    s = -1;
                                                                for (let t = 0; t < e.length; ++t) {
                                                                    let o = e[t],
                                                                        a = function(e) {
                                                                            let t = 0;
                                                                            for (; t < e.length && I(e.charCodeAt(t));) ++t;
                                                                            return t
                                                                        }(o);
                                                                    a !== o.length && (n = null !== (i = n) && void 0 !== i ? i : t, s = t, 0 !== t && a < r && (r = a))
                                                                }
                                                                return e.map((e, t) => 0 === t ? e : e.slice(r)).slice(null !== (t = n) && void 0 !== t ? t : 0, s + 1)
                                                            })(l).join("\n"));
                                                            return e.line += l.length - 1, e.lineStart = n, r
                                                        }
                                                        if (92 === r && 34 === i.charCodeAt(s + 1) && 34 === i.charCodeAt(s + 2) && 34 === i.charCodeAt(s + 3)) {
                                                            a += i.slice(o, s), o = s + 1, s += 4;
                                                            continue
                                                        }
                                                        if (10 === r || 13 === r) {
                                                            a += i.slice(o, s), l.push(a), 13 === r && 10 === i.charCodeAt(s + 1) ? s += 2 : ++s, a = "", o = s, n = s;
                                                            continue
                                                        }
                                                        if (b(r)) ++s;
                                                        else if (D(i, s)) s += 2;
                                                        else throw y(e.source, s, `Invalid character within String: ${C(e,s)}.`)
                                                    }
                                                    throw y(e.source, s, "Unterminated string.")
                                                }(e, n);
                                                return function(e, t) {
                                                    let i = e.source.body,
                                                        r = i.length,
                                                        n = t + 1,
                                                        s = n,
                                                        o = "";
                                                    for (; n < r;) {
                                                        let r = i.charCodeAt(n);
                                                        if (34 === r) return o += i.slice(s, n), k(e, el.STRING, t, n + 1, o);
                                                        if (92 === r) {
                                                            o += i.slice(s, n);
                                                            let t = 117 === i.charCodeAt(n + 1) ? 123 === i.charCodeAt(n + 2) ? function(e, t) {
                                                                let i = e.source.body,
                                                                    r = 0,
                                                                    n = 3;
                                                                for (; n < 12;) {
                                                                    let e = i.charCodeAt(t + n++);
                                                                    if (125 === e) {
                                                                        if (n < 5 || !b(r)) break;
                                                                        return {
                                                                            value: String.fromCodePoint(r),
                                                                            size: n
                                                                        }
                                                                    }
                                                                    if ((r = r << 4 | L(e)) < 0) break
                                                                }
                                                                throw y(e.source, t, `Invalid Unicode escape sequence: "${i.slice(t,t+n)}".`)
                                                            }(e, n) : function(e, t) {
                                                                let i = e.source.body,
                                                                    r = w(i, t + 2);
                                                                if (b(r)) return {
                                                                    value: String.fromCodePoint(r),
                                                                    size: 6
                                                                };
                                                                if (g(r) && 92 === i.charCodeAt(t + 6) && 117 === i.charCodeAt(t + 7)) {
                                                                    let e = w(i, t + 8);
                                                                    if (S(e)) return {
                                                                        value: String.fromCodePoint(r, e),
                                                                        size: 12
                                                                    }
                                                                }
                                                                throw y(e.source, t, `Invalid Unicode escape sequence: "${i.slice(t,t+6)}".`)
                                                            }(e, n) : function(e, t) {
                                                                let i = e.source.body,
                                                                    r = i.charCodeAt(t + 1);
                                                                switch (r) {
                                                                    case 34:
                                                                        return {
                                                                            value: '"',
                                                                            size: 2
                                                                        };
                                                                    case 92:
                                                                        return {
                                                                            value: "\\",
                                                                            size: 2
                                                                        };
                                                                    case 47:
                                                                        return {
                                                                            value: "/",
                                                                            size: 2
                                                                        };
                                                                    case 98:
                                                                        return {
                                                                            value: "\b",
                                                                            size: 2
                                                                        };
                                                                    case 102:
                                                                        return {
                                                                            value: "\f",
                                                                            size: 2
                                                                        };
                                                                    case 110:
                                                                        return {
                                                                            value: "\n",
                                                                            size: 2
                                                                        };
                                                                    case 114:
                                                                        return {
                                                                            value: "\r",
                                                                            size: 2
                                                                        };
                                                                    case 116:
                                                                        return {
                                                                            value: "	",
                                                                            size: 2
                                                                        }
                                                                }
                                                                throw y(e.source, t, `Invalid character escape sequence: "${i.slice(t,t+2)}".`)
                                                            }(e, n);
                                                            o += t.value, n += t.size, s = n;
                                                            continue
                                                        }
                                                        if (10 === r || 13 === r) break;
                                                        if (b(r)) ++n;
                                                        else if (D(i, n)) n += 2;
                                                        else throw y(e.source, n, `Invalid character within String: ${C(e,n)}.`)
                                                    }
                                                    throw y(e.source, n, "Unterminated string.")
                                                }(e, n)
                                        }
                                        if (A(t) || 45 === t) return function(e, t, i) {
                                            let r = e.source.body,
                                                n = t,
                                                s = i,
                                                o = !1;
                                            if (45 === s && (s = r.charCodeAt(++n)), 48 === s) {
                                                if (A(s = r.charCodeAt(++n))) throw y(e.source, n, `Invalid number, unexpected digit after 0: ${C(e,n)}.`)
                                            } else n = R(e, n, s), s = r.charCodeAt(n);
                                            if (46 === s && (o = !0, s = r.charCodeAt(++n), n = R(e, n, s), s = r.charCodeAt(n)), (69 === s || 101 === s) && (o = !0, (43 === (s = r.charCodeAt(++n)) || 45 === s) && (s = r.charCodeAt(++n)), n = R(e, n, s), s = r.charCodeAt(n)), 46 === s || _(s)) throw y(e.source, n, `Invalid number, expected digit but got: ${C(e,n)}.`);
                                            return k(e, o ? el.FLOAT : el.INT, t, n, r.slice(t, n))
                                        }(e, n, t);
                                        if (_(t)) return function(e, t) {
                                            let i = e.source.body,
                                                r = i.length,
                                                n = t + 1;
                                            for (; n < r;) {
                                                let e = i.charCodeAt(n);
                                                if (O(e) || A(e) || 95 === e) ++n;
                                                else break
                                            }
                                            return k(e, el.NAME, t, n, i.slice(t, n))
                                        }(e, n);
                                        throw y(e.source, n, 39 === t ? "Unexpected single quote character ('), did you mean to use a double quote (\")?" : b(t) || D(i, n) ? `Unexpected character: ${C(e,n)}.` : `Invalid character: ${C(e,n)}.`)
                                    }
                                    return k(e, el.EOF, r, r)
                                }(this, e.end);
                                e.next = t, t.prev = e, e = t
                            }
                    while (e.kind === el.COMMENT);
                    return e
                }
            }

            function b(e) {
                return e >= 0 && e <= 55295 || e >= 57344 && e <= 1114111
            }

            function D(e, t) {
                return g(e.charCodeAt(t)) && S(e.charCodeAt(t + 1))
            }

            function g(e) {
                return e >= 55296 && e <= 56319
            }

            function S(e) {
                return e >= 56320 && e <= 57343
            }

            function C(e, t) {
                let i = e.source.body.codePointAt(t);
                if (void 0 === i) return el.EOF;
                if (i >= 32 && i <= 126) {
                    let e = String.fromCodePoint(i);
                    return '"' === e ? "'\"'" : `"${e}"`
                }
                return "U+" + i.toString(16).toUpperCase().padStart(4, "0")
            }

            function k(e, t, i, r, n) {
                let s = e.line,
                    o = 1 + i - e.lineStart;
                return new m(t, i, r, s, o, n)
            }

            function R(e, t, i) {
                if (!A(i)) throw y(e.source, t, `Invalid number, expected digit but got: ${C(e,t)}.`);
                let r = e.source.body,
                    n = t + 1;
                for (; A(r.charCodeAt(n));) ++n;
                return n
            }

            function w(e, t) {
                return L(e.charCodeAt(t)) << 12 | L(e.charCodeAt(t + 1)) << 8 | L(e.charCodeAt(t + 2)) << 4 | L(e.charCodeAt(t + 3))
            }

            function L(e) {
                return e >= 48 && e <= 57 ? e - 48 : e >= 65 && e <= 70 ? e - 55 : e >= 97 && e <= 102 ? e - 87 : -1
            }

            function F(e, t) {
                if (!e) throw Error(t)
            }

            function P(e, t) {
                switch (typeof e) {
                    case "string":
                        return JSON.stringify(e);
                    case "function":
                        return e.name ? `[function ${e.name}]` : "[function]";
                    case "object":
                        return function(e, t) {
                            if (null === e) return "null";
                            if (t.includes(e)) return "[Circular]";
                            let i = [...t, e];
                            if ("function" == typeof e.toJSON) {
                                let t = e.toJSON();
                                if (t !== e) return "string" == typeof t ? t : P(t, i)
                            } else if (Array.isArray(e)) return function(e, t) {
                                if (0 === e.length) return "[]";
                                if (t.length > 2) return "[Array]";
                                let i = Math.min(10, e.length),
                                    r = e.length - i,
                                    n = [];
                                for (let r = 0; r < i; ++r) n.push(P(e[r], t));
                                return 1 === r ? n.push("... 1 more item") : r > 1 && n.push(`... ${r} more items`), "[" + n.join(", ") + "]"
                            }(e, i);
                            return function(e, t) {
                                let i = Object.entries(e);
                                if (0 === i.length) return "{}";
                                if (t.length > 2) return "[" + function(e) {
                                    let t = Object.prototype.toString.call(e).replace(/^\[object /, "").replace(/]$/, "");
                                    if ("Object" === t && "function" == typeof e.constructor) {
                                        let t = e.constructor.name;
                                        if ("string" == typeof t && "" !== t) return t
                                    }
                                    return t
                                }(e) + "]";
                                let r = i.map(([e, i]) => e + ": " + P(i, t));
                                return "{ " + r.join(", ") + " }"
                            }(e, i)
                        }(e, t);
                    default:
                        return String(e)
                }
            }
            let B = globalThis.process && "production" === globalThis.process.env.NODE_ENV ? function(e, t) {
                return e instanceof t
            } : function(e, t) {
                if (e instanceof t) return !0;
                if ("object" == typeof e && null !== e) {
                    var i;
                    let r = t.prototype[Symbol.toStringTag],
                        n = Symbol.toStringTag in e ? e[Symbol.toStringTag] : null === (i = e.constructor) || void 0 === i ? void 0 : i.name;
                    if (r === n) {
                        let t = P(e, []);
                        throw Error(`Cannot use ${r} "${t}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`)
                    }
                }
                return !1
            };
            class U {
                constructor(e, t = "GraphQL request", i = {
                    line: 1,
                    column: 1
                }) {
                    "string" == typeof e || F(!1, `Body must be a string. Received: ${P(e,[])}.`), this.body = e, this.name = t, this.locationOffset = i, this.locationOffset.line > 0 || F(!1, "line in locationOffset is 1-indexed and must be positive."), this.locationOffset.column > 0 || F(!1, "column in locationOffset is 1-indexed and must be positive.")
                }
                get[Symbol.toStringTag]() {
                    return "Source"
                }
            }
            class M {
                constructor(e, t = {}) {
                    let i = B(e, U) ? e : new U(e);
                    this._lexer = new x(i), this._options = t, this._tokenCounter = 0
                }
                parseName() {
                    let e = this.expectToken(el.NAME);
                    return this.node(e, {
                        kind: ea.NAME,
                        value: e.value
                    })
                }
                parseDocument() {
                    return this.node(this._lexer.token, {
                        kind: ea.DOCUMENT,
                        definitions: this.many(el.SOF, this.parseDefinition, el.EOF)
                    })
                }
                parseDefinition() {
                    if (this.peek(el.BRACE_L)) return this.parseOperationDefinition();
                    let e = this.peekDescription(),
                        t = e ? this._lexer.lookahead() : this._lexer.token;
                    if (t.kind === el.NAME) {
                        switch (t.value) {
                            case "schema":
                                return this.parseSchemaDefinition();
                            case "scalar":
                                return this.parseScalarTypeDefinition();
                            case "type":
                                return this.parseObjectTypeDefinition();
                            case "interface":
                                return this.parseInterfaceTypeDefinition();
                            case "union":
                                return this.parseUnionTypeDefinition();
                            case "enum":
                                return this.parseEnumTypeDefinition();
                            case "input":
                                return this.parseInputObjectTypeDefinition();
                            case "directive":
                                return this.parseDirectiveDefinition()
                        }
                        if (e) throw y(this._lexer.source, this._lexer.token.start, "Unexpected description, descriptions are supported only on type definitions.");
                        switch (t.value) {
                            case "query":
                            case "mutation":
                            case "subscription":
                                return this.parseOperationDefinition();
                            case "fragment":
                                return this.parseFragmentDefinition();
                            case "extend":
                                return this.parseTypeSystemExtension()
                        }
                    }
                    throw this.unexpected(t)
                }
                parseOperationDefinition() {
                    let e;
                    let t = this._lexer.token;
                    if (this.peek(el.BRACE_L)) return this.node(t, {
                        kind: ea.OPERATION_DEFINITION,
                        operation: es.QUERY,
                        name: void 0,
                        variableDefinitions: [],
                        directives: [],
                        selectionSet: this.parseSelectionSet()
                    });
                    let i = this.parseOperationType();
                    return this.peek(el.NAME) && (e = this.parseName()), this.node(t, {
                        kind: ea.OPERATION_DEFINITION,
                        operation: i,
                        name: e,
                        variableDefinitions: this.parseVariableDefinitions(),
                        directives: this.parseDirectives(!1),
                        selectionSet: this.parseSelectionSet()
                    })
                }
                parseOperationType() {
                    let e = this.expectToken(el.NAME);
                    switch (e.value) {
                        case "query":
                            return es.QUERY;
                        case "mutation":
                            return es.MUTATION;
                        case "subscription":
                            return es.SUBSCRIPTION
                    }
                    throw this.unexpected(e)
                }
                parseVariableDefinitions() {
                    return this.optionalMany(el.PAREN_L, this.parseVariableDefinition, el.PAREN_R)
                }
                parseVariableDefinition() {
                    return this.node(this._lexer.token, {
                        kind: ea.VARIABLE_DEFINITION,
                        variable: this.parseVariable(),
                        type: (this.expectToken(el.COLON), this.parseTypeReference()),
                        defaultValue: this.expectOptionalToken(el.EQUALS) ? this.parseConstValueLiteral() : void 0,
                        directives: this.parseConstDirectives()
                    })
                }
                parseVariable() {
                    let e = this._lexer.token;
                    return this.expectToken(el.DOLLAR), this.node(e, {
                        kind: ea.VARIABLE,
                        name: this.parseName()
                    })
                }
                parseSelectionSet() {
                    return this.node(this._lexer.token, {
                        kind: ea.SELECTION_SET,
                        selections: this.many(el.BRACE_L, this.parseSelection, el.BRACE_R)
                    })
                }
                parseSelection() {
                    return this.peek(el.SPREAD) ? this.parseFragment() : this.parseField()
                }
                parseField() {
                    let e, t;
                    let i = this._lexer.token,
                        r = this.parseName();
                    return this.expectOptionalToken(el.COLON) ? (e = r, t = this.parseName()) : t = r, this.node(i, {
                        kind: ea.FIELD,
                        alias: e,
                        name: t,
                        arguments: this.parseArguments(!1),
                        directives: this.parseDirectives(!1),
                        selectionSet: this.peek(el.BRACE_L) ? this.parseSelectionSet() : void 0
                    })
                }
                parseArguments(e) {
                    let t = e ? this.parseConstArgument : this.parseArgument;
                    return this.optionalMany(el.PAREN_L, t, el.PAREN_R)
                }
                parseArgument(e = !1) {
                    let t = this._lexer.token,
                        i = this.parseName();
                    return this.expectToken(el.COLON), this.node(t, {
                        kind: ea.ARGUMENT,
                        name: i,
                        value: this.parseValueLiteral(e)
                    })
                }
                parseConstArgument() {
                    return this.parseArgument(!0)
                }
                parseFragment() {
                    let e = this._lexer.token;
                    this.expectToken(el.SPREAD);
                    let t = this.expectOptionalKeyword("on");
                    return !t && this.peek(el.NAME) ? this.node(e, {
                        kind: ea.FRAGMENT_SPREAD,
                        name: this.parseFragmentName(),
                        directives: this.parseDirectives(!1)
                    }) : this.node(e, {
                        kind: ea.INLINE_FRAGMENT,
                        typeCondition: t ? this.parseNamedType() : void 0,
                        directives: this.parseDirectives(!1),
                        selectionSet: this.parseSelectionSet()
                    })
                }
                parseFragmentDefinition() {
                    let e = this._lexer.token;
                    return (this.expectKeyword("fragment"), !0 === this._options.allowLegacyFragmentVariables) ? this.node(e, {
                        kind: ea.FRAGMENT_DEFINITION,
                        name: this.parseFragmentName(),
                        variableDefinitions: this.parseVariableDefinitions(),
                        typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
                        directives: this.parseDirectives(!1),
                        selectionSet: this.parseSelectionSet()
                    }) : this.node(e, {
                        kind: ea.FRAGMENT_DEFINITION,
                        name: this.parseFragmentName(),
                        typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
                        directives: this.parseDirectives(!1),
                        selectionSet: this.parseSelectionSet()
                    })
                }
                parseFragmentName() {
                    if ("on" === this._lexer.token.value) throw this.unexpected();
                    return this.parseName()
                }
                parseValueLiteral(e) {
                    let t = this._lexer.token;
                    switch (t.kind) {
                        case el.BRACKET_L:
                            return this.parseList(e);
                        case el.BRACE_L:
                            return this.parseObject(e);
                        case el.INT:
                            return this.advanceLexer(), this.node(t, {
                                kind: ea.INT,
                                value: t.value
                            });
                        case el.FLOAT:
                            return this.advanceLexer(), this.node(t, {
                                kind: ea.FLOAT,
                                value: t.value
                            });
                        case el.STRING:
                        case el.BLOCK_STRING:
                            return this.parseStringLiteral();
                        case el.NAME:
                            switch (this.advanceLexer(), t.value) {
                                case "true":
                                    return this.node(t, {
                                        kind: ea.BOOLEAN,
                                        value: !0
                                    });
                                case "false":
                                    return this.node(t, {
                                        kind: ea.BOOLEAN,
                                        value: !1
                                    });
                                case "null":
                                    return this.node(t, {
                                        kind: ea.NULL
                                    });
                                default:
                                    return this.node(t, {
                                        kind: ea.ENUM,
                                        value: t.value
                                    })
                            }
                        case el.DOLLAR:
                            if (e) {
                                if (this.expectToken(el.DOLLAR), this._lexer.token.kind === el.NAME) {
                                    let e = this._lexer.token.value;
                                    throw y(this._lexer.source, t.start, `Unexpected variable "$${e}" in constant value.`)
                                }
                                throw this.unexpected(t)
                            }
                            return this.parseVariable();
                        default:
                            throw this.unexpected()
                    }
                }
                parseConstValueLiteral() {
                    return this.parseValueLiteral(!0)
                }
                parseStringLiteral() {
                    let e = this._lexer.token;
                    return this.advanceLexer(), this.node(e, {
                        kind: ea.STRING,
                        value: e.value,
                        block: e.kind === el.BLOCK_STRING
                    })
                }
                parseList(e) {
                    return this.node(this._lexer.token, {
                        kind: ea.LIST,
                        values: this.any(el.BRACKET_L, () => this.parseValueLiteral(e), el.BRACKET_R)
                    })
                }
                parseObject(e) {
                    return this.node(this._lexer.token, {
                        kind: ea.OBJECT,
                        fields: this.any(el.BRACE_L, () => this.parseObjectField(e), el.BRACE_R)
                    })
                }
                parseObjectField(e) {
                    let t = this._lexer.token,
                        i = this.parseName();
                    return this.expectToken(el.COLON), this.node(t, {
                        kind: ea.OBJECT_FIELD,
                        name: i,
                        value: this.parseValueLiteral(e)
                    })
                }
                parseDirectives(e) {
                    let t = [];
                    for (; this.peek(el.AT);) t.push(this.parseDirective(e));
                    return t
                }
                parseConstDirectives() {
                    return this.parseDirectives(!0)
                }
                parseDirective(e) {
                    let t = this._lexer.token;
                    return this.expectToken(el.AT), this.node(t, {
                        kind: ea.DIRECTIVE,
                        name: this.parseName(),
                        arguments: this.parseArguments(e)
                    })
                }
                parseTypeReference() {
                    let e;
                    let t = this._lexer.token;
                    if (this.expectOptionalToken(el.BRACKET_L)) {
                        let i = this.parseTypeReference();
                        this.expectToken(el.BRACKET_R), e = this.node(t, {
                            kind: ea.LIST_TYPE,
                            type: i
                        })
                    } else e = this.parseNamedType();
                    return this.expectOptionalToken(el.BANG) ? this.node(t, {
                        kind: ea.NON_NULL_TYPE,
                        type: e
                    }) : e
                }
                parseNamedType() {
                    return this.node(this._lexer.token, {
                        kind: ea.NAMED_TYPE,
                        name: this.parseName()
                    })
                }
                peekDescription() {
                    return this.peek(el.STRING) || this.peek(el.BLOCK_STRING)
                }
                parseDescription() {
                    if (this.peekDescription()) return this.parseStringLiteral()
                }
                parseSchemaDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("schema");
                    let i = this.parseConstDirectives(),
                        r = this.many(el.BRACE_L, this.parseOperationTypeDefinition, el.BRACE_R);
                    return this.node(e, {
                        kind: ea.SCHEMA_DEFINITION,
                        description: t,
                        directives: i,
                        operationTypes: r
                    })
                }
                parseOperationTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseOperationType();
                    this.expectToken(el.COLON);
                    let i = this.parseNamedType();
                    return this.node(e, {
                        kind: ea.OPERATION_TYPE_DEFINITION,
                        operation: t,
                        type: i
                    })
                }
                parseScalarTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("scalar");
                    let i = this.parseName(),
                        r = this.parseConstDirectives();
                    return this.node(e, {
                        kind: ea.SCALAR_TYPE_DEFINITION,
                        description: t,
                        name: i,
                        directives: r
                    })
                }
                parseObjectTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("type");
                    let i = this.parseName(),
                        r = this.parseImplementsInterfaces(),
                        n = this.parseConstDirectives(),
                        s = this.parseFieldsDefinition();
                    return this.node(e, {
                        kind: ea.OBJECT_TYPE_DEFINITION,
                        description: t,
                        name: i,
                        interfaces: r,
                        directives: n,
                        fields: s
                    })
                }
                parseImplementsInterfaces() {
                    return this.expectOptionalKeyword("implements") ? this.delimitedMany(el.AMP, this.parseNamedType) : []
                }
                parseFieldsDefinition() {
                    return this.optionalMany(el.BRACE_L, this.parseFieldDefinition, el.BRACE_R)
                }
                parseFieldDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription(),
                        i = this.parseName(),
                        r = this.parseArgumentDefs();
                    this.expectToken(el.COLON);
                    let n = this.parseTypeReference(),
                        s = this.parseConstDirectives();
                    return this.node(e, {
                        kind: ea.FIELD_DEFINITION,
                        description: t,
                        name: i,
                        arguments: r,
                        type: n,
                        directives: s
                    })
                }
                parseArgumentDefs() {
                    return this.optionalMany(el.PAREN_L, this.parseInputValueDef, el.PAREN_R)
                }
                parseInputValueDef() {
                    let e;
                    let t = this._lexer.token,
                        i = this.parseDescription(),
                        r = this.parseName();
                    this.expectToken(el.COLON);
                    let n = this.parseTypeReference();
                    this.expectOptionalToken(el.EQUALS) && (e = this.parseConstValueLiteral());
                    let s = this.parseConstDirectives();
                    return this.node(t, {
                        kind: ea.INPUT_VALUE_DEFINITION,
                        description: i,
                        name: r,
                        type: n,
                        defaultValue: e,
                        directives: s
                    })
                }
                parseInterfaceTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("interface");
                    let i = this.parseName(),
                        r = this.parseImplementsInterfaces(),
                        n = this.parseConstDirectives(),
                        s = this.parseFieldsDefinition();
                    return this.node(e, {
                        kind: ea.INTERFACE_TYPE_DEFINITION,
                        description: t,
                        name: i,
                        interfaces: r,
                        directives: n,
                        fields: s
                    })
                }
                parseUnionTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("union");
                    let i = this.parseName(),
                        r = this.parseConstDirectives(),
                        n = this.parseUnionMemberTypes();
                    return this.node(e, {
                        kind: ea.UNION_TYPE_DEFINITION,
                        description: t,
                        name: i,
                        directives: r,
                        types: n
                    })
                }
                parseUnionMemberTypes() {
                    return this.expectOptionalToken(el.EQUALS) ? this.delimitedMany(el.PIPE, this.parseNamedType) : []
                }
                parseEnumTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("enum");
                    let i = this.parseName(),
                        r = this.parseConstDirectives(),
                        n = this.parseEnumValuesDefinition();
                    return this.node(e, {
                        kind: ea.ENUM_TYPE_DEFINITION,
                        description: t,
                        name: i,
                        directives: r,
                        values: n
                    })
                }
                parseEnumValuesDefinition() {
                    return this.optionalMany(el.BRACE_L, this.parseEnumValueDefinition, el.BRACE_R)
                }
                parseEnumValueDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription(),
                        i = this.parseEnumValueName(),
                        r = this.parseConstDirectives();
                    return this.node(e, {
                        kind: ea.ENUM_VALUE_DEFINITION,
                        description: t,
                        name: i,
                        directives: r
                    })
                }
                parseEnumValueName() {
                    if ("true" === this._lexer.token.value || "false" === this._lexer.token.value || "null" === this._lexer.token.value) throw y(this._lexer.source, this._lexer.token.start, `${j(this._lexer.token)} is reserved and cannot be used for an enum value.`);
                    return this.parseName()
                }
                parseInputObjectTypeDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("input");
                    let i = this.parseName(),
                        r = this.parseConstDirectives(),
                        n = this.parseInputFieldsDefinition();
                    return this.node(e, {
                        kind: ea.INPUT_OBJECT_TYPE_DEFINITION,
                        description: t,
                        name: i,
                        directives: r,
                        fields: n
                    })
                }
                parseInputFieldsDefinition() {
                    return this.optionalMany(el.BRACE_L, this.parseInputValueDef, el.BRACE_R)
                }
                parseTypeSystemExtension() {
                    let e = this._lexer.lookahead();
                    if (e.kind === el.NAME) switch (e.value) {
                        case "schema":
                            return this.parseSchemaExtension();
                        case "scalar":
                            return this.parseScalarTypeExtension();
                        case "type":
                            return this.parseObjectTypeExtension();
                        case "interface":
                            return this.parseInterfaceTypeExtension();
                        case "union":
                            return this.parseUnionTypeExtension();
                        case "enum":
                            return this.parseEnumTypeExtension();
                        case "input":
                            return this.parseInputObjectTypeExtension()
                    }
                    throw this.unexpected(e)
                }
                parseSchemaExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("schema");
                    let t = this.parseConstDirectives(),
                        i = this.optionalMany(el.BRACE_L, this.parseOperationTypeDefinition, el.BRACE_R);
                    if (0 === t.length && 0 === i.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.SCHEMA_EXTENSION,
                        directives: t,
                        operationTypes: i
                    })
                }
                parseScalarTypeExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("scalar");
                    let t = this.parseName(),
                        i = this.parseConstDirectives();
                    if (0 === i.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.SCALAR_TYPE_EXTENSION,
                        name: t,
                        directives: i
                    })
                }
                parseObjectTypeExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("type");
                    let t = this.parseName(),
                        i = this.parseImplementsInterfaces(),
                        r = this.parseConstDirectives(),
                        n = this.parseFieldsDefinition();
                    if (0 === i.length && 0 === r.length && 0 === n.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.OBJECT_TYPE_EXTENSION,
                        name: t,
                        interfaces: i,
                        directives: r,
                        fields: n
                    })
                }
                parseInterfaceTypeExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("interface");
                    let t = this.parseName(),
                        i = this.parseImplementsInterfaces(),
                        r = this.parseConstDirectives(),
                        n = this.parseFieldsDefinition();
                    if (0 === i.length && 0 === r.length && 0 === n.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.INTERFACE_TYPE_EXTENSION,
                        name: t,
                        interfaces: i,
                        directives: r,
                        fields: n
                    })
                }
                parseUnionTypeExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("union");
                    let t = this.parseName(),
                        i = this.parseConstDirectives(),
                        r = this.parseUnionMemberTypes();
                    if (0 === i.length && 0 === r.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.UNION_TYPE_EXTENSION,
                        name: t,
                        directives: i,
                        types: r
                    })
                }
                parseEnumTypeExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("enum");
                    let t = this.parseName(),
                        i = this.parseConstDirectives(),
                        r = this.parseEnumValuesDefinition();
                    if (0 === i.length && 0 === r.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.ENUM_TYPE_EXTENSION,
                        name: t,
                        directives: i,
                        values: r
                    })
                }
                parseInputObjectTypeExtension() {
                    let e = this._lexer.token;
                    this.expectKeyword("extend"), this.expectKeyword("input");
                    let t = this.parseName(),
                        i = this.parseConstDirectives(),
                        r = this.parseInputFieldsDefinition();
                    if (0 === i.length && 0 === r.length) throw this.unexpected();
                    return this.node(e, {
                        kind: ea.INPUT_OBJECT_TYPE_EXTENSION,
                        name: t,
                        directives: i,
                        fields: r
                    })
                }
                parseDirectiveDefinition() {
                    let e = this._lexer.token,
                        t = this.parseDescription();
                    this.expectKeyword("directive"), this.expectToken(el.AT);
                    let i = this.parseName(),
                        r = this.parseArgumentDefs(),
                        n = this.expectOptionalKeyword("repeatable");
                    this.expectKeyword("on");
                    let s = this.parseDirectiveLocations();
                    return this.node(e, {
                        kind: ea.DIRECTIVE_DEFINITION,
                        description: t,
                        name: i,
                        arguments: r,
                        repeatable: n,
                        locations: s
                    })
                }
                parseDirectiveLocations() {
                    return this.delimitedMany(el.PIPE, this.parseDirectiveLocation)
                }
                parseDirectiveLocation() {
                    let e = this._lexer.token,
                        t = this.parseName();
                    if (Object.prototype.hasOwnProperty.call(eo, t.value)) return t;
                    throw this.unexpected(e)
                }
                node(e, t) {
                    return !0 !== this._options.noLocation && (t.loc = new E(e, this._lexer.lastToken, this._lexer.source)), t
                }
                peek(e) {
                    return this._lexer.token.kind === e
                }
                expectToken(e) {
                    let t = this._lexer.token;
                    if (t.kind === e) return this.advanceLexer(), t;
                    throw y(this._lexer.source, t.start, `Expected ${V(e)}, found ${j(t)}.`)
                }
                expectOptionalToken(e) {
                    let t = this._lexer.token;
                    return t.kind === e && (this.advanceLexer(), !0)
                }
                expectKeyword(e) {
                    let t = this._lexer.token;
                    if (t.kind === el.NAME && t.value === e) this.advanceLexer();
                    else throw y(this._lexer.source, t.start, `Expected "${e}", found ${j(t)}.`)
                }
                expectOptionalKeyword(e) {
                    let t = this._lexer.token;
                    return t.kind === el.NAME && t.value === e && (this.advanceLexer(), !0)
                }
                unexpected(e) {
                    let t = null != e ? e : this._lexer.token;
                    return y(this._lexer.source, t.start, `Unexpected ${j(t)}.`)
                }
                any(e, t, i) {
                    this.expectToken(e);
                    let r = [];
                    for (; !this.expectOptionalToken(i);) r.push(t.call(this));
                    return r
                }
                optionalMany(e, t, i) {
                    if (this.expectOptionalToken(e)) {
                        let e = [];
                        do e.push(t.call(this)); while (!this.expectOptionalToken(i));
                        return e
                    }
                    return []
                }
                many(e, t, i) {
                    this.expectToken(e);
                    let r = [];
                    do r.push(t.call(this)); while (!this.expectOptionalToken(i));
                    return r
                }
                delimitedMany(e, t) {
                    this.expectOptionalToken(e);
                    let i = [];
                    do i.push(t.call(this)); while (this.expectOptionalToken(e));
                    return i
                }
                advanceLexer() {
                    let {
                        maxTokens: e
                    } = this._options, t = this._lexer.advance();
                    if (void 0 !== e && t.kind !== el.EOF && (++this._tokenCounter, this._tokenCounter > e)) throw y(this._lexer.source, t.start, `Document contains more that ${e} tokens. Parsing aborted.`)
                }
            }

            function j(e) {
                let t = e.value;
                return V(e.kind) + (null != t ? ` "${t}"` : "")
            }

            function V(e) {
                return e === el.BANG || e === el.DOLLAR || e === el.AMP || e === el.PAREN_L || e === el.PAREN_R || e === el.SPREAD || e === el.COLON || e === el.EQUALS || e === el.AT || e === el.BRACKET_L || e === el.BRACKET_R || e === el.BRACE_L || e === el.PIPE || e === el.BRACE_R ? `"${e}"` : e
            }
            let q = /[\x00-\x1f\x22\x5c\x7f-\x9f]/g;

            function $(e) {
                return K[e.charCodeAt(0)]
            }
            let K = ["\\u0000", "\\u0001", "\\u0002", "\\u0003", "\\u0004", "\\u0005", "\\u0006", "\\u0007", "\\b", "\\t", "\\n", "\\u000B", "\\f", "\\r", "\\u000E", "\\u000F", "\\u0010", "\\u0011", "\\u0012", "\\u0013", "\\u0014", "\\u0015", "\\u0016", "\\u0017", "\\u0018", "\\u0019", "\\u001A", "\\u001B", "\\u001C", "\\u001D", "\\u001E", "\\u001F", "", "", '\\"', "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "\\\\", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "\\u007F", "\\u0080", "\\u0081", "\\u0082", "\\u0083", "\\u0084", "\\u0085", "\\u0086", "\\u0087", "\\u0088", "\\u0089", "\\u008A", "\\u008B", "\\u008C", "\\u008D", "\\u008E", "\\u008F", "\\u0090", "\\u0091", "\\u0092", "\\u0093", "\\u0094", "\\u0095", "\\u0096", "\\u0097", "\\u0098", "\\u0099", "\\u009A", "\\u009B", "\\u009C", "\\u009D", "\\u009E", "\\u009F"],
                G = Object.freeze({}),
                Y = {
                    Name: {
                        leave: e => e.value
                    },
                    Variable: {
                        leave: e => "$" + e.name
                    },
                    Document: {
                        leave: e => H(e.definitions, "\n\n")
                    },
                    OperationDefinition: {
                        leave(e) {
                            let t = z("(", H(e.variableDefinitions, ", "), ")"),
                                i = H([e.operation, H([e.name, t]), H(e.directives, " ")], " ");
                            return ("query" === i ? "" : i + " ") + e.selectionSet
                        }
                    },
                    VariableDefinition: {
                        leave: ({
                            variable: e,
                            type: t,
                            defaultValue: i,
                            directives: r
                        }) => e + ": " + t + z(" = ", i) + z(" ", H(r, " "))
                    },
                    SelectionSet: {
                        leave: ({
                            selections: e
                        }) => J(e)
                    },
                    Field: {
                        leave({
                            alias: e,
                            name: t,
                            arguments: i,
                            directives: r,
                            selectionSet: n
                        }) {
                            let s = z("", e, ": ") + t,
                                o = s + z("(", H(i, ", "), ")");
                            return o.length > 80 && (o = s + z("(\n", X(H(i, "\n")), "\n)")), H([o, H(r, " "), n], " ")
                        }
                    },
                    Argument: {
                        leave: ({
                            name: e,
                            value: t
                        }) => e + ": " + t
                    },
                    FragmentSpread: {
                        leave: ({
                            name: e,
                            directives: t
                        }) => "..." + e + z(" ", H(t, " "))
                    },
                    InlineFragment: {
                        leave: ({
                            typeCondition: e,
                            directives: t,
                            selectionSet: i
                        }) => H(["...", z("on ", e), H(t, " "), i], " ")
                    },
                    FragmentDefinition: {
                        leave: ({
                            name: e,
                            typeCondition: t,
                            variableDefinitions: i,
                            directives: r,
                            selectionSet: n
                        }) => `fragment ${e}${z("(",H(i,", "),")")} on ${t} ${z("",H(r," ")," ")}` + n
                    },
                    IntValue: {
                        leave: ({
                            value: e
                        }) => e
                    },
                    FloatValue: {
                        leave: ({
                            value: e
                        }) => e
                    },
                    StringValue: {
                        leave: ({
                            value: e,
                            block: t
                        }) => t ? function(e, t) {
                            let i = e.replace(/"""/g, '\\"""'),
                                r = i.split(/\r\n|[\n\r]/g),
                                n = 1 === r.length,
                                s = r.length > 1 && r.slice(1).every(e => 0 === e.length || I(e.charCodeAt(0))),
                                o = i.endsWith('\\"""'),
                                a = e.endsWith('"') && !o,
                                l = e.endsWith("\\"),
                                u = a || l,
                                c = !(null != t && t.minimize) && (!n || e.length > 70 || u || s || o),
                                h = "",
                                p = n && I(e.charCodeAt(0));
                            return (c && !p || s) && (h += "\n"), h += i, (c || u) && (h += "\n"), '"""' + h + '"""'
                        }(e) : `"${e.replace(q,$)}"`
                    },
                    BooleanValue: {
                        leave: ({
                            value: e
                        }) => e ? "true" : "false"
                    },
                    NullValue: {
                        leave: () => "null"
                    },
                    EnumValue: {
                        leave: ({
                            value: e
                        }) => e
                    },
                    ListValue: {
                        leave: ({
                            values: e
                        }) => "[" + H(e, ", ") + "]"
                    },
                    ObjectValue: {
                        leave: ({
                            fields: e
                        }) => "{" + H(e, ", ") + "}"
                    },
                    ObjectField: {
                        leave: ({
                            name: e,
                            value: t
                        }) => e + ": " + t
                    },
                    Directive: {
                        leave: ({
                            name: e,
                            arguments: t
                        }) => "@" + e + z("(", H(t, ", "), ")")
                    },
                    NamedType: {
                        leave: ({
                            name: e
                        }) => e
                    },
                    ListType: {
                        leave: ({
                            type: e
                        }) => "[" + e + "]"
                    },
                    NonNullType: {
                        leave: ({
                            type: e
                        }) => e + "!"
                    },
                    SchemaDefinition: {
                        leave: ({
                            description: e,
                            directives: t,
                            operationTypes: i
                        }) => z("", e, "\n") + H(["schema", H(t, " "), J(i)], " ")
                    },
                    OperationTypeDefinition: {
                        leave: ({
                            operation: e,
                            type: t
                        }) => e + ": " + t
                    },
                    ScalarTypeDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            directives: i
                        }) => z("", e, "\n") + H(["scalar", t, H(i, " ")], " ")
                    },
                    ObjectTypeDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            interfaces: i,
                            directives: r,
                            fields: n
                        }) => z("", e, "\n") + H(["type", t, z("implements ", H(i, " & ")), H(r, " "), J(n)], " ")
                    },
                    FieldDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            arguments: i,
                            type: r,
                            directives: n
                        }) => z("", e, "\n") + t + (Q(i) ? z("(\n", X(H(i, "\n")), "\n)") : z("(", H(i, ", "), ")")) + ": " + r + z(" ", H(n, " "))
                    },
                    InputValueDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            type: i,
                            defaultValue: r,
                            directives: n
                        }) => z("", e, "\n") + H([t + ": " + i, z("= ", r), H(n, " ")], " ")
                    },
                    InterfaceTypeDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            interfaces: i,
                            directives: r,
                            fields: n
                        }) => z("", e, "\n") + H(["interface", t, z("implements ", H(i, " & ")), H(r, " "), J(n)], " ")
                    },
                    UnionTypeDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            directives: i,
                            types: r
                        }) => z("", e, "\n") + H(["union", t, H(i, " "), z("= ", H(r, " | "))], " ")
                    },
                    EnumTypeDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            directives: i,
                            values: r
                        }) => z("", e, "\n") + H(["enum", t, H(i, " "), J(r)], " ")
                    },
                    EnumValueDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            directives: i
                        }) => z("", e, "\n") + H([t, H(i, " ")], " ")
                    },
                    InputObjectTypeDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            directives: i,
                            fields: r
                        }) => z("", e, "\n") + H(["input", t, H(i, " "), J(r)], " ")
                    },
                    DirectiveDefinition: {
                        leave: ({
                            description: e,
                            name: t,
                            arguments: i,
                            repeatable: r,
                            locations: n
                        }) => z("", e, "\n") + "directive @" + t + (Q(i) ? z("(\n", X(H(i, "\n")), "\n)") : z("(", H(i, ", "), ")")) + (r ? " repeatable" : "") + " on " + H(n, " | ")
                    },
                    SchemaExtension: {
                        leave: ({
                            directives: e,
                            operationTypes: t
                        }) => H(["extend schema", H(e, " "), J(t)], " ")
                    },
                    ScalarTypeExtension: {
                        leave: ({
                            name: e,
                            directives: t
                        }) => H(["extend scalar", e, H(t, " ")], " ")
                    },
                    ObjectTypeExtension: {
                        leave: ({
                            name: e,
                            interfaces: t,
                            directives: i,
                            fields: r
                        }) => H(["extend type", e, z("implements ", H(t, " & ")), H(i, " "), J(r)], " ")
                    },
                    InterfaceTypeExtension: {
                        leave: ({
                            name: e,
                            interfaces: t,
                            directives: i,
                            fields: r
                        }) => H(["extend interface", e, z("implements ", H(t, " & ")), H(i, " "), J(r)], " ")
                    },
                    UnionTypeExtension: {
                        leave: ({
                            name: e,
                            directives: t,
                            types: i
                        }) => H(["extend union", e, H(t, " "), z("= ", H(i, " | "))], " ")
                    },
                    EnumTypeExtension: {
                        leave: ({
                            name: e,
                            directives: t,
                            values: i
                        }) => H(["extend enum", e, H(t, " "), J(i)], " ")
                    },
                    InputObjectTypeExtension: {
                        leave: ({
                            name: e,
                            directives: t,
                            fields: i
                        }) => H(["extend input", e, H(t, " "), J(i)], " ")
                    }
                };

            function H(e, t = "") {
                var i;
                return null !== (i = null == e ? void 0 : e.filter(e => e).join(t)) && void 0 !== i ? i : ""
            }

            function J(e) {
                return z("{\n", X(H(e, "\n")), "\n}")
            }

            function z(e, t, i = "") {
                return null != t && "" !== t ? e + t + i : ""
            }

            function X(e) {
                return z("  ", e.replace(/\n/g, "\n  "))
            }

            function Q(e) {
                var t;
                return null !== (t = null == e ? void 0 : e.some(e => e.includes("\n"))) && void 0 !== t && t
            }
            let W = e => {
                    let t;
                    let i = e.definitions.filter(e => "OperationDefinition" === e.kind);
                    return 1 === i.length && (t = i[0] ? .name ? .value), t
                },
                Z = e => {
                    if ("string" == typeof e) {
                        let t;
                        try {
                            let i = function(e, t) {
                                let i = new M(e, void 0);
                                return i.parseDocument()
                            }(e);
                            t = W(i)
                        } catch (e) {}
                        return {
                            query: e,
                            operationName: t
                        }
                    }
                    let t = W(e);
                    return {
                        query: function(e, t, i = T) {
                            let r, n, s;
                            let o = new Map;
                            for (let e of Object.values(ea)) o.set(e, function(e, t) {
                                let i = e[t];
                                return "object" == typeof i ? i : "function" == typeof i ? {
                                    enter: i,
                                    leave: void 0
                                } : {
                                    enter: e.enter,
                                    leave: e.leave
                                }
                            }(t, e));
                            let a = Array.isArray(e),
                                l = [e],
                                u = -1,
                                c = [],
                                h = e,
                                p = [],
                                d = [];
                            do {
                                var f, y, E;
                                let e;
                                u++;
                                let m = u === l.length,
                                    T = m && 0 !== c.length;
                                if (m) {
                                    if (n = 0 === d.length ? void 0 : p[p.length - 1], h = s, s = d.pop(), T) {
                                        if (a) {
                                            h = h.slice();
                                            let e = 0;
                                            for (let [t, i] of c) {
                                                let r = t - e;
                                                null === i ? (h.splice(r, 1), e++) : h[r] = i
                                            }
                                        } else
                                            for (let [e, t] of (h = Object.defineProperties({}, Object.getOwnPropertyDescriptors(h)), c)) h[e] = t
                                    }
                                    u = r.index, l = r.keys, c = r.edits, a = r.inArray, r = r.prev
                                } else if (s) {
                                    if (null == (h = s[n = a ? u : l[u]])) continue;
                                    p.push(n)
                                }
                                if (!Array.isArray(h)) {
                                    N(h) || F(!1, `Invalid AST Node: ${P(h,[])}.`);
                                    let i = m ? null === (f = o.get(h.kind)) || void 0 === f ? void 0 : f.leave : null === (y = o.get(h.kind)) || void 0 === y ? void 0 : y.enter;
                                    if ((e = null == i ? void 0 : i.call(t, h, n, s, p, d)) === G) break;
                                    if (!1 === e) {
                                        if (!m) {
                                            p.pop();
                                            continue
                                        }
                                    } else if (void 0 !== e && (c.push([n, e]), !m)) {
                                        if (N(e)) h = e;
                                        else {
                                            p.pop();
                                            continue
                                        }
                                    }
                                }
                                void 0 === e && T && c.push([n, h]), m ? p.pop() : (r = {
                                    inArray: a,
                                    index: u,
                                    keys: l,
                                    edits: c,
                                    prev: r
                                }, l = (a = Array.isArray(h)) ? h : null !== (E = i[h.kind]) && void 0 !== E ? E : [], u = -1, c = [], s && d.push(s), s = h)
                            } while (void 0 !== r);
                            return 0 !== c.length ? c[c.length - 1][1] : e
                        }(e, Y),
                        operationName: t
                    }
                };
            class ee extends Error {
                constructor(e, t) {
                    let i = `${ee.extractMessage(e)}: ${JSON.stringify({response:e,request:t})}`;
                    super(i), Object.setPrototypeOf(this, ee.prototype), this.response = e, this.request = t, "function" == typeof Error.captureStackTrace && Error.captureStackTrace(this, ee)
                }
                static extractMessage(e) {
                    return e.errors ? .[0] ? .message ? ? `GraphQL Error (Code: ${e.status})`
                }
            }
            var et, ei, er, en, es, eo, ea, el, eu = i(2554),
                ec = i.t(eu, 2);
            class eh {
                get type() {
                    return this._type
                }
                get id() {
                    return this._id
                }
                get payload() {
                    return this._payload
                }
                constructor(e, t, i) {
                    this._type = e, this._payload = t, this._id = i
                }
                get text() {
                    let e = {
                        type: this.type
                    };
                    return null != this.id && void 0 != this.id && (e.id = this.id), null != this.payload && void 0 != this.payload && (e.payload = this.payload), JSON.stringify(e)
                }
                static parse(e, t) {
                    let {
                        type: i,
                        payload: r,
                        id: n
                    } = JSON.parse(e);
                    return new eh(i, t(r), n)
                }
            }
            let ep = e => {
                    let t = {};
                    return e && ("undefined" != typeof Headers && e instanceof Headers || ec && eu.Headers && e instanceof eu.Headers ? t = s(e) : Array.isArray(e) ? e.forEach(([e, i]) => {
                        e && void 0 !== i && (t[e] = i)
                    }) : t = e), t
                },
                ed = e => e.replace(/([\s,]|#[^\n\r]+)+/g, " ").trim(),
                ef = e => {
                    if (!Array.isArray(e.query)) {
                        let t = [`query=${encodeURIComponent(ed(e.query))}`];
                        return e.variables && t.push(`variables=${encodeURIComponent(e.jsonSerializer.stringify(e.variables))}`), e.operationName && t.push(`operationName=${encodeURIComponent(e.operationName)}`), t.join("&")
                    }
                    if (void 0 !== e.variables && !Array.isArray(e.variables)) throw Error("Cannot create query with given variable type, array expected");
                    let t = e.query.reduce((t, i, r) => (t.push({
                        query: ed(i),
                        variables: e.variables ? e.jsonSerializer.stringify(e.variables[r]) : void 0
                    }), t), []);
                    return `query=${encodeURIComponent(e.jsonSerializer.stringify(t))}`
                },
                ey = e => async t => {
                    let i;
                    let {
                        url: n,
                        query: s,
                        variables: o,
                        operationName: a,
                        fetch: l,
                        fetchOptions: u,
                        middleware: c
                    } = t, h = { ...t.headers
                    }, p = "";
                    "POST" === e ? "string" == typeof(i = eT(s, o, a, u.jsonSerializer)) && (h["Content-Type"] = "application/json") : p = ef({
                        query: s,
                        variables: o,
                        operationName: a,
                        jsonSerializer: u.jsonSerializer ? ? r
                    });
                    let d = {
                            method: e,
                            headers: h,
                            body: i,
                            ...u
                        },
                        f = n,
                        y = d;
                    if (c) {
                        let e = await Promise.resolve(c({ ...d,
                                url: n,
                                operationName: a,
                                variables: o
                            })),
                            {
                                url: t,
                                ...i
                            } = e;
                        f = t, y = i
                    }
                    return p && (f = `${f}?${p}`), await l(f, y)
                };
            class eE {
                constructor(e, t = {}) {
                    this.url = e, this.requestConfig = t, this.rawRequest = async (...e) => {
                        let [t, i, r] = e, n = a(t, i, r), {
                            headers: s,
                            fetch: o = eu,
                            method: l = "POST",
                            requestMiddleware: u,
                            responseMiddleware: c,
                            ...h
                        } = this.requestConfig, {
                            url: p
                        } = this;
                        void 0 !== n.signal && (h.signal = n.signal);
                        let {
                            operationName: d
                        } = Z(n.query);
                        return em({
                            url: p,
                            query: n.query,
                            variables: n.variables,
                            headers: { ...ep(eN(s)),
                                ...ep(n.requestHeaders)
                            },
                            operationName: d,
                            fetch: o,
                            method: l,
                            fetchOptions: h,
                            middleware: u
                        }).then(e => (c && c(e), e)).catch(e => {
                            throw c && c(e), e
                        })
                    }
                }
                async request(e, ...t) {
                    let [i, r] = t, n = o(e, i, r), {
                        headers: s,
                        fetch: a = eu,
                        method: l = "POST",
                        requestMiddleware: u,
                        responseMiddleware: c,
                        ...h
                    } = this.requestConfig, {
                        url: p
                    } = this;
                    void 0 !== n.signal && (h.signal = n.signal);
                    let {
                        query: d,
                        operationName: f
                    } = Z(n.document);
                    return em({
                        url: p,
                        query: d,
                        variables: n.variables,
                        headers: { ...ep(eN(s)),
                            ...ep(n.requestHeaders)
                        },
                        operationName: f,
                        fetch: a,
                        method: l,
                        fetchOptions: h,
                        middleware: u
                    }).then(e => (c && c(e), e.data)).catch(e => {
                        throw c && c(e), e
                    })
                }
                batchRequests(e, t) {
                    let i = l(e, t),
                        {
                            headers: r,
                            ...n
                        } = this.requestConfig;
                    void 0 !== i.signal && (n.signal = i.signal);
                    let s = i.documents.map(({
                            document: e
                        }) => Z(e).query),
                        o = i.documents.map(({
                            variables: e
                        }) => e);
                    return em({
                        url: this.url,
                        query: s,
                        variables: o,
                        headers: { ...ep(eN(r)),
                            ...ep(i.requestHeaders)
                        },
                        operationName: void 0,
                        fetch: this.requestConfig.fetch ? ? eu,
                        method: this.requestConfig.method || "POST",
                        fetchOptions: n,
                        middleware: this.requestConfig.requestMiddleware
                    }).then(e => (this.requestConfig.responseMiddleware && this.requestConfig.responseMiddleware(e), e.data)).catch(e => {
                        throw this.requestConfig.responseMiddleware && this.requestConfig.responseMiddleware(e), e
                    })
                }
                setHeaders(e) {
                    return this.requestConfig.headers = e, this
                }
                setHeader(e, t) {
                    let {
                        headers: i
                    } = this.requestConfig;
                    return i ? i[e] = t : this.requestConfig.headers = {
                        [e]: t
                    }, this
                }
                setEndpoint(e) {
                    return this.url = e, this
                }
            }
            let em = async e => {
                    let {
                        query: t,
                        variables: i,
                        fetchOptions: s
                    } = e, o = ey(n(e.method ? ? "post")), a = Array.isArray(e.query), l = await o(e), u = await ev(l, s.jsonSerializer ? ? r), c = Array.isArray(u) ? !u.some(({
                        data: e
                    }) => !e) : !!u.data, h = Array.isArray(u) || !u.errors || Array.isArray(u.errors) && !u.errors.length || "all" === s.errorPolicy || "ignore" === s.errorPolicy;
                    if (l.ok && h && c) {
                        let {
                            errors: e,
                            ...t
                        } = (Array.isArray(u), u), i = "ignore" === s.errorPolicy ? t : u;
                        return { ...a ? {
                                data: i
                            } : i,
                            headers: l.headers,
                            status: l.status
                        }
                    } {
                        let e = "string" == typeof u ? {
                            error: u
                        } : u;
                        throw new ee({ ...e,
                            status: l.status,
                            headers: l.headers
                        }, {
                            query: t,
                            variables: i
                        })
                    }
                },
                eT = (e, t, i, n) => {
                    let s = n ? ? r;
                    if (!Array.isArray(e)) return s.stringify({
                        query: e,
                        variables: t,
                        operationName: i
                    });
                    if (void 0 !== t && !Array.isArray(t)) throw Error("Cannot create request body with given variable type, array expected");
                    let o = e.reduce((e, i, r) => (e.push({
                        query: i,
                        variables: t ? t[r] : void 0
                    }), e), []);
                    return s.stringify(o)
                },
                ev = async (e, t) => {
                    let i;
                    return (e.headers.forEach((e, t) => {
                        "content-type" === t.toLowerCase() && (i = e)
                    }), i && (i.toLowerCase().startsWith("application/json") || i.toLowerCase().startsWith("application/graphql+json") || i.toLowerCase().startsWith("application/graphql-response+json"))) ? t.parse(await e.text()) : e.text()
                },
                eN = e => "function" == typeof e ? e() : e,
                eI = (e, ...t) => e.reduce((e, i, r) => `${e}${i}${r in t?String(t[r]):""}`, "")
        }
    }
]);