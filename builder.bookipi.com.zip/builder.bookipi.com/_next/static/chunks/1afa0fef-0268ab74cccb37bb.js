"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3166], {
        4305: function(a, n, e) {
            e.d(n, {
                util: function() {
                    return y
                }
            });
            var l = {
                    AED: {
                        symbol: "AED",
                        name: "United Arab Emirates Dirham",
                        symbol_native: "AED",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "AED",
                        name_plural: "UAE dirhams",
                        rtl: !1
                    },
                    AFN: {
                        symbol: "Af",
                        name: "Afghan Afghani",
                        symbol_native: "Af",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "AFN",
                        name_plural: "Afghan Afghanis",
                        rtl: !0
                    },
                    ALL: {
                        symbol: "ALL",
                        name: "Albanian Lek",
                        symbol_native: "Lek",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "ALL",
                        name_plural: "Albanian lek\xeb"
                    },
                    AOA: {
                        symbol: "Kz",
                        name: "Angolan kwanza",
                        symbol_native: "Kz",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "AOA",
                        name_plural: "Angolan kwanza"
                    },
                    AMD: {
                        symbol: "AMD",
                        name: "Armenian Dram",
                        symbol_native: "դր.",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "AMD",
                        name_plural: "Armenian drams"
                    },
                    ANG: {
                        symbol: "ANG",
                        name: "Dutch Guilder",
                        symbol_native: "ƒ",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "ANG",
                        name_plural: "Dutch Guilders"
                    },
                    ARS: {
                        symbol: "AR$",
                        name: "Argentine Peso",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "ARS",
                        name_plural: "Argentine pesos"
                    },
                    AUD: {
                        symbol: "AU$",
                        name: "Australian Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "AUD",
                        name_plural: "Australian dollars"
                    },
                    AWG: {
                        code: "AWG",
                        decimal_digits: 2,
                        name: "Aruban Florin",
                        name_plural: "Aruban Florin",
                        rounding: 0,
                        symbol: "Afl.",
                        symbol_native: "Afl."
                    },
                    AZN: {
                        symbol: "man.",
                        name: "Azerbaijani Manat",
                        symbol_native: "ман.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "AZN",
                        name_plural: "Azerbaijani manats"
                    },
                    BAM: {
                        symbol: "KM",
                        name: "Bosnia-Herzegovina Convertible Mark",
                        symbol_native: "KM",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BAM",
                        name_plural: "Bosnia-Herzegovina convertible marks"
                    },
                    BBD: {
                        symbol: "Bds$",
                        name: "Barbadian Dollar",
                        symbol_native: "Bds$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BBD",
                        name_plural: "Barbadian Dollars"
                    },
                    BDT: {
                        symbol: "Tk",
                        name: "Bangladeshi Taka",
                        symbol_native: "Tk",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BDT",
                        name_plural: "Bangladeshi takas"
                    },
                    BGN: {
                        symbol: "BGN",
                        name: "Bulgarian Lev",
                        symbol_native: "лв.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BGN",
                        name_plural: "Bulgarian leva"
                    },
                    BHD: {
                        symbol: "BD",
                        name: "Bahraini Dinar",
                        symbol_native: "د.ب.‏",
                        decimal_digits: 3,
                        rounding: 0,
                        code: "BHD",
                        name_plural: "Bahraini dinars",
                        rtl: !0
                    },
                    BIF: {
                        symbol: "FBu",
                        name: "Burundian Franc",
                        symbol_native: "FBu",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "BIF",
                        name_plural: "Burundian francs"
                    },
                    BND: {
                        symbol: "BN$",
                        name: "Brunei Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BND",
                        name_plural: "Brunei dollars"
                    },
                    BOB: {
                        symbol: "Bs",
                        name: "Bolivian Boliviano",
                        symbol_native: "Bs",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BOB",
                        name_plural: "Bolivian bolivianos"
                    },
                    BSD: {
                        symbol: "B$",
                        name: "Bahamian Dollar",
                        symbol_native: "B$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BSD",
                        name_plural: "Bahamian dollar"
                    },
                    BRL: {
                        symbol: "R$",
                        name: "Brazilian Real",
                        symbol_native: "R$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BRL",
                        name_plural: "Brazilian reals"
                    },
                    BWP: {
                        symbol: "BWP",
                        name: "Botswanan Pula",
                        symbol_native: "P",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BWP",
                        name_plural: "Botswanan pulas"
                    },
                    BYR: {
                        symbol: "BYR",
                        name: "Belarusian Ruble",
                        symbol_native: "BYR",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "BYR",
                        name_plural: "Belarusian rubles"
                    },
                    BZD: {
                        symbol: "BZ$",
                        name: "Belize Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "BZD",
                        name_plural: "Belize dollars"
                    },
                    CAD: {
                        symbol: "CA$",
                        name: "Canadian Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "CAD",
                        name_plural: "Canadian dollars"
                    },
                    CDF: {
                        symbol: "CDF",
                        name: "Congolese Franc",
                        symbol_native: "FrCD",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "CDF",
                        name_plural: "Congolese francs"
                    },
                    CHF: {
                        symbol: "CHF",
                        name: "Swiss Franc",
                        symbol_native: "CHF",
                        decimal_digits: 2,
                        rounding: .05,
                        code: "CHF",
                        name_plural: "Swiss francs"
                    },
                    CLP: {
                        symbol: "CL$",
                        name: "Chilean Peso",
                        symbol_native: "$",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "CLP",
                        name_plural: "Chilean pesos"
                    },
                    CNY: {
                        symbol: "\xa5",
                        name: "Chinese Yuan",
                        symbol_native: "\xa5",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "CNY",
                        name_plural: "Chinese yuan"
                    },
                    COP: {
                        symbol: "CO$",
                        name: "Colombian Peso",
                        symbol_native: "$",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "COP",
                        name_plural: "Colombian pesos"
                    },
                    CRC: {
                        symbol: "₡",
                        name: "Costa Rican Col\xf3n",
                        symbol_native: "₡",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "CRC",
                        name_plural: "Costa Rican col\xf3ns"
                    },
                    CVE: {
                        symbol: "CV$",
                        name: "Cape Verdean Escudo",
                        symbol_native: "CV$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "CVE",
                        name_plural: "Cape Verdean escudos"
                    },
                    CZK: {
                        symbol: "Kč",
                        name: "Czech Republic Koruna",
                        symbol_native: "Kč",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "CZK",
                        name_plural: "Czech Republic korunas"
                    },
                    DJF: {
                        symbol: "Fdj",
                        name: "Djiboutian Franc",
                        symbol_native: "Fdj",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "DJF",
                        name_plural: "Djiboutian francs"
                    },
                    DKK: {
                        symbol: "Dkr",
                        name: "Danish Krone",
                        symbol_native: "kr",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "DKK",
                        name_plural: "Danish kroner"
                    },
                    DOP: {
                        symbol: "RD$",
                        name: "Dominican Peso",
                        symbol_native: "RD$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "DOP",
                        name_plural: "Dominican pesos"
                    },
                    DZD: {
                        symbol: "DA",
                        name: "Algerian Dinar",
                        symbol_native: "د.ج.‏",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "DZD",
                        name_plural: "Algerian dinars",
                        rtl: !0
                    },
                    EEK: {
                        symbol: "Ekr",
                        name: "Estonian Kroon",
                        symbol_native: "kr",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "EEK",
                        name_plural: "Estonian kroons"
                    },
                    EGP: {
                        symbol: "EGP",
                        name: "Egyptian Pound",
                        symbol_native: "ج.م.‏",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "EGP",
                        name_plural: "Egyptian pounds",
                        rtl: !0
                    },
                    ERN: {
                        symbol: "Nfk",
                        name: "Eritrean Nakfa",
                        symbol_native: "Nfk",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "ERN",
                        name_plural: "Eritrean nakfas"
                    },
                    ETB: {
                        symbol: "Br",
                        name: "Ethiopian Birr",
                        symbol_native: "Br",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "ETB",
                        name_plural: "Ethiopian birrs"
                    },
                    EUR: {
                        symbol: "€",
                        name: "Euro",
                        symbol_native: "€",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "EUR",
                        name_plural: "euros"
                    },
                    GBP: {
                        symbol: "\xa3",
                        name: "British Pound Sterling",
                        symbol_native: "\xa3",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "GBP",
                        name_plural: "British pounds sterling"
                    },
                    GEL: {
                        symbol: "GEL",
                        name: "Georgian Lari",
                        symbol_native: "GEL",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "GEL",
                        name_plural: "Georgian laris"
                    },
                    GHS: {
                        symbol: "GH₵",
                        name: "Ghanaian Cedi",
                        symbol_native: "GH₵",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "GHS",
                        name_plural: "Ghanaian cedis"
                    },
                    GNF: {
                        symbol: "FG",
                        name: "Guinean Franc",
                        symbol_native: "FG",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "GNF",
                        name_plural: "Guinean francs"
                    },
                    GTQ: {
                        symbol: "GTQ",
                        name: "Guatemalan Quetzal",
                        symbol_native: "Q",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "GTQ",
                        name_plural: "Guatemalan quetzals"
                    },
                    HKD: {
                        symbol: "HK$",
                        name: "Hong Kong Dollar",
                        symbol_native: "HKD",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "HKD",
                        name_plural: "Hong Kong dollars"
                    },
                    HNL: {
                        symbol: "HNL",
                        name: "Honduran Lempira",
                        symbol_native: "L",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "HNL",
                        name_plural: "Honduran lempiras"
                    },
                    HRK: {
                        symbol: "kn",
                        name: "Croatian Kuna",
                        symbol_native: "kn",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "HRK",
                        name_plural: "Croatian kunas"
                    },
                    HTG: {
                        symbol: "HTG",
                        name: "Haitian gourde",
                        symbol_native: "G",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "HTG",
                        name_plural: "Haitian gourde"
                    },
                    HUF: {
                        symbol: "Ft",
                        name: "Hungarian Forint",
                        symbol_native: "Ft",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "HUF",
                        name_plural: "Hungarian forints"
                    },
                    IDR: {
                        symbol: "Rp",
                        name: "Indonesian Rupiah",
                        symbol_native: "Rp",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "IDR",
                        name_plural: "Indonesian rupiahs"
                    },
                    ILS: {
                        symbol: "₪",
                        name: "Israeli New Sheqel",
                        symbol_native: "₪",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "ILS",
                        name_plural: "Israeli new sheqels"
                    },
                    INR: {
                        symbol: "Rs",
                        name: "Indian Rupee",
                        symbol_native: "₹",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "INR",
                        name_plural: "Indian rupees"
                    },
                    IQD: {
                        symbol: "IQD",
                        name: "Iraqi Dinar",
                        symbol_native: "د.ع.‏",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "IQD",
                        name_plural: "Iraqi dinars",
                        rtl: !0
                    },
                    IRR: {
                        symbol: "IRR",
                        name: "Iranian Rial",
                        symbol_native: "IRR",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "IRR",
                        name_plural: "Iranian rials",
                        rtl: !0
                    },
                    ISK: {
                        symbol: "Ikr",
                        name: "Icelandic Kr\xf3na",
                        symbol_native: "kr",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "ISK",
                        name_plural: "Icelandic kr\xf3nur"
                    },
                    JMD: {
                        symbol: "J$",
                        name: "Jamaican Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "JMD",
                        name_plural: "Jamaican dollars"
                    },
                    JOD: {
                        symbol: "JD",
                        name: "Jordanian Dinar",
                        symbol_native: "د.أ.‏",
                        decimal_digits: 3,
                        rounding: 0,
                        code: "JOD",
                        name_plural: "Jordanian dinars",
                        rtl: !0
                    },
                    JPY: {
                        symbol: "\xa5",
                        name: "Japanese Yen",
                        symbol_native: "\xa5",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "JPY",
                        name_plural: "Japanese yen"
                    },
                    KES: {
                        symbol: "Ksh",
                        name: "Kenyan Shilling",
                        symbol_native: "Ksh",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "KES",
                        name_plural: "Kenyan shillings"
                    },
                    KHR: {
                        symbol: "KHR",
                        name: "Cambodian Riel",
                        symbol_native: "KHR",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "KHR",
                        name_plural: "Cambodian riels"
                    },
                    KMF: {
                        symbol: "CF",
                        name: "Comorian Franc",
                        symbol_native: "FC",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "KMF",
                        name_plural: "Comorian francs"
                    },
                    KRW: {
                        symbol: "₩",
                        name: "Korean Won(₩)",
                        symbol_native: "₩",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "KRW",
                        name_plural: "Korean won"
                    },
                    KRW2: {
                        symbol: "원",
                        name: "Korean Won(원)",
                        symbol_native: "원",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "KRW2",
                        name_plural: "Korean won"
                    },
                    KWD: {
                        symbol: "KD",
                        name: "Kuwaiti Dinar",
                        symbol_native: "د.ك.‏",
                        decimal_digits: 3,
                        rounding: 0,
                        code: "KWD",
                        name_plural: "Kuwaiti dinars",
                        rtl: !0
                    },
                    KZT: {
                        symbol: "KZT",
                        name: "Kazakhstani Tenge",
                        symbol_native: "тңг.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "KZT",
                        name_plural: "Kazakhstani tenges"
                    },
                    LBP: {
                        symbol: "LB\xa3",
                        name: "Lebanese Pound",
                        symbol_native: "LBP",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "LBP",
                        name_plural: "Lebanese pounds",
                        rtl: !0
                    },
                    LKR: {
                        symbol: "SLRs",
                        name: "Sri Lankan Rupee",
                        symbol_native: "LKR Rs",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "LKR",
                        name_plural: "Sri Lankan rupees"
                    },
                    LTL: {
                        symbol: "Lt",
                        name: "Lithuanian Litas",
                        symbol_native: "Lt",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "LTL",
                        name_plural: "Lithuanian litai"
                    },
                    LVL: {
                        symbol: "Ls",
                        name: "Latvian Lats",
                        symbol_native: "Ls",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "LVL",
                        name_plural: "Latvian lati"
                    },
                    LYD: {
                        symbol: "LD",
                        name: "Libyan Dinar",
                        symbol_native: "د.ل.‏",
                        decimal_digits: 3,
                        rounding: 0,
                        code: "LYD",
                        name_plural: "Libyan dinars",
                        rtl: !0
                    },
                    MAD: {
                        symbol: "MAD",
                        name: "Moroccan Dirham",
                        symbol_native: "MAD",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MAD",
                        name_plural: "Moroccan dirhams",
                        rtl: !0
                    },
                    MDL: {
                        symbol: "MDL",
                        name: "Moldovan Leu",
                        symbol_native: "MDL",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MDL",
                        name_plural: "Moldovan lei"
                    },
                    MGA: {
                        symbol: "MGA",
                        name: "Malagasy Ariary",
                        symbol_native: "MGA",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "MGA",
                        name_plural: "Malagasy Ariaries"
                    },
                    MKD: {
                        symbol: "MKD",
                        name: "Macedonian Denar",
                        symbol_native: "MKD",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MKD",
                        name_plural: "Macedonian denari"
                    },
                    MMK: {
                        symbol: "MMK",
                        name: "Myanma Kyat",
                        symbol_native: "K",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "MMK",
                        name_plural: "Myanma kyats"
                    },
                    MOP: {
                        symbol: "MOP$",
                        name: "Macanese Pataca",
                        symbol_native: "MOP$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MOP",
                        name_plural: "Macanese patacas"
                    },
                    MUR: {
                        symbol: "MURs",
                        name: "Mauritian Rupee",
                        symbol_native: "MURs",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "MUR",
                        name_plural: "Mauritian rupees"
                    },
                    MXN: {
                        symbol: "MX$",
                        name: "Mexican Peso",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MXN",
                        name_plural: "Mexican pesos"
                    },
                    MVR: {
                        symbol: "MVR",
                        name: "Maldivian rufiyaa",
                        symbol_native: "MVR",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MVR",
                        name_plural: "Maldivian rufiyaas"
                    },
                    MYR: {
                        symbol: "RM",
                        name: "Malaysian Ringgit",
                        symbol_native: "RM",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MYR",
                        name_plural: "Malaysian ringgits"
                    },
                    MZN: {
                        symbol: "MTn",
                        name: "Mozambican Metical",
                        symbol_native: "MTn",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "MZN",
                        name_plural: "Mozambican meticals"
                    },
                    NAD: {
                        symbol: "N$",
                        name: "Namibian Dollar",
                        symbol_native: "N$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "NAD",
                        name_plural: "Namibian dollars"
                    },
                    NGN: {
                        symbol: "₦",
                        name: "Nigerian Naira",
                        symbol_native: "₦",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "NGN",
                        name_plural: "Nigerian nairas"
                    },
                    NIO: {
                        symbol: "C$",
                        name: "Nicaraguan C\xf3rdoba",
                        symbol_native: "C$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "NIO",
                        name_plural: "Nicaraguan c\xf3rdobas"
                    },
                    NOK: {
                        symbol: "Nkr",
                        name: "Norwegian Krone",
                        symbol_native: "kr",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "NOK",
                        name_plural: "Norwegian kroner"
                    },
                    NPR: {
                        symbol: "NPRs",
                        name: "Nepalese Rupee",
                        symbol_native: "NPRs",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "NPR",
                        name_plural: "Nepalese rupees"
                    },
                    NZD: {
                        symbol: "NZ$",
                        name: "New Zealand Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "NZD",
                        name_plural: "New Zealand dollars"
                    },
                    OMR: {
                        symbol: "OMR",
                        name: "Omani Rial",
                        symbol_native: "OMR",
                        decimal_digits: 3,
                        rounding: 0,
                        code: "OMR",
                        name_plural: "Omani rials"
                    },
                    PAB: {
                        symbol: "B/.",
                        name: "Panamanian Balboa",
                        symbol_native: "B/.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "PAB",
                        name_plural: "Panamanian balboas"
                    },
                    PEN: {
                        symbol: "S/.",
                        name: "Peruvian Nuevo Sol",
                        symbol_native: "S/.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "PEN",
                        name_plural: "Peruvian nuevos soles"
                    },
                    PGK: {
                        symbol: "K",
                        name: "Papua New Guinea Kina",
                        symbol_native: "K",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "PGK",
                        name_plural: "Papua New Guinea Kina"
                    },
                    PHP: {
                        symbol: "₱",
                        name: "Philippine Peso",
                        symbol_native: "₱",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "PHP",
                        name_plural: "Philippine pesos"
                    },
                    PKR: {
                        symbol: "PKRs",
                        name: "Pakistani Rupee",
                        symbol_native: "₨",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "PKR",
                        name_plural: "Pakistani rupees"
                    },
                    PLN: {
                        symbol: "zł",
                        name: "Polish Zloty",
                        symbol_native: "zł",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "PLN",
                        name_plural: "Polish zlotys"
                    },
                    PYG: {
                        symbol: "₲",
                        name: "Paraguayan Guarani",
                        symbol_native: "₲",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "PYG",
                        name_plural: "Paraguayan guaranis"
                    },
                    QAR: {
                        symbol: "QR",
                        name: "Qatari Rial",
                        symbol_native: "ر.ق.‏",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "QAR",
                        name_plural: "Qatari rials",
                        rtl: !0
                    },
                    RON: {
                        symbol: "lei",
                        name: "Romanian Leu",
                        symbol_native: "lei",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "RON",
                        name_plural: "Romanian lei"
                    },
                    RSD: {
                        symbol: "din.",
                        name: "Serbian Dinar",
                        symbol_native: "дин.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "RSD",
                        name_plural: "Serbian dinars"
                    },
                    RUB: {
                        symbol: "RUB",
                        name: "Russian Ruble",
                        symbol_native: "руб.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "RUB",
                        name_plural: "Russian rubles"
                    },
                    RWF: {
                        symbol: "RWF",
                        name: "Rwandan Franc",
                        symbol_native: "FR",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "RWF",
                        name_plural: "Rwandan francs"
                    },
                    SAR: {
                        symbol: "SR",
                        name: "Saudi Riyal",
                        symbol_native: "ر.س.‏",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "SAR",
                        name_plural: "Saudi riyals",
                        rtl: !0
                    },
                    SCR: {
                        code: "SCR",
                        decimal_digits: 2,
                        name: "Seychelles Rupee",
                        name_plural: "Seychelles Rupees",
                        rounding: 0,
                        symbol: "RS",
                        symbol_native: "RS"
                    },
                    SDG: {
                        symbol: "SDG",
                        name: "Sudanese Pound",
                        symbol_native: "SDG",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "SDG",
                        name_plural: "Sudanese pounds"
                    },
                    SEK: {
                        symbol: "Skr",
                        name: "Swedish Krona",
                        symbol_native: "kr",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "SEK",
                        name_plural: "Swedish kronor"
                    },
                    SGD: {
                        symbol: "S$",
                        name: "Singapore Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "SGD",
                        name_plural: "Singapore dollars"
                    },
                    SLE: {
                        symbol: "Le",
                        name: "Sierra Leonean leone",
                        symbol_native: "Le",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "SLE",
                        name_plural: "Sierra Leonean Leones"
                    },
                    SLL: {
                        symbol: "SLL",
                        name: "Sierra Leonean Leone",
                        symbol_native: "SLL",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "SLL",
                        name_plural: "Sierra Leonean Leones"
                    },
                    SOS: {
                        symbol: "Ssh",
                        name: "Somali Shilling",
                        symbol_native: "Ssh",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "SOS",
                        name_plural: "Somali shillings"
                    },
                    SRD: {
                        symbol: "SRD",
                        name: "Surinamese dollar",
                        symbol_native: "SRD",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "SRD",
                        name_plural: "Surinamese dollars"
                    },
                    SYP: {
                        symbol: "SY\xa3",
                        name: "Syrian Pound",
                        symbol_native: "ل.س.‏",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "SYP",
                        name_plural: "Syrian pounds",
                        rtl: !0
                    },
                    THB: {
                        symbol: "฿",
                        name: "Thai Baht",
                        symbol_native: "฿",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "THB",
                        name_plural: "Thai baht"
                    },
                    TND: {
                        symbol: "DT",
                        name: "Tunisian Dinar",
                        symbol_native1: "د.ت.‏",
                        symbol_native: "TND",
                        decimal_digits: 3,
                        rounding: 0,
                        code: "TND",
                        name_plural: "Tunisian dinars"
                    },
                    TOP: {
                        symbol: "T$",
                        name: "Tongan Paʻanga",
                        symbol_native: "T$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "TOP",
                        name_plural: "Tongan paʻanga"
                    },
                    TRY: {
                        symbol: "TL",
                        name: "Turkish Lira",
                        symbol_native: "TL",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "TRY",
                        name_plural: "Turkish Lira"
                    },
                    TTD: {
                        symbol: "TT$",
                        name: "Trinidad and Tobago Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "TTD",
                        name_plural: "Trinidad and Tobago dollars"
                    },
                    TWD: {
                        symbol: "NT$",
                        name: "New Taiwan Dollar",
                        symbol_native: "NT$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "TWD",
                        name_plural: "New Taiwan dollars"
                    },
                    TZS: {
                        symbol: "TSh",
                        name: "Tanzanian Shilling",
                        symbol_native: "TSh",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "TZS",
                        name_plural: "Tanzanian shillings"
                    },
                    UAH: {
                        symbol: "₴",
                        name: "Ukrainian Hryvnia",
                        symbol_native: "₴",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "UAH",
                        name_plural: "Ukrainian hryvnias"
                    },
                    UGX: {
                        symbol: "USh",
                        name: "Ugandan Shilling",
                        symbol_native: "USh",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "UGX",
                        name_plural: "Ugandan shillings"
                    },
                    USD: {
                        symbol: "US$",
                        name: "US Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "USD",
                        name_plural: "US dollars"
                    },
                    UYU: {
                        symbol: "$U",
                        name: "Uruguayan Peso",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "UYU",
                        name_plural: "Uruguayan pesos"
                    },
                    UZS: {
                        symbol: "UZS",
                        name: "Uzbekistan Som",
                        symbol_native: "UZS",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "UZS",
                        name_plural: "Uzbekistan som"
                    },
                    VEF: {
                        symbol: "Bs.F.",
                        name: "Venezuelan Bol\xedvar",
                        symbol_native: "Bs.F.",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "VEF",
                        name_plural: "Venezuelan bol\xedvars"
                    },
                    VES: {
                        symbol: "VES",
                        name: "Bol\xedvar Soberano",
                        symbol_native: "Bs.S ",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "VES",
                        name_plural: "Bol\xedvares Soberanos"
                    },
                    VND: {
                        symbol: "Dong",
                        name: "Vietnamese Dong",
                        symbol_native: "Dong",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "VND",
                        name_plural: "Vietnamese dong"
                    },
                    XAF: {
                        symbol: "FCFA",
                        name: "CFA Franc BEAC",
                        symbol_native: "FCFA",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "XAF",
                        name_plural: "CFA francs BEAC"
                    },
                    XCD: {
                        symbol: "XCD$",
                        name: "East Caribbean Dollar",
                        symbol_native: "$",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "XCD",
                        name_plural: "East Caribbean Dollars"
                    },
                    XOF: {
                        symbol: "CFA",
                        name: "CFA Franc BCEAO",
                        symbol_native: "CFA",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "XOF",
                        name_plural: "CFA francs BCEAO"
                    },
                    XPF: {
                        symbol: "XPF",
                        name: "Central Pacific Franc",
                        symbol_native: "F",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "XPF",
                        name_plural: "Central Pacific Franc"
                    },
                    YER: {
                        symbol: "YR",
                        name: "Yemeni Rial",
                        symbol_native: "ر.ي.‏",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "YER",
                        name_plural: "Yemeni rials",
                        rtl: !0
                    },
                    ZAR: {
                        symbol: "R",
                        name: "South African Rand",
                        symbol_native: "R",
                        decimal_digits: 2,
                        rounding: 0,
                        code: "ZAR",
                        name_plural: "South African rand"
                    },
                    ZMK: {
                        symbol: "ZK",
                        name: "Zambian Kwacha",
                        symbol_native: "ZK",
                        decimal_digits: 0,
                        rounding: 0,
                        code: "ZMK",
                        name_plural: "Zambian kwachas"
                    }
                },
                r = {
                    am: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: "AMD"
                    },
                    ar: {
                        decimal: ".",
                        group: ",",
                        format: "$$\xa0###",
                        currency: "ARS"
                    },
                    bg: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: "BGN"
                    },
                    bn: {
                        decimal: ".",
                        group: ",",
                        format: "###$$",
                        currency: "BND"
                    },
                    ca: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: "CAD"
                    },
                    cs: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: "EUR"
                    },
                    da: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: "DKK"
                    },
                    de: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    el: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    en: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    "en-GB": {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    es: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    "es-419": {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    et: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    fa: {
                        decimal: ".",
                        group: ",",
                        format: "‎$$\xa0###",
                        currency: ""
                    },
                    fi: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    fil: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    fr: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    he: {
                        decimal: ".",
                        group: ",",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    hi: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    hr: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    gu: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    hu: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    id: {
                        decimal: ",",
                        group: ".",
                        format: "$$###",
                        currency: ""
                    },
                    it: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    ja: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    kn: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    ko: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    lv: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    lt: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    ml: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    mr: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    ms: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    nb: {
                        decimal: ",",
                        group: "\xa0",
                        format: "$$\xa0###",
                        currency: ""
                    },
                    nl: {
                        decimal: ",",
                        group: ".",
                        format: "$$\xa0###",
                        currency: ""
                    },
                    pt: {
                        decimal: ",",
                        group: ".",
                        format: "$$\xa0###",
                        currency: ""
                    },
                    pl: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    "pt-PT": {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    ro: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    ru: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    sk: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    sl: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    sr: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    sv: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    sw: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    ta: {
                        decimal: ".",
                        group: ",",
                        format: "$$\xa0###",
                        currency: ""
                    },
                    te: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    th: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    tr: {
                        decimal: ",",
                        group: ".",
                        format: "$$###",
                        currency: ""
                    },
                    uk: {
                        decimal: ",",
                        group: "\xa0",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    vi: {
                        decimal: ",",
                        group: ".",
                        format: "###\xa0$$",
                        currency: ""
                    },
                    "zh-Hans": {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    zh: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    "zh-Hant": {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    c_1: {
                        decimal: ".",
                        group: ",",
                        format: "$$###",
                        currency: ""
                    },
                    c_2: {
                        decimal: ".",
                        group: ",",
                        format: "$$ ###",
                        currency: ""
                    },
                    c_3: {
                        decimal: ",",
                        group: ".",
                        format: "### $$",
                        currency: ""
                    },
                    c_4: {
                        decimal: ",",
                        group: " ",
                        format: "### $$",
                        currency: ""
                    }
                },
                o = new Map([
                    ["AF", {
                        currency: "AFN",
                        orientation: "rtl",
                        symbol: "؋",
                        locale: "af-AF"
                    }],
                    ["AL", {
                        currency: "ALL",
                        orientation: "ltr",
                        symbol: "L",
                        locale: "sq-AL"
                    }],
                    ["DZ", {
                        currency: "DZD",
                        orientation: "ltr",
                        symbol: "د.ج",
                        locale: "ar-DZ"
                    }],
                    ["AO", {
                        currency: "AOA",
                        orientation: "ltr",
                        symbol: "Kz",
                        locale: "pt-AO"
                    }],
                    ["AI", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-AI"
                    }],
                    ["AG", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-AG"
                    }],
                    ["AM", {
                        currency: "AMD",
                        orientation: "ltr",
                        symbol: "֏",
                        locale: "hy-AM"
                    }],
                    ["AU", {
                        currency: "AUD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-AU"
                    }],
                    ["AZ", {
                        currency: "AZN",
                        orientation: "ltr",
                        symbol: "₼",
                        locale: "az-Latn-AZ"
                    }],
                    ["BS", {
                        currency: "BSD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-BS"
                    }],
                    ["BH", {
                        currency: "BHD",
                        orientation: "rtl",
                        symbol: ".د.ب",
                        locale: "ar-BH"
                    }],
                    ["BB", {
                        currency: "BBD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-BB"
                    }],
                    ["BY", {
                        currency: "BYN",
                        orientation: "ltr",
                        symbol: "Br",
                        locale: "be-BY"
                    }],
                    ["BE", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "nl-BE"
                    }],
                    ["BZ", {
                        currency: "BZD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-BZ"
                    }],
                    ["BJ", {
                        currency: "XOF",
                        orientation: "rtl",
                        symbol: "XOF",
                        locale: "fr-BJ"
                    }],
                    ["BM", {
                        currency: "BMD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-BM"
                    }],
                    ["BT", {
                        currency: "BTN",
                        orientation: "ltr",
                        symbol: "Nu.",
                        locale: "dz-BT"
                    }],
                    ["BA", {
                        currency: "BAM",
                        orientation: "ltr",
                        symbol: "KM",
                        locale: "bs-Latn-BA"
                    }],
                    ["BW", {
                        currency: "BWP",
                        orientation: "ltr",
                        symbol: "P",
                        locale: "en-BW"
                    }],
                    ["VG", {
                        currency: "USD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-VG"
                    }],
                    ["BN", {
                        currency: "BND",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "ms-BN"
                    }],
                    ["BG", {
                        currency: "BGN",
                        orientation: "ltr",
                        symbol: "лв",
                        locale: "bg-BG"
                    }],
                    ["BF", {
                        currency: "XOF",
                        orientation: "rtl",
                        symbol: "XOF",
                        locale: "fr-BF"
                    }],
                    ["KH", {
                        currency: "KHR",
                        orientation: "ltr",
                        symbol: "៛",
                        locale: "km-KH"
                    }],
                    ["CA", {
                        currency: "CAD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-CA"
                    }],
                    ["CV", {
                        currency: "CVE",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "pt-CV"
                    }],
                    ["KY", {
                        currency: "KYD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-KY"
                    }],
                    ["TD", {
                        currency: "XAF",
                        orientation: "ltr",
                        symbol: "Fr",
                        locale: "fr-TD"
                    }],
                    ["CD", {
                        currency: "CDF",
                        orientation: "ltr",
                        symbol: "Fr",
                        locale: "sw-CD"
                    }],
                    ["HR", {
                        currency: "HRK",
                        orientation: "ltr",
                        symbol: "kn",
                        locale: "hr-HR"
                    }],
                    ["CY", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "el-CY"
                    }],
                    ["CZ", {
                        currency: "CZK",
                        orientation: "ltr",
                        symbol: "Kč",
                        locale: "cs-CZ"
                    }],
                    ["DK", {
                        currency: "DKK",
                        orientation: "ltr",
                        symbol: "kr",
                        locale: "da-DK"
                    }],
                    ["DM", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-DM"
                    }],
                    ["EG", {
                        currency: "EGP",
                        orientation: "ltr",
                        symbol: "\xa3",
                        locale: "ar-EG"
                    }],
                    ["EE", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "et-EE"
                    }],
                    ["SZ", {
                        currency: "SZL",
                        orientation: "ltr",
                        symbol: "E",
                        locale: "en-SZ"
                    }],
                    ["FJ", {
                        currency: "FJD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-FJ"
                    }],
                    ["FI", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "fi-FI"
                    }],
                    ["GM", {
                        currency: "GMD",
                        orientation: "ltr",
                        symbol: "D",
                        locale: "en-GM"
                    }],
                    ["GE", {
                        currency: "GEL",
                        orientation: "ltr",
                        symbol: "₾",
                        locale: "ka-GE"
                    }],
                    ["GH", {
                        currency: "GHS",
                        orientation: "ltr",
                        symbol: "₵",
                        locale: "en-GH"
                    }],
                    ["GR", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "el-GR"
                    }],
                    ["GD", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-GD"
                    }],
                    ["GW", {
                        currency: "XOF",
                        orientation: "rtl",
                        symbol: "XOF",
                        locale: "pt-GW"
                    }],
                    ["GY", {
                        currency: "GYD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-GY"
                    }],
                    ["HU", {
                        currency: "HUF",
                        orientation: "ltr",
                        symbol: "Ft",
                        locale: "hu-HU"
                    }],
                    ["IS", {
                        currency: "ISK",
                        orientation: "ltr",
                        symbol: "kr",
                        locale: "is-IS"
                    }],
                    ["IN", {
                        currency: "INR",
                        orientation: "ltr",
                        symbol: "₹",
                        locale: "hi-IN"
                    }],
                    ["ID", {
                        currency: "IDR",
                        orientation: "ltr",
                        symbol: "Rp",
                        locale: "id-ID"
                    }],
                    ["IQ", {
                        currency: "IQD",
                        orientation: "rtl",
                        symbol: "ع.د",
                        locale: "ar-IQ"
                    }],
                    ["IE", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "en-IE"
                    }],
                    ["IL", {
                        currency: "ILS",
                        orientation: "ltr",
                        symbol: "₪",
                        locale: "he-IL"
                    }],
                    ["JM", {
                        currency: "JMD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-JM"
                    }],
                    ["JO", {
                        currency: "JOD",
                        orientation: "rtl",
                        symbol: "د.ا",
                        locale: "ar-JO"
                    }],
                    ["KZ", {
                        currency: "KZT",
                        orientation: "ltr",
                        symbol: "₸",
                        locale: "kk-KZ"
                    }],
                    ["KE", {
                        currency: "KES",
                        orientation: "ltr",
                        symbol: "Ksh",
                        locale: "en-KE"
                    }],
                    ["XK", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "sq-XK"
                    }],
                    ["KW", {
                        currency: "KWD",
                        orientation: "ltr",
                        symbol: "د.ك",
                        locale: "ar-KW"
                    }],
                    ["KG", {
                        currency: "KGS",
                        orientation: "ltr",
                        symbol: "с",
                        locale: "ky-KG"
                    }],
                    ["LA", {
                        currency: "LAK",
                        orientation: "ltr",
                        symbol: "₭",
                        locale: "lo-LA"
                    }],
                    ["LV", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "lv-LV"
                    }],
                    ["LB", {
                        currency: "LBP",
                        orientation: "rtl",
                        symbol: "ل.ل",
                        locale: "ar-LB"
                    }],
                    ["LR", {
                        currency: "LRD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-LR"
                    }],
                    ["LY", {
                        currency: "LYD",
                        orientation: "rtl",
                        symbol: "ل.د",
                        locale: "ar-LY"
                    }],
                    ["LT", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "lt-LT"
                    }],
                    ["LU", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "fr-LU"
                    }],
                    ["MG", {
                        currency: "MGA",
                        orientation: "ltr",
                        symbol: "Ar",
                        locale: "mg-MG"
                    }],
                    ["MW", {
                        currency: "MWK",
                        orientation: "ltr",
                        symbol: "MK",
                        locale: "en-MW"
                    }],
                    ["MY", {
                        currency: "MYR",
                        orientation: "ltr",
                        symbol: "RM",
                        locale: "ms-MY"
                    }],
                    ["MV", {
                        currency: "MVR",
                        orientation: "ltr",
                        symbol: "MVR",
                        locale: "dv-MV"
                    }],
                    ["ML", {
                        currency: "XOF",
                        orientation: "ltr",
                        symbol: "XOF",
                        locale: "fr-ML"
                    }],
                    ["MT", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "mt-MT"
                    }],
                    ["MR", {
                        currency: "MRU",
                        orientation: "ltr",
                        symbol: "UM",
                        locale: "ar-MR"
                    }],
                    ["FM", {
                        currency: "USD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-FM"
                    }],
                    ["MD", {
                        currency: "MDL",
                        orientation: "ltr",
                        symbol: "L",
                        locale: "ro-MD"
                    }],
                    ["MN", {
                        currency: "MNT",
                        orientation: "ltr",
                        symbol: "₮",
                        locale: "mn-MN"
                    }],
                    ["ME", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "sr-Latn-ME"
                    }],
                    ["MS", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-MS"
                    }],
                    ["MA", {
                        currency: "MAD",
                        orientation: "ltr",
                        symbol: "د.م.",
                        locale: "ar-MA"
                    }],
                    ["MZ", {
                        currency: "MZN",
                        orientation: "ltr",
                        symbol: "MT",
                        locale: "pt-MZ"
                    }],
                    ["MM", {
                        currency: "MMK",
                        orientation: "ltr",
                        symbol: "K",
                        locale: "my-MM"
                    }],
                    ["NA", {
                        currency: "NAD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-NA"
                    }],
                    ["NR", {
                        currency: "AUD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-NR"
                    }],
                    ["NP", {
                        currency: "NPR",
                        orientation: "ltr",
                        symbol: "रू",
                        locale: "ne-NP"
                    }],
                    ["NZ", {
                        currency: "NZD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-NZ"
                    }],
                    ["NE", {
                        currency: "XOF",
                        orientation: "rtl",
                        symbol: "XOF",
                        locale: "fr-NE"
                    }],
                    ["NG", {
                        currency: "NGN",
                        orientation: "ltr",
                        symbol: "₦",
                        locale: "en-NG"
                    }],
                    ["MK", {
                        currency: "MKD",
                        orientation: "ltr",
                        symbol: "ден",
                        locale: "mk-MK"
                    }],
                    ["NO", {
                        currency: "NOK",
                        orientation: "ltr",
                        symbol: "kr",
                        locale: "nb-NO"
                    }],
                    ["OM", {
                        currency: "OMR",
                        orientation: "rtl",
                        symbol: "ر.ع.",
                        locale: "ar-OM"
                    }],
                    ["PK", {
                        currency: "PKR",
                        orientation: "ltr",
                        symbol: "₨",
                        locale: "ur-PK"
                    }],
                    ["PW", {
                        currency: "USD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-PW"
                    }],
                    ["PG", {
                        currency: "PGK",
                        orientation: "ltr",
                        symbol: "K",
                        locale: "en-PG"
                    }],
                    ["PY", {
                        currency: "PYG",
                        orientation: "ltr",
                        symbol: "₲",
                        locale: "es-PY"
                    }],
                    ["PE", {
                        currency: "PEN",
                        orientation: "ltr",
                        symbol: "S/.",
                        locale: "es-PE"
                    }],
                    ["PH", {
                        currency: "PHP",
                        orientation: "ltr",
                        symbol: "₱",
                        locale: "fil-PH"
                    }],
                    ["PL", {
                        currency: "PLN",
                        orientation: "ltr",
                        symbol: "zł",
                        locale: "pl-PL"
                    }],
                    ["PT", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "pt-PT"
                    }],
                    ["QA", {
                        currency: "QAR",
                        orientation: "rtl",
                        symbol: "ر.ق",
                        locale: "ar-QA"
                    }],
                    ["RO", {
                        currency: "RON",
                        orientation: "ltr",
                        symbol: "lei",
                        locale: "ro-RO"
                    }],
                    ["RW", {
                        currency: "RWF",
                        orientation: "ltr",
                        symbol: "Fr",
                        locale: "rw-RW"
                    }],
                    ["ST", {
                        currency: "STN",
                        orientation: "ltr",
                        symbol: "Db",
                        locale: "pt-ST"
                    }],
                    ["SA", {
                        currency: "SAR",
                        orientation: "rtl",
                        symbol: "ر.س",
                        locale: "ar-SA"
                    }],
                    ["SN", {
                        currency: "XOF",
                        orientation: "rtl",
                        symbol: "XOF",
                        locale: "fr-SN"
                    }],
                    ["RS", {
                        currency: "RSD",
                        orientation: "ltr",
                        symbol: "din",
                        locale: "sr-Latn-RS"
                    }],
                    ["SC", {
                        currency: "SCR",
                        orientation: "ltr",
                        symbol: "₨",
                        locale: "fr-SC"
                    }],
                    ["SL", {
                        currency: "SLL",
                        orientation: "ltr",
                        symbol: "Le",
                        locale: "en-SL"
                    }],
                    ["SG", {
                        currency: "SGD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-SG"
                    }],
                    ["SK", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "sk-SK"
                    }],
                    ["SI", {
                        currency: "EUR",
                        orientation: "ltr",
                        symbol: "€",
                        locale: "sl-SI"
                    }],
                    ["SB", {
                        currency: "SBD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-SB"
                    }],
                    ["ZA", {
                        currency: "ZAR",
                        orientation: "ltr",
                        symbol: "R",
                        locale: "en-ZA"
                    }],
                    ["LK", {
                        currency: "LKR",
                        orientation: "ltr",
                        symbol: "Rs",
                        locale: "si-LK"
                    }],
                    ["KN", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-KN"
                    }],
                    ["LC", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-LC"
                    }],
                    ["VC", {
                        currency: "XCD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-VC"
                    }],
                    ["SR", {
                        currency: "SRD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "nl-SR"
                    }],
                    ["SE", {
                        currency: "SEK",
                        orientation: "ltr",
                        symbol: "kr",
                        locale: "sv-SE"
                    }],
                    ["CH", {
                        currency: "CHF",
                        orientation: "ltr",
                        symbol: "CHF",
                        locale: "de-CH"
                    }],
                    ["TW", {
                        currency: "TWD",
                        orientation: "ltr",
                        symbol: "NT$",
                        locale: "zh-TW"
                    }],
                    ["TJ", {
                        currency: "TJS",
                        orientation: "ltr",
                        symbol: "SM",
                        locale: "tg-Cyrl-TJ"
                    }],
                    ["TZ", {
                        currency: "TZS",
                        orientation: "ltr",
                        symbol: "TSh",
                        locale: "sw-TZ"
                    }],
                    ["TH", {
                        currency: "THB",
                        orientation: "ltr",
                        symbol: "฿",
                        locale: "th-TH"
                    }],
                    ["TO", {
                        currency: "TOP",
                        orientation: "ltr",
                        symbol: "T$",
                        locale: "to-TO"
                    }],
                    ["TT", {
                        currency: "TTD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-TT"
                    }],
                    ["TN", {
                        currency: "TND",
                        orientation: "rtl",
                        symbol: "د.ت",
                        locale: "ar-TN"
                    }],
                    ["TR", {
                        currency: "TRY",
                        orientation: "ltr",
                        symbol: "₺",
                        locale: "tr-TR"
                    }],
                    ["TM", {
                        currency: "TMT",
                        orientation: "ltr",
                        symbol: "m",
                        locale: "tk-TM"
                    }],
                    ["TC", {
                        currency: "USD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-TC"
                    }],
                    ["UG", {
                        currency: "UGX",
                        orientation: "ltr",
                        symbol: "USh",
                        locale: "sw-UG"
                    }],
                    ["UA", {
                        currency: "UAH",
                        orientation: "ltr",
                        symbol: "₴",
                        locale: "uk-UA"
                    }],
                    ["AE", {
                        currency: "AED",
                        orientation: "rtl",
                        symbol: "د.إ",
                        locale: "ar-AE"
                    }],
                    ["GB", {
                        currency: "GBP",
                        orientation: "ltr",
                        symbol: "\xa3",
                        locale: "en-GB"
                    }],
                    ["US", {
                        currency: "USD",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-US"
                    }],
                    ["UY", {
                        currency: "UYU",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "es-UY"
                    }],
                    ["UZ", {
                        currency: "UZS",
                        orientation: "ltr",
                        symbol: "soʻm",
                        locale: "uz-Latn-UZ"
                    }],
                    ["VU", {
                        currency: "VUV",
                        orientation: "ltr",
                        symbol: "Vt",
                        locale: "bi-VU"
                    }],
                    ["VN", {
                        currency: "VND",
                        orientation: "ltr",
                        symbol: "₫",
                        locale: "vi-VN"
                    }],
                    ["YE", {
                        currency: "YER",
                        orientation: "rtl",
                        symbol: "﷼",
                        locale: "ar-YE"
                    }],
                    ["ZM", {
                        currency: "ZMW",
                        orientation: "ltr",
                        symbol: "ZK",
                        locale: "en-ZM"
                    }],
                    ["ZW", {
                        currency: "ZWL",
                        orientation: "ltr",
                        symbol: "$",
                        locale: "en-ZW"
                    }]
                ]),
                i = function(a, n, e, l, r) {
                    var o, i, m, t, c, s, u;
                    return void 0 === r && (r = !1), i = n, m = e, t = l, o = r ? Math.abs(a) : a, i = isNaN(i = Math.abs(i)) ? 2 : i, m = void 0 == m ? "." : m, t = void 0 == t ? "," : t, (u = (o < 0 ? "-" : "") + ((s = (s = (c = String(parseInt(o = Math.abs(Number(o) || 0).toFixed(i)))).length) > 3 ? s % 3 : 0) ? c.substr(0, s) + t : "") + c.substr(s).replace(/(\d{3})(?=\d)/g, "$1" + t) + (i ? m + Math.abs(o - c).toFixed(i).slice(2) : ""))[u.length - 1] === m && (u = u.substr(0, u.length - 1)), u
                },
                m = function(a, n, e, o, m, t, c, s) {
                    void 0 === s && (s = {
                        forceDecimal: void 0
                    });
                    var u, d = n || "USD";
                    l[d] || (d = "USD");
                    var y = "none" === n ? "" : l[d][c ? "symbol" : "symbol_native"];
                    u = s.forceDecimal || 0 === s.forceDecimal ? s.forceDecimal : t ? 0 : l[d].decimal_digits;
                    var b = e || "en";
                    b = b.substring(0, 2);
                    var g = o ? "c_" + o.toString() : b;
                    r[g] || (g = "c_1");
                    var _ = r[g],
                        p = i(parseFloat(a), u, _.decimal, _.group, !0),
                        D = (p = (p = _.format.replace("###", p)).replace("$$", y)).split(_.decimal),
                        $ = r[g],
                        v = $.format.startsWith("$$");
                    return {
                        currencySplit: D,
                        currencySplitFormatedArr: $.format.replace("###", "|###|").replace("$$", "|$$$$|").split("|").filter(function(a) {
                            return "" !== a
                        }).map(function(n) {
                            if ("###" === n) {
                                var e = i(parseFloat(a), u, $.decimal, $.group, !0).split(_.decimal);
                                return e.length > 0 && (e[0] = {
                                    type: "int",
                                    val: e[0]
                                }), e.length > 1 && (e.push({
                                    type: "decimal",
                                    val: e[1]
                                }), e[1] = {
                                    type: "decimalSeperator",
                                    val: _.decimal
                                }), v || (e = [{
                                    type: "negative",
                                    val: a < 0 ? "-" : ""
                                }].concat(e)), e
                            }
                            return "$$" !== n ? [{
                                type: "text",
                                val: n
                            }] : v ? [{
                                type: "negative",
                                val: a < 0 ? "-" : ""
                            }, {
                                type: "symbol",
                                val: y
                            }] : [{
                                type: "symbol",
                                val: y
                            }]
                        }).reduce(function(a, n) {
                            return a.concat(n)
                        }),
                        format: _,
                        str: (a < 0 ? "-" : "") + p,
                        symbol: y
                    }
                },
                t = function(a, n, e, l, r, o, i, t) {
                    return void 0 === t && (t = {
                        forceDecimal: void 0
                    }), m(a, n, e, l, r, o, i, t).str
                },
                c = function(a) {
                    return o.get(a || "US")
                },
                s = function(a, n, e, l) {
                    var r = void 0 === l ? {} : l,
                        o = r.maximumFractionDigits,
                        i = r.minimumFractionDigits;
                    return new Intl.NumberFormat(n, {
                        style: "currency",
                        currency: e,
                        numberingSystem: "latn",
                        minimumFractionDigits: null != i ? i : 0,
                        maximumFractionDigits: Math.max(null != i ? i : 0, null != o ? o : a % 1 == 0 ? 0 : 2)
                    })
                },
                u = function(a, n) {
                    var e = a.split(n),
                        l = parseFloat(e[0].replace(/\D/g, "") + "." + e[1]);
                    return isNaN(l) ? 0 : l
                },
                d = function(a, n) {
                    var e, l = c(a),
                        r = l.locale,
                        o = l.currency,
                        i = (n || s(1.1, r, o)).formatToParts(1.1).find(function(a) {
                            return "decimal" === a.type
                        });
                    return null != (e = null == i ? void 0 : i.value) ? e : "."
                },
                y = {
                    currencyFormat: t,
                    formatMoney: i,
                    getSafe: function(a) {
                        try {
                            return a()
                        } catch (a) {
                            return
                        }
                    },
                    FormatCurrency: function(a, n, e, l, r) {
                        return void 0 === r && (r = {
                            forceDecimal: void 0
                        }), t(a, n, e, l, void 0, void 0, void 0, r)
                    },
                    FormatCurrencyInPdf: function(a, n, e, l) {
                        return t(a, n, e, l, !0)
                    },
                    FormatCurrencyDetails: m,
                    roundNumber: function(a, n) {
                        var e = Math.pow(10, n);
                        return Math.round((a + Number.EPSILON) * e) / e
                    },
                    FormatCurrencyNumber: function(a, n) {
                        var e = n || "USD";
                        l[e] || (e = "USD");
                        var r = l[e].decimal_digits;
                        return parseInt(Math.round(a * Math.pow(10, r))) / Math.pow(10, r)
                    },
                    isValidEmail: function(a) {
                        return !!a && /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@(?:(?:[a-zA-Z0-9-]+\.)+[a-zA-Z0-9-]+|\[IPv6:[A-Fa-f0-9:]+\]|\[[0-9]{1,3}(\.[0-9]{1,3}){3}\])$/.test(a)
                    },
                    formatCurrencyForApp: function(a, n, e) {
                        var l = void 0 === e ? {} : e,
                            r = l.maximumFractionDigits,
                            o = l.minimumFractionDigits,
                            i = c(n),
                            m = i.currency;
                        return s(a, i.locale, m, {
                            maximumFractionDigits: r,
                            minimumFractionDigits: o
                        }).format(a)
                    },
                    getDecimalSymbol: d,
                    getDefaultCurrency: c,
                    getFormattedCurrencyParts: function(a, n, e, l) {
                        var r = c(n),
                            o = r.locale,
                            i = r.currency,
                            m = r.symbol,
                            t = r.orientation,
                            y = d(n, l),
                            b = "string" == typeof a ? u(a, y) : a;
                        return {
                            amount: (l || s(b, o, i, e)).formatToParts(b).filter(function(a) {
                                return !["currency", "literal"].includes(a.type)
                            }).map(function(a) {
                                return a.value
                            }).join(""),
                            currency: m,
                            orientation: t
                        }
                    },
                    parseCurrencyString: u,
                    formatterBuilder: s
                }
        }
    }
]);