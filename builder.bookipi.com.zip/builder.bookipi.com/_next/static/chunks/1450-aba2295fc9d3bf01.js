"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1450], {
        6987: function(n, e, t) {
            t.d(e, {
                F: function() {
                    return l
                }
            });
            var s = t(2066),
                i = t(2846),
                o = t(4426);

            function r() {
                let n = (0, s._)(["\n  query Query($siteUrl: String!) {\n    checkDraftDuplicateSiteUrl(siteUrl: $siteUrl)\n  }\n"]);
                return r = function() {
                    return n
                }, n
            }
            let a = (0, o.Ps)(r()),
                u = null,
                l = async n => (null == u || u.abort(), u = new AbortController, (0, i.S)({
                    signal: u.signal
                }).request(a, {
                    siteUrl: n
                }))
        },
        9223: function(n, e, t) {
            t.d(e, {
                D: function() {
                    return u
                }
            });
            var s = t(2066),
                i = t(2846),
                o = t(4426);

            function r() {
                let n = (0, s._)(["\n  query Query {\n    loadWebPageDraft {\n      contactMenu {\n        title\n        description\n        requiredPhoneNumber\n        requiredYourMessage\n        showPhoneNumber\n        showYourMessage\n      }\n      ctaMenu {\n        button {\n          isEnable\n          link\n          placeholder\n          text\n          type\n        }\n        description\n        heading\n        showCta\n        subheading\n      }\n      customMenu {\n        businessName\n        customCode\n        googleAnalytics4\n        googleTagManager\n        siteUrl\n      }\n      faqMenu {\n        questions {\n          answer\n          isEnable\n          question\n        }\n        showFaq\n      }\n      headerMenu {\n        logo\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n        phoneNumber {\n          isEnable\n          phoneNumber\n        }\n        siteName\n        socialIcons {\n          icons {\n            iconName\n            iconSrc\n            linkSrc\n            provider\n          }\n          isEnable\n        }\n      }\n      introMenu {\n        heading\n        imageDescription\n        imageSrc {\n          small\n          regular\n          downloadLocation\n          userHtml\n          username\n        }\n        subheading\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n      }\n      locationMenu {\n        address\n        heading\n        showLocation\n        showSubheading\n        subheading\n        lat\n        lng\n      }\n      quoteMenu {\n        quotos {\n          imageDescription\n          label\n          name\n          profileImageSrc {\n            thumb\n            downloadLocation\n            userHtml\n            username\n          }\n          showFiveStarRating\n          showQuote\n          text\n        }\n      }\n      serviceMenu {\n        services {\n          heading\n          imageDescription\n          description\n          imageSrc {\n            small\n            regular\n            downloadLocation\n            userHtml\n            username\n          }\n          button {\n            isEnable\n            text\n            link\n            type\n          }\n        }\n      }\n      webSiteMenu {\n        faviconSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        logoSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        seoDescription\n        seoTitle\n        siteName\n        showFooterLink\n        socialImageSrc {\n          small\n          downloadLocation\n          userHtml\n          username\n        }\n      }\n    }\n  }\n"]);
                return r = function() {
                    return n
                }, n
            }
            let a = (0, o.Ps)(r()),
                u = async () => (0, i.S)().request(a)
        },
        4868: function(n, e, t) {
            t.d(e, {
                A: function() {
                    return i
                }
            });
            var s = t(5689);

            function i(n) {
                let {
                    children: e,
                    isOpen: t,
                    isToggling: i,
                    closeModal: o
                } = n;
                return (0, s.jsxs)("div", {
                    className: "fixed left-0 top-0 z-modal flex h-full w-screen items-center justify-center",
                    style: {
                        visibility: t ? "visible" : "hidden"
                    },
                    children: [(0, s.jsx)("div", {
                        className: "fixed inset-0 z-20 h-full w-full overflow-y-auto bg-gray-600 bg-opacity-50",
                        onClick: o,
                        style: {
                            opacity: i ? 0 : .8
                        }
                    }), e]
                })
            }
        },
        9239: function(n, e, t) {
            t.d(e, {
                J1: function() {
                    return a
                },
                Pw: function() {
                    return o
                },
                RZ: function() {
                    return s
                },
                eK: function() {
                    return r
                },
                hi: function() {
                    return i
                }
            });
            let s = {
                    FAILED_TO_COPY_LINK: "Failed to copy link, please try again",
                    FAILED_TO_PUBLISH_WEBSITE: "Failed to publish website, please try again",
                    PAGE_REG: "Failed to regenerate page, please try again",
                    PAGE_UNP: "Failed to unpublish website, please try again",
                    FAILED_TO_FETCH_ENTRI_TOKEN: "Failed to fetch Entri token"
                },
                i = {
                    CONTACT_FORM_SUBMIT_IN_PREVIEW: "This feature is not active in preview. Please test in your published URL",
                    FIX_ERRORS_IN_MENU: "Please fix errors in the menu"
                },
                o = {
                    PAGE_REG: "Page regenerated",
                    PAGE_UNP: "Website unpublished",
                    LINK_COPIED: "Link copied"
                },
                r = {
                    EMPTY: "URL field cannot be empty",
                    VALID: "",
                    INVALID_VALUE: "Your Site URL can only include alphanumeric characters (abc123) and hyphens (-)",
                    DUPLICATE: "Duplicate URL"
                },
                a = {
                    MESSAGES: {
                        PROPOSAL_REG: "Are you sure you want to regenerate this proposal?",
                        PAGE_REG: "Are you sure you want to regenerate this page?",
                        PAGE_UNP: "Are you sure you want to unpublish this page?",
                        CONTACT_FORM_DELETE: "Are you sure you want to delete this?"
                    },
                    CONFIRM_TEXT: "Yes, I am sure",
                    CANCEL_TEXT: "No, cancel"
                }
        },
        7637: function(n, e, t) {
            t.r(e), t.d(e, {
                BusinessInfoContext: function() {
                    return b
                },
                BusinessInfoProvider: function() {
                    return w
                },
                INITIAL_BUSINESS_INFO: function() {
                    return f
                },
                useBusinessInfo: function() {
                    return S
                }
            });
            var s = t(5689),
                i = t(2066),
                o = t(2846),
                r = t(4426);

            function a() {
                let n = (0, i._)(["\n  query Query {\n    getBusiness {\n      _id\n      businessName\n      businessDescription\n      domain\n      domainStatus\n      location {\n        country\n        city\n        lat\n        lon\n      }\n      isPublished\n    }\n  }\n"]);
                return a = function() {
                    return n
                }, n
            }
            let u = (0, r.Ps)(a()),
                l = async () => {
                    let n = await (0, o.S)().request(u);
                    return n.getBusiness
                };
            var c = t(8159),
                d = t(7105),
                g = t(5041),
                m = t(3130),
                h = t(983),
                p = t(2386);
            let f = {
                    id: "",
                    businessName: "",
                    businessDescription: "",
                    city: "",
                    country: "",
                    location: {
                        lat: 0,
                        lng: 0
                    },
                    isPublished: !1,
                    domain: "",
                    domainStatus: c.Fu.PENDING
                },
                b = (0, p.createContext)({
                    setBusinessInfo: n => {},
                    businessInfo: f,
                    isReady: !1,
                    isDomainConnected: !1,
                    publishedModalProps: {
                        isOpen: !1,
                        isToggling: !1,
                        toggle: () => {},
                        close: () => {}
                    },
                    customDomainModalProps: {
                        isOpen: !1,
                        isToggling: !1,
                        toggle: () => {},
                        close: () => {}
                    }
                });

            function w(n) {
                let {
                    children: e
                } = n;
                ! function() {
                    let n = (0, g.useRouter)(),
                        e = (0, g.useSearchParams)(),
                        t = e.get("token"),
                        s = sessionStorage.getItem("token");
                    if (t) {
                        sessionStorage.setItem("token", t);
                        return
                    }
                    s || n.push("https://web.bookipi.com/")
                }();
                let [t, i] = (0, p.useState)(f), [o, r] = (0, p.useState)(!1), a = (0, h.usePopup)({
                    defaultOpen: !1,
                    duration: 100
                }), u = (0, h.usePopup)({
                    defaultOpen: !1,
                    duration: 100
                }), c = !!t.domain && ["success", "pending"].includes(t.domainStatus);
                return (0, d.q)(async () => {
                    try {
                        let n = await l();
                        i({
                            id: n._id,
                            businessName: n.businessName || "",
                            businessDescription: n.businessDescription || "",
                            city: n.location.city || "",
                            country: n.location.country || "",
                            location: {
                                lng: n.location.lon || 0,
                                lat: n.location.lat || 0
                            },
                            isPublished: n.isPublished || !1,
                            domain: n.domain || "",
                            domainStatus: n.domainStatus || "pending"
                        })
                    } catch (n) {
                        (0, m.Y)(n)
                    }
                    r(!0)
                }), (0, s.jsx)(b.Provider, {
                    value: {
                        setBusinessInfo: i,
                        businessInfo: t,
                        isReady: o,
                        isDomainConnected: c,
                        publishedModalProps: a,
                        customDomainModalProps: u
                    },
                    children: e
                })
            }
            let S = () => (0, p.useContext)(b)
        },
        5324: function(n, e, t) {
            t.r(e), t.d(e, {
                DraftPageContext: function() {
                    return S
                },
                DraftPageContextProvider: function() {
                    return x
                },
                REQUIRED_DASHBOARD_FIELDS: function() {
                    return N
                },
                useDraftPage: function() {
                    return y
                }
            });
            var s = t(5689),
                i = t(2386),
                o = t(8159),
                r = t(9223),
                a = t(2066),
                u = t(4426),
                l = t(2846);

            function c() {
                let n = (0, a._)(["\n  query Query(\n    $businessName: String!\n    $businessLocation: String!\n    $businessDescription: String!\n  ) {\n    generatePage(\n      businessName: $businessName\n      businessLocation: $businessLocation\n      businessDescription: $businessDescription\n    ) {\n      webSiteMenu {\n        siteName\n        logoSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        faviconSrc {\n          thumb\n          downloadLocation\n          userHtml\n          username\n        }\n        seoTitle\n        seoDescription\n        socialImageSrc {\n          small\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        showFooterLink\n      }\n      introMenu {\n        heading\n        subheading\n        imageSrc {\n          regular\n          downloadLocation\n          userHtml\n          username\n        }\n        imageDescription\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n      }\n      serviceMenu {\n        services {\n          heading\n          imageDescription\n          description\n          imageSrc {\n            regular\n            downloadLocation\n            userHtml\n            username\n          }\n          button {\n            isEnable\n            text\n            link\n            type\n          }\n        }\n      }\n      quoteMenu {\n        quotos {\n          showQuote\n          text\n          name\n          label\n          imageDescription\n          profileImageSrc {\n            thumb\n            downloadLocation\n            userHtml\n            username\n          }\n          showFiveStarRating\n        }\n      }\n      faqMenu {\n        showFaq\n        questions {\n          answer\n          question\n        }\n      }\n      headerMenu {\n        logo\n        siteName\n        socialIcons {\n          icons {\n            iconName\n            iconSrc\n            linkSrc\n            provider\n          }\n          isEnable\n        }\n        button {\n          isEnable\n          text\n          link\n          type\n        }\n        phoneNumber {\n          isEnable\n          phoneNumber\n        }\n      }\n      ctaMenu {\n        heading\n        subheading\n        showCta\n        description\n        button {\n          isEnable\n          type\n          text\n          link\n        }\n      }\n      locationMenu {\n        showLocation\n        heading\n        showSubheading\n        subheading\n        address\n        lat\n        lng\n      }\n      customMenu {\n        siteUrl\n        googleAnalytics4\n        googleTagManager\n        customCode\n      }\n      contactMenu {\n        title\n        description\n        showPhoneNumber\n        showYourMessage\n        requiredPhoneNumber\n        requiredYourMessage\n      }\n    }\n  }\n"]);
                return c = function() {
                    return n
                }, n
            }
            let d = (0, u.Ps)(c()),
                g = async n => (0, l.S)().request(d, n);
            var m = t(6987),
                h = t(7105),
                p = t(5794),
                f = t(3130),
                b = t(5041),
                w = t(7637);
            let S = (0, i.createContext)({
                    pageContents: o.wL,
                    setPageContents: n => {},
                    loading: !0,
                    generating: !1,
                    setGenerating: n => {},
                    setLoading: n => {},
                    saveDraft: () => {},
                    generatePage: async (n, e) => o.wL,
                    setMenu: n => n => {},
                    hasChanges: !1
                }),
                N = [{
                    menuType: "webSiteMenu",
                    field: "siteName"
                }, {
                    menuType: "customMenu",
                    field: "siteUrl"
                }];

            function x(n) {
                let {
                    children: e
                } = n, [t, a] = (0, i.useState)(o.wL), [u, l] = (0, i.useState)(!0), [c, d] = (0, i.useState)(!1), [N, x] = (0, i.useState)(JSON.stringify(t)), y = (0, b.useSearchParams)(), E = (0, b.usePathname)(), v = (0, b.useRouter)(), I = y.get("type") || "aiwb", P = E.includes("proposal") || I.includes("proposal"), {
                    businessInfo: {
                        isPublished: D
                    }
                } = (0, w.useBusinessInfo)(), _ = async (n, e) => {
                    d(!0);
                    let {
                        generatePage: t
                    } = await g(n), {
                        customMenu: s,
                        locationMenu: i
                    } = t, o = (0, p.Ew)(s.siteUrl), r = await (0, m.F)(o);
                    s.siteUrl = r.checkDraftDuplicateSiteUrl ? "".concat(o, "-").concat(Date.now()) : o;
                    let u = { ...t,
                        locationMenu: { ...i,
                            ...e,
                            address: n.businessLocation
                        }
                    };
                    return a(u), u
                };
                (0, h.q)(async () => {
                    try {
                        let {
                            loadWebPageDraft: n
                        } = await (0, r.D)();
                        n || D || v.push("/about"), a(n), x(JSON.stringify(n))
                    } catch (n) {
                        (0, f.Y)(n)
                    }
                    l(!1)
                });
                let C = N !== JSON.stringify(t);
                return (0, i.useEffect)(() => {
                    if (!P && !u && C) return window.onbeforeunload = n => {
                        n.preventDefault(), n.returnValue = !0
                    }, () => {
                        window.onbeforeunload = null
                    }
                }, [u, C, P]), (0, s.jsx)(S.Provider, {
                    value: {
                        pageContents: t,
                        setPageContents: a,
                        setMenu: n => e => {
                            a(t => ({ ...t,
                                [n]: { ...t[n],
                                    ...e(t[n])
                                }
                            }))
                        },
                        loading: u,
                        generating: c,
                        setGenerating: d,
                        setLoading: l,
                        saveDraft: () => {
                            x(JSON.stringify(t))
                        },
                        generatePage: _,
                        hasChanges: C
                    },
                    children: e
                })
            }
            let y = () => (0, i.useContext)(S)
        },
        1703: function(n, e, t) {
            t.r(e), t.d(e, {
                ToastContext: function() {
                    return c
                },
                ToastContextProvider: function() {
                    return g
                },
                useToastContext: function() {
                    return m
                }
            });
            var s = t(5689),
                i = t(2386),
                o = t(7305),
                r = t(4279),
                a = t(1123);
            let u = {
                [o.Ix.SUCCESS]: (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, s.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M16.707 5.29279C16.8945 5.48031 16.9998 5.73462 16.9998 5.99979C16.9998 6.26495 16.8945 6.51926 16.707 6.70679L8.70698 14.7068C8.51945 14.8943 8.26514 14.9996 7.99998 14.9996C7.73482 14.9996 7.48051 14.8943 7.29298 14.7068L3.29298 10.7068C3.11082 10.5182 3.01003 10.2656 3.01231 10.0034C3.01458 9.74119 3.11975 9.49038 3.30516 9.30497C3.49057 9.11956 3.74138 9.01439 4.00358 9.01211C4.26578 9.00983 4.51838 9.11063 4.70698 9.29279L7.99998 12.5858L15.293 5.29279C15.4805 5.10532 15.7348 5 16 5C16.2651 5 16.5195 5.10532 16.707 5.29279Z"
                        })
                    }), (0, s.jsx)("span", {
                        className: "sr-only",
                        children: "Success icon"
                    })]
                }),
                [o.Ix.WARNING]: (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, s.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM10 15a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm1-4a1 1 0 0 1-2 0V6a1 1 0 0 1 2 0v5Z"
                        })
                    }), (0, s.jsx)("span", {
                        className: "sr-only",
                        children: "Warning icon"
                    })]
                }),
                [o.Ix.DANGER]: (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, s.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 11.793a1 1 0 1 1-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 0 1-1.414-1.414L8.586 10 6.293 7.707a1 1 0 0 1 1.414-1.414L10 8.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 10l2.293 2.293Z"
                        })
                    }), (0, s.jsx)("span", {
                        className: "sr-only",
                        children: "Error icon"
                    })]
                })
            };

            function l(n) {
                let {
                    status: e,
                    message: t,
                    closeToast: i
                } = n;
                return (0, s.jsxs)(a.FN, {
                    className: "pointer-events-auto mt-2 min-w-[300px] max-w-md items-center pr-2",
                    children: [(0, s.jsx)("div", {
                        className: (0, r.Z)("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", {
                            "bg-red-100 text-red-500 dark:bg-red-800 dark:text-red-200": e === o.Ix.DANGER,
                            "bg-orange-100 text-orange-500 dark:bg-orange-700 dark:text-orange-200": e === o.Ix.WARNING,
                            "bg-primary-100 text-primary-500 dark:bg-primary-700 dark:text-primary-200": e === o.Ix.SUCCESS
                        }),
                        children: e in u && u[e]
                    }), (0, s.jsx)("div", {
                        className: "mx-3 flex-grow text-sm font-normal",
                        children: t
                    }), (0, s.jsx)(a.FN.Toggle, {
                        onClick: i,
                        className: "flex items-center justify-center p-0 [&_svg]:h-[18px] [&_svg]:w-[18px]"
                    })]
                })
            }
            let c = (0, i.createContext)({
                    toast: [],
                    showToast: (n, e) => {}
                }),
                d = () => {
                    let n = Date.now(),
                        e = Math.random().toString(36).substring(7);
                    return [e, n].join("-")
                },
                g = n => {
                    let {
                        children: e
                    } = n, [t, o] = (0, i.useState)([]);
                    return (0, s.jsxs)(c.Provider, {
                        value: {
                            toast: t,
                            showToast: (n, e) => {
                                let t = d(),
                                    s = () => {
                                        o(n => n.filter(n => n.id !== t)), clearTimeout(i)
                                    },
                                    i = setTimeout(s, 3e3),
                                    r = {
                                        id: t,
                                        message: n,
                                        status: e,
                                        clear: s
                                    };
                                o(n => [...n, r])
                            }
                        },
                        children: [e, (0, s.jsx)("div", {
                            role: "alert",
                            className: "pointer-events-none fixed left-0 top-0 z-50 flex h-full w-full justify-center",
                            children: (0, s.jsx)("div", {
                                className: "mt-14",
                                children: t.map(n => (0, s.jsx)(l, {
                                    message: n.message,
                                    status: n.status,
                                    closeToast: n.clear
                                }, n.id))
                            })
                        })]
                    })
                },
                m = () => (0, i.useContext)(c)
        },
        6612: function(n, e, t) {
            t.d(e, {
                i: function() {
                    return l
                }
            });
            var s = t(5794),
                i = t(8053),
                o = t(5041),
                r = t(2386),
                a = t(2808);
            let u = n => n ? "app" : (0, s.gA)() ? "mobile" : "web";

            function l() {
                let n = (0, a.U)(),
                    [e] = (0, r.useState)(() => u(n)),
                    t = (0, o.usePathname)(),
                    s = t.includes("proposal"),
                    l = s ? "Proposal" : "Web Builder";
                return {
                    trackAction: function(n) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            s = {
                                platform: e,
                                ...t
                            };
                        (0, i.j)("".concat(l, " ").concat(n), s)
                    },
                    trackEvent: function(n) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            s = {
                                platform: e,
                                ...t
                            };
                        (0, i.j)(n, s)
                    }
                }
            }
        },
        2808: function(n, e, t) {
            t.d(e, {
                U: function() {
                    return r
                }
            });
            var s = t(5041),
                i = t(2386);
            let o = n => {
                if (n.has("is_from_app")) {
                    let e = "true" == n.get("is_from_app");
                    return sessionStorage.setItem("is_from_app", String(Number(e))), e
                }
                return "1" == sessionStorage.getItem("is_from_app")
            };

            function r() {
                let n = (0, s.useSearchParams)(),
                    [e] = (0, i.useState)(() => o(n));
                return e
            }
        },
        2846: function(n, e, t) {
            t.d(e, {
                S: function() {
                    return o
                },
                Z: function() {
                    return i
                }
            });
            var s = t(4426);
            let i = "https://builder.bookipi.com/graphql",
                o = function() {
                    let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = sessionStorage.getItem("token"),
                        t = new s.g6(i, {
                            headers: {
                                "Apollo-Require-Preflight": "true",
                                authorization: "Bearer ".concat(e)
                            },
                            ...n
                        });
                    return t
                }
        },
        7305: function(n, e, t) {
            var s, i, o, r;
            t.d(e, {
                Ix: function() {
                    return s
                }
            }), t(2386), (o = s || (s = {})).SUCCESS = "success", o.WARNING = "warning", o.DANGER = "danger", (r = i || (i = {})).REGENERATE = "regenerate", r.PUBLISH = "publish", r.UNPUBLISH = "unpublish"
        },
        3130: function(n, e, t) {
            t.d(e, {
                Y: function() {
                    return i
                }
            });
            let s = {
                    UNAUTHORIZED: 401,
                    FORBIDDEN: 403,
                    NOT_FOUND: 404,
                    INTERNAL_SERVER_ERROR: 500,
                    ABORTED: 20
                },
                i = n => {
                    if (!("code" in n) || n.code !== s.ABORTED) {
                        if ("response" in n) {
                            let {
                                errors: i
                            } = null == n ? void 0 : n.response;
                            if (i && i.length) {
                                var e, t;
                                let n = null == i ? void 0 : null === (e = i[0]) || void 0 === e ? void 0 : null === (t = e.extensions) || void 0 === t ? void 0 : t.originalError;
                                if ((null == n ? void 0 : n.statusCode) === s.UNAUTHORIZED) {
                                    location.href = "https://web.bookipi.com/";
                                    return
                                }
                            }
                        }
                        console.error(n)
                    }
                }
        }
    }
]);