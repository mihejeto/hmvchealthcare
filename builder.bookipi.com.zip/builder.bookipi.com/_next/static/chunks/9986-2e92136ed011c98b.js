"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9986], {
        3532: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var r = n(5689),
                s = n(4279);

            function i(e) {
                let {
                    type: t = "button",
                    textTransform: n = "capitalize",
                    outline: i = !1,
                    text: o,
                    buttonSize: a,
                    iconStyle: l,
                    iconDirection: u = "left",
                    disabled: c = !1,
                    className: d,
                    onClick: m,
                    href: p = "#",
                    as: g = "button"
                } = e;
                return (0, r.jsxs)(g, {
                    href: p,
                    type: t,
                    onClick: m,
                    disabled: c,
                    target: "_blank",
                    className: (0, s.Z)("inline-flex w-full items-center justify-center rounded-lg text-center focus:outline-none focus:ring-4 focus:ring-primary-300 disabled:bg-gray-100 disabled:text-gray-300 dark:bg-primary-600 \n        dark:hover:bg-primary-700 dark:focus:ring-primary-800", i ? "border border-blue-700 text-blue-700 hover:border-primary-300 focus:ring-4 focus:ring-primary-300 dark:border-primary-600 dark:text-primary-600 dark:hover:border-primary-700 dark:hover:text-primary-700 dark:focus:ring-primary-800" : "bg-blue-700 text-white hover:bg-primary-700 focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800", d, n, {
                        "px-3 py-2 text-sm font-medium": "xs" === a || "sm" === a,
                        "px-[20px] py-[10px] text-sm font-medium": "base" === a,
                        "px-5 py-3 text-base font-medium sm:py-3.5": "l" === a,
                        "px-6 py-[14px] text-base font-medium": "xl" === a
                    }),
                    children: [u && l && "left" === u && l, o, u && l && "right" === u && l]
                })
            }
        },
        4886: function(e, t, n) {
            var r = n(5689),
                s = n(4279),
                i = n(2386),
                o = n(1646);
            let a = (0, i.forwardRef)((e, t) => {
                let {
                    id: n,
                    iconStyle: i,
                    label: a,
                    labelHidden: l = !0,
                    size: u = "regular",
                    helperText: c,
                    tooltipContent: d,
                    className: m = "",
                    ...p
                } = e;
                return (0, r.jsxs)("div", {
                    children: [(0, r.jsxs)("label", {
                        htmlFor: n,
                        className: (0, s.Z)({
                            "sr-only": l,
                            asterisk: !!p.required
                        }, d ? "inline-flex items-center" : "flex", "mb-2 gap-2"),
                        children: [(0, r.jsx)("span", {
                            className: "text-sm font-medium text-gray-900 dark:text-white",
                            children: a
                        }), d && (0, r.jsx)(o.u, {
                            content: d,
                            children: (0, r.jsx)("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "0.875em",
                                viewBox: "0 0 512 512",
                                children: (0, r.jsx)("path", {
                                    d: "M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336h24V272H216c-13.3 0-24-10.7-24-24s10.7-24 24-24h48c13.3 0 24 10.7 24 24v88h8c13.3 0 24 10.7 24 24s-10.7 24-24 24H216c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
                                })
                            })
                        })]
                    }), (0, r.jsxs)("div", {
                        className: "relative",
                        children: [i && (0, r.jsx)("div", {
                            className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4",
                            children: i
                        }), (0, r.jsx)("input", {
                            ref: t,
                            name: n,
                            style: { ...i && {
                                    paddingLeft: "46px"
                                }
                            },
                            className: (0, s.Z)({
                                "p-2.5 text-sm font-normal": "regular" === u,
                                "px-4 py-[14px] text-base font-normal": "large" === u,
                                "cursor-not-allowed": !!(p.disabled || p.readOnly)
                            }, "inline-block w-full rounded-lg border border-gray-300 bg-gray-50 text-gray-900 focus:border-blue-500 focus:ring-blue-500   dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500", m),
                            ...p
                        })]
                    }), c && (0, r.jsx)("p", {
                        id: "standard_error_help",
                        className: "mt-2 text-xs text-red-600 dark:text-red-400",
                        children: c
                    })]
                })
            });
            a.displayName = "Input", t.Z = a
        },
        1646: function(e, t, n) {
            n.d(t, {
                u: function() {
                    return o
                }
            });
            var r = n(5689),
                s = n(4279),
                i = n(1123);

            function o(e) {
                let {
                    children: t,
                    content: n = "Sample tooltip content",
                    className: o = "",
                    ...a
                } = e;
                return (0, r.jsx)(i.u, {
                    content: n,
                    className: (0, s.Z)(o, "z-50"),
                    ...a,
                    children: t
                })
            }
        },
        9311: function(e, t, n) {
            n.d(t, {
                J: function() {
                    return i
                }
            });
            var r = n(5689),
                s = n(4279);

            function i(e) {
                let {
                    children: t,
                    className: n
                } = e;
                return (0, r.jsx)("span", {
                    className: (0, s.Z)("inline-block rounded-full p-2", n),
                    children: t
                })
            }
        },
        7637: function(e, t, n) {
            n.r(t), n.d(t, {
                BusinessInfoContext: function() {
                    return h
                },
                BusinessInfoProvider: function() {
                    return b
                },
                INITIAL_BUSINESS_INFO: function() {
                    return x
                },
                useBusinessInfo: function() {
                    return v
                }
            });
            var r = n(5689),
                s = n(2066),
                i = n(2846),
                o = n(4426);

            function a() {
                let e = (0, s._)(["\n  query Query {\n    getBusiness {\n      _id\n      businessName\n      businessDescription\n      domain\n      domainStatus\n      location {\n        country\n        city\n        lat\n        lon\n      }\n      isPublished\n    }\n  }\n"]);
                return a = function() {
                    return e
                }, e
            }
            let l = (0, o.Ps)(a()),
                u = async () => {
                    let e = await (0, i.S)().request(l);
                    return e.getBusiness
                };
            var c = n(8159),
                d = n(7105),
                m = n(5041),
                p = n(3130),
                g = n(983),
                f = n(2386);
            let x = {
                    id: "",
                    businessName: "",
                    businessDescription: "",
                    city: "",
                    country: "",
                    location: {
                        lat: 0,
                        lng: 0
                    },
                    isPublished: !1,
                    domain: "",
                    domainStatus: c.Fu.PENDING
                },
                h = (0, f.createContext)({
                    setBusinessInfo: e => {},
                    businessInfo: x,
                    isReady: !1,
                    isDomainConnected: !1,
                    publishedModalProps: {
                        isOpen: !1,
                        isToggling: !1,
                        toggle: () => {},
                        close: () => {}
                    },
                    customDomainModalProps: {
                        isOpen: !1,
                        isToggling: !1,
                        toggle: () => {},
                        close: () => {}
                    }
                });

            function b(e) {
                let {
                    children: t
                } = e;
                ! function() {
                    let e = (0, m.useRouter)(),
                        t = (0, m.useSearchParams)(),
                        n = t.get("token"),
                        r = sessionStorage.getItem("token");
                    if (n) {
                        sessionStorage.setItem("token", n);
                        return
                    }
                    r || e.push("https://web.bookipi.com/")
                }();
                let [n, s] = (0, f.useState)(x), [i, o] = (0, f.useState)(!1), a = (0, g.usePopup)({
                    defaultOpen: !1,
                    duration: 100
                }), l = (0, g.usePopup)({
                    defaultOpen: !1,
                    duration: 100
                }), c = !!n.domain && ["success", "pending"].includes(n.domainStatus);
                return (0, d.q)(async () => {
                    try {
                        let e = await u();
                        s({
                            id: e._id,
                            businessName: e.businessName || "",
                            businessDescription: e.businessDescription || "",
                            city: e.location.city || "",
                            country: e.location.country || "",
                            location: {
                                lng: e.location.lon || 0,
                                lat: e.location.lat || 0
                            },
                            isPublished: e.isPublished || !1,
                            domain: e.domain || "",
                            domainStatus: e.domainStatus || "pending"
                        })
                    } catch (e) {
                        (0, p.Y)(e)
                    }
                    o(!0)
                }), (0, r.jsx)(h.Provider, {
                    value: {
                        setBusinessInfo: s,
                        businessInfo: n,
                        isReady: i,
                        isDomainConnected: c,
                        publishedModalProps: a,
                        customDomainModalProps: l
                    },
                    children: t
                })
            }
            let v = () => (0, f.useContext)(h)
        },
        1703: function(e, t, n) {
            n.r(t), n.d(t, {
                ToastContext: function() {
                    return c
                },
                ToastContextProvider: function() {
                    return m
                },
                useToastContext: function() {
                    return p
                }
            });
            var r = n(5689),
                s = n(2386),
                i = n(7305),
                o = n(4279),
                a = n(1123);
            let l = {
                [i.Ix.SUCCESS]: (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, r.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M16.707 5.29279C16.8945 5.48031 16.9998 5.73462 16.9998 5.99979C16.9998 6.26495 16.8945 6.51926 16.707 6.70679L8.70698 14.7068C8.51945 14.8943 8.26514 14.9996 7.99998 14.9996C7.73482 14.9996 7.48051 14.8943 7.29298 14.7068L3.29298 10.7068C3.11082 10.5182 3.01003 10.2656 3.01231 10.0034C3.01458 9.74119 3.11975 9.49038 3.30516 9.30497C3.49057 9.11956 3.74138 9.01439 4.00358 9.01211C4.26578 9.00983 4.51838 9.11063 4.70698 9.29279L7.99998 12.5858L15.293 5.29279C15.4805 5.10532 15.7348 5 16 5C16.2651 5 16.5195 5.10532 16.707 5.29279Z"
                        })
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Success icon"
                    })]
                }),
                [i.Ix.WARNING]: (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, r.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM10 15a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm1-4a1 1 0 0 1-2 0V6a1 1 0 0 1 2 0v5Z"
                        })
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Warning icon"
                    })]
                }),
                [i.Ix.DANGER]: (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("svg", {
                        className: "h-5 w-5",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 20 20",
                        children: (0, r.jsx)("path", {
                            d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 11.793a1 1 0 1 1-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 0 1-1.414-1.414L8.586 10 6.293 7.707a1 1 0 0 1 1.414-1.414L10 8.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 10l2.293 2.293Z"
                        })
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Error icon"
                    })]
                })
            };

            function u(e) {
                let {
                    status: t,
                    message: n,
                    closeToast: s
                } = e;
                return (0, r.jsxs)(a.FN, {
                    className: "pointer-events-auto mt-2 min-w-[300px] max-w-md items-center pr-2",
                    children: [(0, r.jsx)("div", {
                        className: (0, o.Z)("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", {
                            "bg-red-100 text-red-500 dark:bg-red-800 dark:text-red-200": t === i.Ix.DANGER,
                            "bg-orange-100 text-orange-500 dark:bg-orange-700 dark:text-orange-200": t === i.Ix.WARNING,
                            "bg-primary-100 text-primary-500 dark:bg-primary-700 dark:text-primary-200": t === i.Ix.SUCCESS
                        }),
                        children: t in l && l[t]
                    }), (0, r.jsx)("div", {
                        className: "mx-3 flex-grow text-sm font-normal",
                        children: n
                    }), (0, r.jsx)(a.FN.Toggle, {
                        onClick: s,
                        className: "flex items-center justify-center p-0 [&_svg]:h-[18px] [&_svg]:w-[18px]"
                    })]
                })
            }
            let c = (0, s.createContext)({
                    toast: [],
                    showToast: (e, t) => {}
                }),
                d = () => {
                    let e = Date.now(),
                        t = Math.random().toString(36).substring(7);
                    return [t, e].join("-")
                },
                m = e => {
                    let {
                        children: t
                    } = e, [n, i] = (0, s.useState)([]);
                    return (0, r.jsxs)(c.Provider, {
                        value: {
                            toast: n,
                            showToast: (e, t) => {
                                let n = d(),
                                    r = () => {
                                        i(e => e.filter(e => e.id !== n)), clearTimeout(s)
                                    },
                                    s = setTimeout(r, 3e3),
                                    o = {
                                        id: n,
                                        message: e,
                                        status: t,
                                        clear: r
                                    };
                                i(e => [...e, o])
                            }
                        },
                        children: [t, (0, r.jsx)("div", {
                            role: "alert",
                            className: "pointer-events-none fixed left-0 top-0 z-50 flex h-full w-full justify-center",
                            children: (0, r.jsx)("div", {
                                className: "mt-14",
                                children: n.map(e => (0, r.jsx)(u, {
                                    message: e.message,
                                    status: e.status,
                                    closeToast: e.clear
                                }, e.id))
                            })
                        })]
                    })
                },
                p = () => (0, s.useContext)(c)
        },
        6612: function(e, t, n) {
            n.d(t, {
                i: function() {
                    return u
                }
            });
            var r = n(5794),
                s = n(8053),
                i = n(5041),
                o = n(2386),
                a = n(2808);
            let l = e => e ? "app" : (0, r.gA)() ? "mobile" : "web";

            function u() {
                let e = (0, a.U)(),
                    [t] = (0, o.useState)(() => l(e)),
                    n = (0, i.usePathname)(),
                    r = n.includes("proposal"),
                    u = r ? "Proposal" : "Web Builder";
                return {
                    trackAction: function(e) {
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = {
                                platform: t,
                                ...n
                            };
                        (0, s.j)("".concat(u, " ").concat(e), r)
                    },
                    trackEvent: function(e) {
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                            r = {
                                platform: t,
                                ...n
                            };
                        (0, s.j)(e, r)
                    }
                }
            }
        },
        2808: function(e, t, n) {
            n.d(t, {
                U: function() {
                    return o
                }
            });
            var r = n(5041),
                s = n(2386);
            let i = e => {
                if (e.has("is_from_app")) {
                    let t = "true" == e.get("is_from_app");
                    return sessionStorage.setItem("is_from_app", String(Number(t))), t
                }
                return "1" == sessionStorage.getItem("is_from_app")
            };

            function o() {
                let e = (0, r.useSearchParams)(),
                    [t] = (0, s.useState)(() => i(e));
                return t
            }
        },
        2846: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return i
                },
                Z: function() {
                    return s
                }
            });
            var r = n(4426);
            let s = "https://builder.bookipi.com/graphql",
                i = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = sessionStorage.getItem("token"),
                        n = new r.g6(s, {
                            headers: {
                                "Apollo-Require-Preflight": "true",
                                authorization: "Bearer ".concat(t)
                            },
                            ...e
                        });
                    return n
                }
        },
        7305: function(e, t, n) {
            var r, s, i, o;
            n.d(t, {
                Ix: function() {
                    return r
                }
            }), n(2386), (i = r || (r = {})).SUCCESS = "success", i.WARNING = "warning", i.DANGER = "danger", (o = s || (s = {})).REGENERATE = "regenerate", o.PUBLISH = "publish", o.UNPUBLISH = "unpublish"
        },
        3130: function(e, t, n) {
            n.d(t, {
                Y: function() {
                    return s
                }
            });
            let r = {
                    UNAUTHORIZED: 401,
                    FORBIDDEN: 403,
                    NOT_FOUND: 404,
                    INTERNAL_SERVER_ERROR: 500,
                    ABORTED: 20
                },
                s = e => {
                    if (!("code" in e) || e.code !== r.ABORTED) {
                        if ("response" in e) {
                            let {
                                errors: s
                            } = null == e ? void 0 : e.response;
                            if (s && s.length) {
                                var t, n;
                                let e = null == s ? void 0 : null === (t = s[0]) || void 0 === t ? void 0 : null === (n = t.extensions) || void 0 === n ? void 0 : n.originalError;
                                if ((null == e ? void 0 : e.statusCode) === r.UNAUTHORIZED) {
                                    location.href = "https://web.bookipi.com/";
                                    return
                                }
                            }
                        }
                        console.error(e)
                    }
                }
        },
        6105: function(e, t) {
            t.Z = {
                src: "https://builder.bookipi.com/_next/static/media/arrow-left.3510ba8d.svg",
                height: 24,
                width: 24,
                blurWidth: 0,
                blurHeight: 0
            }
        },
        3056: function(e, t) {
            t.Z = {
                src: "https://builder.bookipi.com/_next/static/media/building.ca7f4229.svg",
                height: 28,
                width: 28,
                blurWidth: 0,
                blurHeight: 0
            }
        },
        4614: function(e, t) {
            t.Z = {
                src: "https://builder.bookipi.com/_next/static/media/close.6928f6bf.svg",
                height: 24,
                width: 24,
                blurWidth: 0,
                blurHeight: 0
            }
        }
    }
]);